﻿using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoConfiguracion.IRepository
{
    public interface IConfiguracion
    {       
        #region lexico
        Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTabla(string strTabla, OcCredenciales objCredenciales);

        Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTablaTema(string strTabla, string strTema, OcCredenciales objCredenciales);

        #endregion

        #region Errores

        Task<CrsApiResponse<ErrorRespuestaDto>> RegistrarError(ErrorRegistrarDto objErrorRegistrar, OcCredenciales objCredenciales);

        #endregion
    }
}
