﻿using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoConfiguracion.IRepository
{
    public interface IAutenticacion
    {
        Task<CrsApiResponse<AutenticacionRespuestaDto>> GenerarToken(AutenticacionConsultarDto loginDto);

        Task<CrsApiResponse<UsuarioRespRegistroDto>> RegistrarUsuarioServicio();

        bool ValidarCredenciales(string usuario, string contraseña);

        bool ValidarCredenciales(OcCredenciales ocCredenciales);
    }
}
