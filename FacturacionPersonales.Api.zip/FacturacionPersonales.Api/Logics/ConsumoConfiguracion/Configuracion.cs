﻿using AutoMapper;
using Common.Parameters;
using DevExpress.XtraRichEdit.Import.Html;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioTransaccional;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.Extensions.Configuration;
using Models.Dtos;
using Models.ModelCheck;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Logics.ServicioTransaccional.ServicioEnvioCorreoClass;

namespace Logics.ConsumoConfiguracion
{
    public class Configuracion : IConfiguracion
    {
        private readonly IMapper _mapper;     
        private readonly LexicoRepository _lexicoRepository;
        private readonly ErrorRepository _errorRepository;

        public Configuracion(
            IMapper mapper,
            IConfiguration configuration,            
            LexicoRepository lexicoRepository,
            ErrorRepository errorRepository
            )
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _lexicoRepository = lexicoRepository ?? throw new ArgumentNullException(nameof(lexicoRepository));
            _errorRepository = errorRepository ?? throw new ArgumentNullException(nameof(errorRepository));
        }

        #region Lexico
        public async Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTabla(string strTabla, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<LexicoDto>>();
            try
            {

                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _lexicoRepository.ObtenerListaLexicoPorTabla(strTabla);
                    var responseDto = _mapper.Map<List<LexicoDto>>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(responseDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<LexicoDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }
        

        public async Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTablaTema(string strTabla, string strTema, OcCredenciales objCredenciales)
        {
            CrsApiResponse<List<LexicoDto>> response = new CrsApiResponse<List<LexicoDto>>();
            try
            {
                
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _lexicoRepository.ObtenerListaLexicoPorTablaTema(strTabla, strTema);
                    var responseDto = _mapper.Map<List<LexicoDto>>(responseQuery);                    
                    return ApiResponseHelper.GetGenericResponse(responseDto);

                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<LexicoDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        #endregion

        #region Errores

        public async Task<CrsApiResponse<ErrorRespuestaDto>> RegistrarError(ErrorRegistrarDto objErrorRegistrar, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<ErrorRespuestaDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objError = _mapper.Map<ERROR>(objErrorRegistrar);
                    var responseQuery = _errorRepository.RegistrarError(objError, objCredenciales);

                    if (responseQuery != null)
                    {
                        var errorRespuestaDto = new ErrorRespuestaDto
                        {
                            registrado = responseQuery
                        };
                        return ApiResponseHelper.GetGenericResponse(errorRespuestaDto);
                    }
                    else
                    {
                        response.status = HttpStatusCode.InternalServerError;// "500";
                        response.errors = new List<ErrorDetail>
                        {
                            new ErrorDetail { errorMessage = "Error while registering error." }
                        };
                        return response;
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<ErrorRespuestaDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        #endregion
    }
}
