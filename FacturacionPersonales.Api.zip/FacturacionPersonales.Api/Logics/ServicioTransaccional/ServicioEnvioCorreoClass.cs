﻿using Agent;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Models.Dtos;
using Models.OcDtos;
using ServicioEnvioCorreo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;

//using System.Net.Mail;
//using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioTransaccional
{
    public class ServicioEnvioCorreoClass
    {        
        public ServicioEnvioCorreoClass()
        {
            // Constructor logic if needed
        }

        public void EnviarCorreo(OC_ENVIO_CORREO objCorreo, OcCredenciales objCredenciales, CrsApiResponse<EnviarCorreo> crsApiResponse)
        {
            //enviamos correo electronico y preparamos el ambiente para ello
            IServicioEnvioCorreo servicioEnvioCorreo = Localizador.ServicioEnvioCorreo();
            try
            {               
                //preparamos para el envio de correo
                var objCredencialesEnvioCorreo = new CREDENCIALES { USUARIO = objCredenciales.usuario, IP = objCredenciales.ip };

                //enviamosCorreo               
                var responseEnvioCorreo = servicioEnvioCorreo.EnviarCorreoPostImages(objCorreo, objCredencialesEnvioCorreo);
                if (!responseEnvioCorreo)
                {
                    crsApiResponse.hasError = true;
                    crsApiResponse.errors.Add(new ErrorDetail { methodName = "Enviar Correo", errorMessage = "No se ha podido enviar el correo electronico", propertyName = "Enviar Correo" });
                    crsApiResponse.status = HttpStatusCode.BadRequest;// "400";

                }
                else
                {
                    crsApiResponse.hasError = false;
                    crsApiResponse.result = new EnviarCorreo { enviado = true };
                    crsApiResponse.status = HttpStatusCode.OK;// "200";
                }
            }
            catch (Exception ex)
            {
                //Log.Error(ex);
                throw;
            }
            finally
            {
                Localizador.Close(servicioEnvioCorreo);
            }
        }



        //public bool EnviarCorreo(occ_correo objCorreo)
        //{
        //    try
        //    {
        //        var objMailMessage = new MailMessage();
        //        //objMailMessage.From = new MailAddress("bolcrsprod@crediseguro.com.bo", "Bolivia - Crediseguro Producción");
        //        //objMailMessage.From = new MailAddress("ProduccionSistemas@crediseguro.com.bo");
        //        //objMailMessage.Sender = new MailAddress("bolcrsprod@crediseguro.com.bo", "Bolivia - Crediseguro Producción");
        //        //objMailMessage.Bcc.Add("bolcrsprod@crediseguro.com.bo");
        //        ///Envio Correo Destinatarios  
        //        foreach (string strCorreo in objCorreo.ListaCorreoDestinatario)
        //            objMailMessage.To.Add(new MailAddress(strCorreo));
        //        ///Destinatarios con copia a:
        //        foreach (string strCorreo in objCorreo.ListaCorreoCopia)
        //            objMailMessage.CC.Add(new MailAddress(strCorreo));
        //        ///Files attachment -  lista de
        //        foreach (var objArchivoAdjunto in objCorreo.ListaArchivosAdjuntos)
        //        {
        //            if (objArchivoAdjunto.FlagBytes)
        //                objMailMessage.Attachments.Add(new Attachment(new MemoryStream(objArchivoAdjunto.Bytes), objArchivoAdjunto.Nombre));
        //            else
        //                objMailMessage.Attachments.Add(new Attachment(new MemoryStream(File.ReadAllBytes(objArchivoAdjunto.Ruta)), objArchivoAdjunto.Nombre));
        //        }
        //        objMailMessage.Subject = objCorreo.Asunto;
        //        AlternateView objAlternateView = AlternateView.CreateAlternateViewFromString(objCorreo.Contenido, Encoding.UTF8, MediaTypeNames.Text.Html);
        //        foreach (var objImagen in objCorreo.ListaImagenes)
        //        {
        //            LinkedResource objLinkedResource = new LinkedResource(new MemoryStream(objImagen.Bytes));
        //            objLinkedResource.ContentId = objImagen.ContentId;
        //            objAlternateView.LinkedResources.Add(objLinkedResource);
        //        }
        //        objMailMessage.AlternateViews.Add(objAlternateView);
        //        objMailMessage.IsBodyHtml = objCorreo.FlagHtml;
        //        objMailMessage.Body = objCorreo.Contenido;
        //        objMailMessage.Priority = objCorreo.Prioridad;
        //        //using (var objSmtpClient = new SmtpClient("172.31.5.24"))
        //        ////using (var objSmtpClient = new SmtpClient("btbrly00.bancred.com.bo"))
        //        //{
        //        //    objSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //        //    //objSmtpClient.Host = "btbrly00.bancred.com.bo";
        //        //    //objSmtpClient.Credentials = new NetworkCredential("bolcrsprod@crediseguro.com.bo", "Creditogenerico1.");
        //        //    objSmtpClient.Send(objMailMessage);
        //        //}
        //        using (var objSmtpClient = new SmtpClient())
        //        {
        //            objSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
        //            objSmtpClient.Host = "btbrly00.bancred.com.bo";
        //            objSmtpClient.Port = 25;
        //            objSmtpClient.UseDefaultCredentials = true; // This matches defaultCredentials="true"
        //                                                        // No need to set Credentials if using default credentials
        //            objMailMessage.From = new MailAddress("ProduccionSistemas@crediseguro.com.bo");
        //            objSmtpClient.Send(objMailMessage);
        //        }
        //        objMailMessage.Dispose();
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //}

        //public bool EnviarCorreo(occ_correo objCorreo)
        //{
        //    try
        //    {
        //        var message = new MimeMessage();

        //        // Remitente
        //        message.From.Add(new MailboxAddress("ProduccionSistemas", "ProduccionSistemas@crediseguro.com.bo"));

        //        // Destinatarios
        //        foreach (var strCorreo in objCorreo.ListaCorreoDestinatario)
        //            message.To.Add(MailboxAddress.Parse(strCorreo));

        //        // Copia
        //        foreach (var strCorreo in objCorreo.ListaCorreoCopia)
        //            message.Cc.Add(MailboxAddress.Parse(strCorreo));

        //        message.Subject = objCorreo.Asunto;

        //        // Construcción del cuerpo
        //        var builder = new BodyBuilder();

        //        //// Adjuntos
        //        //foreach (var objArchivoAdjunto in objCorreo.ListaArchivosAdjuntos)
        //        //{
        //        //    if (objArchivoAdjunto.FlagBytes)
        //        //        builder.Attachments.Add(objArchivoAdjunto.Nombre, objArchivoAdjunto.Bytes);
        //        //    else
        //        //        builder.Attachments.Add(objArchivoAdjunto.Nombre, File.ReadAllBytes(objArchivoAdjunto.Ruta));
        //        //}

        //        //// Imágenes embebidas
        //        //foreach (var objImagen in objCorreo.ListaImagenes)
        //        //{
        //        //    var image = builder.LinkedResources.Add(objImagen.ContentId, objImagen.Bytes);
        //        //    image.ContentId = objImagen.ContentId;
        //        //}

        //        // Cuerpo HTML o texto
        //        if (objCorreo.FlagHtml)
        //            builder.HtmlBody = objCorreo.Contenido;
        //        else
        //            builder.TextBody = objCorreo.Contenido;

        //        message.Body = builder.ToMessageBody();

        //        //// Prioridad
        //        //switch (objCorreo.Prioridad)
        //        //{
        //        //    case System.Net.Mail.MailPriority.High:
        //        //        message.Priority = MessagePriority.Urgent;
        //        //        message.Headers.Add("X-Priority", "1");
        //        //        break;
        //        //    case System.Net.Mail.MailPriority.Low:
        //        //        message.Priority = MessagePriority.NonUrgent;
        //        //        message.Headers.Add("X-Priority", "5");
        //        //        break;
        //        //    default:
        //        //        message.Priority = MessagePriority.Normal;
        //        //        message.Headers.Add("X-Priority", "3");
        //        //        break;
        //        //}

        //        // Envío
        //        using (var client = new SmtpClient())
        //        {
        //            client.Connect("btbrly00.bancred.com.bo", 25, SecureSocketOptions.Auto);
        //            client.AuthenticationMechanisms.Remove("XOAUTH2"); // Si no usas autenticación OAuth2
        //            client.Authenticate(null, null, null); // Si usas credenciales, ponlas aquí

        //            client.Send(message);
        //            client.Disconnect(true);
        //        }

        //        return true;
        //    }
        //    catch
        //    {
        //        throw;
        //    }
        //}

        public class occ_correo
        {
            public string Asunto { get; set; }
            public List<string> ListaCorreoDestinatario { get; set; }
            public List<string> ListaCorreoCopia { get; set; }
            public bool FlagHtml { get; set; }
            public string Contenido { get; set; }
            public List<occ_correo_archivo_adjunto> ListaArchivosAdjuntos { get; set; }
            public List<occ_correo_imagen> ListaImagenes { get; set; }
           // public MailPriority Prioridad { get; set; }
            public occ_correo()
            {
                this.ListaCorreoDestinatario = new List<string>();
                this.ListaCorreoCopia = new List<string>();
                this.ListaArchivosAdjuntos = new List<occ_correo_archivo_adjunto>();
                this.ListaImagenes = new List<occ_correo_imagen>();
            }
        }
        public class occ_correo_archivo_adjunto
        {
            public bool FlagBytes { get; set; }
            public byte[] Bytes { get; set; }
            public string Ruta { get; set; }
            public string Nombre { get; set; }
        }
        public class occ_correo_imagen
        {
            public string ContentId { get; set; }
            public byte[] Bytes { get; set; }
        }
    }
}
