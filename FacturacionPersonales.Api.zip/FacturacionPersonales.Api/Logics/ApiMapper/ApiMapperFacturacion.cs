﻿using AutoMapper;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperFacturacion : Profile
    {
        public ApiMapperFacturacion()
        {
            CreateMap<LOTE_FACTURAS, LoteDto>()
                .ForMember(dest => dest.idLote, opt => opt.MapFrom(src => src.LOPVC_ID_LOTE))
                .ForMember(dest => dest.nombreArchivo, opt => opt.MapFrom(src => src.LOPVC_NOMBRE_ARCHIVO))
                .ForMember(dest => dest.numeroFacturas, opt => opt.MapFrom(src => src.LOPIN_NUMERO_FACTURAS))
                .ForMember(dest => dest.fechaFacturaInicio, opt => opt.MapFrom(src => src.LOSDT_FECHA_FACTURA_INICIO))
                .ForMember(dest => dest.fechaFacturaFin, opt => opt.MapFrom(src => src.LOSDT_FECHA_FACTURA_FIN))
                .ForMember(dest => dest.fechaFacturacion, opt => opt.MapFrom(src => src.LOPDT_FECHA_FACTURACION))
                .ForMember(dest => dest.procesado, opt => opt.MapFrom(src => src.LOPBT_PROCESADO))
                .ForMember(dest => dest.idFechaInsert, opt => opt.MapFrom(src => src.LOPIN_ID_FECHA_INSERT))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.LOPDT_FECHA_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.LOPDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.LOPVC_ID_USER_INSERT))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.LOPVC_ID_USER_MODIF))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.LOPBT_ACTIVO));

            CreateMap<LoteDto, LOTE_FACTURAS>()
                .ForMember(dest => dest.LOPVC_ID_LOTE, opt => opt.MapFrom(src => src.idLote))
                .ForMember(dest => dest.LOPVC_NOMBRE_ARCHIVO, opt => opt.MapFrom(src => src.nombreArchivo))
                .ForMember(dest => dest.LOPIN_NUMERO_FACTURAS, opt => opt.MapFrom(src => src.numeroFacturas))
                .ForMember(dest => dest.LOSDT_FECHA_FACTURA_INICIO, opt => opt.MapFrom(src => src.fechaFacturaInicio))
                .ForMember(dest => dest.LOSDT_FECHA_FACTURA_FIN, opt => opt.MapFrom(src => src.fechaFacturaFin))
                .ForMember(dest => dest.LOPDT_FECHA_FACTURACION, opt => opt.MapFrom(src => src.fechaFacturacion))
                .ForMember(dest => dest.LOPBT_PROCESADO, opt => opt.MapFrom(src => src.procesado))
                .ForMember(dest => dest.LOPIN_ID_FECHA_INSERT, opt => opt.MapFrom(src => src.idFechaInsert))
                .ForMember(dest => dest.LOPDT_FECHA_INSERT, opt => opt.MapFrom(src => src.fechaInsert))
                .ForMember(dest => dest.LOPDT_FECHA_MODIF, opt => opt.MapFrom(src => src.fechaModif))
                .ForMember(dest => dest.LOPVC_ID_USER_INSERT, opt => opt.MapFrom(src => src.idUserInsert))
                .ForMember(dest => dest.LOPVC_ID_USER_MODIF, opt => opt.MapFrom(src => src.idUserModif))
                .ForMember(dest => dest.LOPBT_ACTIVO, opt => opt.MapFrom(src => src.activo));
        }
    }
}
