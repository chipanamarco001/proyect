﻿using AutoMapper;
using Common.Decrypt;
using ManageDB.SqlRepository;
using Models.DtosSp;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperAutenticacion : Profile
    {

        public ApiMapperAutenticacion()
        {
            // USUARIO <-> UsuarioDto
            CreateMap<USUARIO, UsuarioDto>()
                .ForMember(dest => dest.idUsuario, opt => opt.MapFrom(src => src.USPVC_ID_USUARIO))
                //.ForMember(dest => dest.apellidoPaterno, opt => opt.MapFrom(src => src.USSVC_APELLIDO_PATERNO))
                //.ForMember(dest => dest.apellidoMaterno, opt => opt.MapFrom(src => src.USSVC_APELLIDO_MATERNO))
                .ForMember(dest => dest.nombreCompleto, opt => opt.MapFrom(src => src.USPVC_NOMBRE_COMPLETO))
                .ForMember(dest => dest.correo, opt => opt.MapFrom(src => src.USPVC_CORREO))
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.USPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.USSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.USSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.USSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.USSVC_ID_USER_MODIF))
                .ReverseMap();

            CreateMap<UsuarioRegistroDto, USUARIO>()
               .ForMember(dest => dest.USPVC_ID_USUARIO, opt => opt.MapFrom(src => src.idUsuario))
               .ForMember(dest => dest.USPVC_TIPO, opt => opt.MapFrom(src => src.tipo))
               .ForMember(dest => dest.USPVC_NOMBRE_COMPLETO, opt => opt.MapFrom(src => src.nombreCompleto))
               .ForMember(dest => dest.USPVC_CORREO, opt => opt.MapFrom(src => src.correo))
               .ForMember(dest => dest.USPCH_ID_DEPARTAMENTO, opt => opt.MapFrom(src => src.departamento))
               .ForMember(dest => dest.USPBT_PASSWORD, opt => opt.MapFrom(src => Cryptography.Encrypt(src.password)))
               .ForMember(dest => dest.USPBT_PASSWORD_RESETEO, opt => opt.MapFrom(src => Cryptography.Encrypt(src.passwordReseteo)))
               .ForMember(dest => dest.ROPBI_ID_ROL, opt => opt.MapFrom(src => src.idRol))
               .ForMember(dest => dest.USPBT_ACTIVO, opt => opt.MapFrom(src => true))
               .ForMember(dest => dest.USSDT_FECHA_INSERT, opt => opt.MapFrom(src => DateTime.Now))
               .ForMember(dest => dest.USSVC_ID_USER_INSERT, opt => opt.Ignore())
               .ForMember(dest => dest.USSDT_FECHA_MODIF, opt => opt.Ignore())
               .ForMember(dest => dest.USSVC_ID_USER_MODIF, opt => opt.Ignore())
                .ReverseMap();

            // Mapeo de UsuarioRegistroCanalDto a USUARIO
            CreateMap<UsuarioRegistroCanalDto, USUARIO>()
                .ForMember(dest => dest.USPVC_ID_USUARIO, opt => opt.MapFrom(src => src.idUsuario))
                .ForMember(dest => dest.USPVC_NOMBRE_COMPLETO, opt => opt.MapFrom(src => src.nombreCompleto))
                .ForMember(dest => dest.USPBT_PASSWORD, opt => opt.MapFrom(src => Cryptography.Encrypt(src.password)))
                // Valores por defecto o requeridos por la entidad
                .ForMember(dest => dest.USPVC_TIPO, opt => opt.MapFrom(src => "CANAL"))
                .ForMember(dest => dest.USPVC_CORREO, opt => opt.MapFrom(src => string.Empty))
                .ForMember(dest => dest.USPCH_ID_DEPARTAMENTO, opt => opt.MapFrom(src => string.Empty))
                .ForMember(dest => dest.ROPBI_ID_ROL, opt => opt.MapFrom(src => 0L))
                .ForMember(dest => dest.USPBT_ACTIVO, opt => opt.MapFrom(src => true))
                .ForMember(dest => dest.USSDT_FECHA_INSERT, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.USSVC_ID_USER_INSERT, opt => opt.Ignore())
                .ForMember(dest => dest.USSDT_FECHA_MODIF, opt => opt.Ignore())
                .ForMember(dest => dest.USSVC_ID_USER_MODIF, opt => opt.Ignore());

            // Mapeo de USUARIO a UsuarioRegistroCanalDto (sin exponer la contraseña)
            CreateMap<USUARIO, UsuarioRegistroCanalDto>()
                .ForMember(dest => dest.idUsuario, opt => opt.MapFrom(src => src.USPVC_ID_USUARIO))
                .ForMember(dest => dest.nombreCompleto, opt => opt.MapFrom(src => src.USPVC_NOMBRE_COMPLETO))
                .ForMember(dest => dest.password, opt => opt.Ignore());

            // ROL <-> RolDto
            CreateMap<ROL, RolDto>()
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.area, opt => opt.MapFrom(src => src.ROPVC_AREA))
                .ForMember(dest => dest.nombre, opt => opt.MapFrom(src => src.ROPVC_NOMBRE))
                .ForMember(dest => dest.descripcion, opt => opt.MapFrom(src => src.ROSVC_DESCRIPCION))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.ROPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.ROSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.ROSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.ROSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.ROSVC_ID_USER_MODIF))
                .ReverseMap();
                       
            // MENU <-> MenuDto
            CreateMap<MENU, MenuDto>()
                .ForMember(dest => dest.idMenu, opt => opt.MapFrom(src => src.MEPBI_ID_MENU))
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.MEPVC_TIPO))
                .ForMember(dest => dest.nivel, opt => opt.MapFrom(src => src.MEPIN_NIVEL))
                .ForMember(dest => dest.nivelOrden, opt => opt.MapFrom(src => src.MEPIN_NIVEL_ORDEN))
                .ForMember(dest => dest.contenedor, opt => opt.MapFrom(src => src.MEPVC_CONTENEDOR))
                .ForMember(dest => dest.paginaOrden, opt => opt.MapFrom(src => src.MEPIN_PAGINA_ORDEN))
                .ForMember(dest => dest.paginaNombre, opt => opt.MapFrom(src => src.MEPVC_PAGINA_NOMBRE))
                .ForMember(dest => dest.paginaUrl, opt => opt.MapFrom(src => src.MEPVC_PAGINA_URL))
                .ForMember(dest => dest.idMenuPadre, opt => opt.MapFrom(src => src.MESBI_ID_MENU_PADRE))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.MEPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.MESDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.MESVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.MESDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.MESVC_ID_USER_MODIF))
                .ReverseMap();             

        }
    }
}
