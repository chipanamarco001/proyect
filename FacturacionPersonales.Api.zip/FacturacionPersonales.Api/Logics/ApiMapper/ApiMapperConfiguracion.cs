﻿using AutoMapper;
using ManageDB.SqlRepository;
using Models.DtosSp;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperConfiguracion: Profile
    {
        public ApiMapperConfiguracion()
        {
            #region Lexico

            CreateMap<LEXICO, LexicoDto>()
                    .ForMember(dest => dest.tabla, opt => opt.MapFrom(src => src.LEPVC_TABLA))
                    .ForMember(dest => dest.tema, opt => opt.MapFrom(src => src.LESVC_TEMA))
                    .ForMember(dest => dest.valor, opt => opt.MapFrom(src => src.LEPVC_VALOR))
                    .ForMember(dest => dest.descripcion1, opt => opt.MapFrom(src => src.LESVC_DESCRIPCION_1))
                    .ForMember(dest => dest.descripcion2, opt => opt.MapFrom(src => src.LESVC_DESCRIPCION_2))
                    .ForMember(dest => dest.descripcion3, opt => opt.MapFrom(src => src.LESVC_DESCRIPCION_3))
                    .ReverseMap();

            #endregion

            #region Errores

            // ERROR <-> ErrorDto
            CreateMap<ERROR, ErrorDto>()
                .ForMember(dest => dest.idError, opt => opt.MapFrom(src => src.ERPBI_ID_ERROR))
                .ForMember(dest => dest.pagina, opt => opt.MapFrom(src => src.ERPVC_PAGINA))
                .ForMember(dest => dest.metodo, opt => opt.MapFrom(src => src.ERPVC_METODO))
                .ForMember(dest => dest.mensaje, opt => opt.MapFrom(src => src.ERPVC_MENSAJE))
                .ForMember(dest => dest.stackTrace, opt => opt.MapFrom(src => src.ERPVC_STACK_TRACE))
                .ForMember(dest => dest.innerException, opt => opt.MapFrom(src => src.ERPVC_INNER_EXCEPTION))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.ERPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.ERSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.ERSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.ERSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.ERSVC_ID_USER_MODIF))
                .ReverseMap();

            // ERROR <-> ErrorRegistrarDto
            CreateMap<ERROR, ErrorRegistrarDto>()
                .ForMember(dest => dest.pagina, opt => opt.MapFrom(src => src.ERPVC_PAGINA))
                .ForMember(dest => dest.metodo, opt => opt.MapFrom(src => src.ERPVC_METODO))
                .ForMember(dest => dest.mensaje, opt => opt.MapFrom(src => src.ERPVC_MENSAJE))
                .ForMember(dest => dest.stackTrace, opt => opt.MapFrom(src => src.ERPVC_STACK_TRACE))
                .ForMember(dest => dest.innerException, opt => opt.MapFrom(src => src.ERPVC_INNER_EXCEPTION))
                .ReverseMap();

            #endregion
        }
    }
}
