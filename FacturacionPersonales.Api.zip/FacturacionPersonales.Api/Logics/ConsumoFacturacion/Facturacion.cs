﻿using AutoMapper;
using Common.Decrypt;
using Common.Parameters;
using Logics.ConsumoFacturacion.IRepository;
using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoFacturacion
{
    public class Facturacion: IFacturacion
    {
        private readonly IMapper _mapper;
        private readonly FacturaRepository _facturaRepository;
        private readonly FacturaDRepository _facturaDRepository;
        private readonly LoteFacturasRepository _loteFacturasRepository;
        private readonly UsuarioRepository _usuarioRepository;
        public Facturacion(IMapper mapper, FacturaRepository facturaRepository, FacturaDRepository facturaDRepository, LoteFacturasRepository loteFacturasRepository, UsuarioRepository usuarioRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _facturaRepository = facturaRepository ?? throw new ArgumentNullException(nameof(facturaRepository));
            _facturaDRepository = facturaDRepository ?? throw new ArgumentNullException(nameof(facturaDRepository));
            _loteFacturasRepository = loteFacturasRepository ?? throw new ArgumentNullException(nameof(facturaRepository));
            _usuarioRepository = usuarioRepository ?? throw new ArgumentNullException(nameof(usuarioRepository));
        }

        #region Factura

        public async Task<CrsApiResponse<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>> ObtenerFacturasPorFechasEstado(SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request objObtenerFacturasRequest, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _facturaRepository.ObtenerFacturasPorFechasEstado(objObtenerFacturasRequest, objCredenciales);
                    //var responseDto = _mapper.Map<List<LexicoDto>>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        public async Task<CrsApiResponse<GenerarArchivCsvResponse>> RegistrarFacturacion(List<ActFacturasDto> facturasDto, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<GenerarArchivCsvResponse>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var lstIdFacturas = facturasDto;
                    var responseRegistroLote = _loteFacturasRepository.RegistrarLote(lstIdFacturas.Count, objCredenciales);
                    var responseFacturado =  _facturaRepository.ActualizarFacturas(lstIdFacturas, responseRegistroLote.loteId, "FACTURADO", objCredenciales);

                    var objResponseCsv = new GenerarArchivCsvResponse();
                    if (responseFacturado.procesado)
                    {
                        var loteActualizado = _loteFacturasRepository.ActualizarEstadoProcesadoLote(responseRegistroLote.loteId, objCredenciales);

                        var facturasCsv = _facturaRepository.ObtenerFacturasPorIdLote(responseFacturado.idLoteFacturas);

                        var lstResumen = facturasCsv
                            .GroupBy(f => f.moneda)
                            .Select(g => new ResumenCsv
                            {
                                //Moneda = g.Key,
                                intMoneda = g.Key == "B" || g.Key == "BOB" || g.Key == "1" ? 1 :
                                            g.Key == "U" || g.Key == "USD" || g.Key == "2" ? 2 : 0,
                                decMonto = g.Sum(f => f.montoTotalMoneda),
                                intCantidad = g.Sum(f => f.cantidadTotal)
                            })
                            .ToList();

                        var strArchivo = new StringBuilder();
                        // Cabeceras
                        strArchivo.AppendLine(
                            "Numero Factura," +
                            "Nombre Razon Social," +
                            "Codigo Tipo Documento de Identidad," +
                            "Numero Documento,Complemento," +
                            "Codigo Cliente," +
                            "Codigo Metodo Pago," +
                            "Numero Tarjeta," +
                            "Monto Total," +
                            "Codigo Moneda," +
                            "Monto Total Moneda," +
                            "Usuario," +
                            "Codigo Leyenda," +
                            "Monto Total Sujeto IVA," +
                            "Tipo de Cambio," +
                            "Monto GiftCard," +
                            "Descuento Adicional," +
                            "Actividad Economica," +
                            "Codigo Producto SIN," +
                            "Codigo Producto," +
                            "Descripcion," +
                            "Unidad Medida," +
                            "Precio Unitario," +
                            "Cantidad," +
                            "Monto Descuento," +
                            "Subtotal," +
                            "Numero Serie," +
                            "Numero IMEI," +
                            "Correo"
                            );

                        // Cuerpo
                        facturasCsv.ForEach(f =>
                        {
                            int codigoMoneda = f.moneda == "B" || f.moneda == "BOB" || f.moneda == "1" ? 1 :
                                               f.moneda == "U" || f.moneda == "USD" || f.moneda == "2" ? 2 : 0;

                            strArchivo.AppendLine(string.Join(",", new string[]
                            {
                                f.numeroFactura.ToString(),
                                f.razonSocial,
                                f.tipoDocumento,
                                f.numeroDocumento,
                                f.complemento,
                                f.codigoClienteAsegurado,
                                f.codigoMetodoPago,
                                f.numeroTarjeta,
                                f.montoTotal.ToString().Replace(',', '-'),
                                codigoMoneda.ToString(),
                                f.montoTotalMoneda.ToString().Replace(',', '-'),
                                f.usuarioInsert,
                                f.codigoLeyenda,
                                f.montoTotalSujetoIva.ToString().Replace(',', '-'),
                                f.tipoCambio.ToString().Replace(',', '-'),
                                f.montoGiftcard.ToString().Replace(',', '-'),
                                f.descuentoAdicional.ToString().Replace(',', '-'),
                                f.actividadEconomica,
                                f.codigoProductoSin,
                                f.productoId,
                                //f.descripcion,
                                f.codigoUnidadMedida.ToString(),
                                f.precioUnitarioTotal.ToString().Replace(',', '-'),
                                f.cantidadTotal.ToString(),
                                f.montoDescuento.ToString().Replace(',', '-'),
                                f.subTotal.ToString().Replace(',', '-'),
                                f.numeroSerie,
                                f.numeroImei,
                                f.correo
                            }));
                        });

                        var objArchivoCsv = Encoding.ASCII.GetBytes(strArchivo.ToString());

                        objResponseCsv.procesado = responseFacturado.procesado;
                        objResponseCsv.byteCsvArchivo = objArchivoCsv;
                        objResponseCsv.lstResumen = lstResumen;
                        objResponseCsv.idLote = responseRegistroLote.loteId;
                        //objResponseCsv.nombreArchivo = 
                    }
                    responseFacturado.procesado = false;                    
                    return ApiResponseHelper.GetGenericResponse(objResponseCsv);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<GenerarArchivCsvResponse>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<GenerarArchivCsvResponse>> ObtenerArchivoCsvIdLote(CsvLoteDto objLoteCsv, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<GenerarArchivCsvResponse>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objResponseCsv = new GenerarArchivCsvResponse();

                    var facturasCsv = _facturaRepository.ObtenerFacturasPorIdLote(objLoteCsv.idLoteFacturas);
                    if (facturasCsv == null || facturasCsv.Count == 0)
                    {
                        objResponseCsv.procesado = true;
                        objResponseCsv.idLote = objLoteCsv.idLoteFacturas;

                        return ApiResponseHelper.GetGenericResponse(objResponseCsv);
                    }
                    var lstResumen = facturasCsv
                        .GroupBy(f => f.moneda)
                        .Select(g => new ResumenCsv
                        {
                            //Moneda = g.Key,
                            intMoneda = g.Key == "B" || g.Key == "BOB" || g.Key == "1" ? 1 :
                                        g.Key == "U" || g.Key == "USD" || g.Key == "2" ? 2 : 0,
                            decMonto = g.Sum(f => f.montoTotalMoneda),
                            intCantidad = g.Sum(f => f.cantidadTotal)
                        })
                        .ToList();

                    var strArchivo = new StringBuilder();
                    // Cabeceras
                    strArchivo.AppendLine(
                        "Numero Factura," +
                        "Nombre Razon Social," +
                        "Codigo Tipo Documento de Identidad," +
                        "Numero Documento,Complemento," +
                        "Codigo Cliente," +
                        "Codigo Metodo Pago," +
                        "Numero Tarjeta," +
                        "Monto Total," +
                        "Codigo Moneda," +
                        "Monto Total Moneda," +
                        "Usuario," +
                        "Codigo Leyenda," +
                        "Monto Total Sujeto IVA," +
                        "Tipo de Cambio," +
                        "Monto GiftCard," +
                        "Descuento Adicional," +
                        "Actividad Economica," +
                        "Codigo Producto SIN," +
                        "Codigo Producto," +
                        "Descripcion," +
                        "Unidad Medida," +
                        "Precio Unitario," +
                        "Cantidad," +
                        "Monto Descuento," +
                        "Subtotal," +
                        "Numero Serie," +
                        "Numero IMEI," +
                        "Correo"
                        );

                    // Cuerpo

                    facturasCsv.ForEach(f =>
                    {
                        int codigoMoneda = f.moneda == "B" || f.moneda == "BOB" || f.moneda == "1" ? 1 :
                                           f.moneda == "U" || f.moneda == "USD" || f.moneda == "2" ? 2 : 0;

                        strArchivo.AppendLine(string.Join(",", new string[]
                        {
                                f.numeroFactura.ToString(),
                                f.razonSocial,
                                f.tipoDocumento,
                                f.numeroDocumento,
                                f.complemento,
                                f.codigoClienteAsegurado,
                                f.codigoMetodoPago,
                                f.numeroTarjeta,
                                f.montoTotal.ToString().Replace(',', '-'),
                                codigoMoneda.ToString(),
                                f.montoTotalMoneda.ToString().Replace(',', '-'),
                                f.usuarioInsert,
                                f.codigoLeyenda,
                                f.montoTotalSujetoIva.ToString().Replace(',', '-'),
                                f.tipoCambio.ToString().Replace(',', '-'),
                                f.montoGiftcard.ToString().Replace(',', '-'),
                                f.descuentoAdicional.ToString().Replace(',', '-'),
                                f.actividadEconomica,
                                f.codigoProductoSin,
                                f.productoId,
                                //f.descripcion,
                                f.codigoUnidadMedida.ToString(),
                                f.precioUnitarioTotal.ToString().Replace(',', '-'),
                                f.cantidadTotal.ToString(),
                                f.montoDescuento.ToString().Replace(',', '-'),
                                f.subTotal.ToString().Replace(',', '-'),
                                f.numeroSerie,
                                f.numeroImei,
                                f.correo
                        }));
                    });

                    var objArchivoCsv = Encoding.ASCII.GetBytes(strArchivo.ToString());

                    objResponseCsv.procesado = true;
                    objResponseCsv.byteCsvArchivo = objArchivoCsv;
                    objResponseCsv.lstResumen = lstResumen;
                    objResponseCsv.idLote = objLoteCsv.idLoteFacturas;
                    //objResponseCsv.nombreArchivo = 

                    return ApiResponseHelper.GetGenericResponse(objResponseCsv);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<GenerarArchivCsvResponse>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<RespActFacturasDto>> RegistrarAnulacion(List<ActFacturasDto> facturasDto, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<RespActFacturasDto>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var lstIdFacturas = facturasDto;
                    var responseFacturado = _facturaRepository.ActualizarFacturas(lstIdFacturas, null, "ANULADO", objCredenciales);
                    //var responseFacturado = await Task.Run(() => _facturaRepository.ActualizarFacturas(lstIdFacturas, null, "ANULADO", objCredenciales));

                    return ApiResponseHelper.GetGenericResponse(responseFacturado);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<RespActFacturasDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<SPR_REGISTRAR_FACTURAS_Result>> SPR_REGISTRAR_FACTURA(SPR_REGISTRAR_FACTURAS_Request objRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SPR_REGISTRAR_FACTURAS_Result>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseFacturado = _facturaRepository.SPR_REGISTRAR_FACTURAS(objRegistroFacturas, objCredenciales);
                    
                    return ApiResponseHelper.GetGenericResponse(responseFacturado);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SPR_REGISTRAR_FACTURAS_Result>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }

        public async Task<CrsApiResponse<SPR_REGISTRAR_FACTURAS_Result>> SPR_REGISTRAR_FACTURA_V2(SPR_REGISTRAR_FACTURAS_V2_Request objRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SPR_REGISTRAR_FACTURAS_Result>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseFacturado = _facturaRepository.SPR_REGISTRAR_FACTURASV2(objRegistroFacturas, objCredenciales);

                    return ApiResponseHelper.GetGenericResponse(responseFacturado);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SPR_REGISTRAR_FACTURAS_Result>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }

        public async Task<CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>> SPR_REGISTRAR_FACTURAS(List<SPR_REGISTRAR_FACTURAS_Request> lstRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var lstResponse = new List<SPR_REGISTRAR_FACTURAS_Result>();
                    foreach (var objRegistroFacturas in lstRegistroFacturas)
                    {
                        if (objRegistroFacturas == null)
                        {
                            CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, new ArgumentNullException(nameof(objRegistroFacturas)), MethodBase.GetCurrentMethod().Name, string.Empty, "Objeto de registro de factura es nulo");
                            return response;
                        }
                        else
                        {
                            var responseFacturado = _facturaRepository.SPR_REGISTRAR_FACTURAS(objRegistroFacturas, objCredenciales);
                            lstResponse.Add(responseFacturado);
                        }
                    }
                    return ApiResponseHelper.GetGenericResponse(lstResponse);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }

        public async Task<CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>> SPR_REGISTRAR_FACTURAS_V2(List<SPR_REGISTRAR_FACTURAS_V2_Request> lstRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var lstResponse = new List<SPR_REGISTRAR_FACTURAS_Result>();
                    foreach (var objRegistroFacturas in lstRegistroFacturas)
                    {
                        if (objRegistroFacturas == null)
                        {
                            CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, new ArgumentNullException(nameof(objRegistroFacturas)), MethodBase.GetCurrentMethod().Name, string.Empty, "Objeto de registro de factura es nulo");
                            return response;
                        }
                        else
                        {
                            var responseFacturado = _facturaRepository.SPR_REGISTRAR_FACTURASV2(objRegistroFacturas, objCredenciales);
                            lstResponse.Add(responseFacturado);
                        }
                    }
                    return ApiResponseHelper.GetGenericResponse(lstResponse);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }

        public async Task<CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>> SPR_REGISTRAR_FACTURAS_MASIVO(List<SPR_REGISTRAR_FACTURAS_Request> facturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
               
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var errores = new List<ErrorDetail>();
                    int index = 1;
                    foreach (var factura in facturas)
                    {
                        if (string.IsNullOrWhiteSpace(factura.tipoDocumento) || factura.tipoDocumento.Length > 10)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'tipoDocumento' es requerido y máximo 10 caracteres.",
                                propertyName = "tipoDocumento",
                                errorUsuario = "El tipo de documento es obligatorio y no debe exceder 10 caracteres."
                            });

                        if (string.IsNullOrWhiteSpace(factura.numeroDocumento) || factura.numeroDocumento.Length > 50)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'numeroDocumento' es requerido y máximo 50 caracteres.",
                                propertyName = "numeroDocumento",
                                errorUsuario = "El número de documento es obligatorio y no debe exceder 50 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.complemento) && factura.complemento.Length > 3)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'complemento' máximo 3 caracteres.",
                                propertyName = "complemento",
                                errorUsuario = "El complemento no debe exceder 3 caracteres."
                            });

                        if (string.IsNullOrWhiteSpace(factura.codigoClienteAsegurado) || factura.codigoClienteAsegurado.Length > 50)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'codigoClienteAsegurado' es requerido y máximo 50 caracteres.",
                                propertyName = "codigoClienteAsegurado",
                                errorUsuario = "El código de cliente asegurado es obligatorio y no debe exceder 50 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.correo) && factura.correo.Length > 50)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'correo' máximo 50 caracteres.",
                                propertyName = "correo",
                                errorUsuario = "El correo no debe exceder 50 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.idPoliza) && factura.idPoliza.Length > 20)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'idPoliza' máximo 20 caracteres.",
                                propertyName = "idPoliza",
                                errorUsuario = "El ID de póliza no debe exceder 20 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.idCertificado) && factura.idCertificado.Length > 30)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'idCertificado' máximo 30 caracteres.",
                                propertyName = "idCertificado",
                                errorUsuario = "El ID de certificado no debe exceder 30 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.idProducto) && factura.idProducto.Length > 10)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'idProducto' máximo 10 caracteres.",
                                propertyName = "idProducto",
                                errorUsuario = "El ID de producto no debe exceder 10 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.razonSocial) && factura.razonSocial.Length > 150)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'razonSocial' máximo 150 caracteres.",
                                propertyName = "razonSocial",
                                errorUsuario = "La razón social no debe exceder 150 caracteres."
                            });

                        if (!string.IsNullOrEmpty(factura.moneda) && factura.moneda.Length > 3)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'moneda' máximo 3 caracteres.",
                                propertyName = "moneda",
                                errorUsuario = "La moneda no debe exceder 3 caracteres."
                            });

                        if (factura.fechaFactura == default)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'fechaFactura' es requerido.",
                                propertyName = "fechaFactura",
                                errorUsuario = "La fecha de factura es obligatoria."
                            });

                        //if (!string.IsNullOrEmpty(factura.numeroTarjeta) && factura.numeroTarjeta.Length > 50)
                        //    errores.Add(new ErrorDetail
                        //    {
                        //        errorMessage = $"[{index}] 'numeroTarjeta' máximo 50 caracteres.",
                        //        propertyName = "numeroTarjeta",
                        //        errorUsuario = "El número de tarjeta no debe exceder 50 caracteres."
                        //    });

                        //if (!string.IsNullOrEmpty(factura.numeroSerie) && factura.numeroSerie.Length > 100)
                        //    errores.Add(new ErrorDetail
                        //    {
                        //        errorMessage = $"[{index}] 'numeroSerie' máximo 100 caracteres.",
                        //        propertyName = "numeroSerie",
                        //        errorUsuario = "El número de serie no debe exceder 100 caracteres."
                        //    });

                        //if (!string.IsNullOrEmpty(factura.numeroImei) && factura.numeroImei.Length > 100)
                        //    errores.Add(new ErrorDetail
                        //    {
                        //        errorMessage = $"[{index}] 'numeroImei' máximo 100 caracteres.",
                        //        propertyName = "numeroImei",
                        //        errorUsuario = "El número IMEI no debe exceder 100 caracteres."
                        //    });

                        if (!string.IsNullOrEmpty(factura.detalle) && factura.detalle.Length > 500)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'detalle' máximo 500 caracteres.",
                                propertyName = "detalle",
                                errorUsuario = "El detalle no debe exceder 500 caracteres."
                            });

                        if (factura.cantidad < 1)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'cantidad' debe ser mayor a 0.",
                                propertyName = "cantidad",
                                errorUsuario = "La cantidad debe ser mayor a 0."
                            });

                        if (factura.precioUnitario < 0)
                            errores.Add(new ErrorDetail
                            {
                                errorMessage = $"[{index}] 'precioUnitario' debe ser mayor o igual a 0.",
                                propertyName = "precioUnitario",
                                errorUsuario = "El precio unitario debe ser mayor o igual a 0."
                            });

                        // Puedes agregar validaciones para los campos decimal si están en el DTO
                        // Ejemplo: montoGifcard, descuentoAdicional, montoDescuento, nit, idAfiliacion
                        index++;
                    }

                    if (errores.Any())
                    {
                        response.status = HttpStatusCode.BadRequest;
                        response.hasError = true;
                        response.errors = errores;
                        return response;
                    }

                    var dt = new DataTable();
                    dt.Columns.Add("ASPVC_TIPO_DOCUMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_NUMERO_DOCUMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_COMPLEMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_CODIGO_CLIENTE_ASEGURADO", typeof(string));
                    dt.Columns.Add("ASPVC_CORREO", typeof(string));
                    dt.Columns.Add("ID_USER_INSERT", typeof(string));
                    dt.Columns.Add("POPVC_ID_POLIZA", typeof(string));
                    dt.Columns.Add("AFPIN_ID_AFILIACION", typeof(long));
                    dt.Columns.Add("AFPIN_ID_CERTIFICADO", typeof(string));
                    dt.Columns.Add("PRPVC_ID_PRODUCTO", typeof(string));
                    dt.Columns.Add("FAPBI_NIT", typeof(long));
                    dt.Columns.Add("FAPVC_RAZON_SOCIAL", typeof(string));
                    dt.Columns.Add("FAPVC_MONEDA", typeof(string));
                    dt.Columns.Add("FAPDT_FECHA_FACTURA", typeof(DateTime));
                    dt.Columns.Add("FAPVC_NUMERO_TARJETA", typeof(string));
                    dt.Columns.Add("FAPDC_MONTO_GIFCARD", typeof(decimal));
                    dt.Columns.Add("FAPDC_DESCUENTO_ADICIONAL", typeof(decimal));
                    dt.Columns.Add("FAPDC_MONTO_DESCUENTO", typeof(decimal));
                    dt.Columns.Add("FAPVC_NUMERO_SERIE", typeof(string));
                    dt.Columns.Add("FAPVC_NUMERO_IMEI", typeof(string));
                    dt.Columns.Add("LFPIN_CANTIDAD", typeof(int));
                    dt.Columns.Add("LFPVC_DETALLE", typeof(string));
                    dt.Columns.Add("LFPDC_PRECIO_UNITARIO", typeof(decimal));

                    // Llenar el DataTable con los datos del DTO
                    foreach (var factura in facturas)
                    {                        
                        dt.Rows.Add(
                            factura.tipoDocumento,
                            factura.numeroDocumento,
                            factura.complemento,
                            factura.codigoClienteAsegurado,
                            factura.correo,
                            objCredenciales.usuario,
                            factura.idPoliza,
                            factura.idAfiliacion,
                            factura.idCertificado,
                            factura.idProducto,
                            factura.nit,
                            factura.razonSocial,
                            factura.moneda,
                            factura.fechaFactura,
                            null,//factura.numeroTarjeta,
                            0,//factura.montoGifcard,
                            0,//factura.descuentoAdicional,
                            0,//factura.montoDescuento,
                            null,//factura.numeroSerie,
                            null,//factura.numeroImei,
                            factura.cantidad,
                            factura.detalle,
                            factura.precioUnitario
                        );
                    }                    
                    var responseQuery =_facturaDRepository.RegistrarFacturasMasivo(dt);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }

        public async Task<CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>> SPR_REGISTRAR_FACTURAS_MASIVO_V2(List<SPR_REGISTRAR_FACTURAS_V2_Request> facturas, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }

                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {                   
                    var dt = new DataTable();
                    dt.Columns.Add("ASPVC_TIPO_DOCUMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_NUMERO_DOCUMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_COMPLEMENTO", typeof(string));
                    dt.Columns.Add("ASPVC_CODIGO_CLIENTE_ASEGURADO", typeof(string));
                    dt.Columns.Add("ASPVC_CORREO", typeof(string));
                    dt.Columns.Add("ID_USER_INSERT", typeof(string));
                    dt.Columns.Add("POPVC_ID_POLIZA", typeof(string));
                    dt.Columns.Add("AFPIN_ID_AFILIACION", typeof(long));
                    dt.Columns.Add("AFPIN_ID_CERTIFICADO", typeof(string));
                    dt.Columns.Add("PRPVC_ID_PRODUCTO", typeof(string));
                    dt.Columns.Add("FAPBI_NIT", typeof(long));
                    dt.Columns.Add("FAPVC_RAZON_SOCIAL", typeof(string));
                    dt.Columns.Add("FAPVC_MONEDA", typeof(string));
                    dt.Columns.Add("FAPDT_FECHA_FACTURA", typeof(DateTime));
                    dt.Columns.Add("FAPVC_NUMERO_TARJETA", typeof(string));
                    dt.Columns.Add("FAPDC_MONTO_GIFCARD", typeof(decimal));
                    dt.Columns.Add("FAPDC_DESCUENTO_ADICIONAL", typeof(decimal));
                    dt.Columns.Add("FAPDC_MONTO_DESCUENTO", typeof(decimal));
                    dt.Columns.Add("FAPVC_NUMERO_SERIE", typeof(string));
                    dt.Columns.Add("FAPVC_NUMERO_IMEI", typeof(string));
                    dt.Columns.Add("LFPIN_CANTIDAD", typeof(int));
                    dt.Columns.Add("LFPVC_DETALLE", typeof(string));
                    dt.Columns.Add("LFPDC_PRECIO_UNITARIO", typeof(decimal));

                    // Llenar el DataTable con los datos del DTO
                    foreach (var factura in facturas)
                    {
                        dt.Rows.Add(
                            factura.tipoDocumento,
                            factura.numeroDocumento,
                            factura.complemento,
                            factura.codigoClienteAsegurado,
                            factura.correo,
                            objCredenciales.usuario,
                            factura.idPoliza,
                            factura.idAfiliacion,
                            factura.idCertificado,
                            factura.idProducto,
                            factura.nit,
                            factura.razonSocial,
                            factura.moneda,
                            factura.fechaFactura,
                            factura.numeroTarjeta,
                            factura.montoGifcard,
                            factura.descuentoAdicional,
                            factura.montoDescuento,
                            factura.numeroSerie,
                            factura.numeroImei,
                            factura.cantidad,
                            factura.detalle,
                            factura.precioUnitario
                        );
                    }
                    var responseQuery = _facturaDRepository.RegistrarFacturasMasivo(dt);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SPR_REGISTRAR_FACTURAS_Result>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }

        }
        #endregion

        #region Lote facturas

        public async Task<CrsApiResponse<List<LoteDto>>> ObtenerLotesPorFechas(LoteBusquedaFechasDto objLoteBusqueda, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<LoteDto>>();
            try
            {
                if (!ValidarContraseña(objCredenciales.contraseña))
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;
                    return response;
                }
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _loteFacturasRepository.ObtenerLotesPorFechas(objLoteBusqueda.fechaInicio, objLoteBusqueda.fechaFin);
                    var responseDto = _mapper.Map<List<LoteDto>>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(responseDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<LoteDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        #endregion

        //public bool ValidarCredencialesPersonales(OcCredenciales ocCredenciales)
        //{
        //    var objUsuario = _usuarioRepository.ObtenerUsuarioPorId(Parameters.AplicativoConsumoV1);
        //    if (objUsuario == null || objUsuario.USPBT_PASSWORD == null)
        //        return false;

        //    var bytePassword = Cryptography.Encrypt(ocCredenciales.contraseña);
        //    return objUsuario.USPBT_PASSWORD.SequenceEqual(bytePassword);
        //}
        public bool ValidarContraseña(string contraseña)
        {
            var bytePassword = Cryptography.Encrypt(contraseña);
            var objUsuario = _usuarioRepository.ObtenerUsuarioPorContraseña(bytePassword);
            if (objUsuario == null || objUsuario.USPBT_PASSWORD == null)
                return false;
            return true;
        }
    }
}
