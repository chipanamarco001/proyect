﻿using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoFacturacion.IRepository
{
    public interface IFacturacion
    {
        #region facturacion
        Task<CrsApiResponse<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>> ObtenerFacturasPorFechasEstado(SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request objObtenerFacturasRequest, OcCredenciales objCredenciales);

        Task<CrsApiResponse<GenerarArchivCsvResponse>> RegistrarFacturacion(List<ActFacturasDto> facturasDto, OcCredenciales objCredenciales);

        Task<CrsApiResponse<GenerarArchivCsvResponse>> ObtenerArchivoCsvIdLote(CsvLoteDto objLoteCsv, OcCredenciales objCredenciales);

        Task<CrsApiResponse<RespActFacturasDto>> RegistrarAnulacion(List<ActFacturasDto> facturasDto, OcCredenciales objCredenciales);

        Task<CrsApiResponse<SPR_REGISTRAR_FACTURAS_Result>> SPR_REGISTRAR_FACTURA(SPR_REGISTRAR_FACTURAS_Request objRegistroFacturas, OcCredenciales objCredenciales);

        Task<CrsApiResponse<List<SPR_REGISTRAR_FACTURAS_Result>>> SPR_REGISTRAR_FACTURAS_MASIVO(List<SPR_REGISTRAR_FACTURAS_Request> facturas, OcCredenciales objCredenciales);

        #endregion

        #region Lote facturas

        Task<CrsApiResponse<List<LoteDto>>> ObtenerLotesPorFechas(LoteBusquedaFechasDto objLoteBusqueda, OcCredenciales objCredenciales);

        #endregion
    }
}
