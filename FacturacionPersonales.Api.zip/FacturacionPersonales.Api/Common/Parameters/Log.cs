﻿using Serilog;
using Serilog.Sinks.MSSqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Parameters
{
    public class Log
    {
        private static bool _isConfigured = false;

        public static void Configure(string connectionString)
        {
            if (_isConfigured) return;

            Serilog.Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.File("C://Logs/logCheck.txt", rollingInterval: RollingInterval.Day)
                .WriteTo.MSSqlServer(
                    connectionString: connectionString,
                    sinkOptions: new MSSqlServerSinkOptions
                    {
                        TableName = "Logs",
                        AutoCreateSqlTable = true
                    }
                )
                .CreateLogger();

            _isConfigured = true;
        }
        public static void Info(string message) => Serilog.Log.Information(message);
        public static void Info(string message, params object[] args) => Serilog.Log.Information(message, args);

        public static void Error(string message) => Serilog.Log.Error(message);
        public static void Error(Exception ex, string message) => Serilog.Log.Error(ex, message);
        public static void Error(string message, params object[] args) => Serilog.Log.Error(message, args);

        public static void Warn(string message) => Serilog.Log.Warning(message);
        public static void Warn(string message, params object[] args) => Serilog.Log.Warning(message, args);

        public static void Debug(string message) => Serilog.Log.Debug(message);
        public static void Debug(string message, params object[] args) => Serilog.Log.Debug(message, args);

        public static void Fatal(string message) => Serilog.Log.Fatal(message);
        public static void Fatal(Exception ex, string message) => Serilog.Log.Fatal(ex, message);
        public static void Fatal(string message, params object[] args) => Serilog.Log.Fatal(message, args);
    }
}
