﻿using Azure;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Common.Parameters
{
    public class CComplexParameter
    {
        public static bool IsCredentialsValidated<T>(OcCredenciales credentials, CrsApiResponse<T> response)
        {
            if (credentials == null)
            {
                response.errors.Add(new ErrorDetail { methodName = "CredentialsValidator", errorMessage = "Credenciales inválidas", propertyName = "Credentials" });
                response.status = HttpStatusCode.BadRequest;
                return false;
            }
            if (String.IsNullOrEmpty(credentials.ip))
            {
                response.errors.Add(new ErrorDetail { methodName = "CredentialsValidator", errorMessage = "Credenciales inválidas", propertyName = "Credentials" });
                response.status = HttpStatusCode.BadRequest;
                return false;
            }
            if (!IPAddress.TryParse(credentials.ip, out IPAddress ipAddress))
            {
                response.errors.Add(new ErrorDetail { methodName = "CredentialsValidator", errorMessage = "Dirección IP inválida", propertyName = "Credentials" });
                response.status = HttpStatusCode.BadRequest;
                return false;
            }
            if (String.IsNullOrEmpty(credentials.usuario))
            {
                response.errors.Add(new ErrorDetail { methodName = "CredentialsValidator", errorMessage = "Nombre de usuario inválido", propertyName = "Credentials" });
                response.status = HttpStatusCode.BadRequest;
                return false;
            }

            // Enriquecer el contexto de log con usuario e IP
            LogContext.PushProperty("Usuario", credentials.usuario ?? "Anonimo");
            LogContext.PushProperty("IpConsumo", credentials.ip ?? "Desconocida");

            response.status = HttpStatusCode.OK;
            response.messages.Add(new Message { methodName = "CredentialsValidator", messageTec = "Credenciales válidas", userMessage = "Autenticado" });
            response.hasError = false;
            return true;
        }        

        public static void EvaluaRespuestaList<T>(List<T> response, CrsApiResponse<List<T>> crsApiResponse)
        {
            if (response.Count == 0)
            {
                crsApiResponse.status = HttpStatusCode.OK;
                crsApiResponse.messages.Add(new Message { methodName = "CredentialsValidator", messageTec = "Credenciales válidas", userMessage = "Autenticado" });
                crsApiResponse.hasError = false;
            }
            else if (response.Count > 0)
            {
                crsApiResponse.status = HttpStatusCode.OK;
                crsApiResponse.messages.Add(new Message { methodName = "CredentialsValidator", messageTec = "Credenciales válidas", userMessage = "Autenticado" });
                crsApiResponse.hasError = false;
                crsApiResponse.result = response;
            }
            else
            {
                crsApiResponse.status = HttpStatusCode.NotFound;
                crsApiResponse.errors.Add(new ErrorDetail { methodName = "CredentialsValidator", errorMessage = "No se encontraron resultados", propertyName = "Response" });
                crsApiResponse.hasError = true;
            }

            if (crsApiResponse.result == null)
            {
                crsApiResponse.result = default(List<T>); // Fix: Ensure the default value matches the expected type (List<T>)
            }
        }
    }
}
