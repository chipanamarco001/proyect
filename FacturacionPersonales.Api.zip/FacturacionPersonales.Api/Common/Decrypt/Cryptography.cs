﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Common.Decrypt
{
    public class Cryptography
    {
        private static byte[] byteCRSKey = Encoding.Unicode.GetBytes("ruP?b9R,ZN+sLe!3");
        private static byte[] byteCRSIV = new byte[] { 3, 18, 5, 4, 9, 19, 5, 7, 21, 18, 15, 0, 19, 0, 1, 0 };
        private static string EncryptStringToBytes_Aes(string strInputText)
        {
            if (strInputText == null || strInputText.Length <= 0)
                throw new ArgumentNullException("Cryptography - strInputText");
            byte[] byteEncryptedText;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = byteCRSKey;
                aesAlg.IV = byteCRSIV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(strInputText);
                        }
                        byteEncryptedText = msEncrypt.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(byteEncryptedText);
        }
       
        private static string DecryptStringFromBytes_Aes(string strInputText)
        {
            if (strInputText == null || strInputText.Length <= 0)
                throw new ArgumentNullException("Cryptography - strInputText");
            byte[] byteInput = Convert.FromBase64String(strInputText);
            string strDecryptedInput = null;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = byteCRSKey;
                aesAlg.IV = byteCRSIV;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(byteInput))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            strDecryptedInput = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            return strDecryptedInput;
        }
        private static string GenerarToken(string strIdUsuario)
        {
            if (strIdUsuario == null || strIdUsuario.Length <= 0)
                throw new ArgumentNullException("Cryptography - strInputText");
            byte[] byteEncryptedText;
            string strCRSKey = strIdUsuario + DateTime.Now.Ticks.ToString() + "XXXXXXXXXXXXXXXX";
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.Unicode.GetBytes(strCRSKey.Substring(0, 16));
                aesAlg.IV = byteCRSIV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(strIdUsuario);
                        }
                        byteEncryptedText = msEncrypt.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(byteEncryptedText);
        }

        private static string GenerarOTP()
        {
            const string chars = "0123456789";
            Random random = new Random();
            char[] stringChars = new char[6];
            for (int i = 0; i < 6; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }
            string strOTP = new string(stringChars);
            return EncryptStr(strOTP);
        }
        public static string EncryptStr(string strInput)
        {
            return EncryptStringToBytes_Aes(strInput);
        }
        public static byte[] Encrypt(string strInput)
        {
            return Encoding.ASCII.GetBytes(EncryptStringToBytes_Aes(strInput));
        }
        public static string Decrypt(string strInput)
        {
            return DecryptStringFromBytes_Aes(strInput);
        }
        public static string Token(string strInput)
        {
            return GenerarToken(strInput);
        }
        public static string OTP()
        {
            return GenerarOTP();
        }
    }
}
