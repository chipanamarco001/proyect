﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class LoteDto
    {
        public string idLote { get; set; } = null!;
        public string? nombreArchivo { get; set; }
        public int numeroFacturas { get; set; }
        public DateOnly? fechaFacturaInicio { get; set; }
        public DateOnly? fechaFacturaFin { get; set; }
        public DateOnly? fechaFacturacion { get; set; }
        public bool procesado { get; set; }
        public int? idFechaInsert { get; set; }
        public DateTime fechaInsert { get; set; }
        public DateTime? fechaModif { get; set; }
        public string idUserInsert { get; set; } = null!;
        public string? idUserModif { get; set; }
        public bool activo { get; set; }
    }

    public class LoteFacturasRegistroDto
    {
        public string loteId { get; set; } // LOPVC_ID_LOTE
        public int numeroFacturas { get; set; } // LOPIN_NUMERO_FACTURAS
        public DateTime? fechaFacturaInicio { get; set; } // LOSDT_FECHA_FACTURA_INICIO
        public DateTime? fechaFacturaFin { get; set; } // LOSDT_FECHA_FACTURA_FIN
        public DateTime? fechaFacturacion { get; set; } // LOPDT_FECHA_FACTURACION
        public bool procesado { get; set; } // LOPBT_PROCESADO
        public DateTime fechaInsert { get; set; } // LOPDT_FECHA_INSERT
        public DateTime? fechaModif { get; set; } // LOPDT_FECHA_MODIF
        public string userInsertId { get; set; } // LOPVC_ID_USER_INSERT
        public string? userModifId { get; set; } // LOPVC_ID_USER_MODIF
        public bool activo { get; set; } // LOPBT_ACTIVO
    }

    public class LoteRespRegistroDto
    {
        public string loteId { get; set; } // LOPVC_ID_LOTE
        public int numeroFacturas { get; set; } // LOPIN_NUMERO_FACTURAS
        public DateTime? fechaFacturacion { get; set; } // LOPDT_FECHA_FACTURACION
        public bool registrado { get; set; }
        public string mensajeRespuesta { get; set; } = null!;
    }

    public class CsvLoteDto
    {
        public string idLoteFacturas { get; set; }
    }

    public class LoteBusquedaFechasDto
    {
        public DateOnly fechaInicio { get; set; }
        public DateOnly fechaFin { get; set; }
    }
}
