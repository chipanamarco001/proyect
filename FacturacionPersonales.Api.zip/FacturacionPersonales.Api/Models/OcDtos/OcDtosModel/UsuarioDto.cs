﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class UsuarioDto
    {
        public string idUsuario { get; set; } = null!;
        //public string apellidoPaterno { get; set; } = null!;
        //public string apellidoMaterno { get; set; } = null!;
        public string tipo { get; set; } = null!;
        public string nombreCompleto { get; set; } = null!;
        public string correo { get; set; } = null!;
        public string departamento { get; set; } = null!;
        public string password { get; set; } = null!;
        public string passwordReseteo { get; set; } = null!;
        public long idRol { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }

    public class UsuarioRegistroDto
    {
        public string idUsuario { get; set; } = null!;
        public string tipo { get; set; } = null!;
        public string nombreCompleto { get; set; } = null!;
        public string correo { get; set; } = null!;
        public string departamento { get; set; } = null!;
        public string password { get; set; } = null!;
        public string passwordReseteo { get; set; } = null!;
        public long idRol { get; set; }
    }

    public class UsuarioRegistroCanalDto
    {
        public string idUsuario { get; set; } = null!;
        public string nombreCompleto { get; set; } = null!;
        public string password { get; set; } = null!;
    }

    public class UsuarioRespRegistroDto
    {
        public string idUsuario { get; set; } = null!;
        public bool registrado { get; set; }
        public string mensajeRespuesta { get; set; } = null!;
    }
}
