﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class LexicoDto
    {
        public string tabla { get; set; } = null!;

        public string tema { get; set; } = null!;

        public string valor { get; set; } = null!;

        public string descripcion1 { get; set; } = null!;

        public string descripcion2 { get; set; } = null!;

        public string? descripcion3 { get; set; }
    }
}
