﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class FacturaDto
    {
        public long idFactura { get; set; }
        public string? idLote { get; set; }
        public string poliza { get; set; } = null!;
        public long idAfiliacion { get; set; }
        public string certificado { get; set; } = null!;
        public string producto { get; set; } = null!;
        public long idAsegurado { get; set; }
        public long nit { get; set; }
        public string? razonSocial { get; set; }
        public string? observaciones { get; set; }
        public string moneda { get; set; } = null!;
        public DateOnly fechaFactura { get; set; }
        public double? tipoCambio { get; set; }
        public string tipoFactura { get; set; } = null!;
        public string codigoProductoSin { get; set; } = null!;
        public string codigoMetodoPago { get; set; } = null!;
        public string numeroTarjeta { get; set; } = null!;
        public decimal montoGiftcard { get; set; }
        public decimal descuentoAdicional { get; set; }
        public decimal montoDescuento { get; set; }
        public string numeroSerie { get; set; } = null!;
        public string numeroImei { get; set; } = null!;
        public DateTime? fechaInsert { get; set; }
        public DateTime? fechaModif { get; set; }
        public string? usuarioRegistro { get; set; }
        public string? usuarioModificacion { get; set; }
        public string estado { get; set; } = null!;
        public bool activo { get; set; }
    }

    public class ActFacturasDto
    {
        //public List<long> idFacturas { get; set; }
        public long idFacturas { get; set; }

        public int numeroFactura { get; set; }
    }

    public class RespActFacturasDto
    {
        public bool procesado { get; set; }

        public string idLoteFacturas { get; set; }
    }

    public class GenerarArchivCsvResponse
    {
        public bool procesado { get; set; }
        public byte[] byteCsvArchivo { get; set; }
        public List<ResumenCsv> lstResumen { get; set; }
        public string idLote { get; set; }
        public string nombreArchivo { get; set; }
    }
    public class ResumenCsv
    {
        public int intMoneda { get; set; }
        public decimal decMonto { get; set; }
        public int intCantidad { get; set; }
    }
}
