﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class AseguradoDto
    {
        public long IdAsegurado { get; set; }
        public string? TipoDocumento { get; set; }
        public string? NumeroDocumento { get; set; }
        public string? Complemento { get; set; }
        public string? CodigoClienteAsegurado { get; set; }
        public string? NumeroTarjeta { get; set; }
        public string? Correo { get; set; }
        public string? UsuarioRegistro { get; set; }
        public string? UsuarioModificacion { get; set; }
        public bool Activo { get; set; }
    }

}
