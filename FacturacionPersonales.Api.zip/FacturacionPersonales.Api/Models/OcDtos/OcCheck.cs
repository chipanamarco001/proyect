﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.ModelCheck
{
    public class OcCheck
    {

        public class LexicoTablaRequest
        {
            public string tabla { get; set; } = null!;
        }

        public class LexicoTablaTemaRequest
        {
            public string tabla { get; set; } = null!;
            public string tema { get; set; } = null!;
        }

        public class ObtenerClienteBaseYapeRequest
        {
            public string numeroDocumento { get; set; } = null!;
            public string correo { get; set; } = null!;
        }

        public class ObtenerSubProductoParametroRequest
        {
            public long idSubProducto { get; set; } = 0!;
        }
    }
}
