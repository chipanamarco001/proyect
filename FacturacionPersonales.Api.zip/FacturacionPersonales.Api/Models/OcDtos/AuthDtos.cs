﻿using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos
{
    public class AuthDtos
    {
    }

    public class AutenticacionConsultarDto
    {
        public string usuario { get; set; }

        public string pass { get; set; }
    }

    public class AutenticacionRespuestaDto
    {
        public string token { get; set; }

        public string username { get; set; }

    }

    public class AutenticacionRespuestaCanalDto
    {
        public bool autenticado { get; set; }

        public string username { get; set; }

    }
    public class AutenticacionRespuestaExternoDto
    {
        public string dominio { get; set; }
        public string matricula { get; set; }
        public string nombreCompleto { get; set; }
        public string correo { get; set; }
        public string area { get; set; }
        public string nombreArea { get; set; }
        public string idDepartamento { get; set; }
        public byte[] foto { get; set; }
        public List<MenuAutenticacionDto> menu { get; set; }
        public string token { get; set; }
        public string otp { get; set; }
        public bool reestablecer { get; set; }
    }
}
