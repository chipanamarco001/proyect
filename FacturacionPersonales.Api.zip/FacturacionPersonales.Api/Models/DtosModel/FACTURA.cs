﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("FACTURA", Schema = "fac")]
public partial class FACTURA
{
    [Key]
    public long FAPIN_ID_FACTURA { get; set; }

    [StringLength(11)]
    [Unicode(false)]
    public string? LOPVC_ID_LOTE { get; set; }

    public int? FASIN_NUMERO_FACTURA { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    public long AFPIN_ID_AFILIACION { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string AFPIN_ID_CERTIFICADO { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string PRPVC_ID_PRODUCTO { get; set; } = null!;

    public long ASPBI_ID_ASEGURADO { get; set; }

    public long FAPBI_NIT { get; set; }

    [StringLength(150)]
    [Unicode(false)]
    public string? FAPVC_RAZON_SOCIAL { get; set; }

    [StringLength(300)]
    [Unicode(false)]
    public string? FAPVC_OBSERVACIONES { get; set; }

    [StringLength(3)]
    [Unicode(false)]
    public string FAPVC_MONEDA { get; set; } = null!;

    public int? FAPIN_CODIGO_UNIDAD_MEDIDA { get; set; }

    public DateOnly FAPDT_FECHA_FACTURA { get; set; }

    public double? FAPFL_TIPO_CAMBIO { get; set; }

    [StringLength(1)]
    [Unicode(false)]
    public string FAPVC_TIPO_FACTURA { get; set; } = null!;

    [StringLength(20)]
    [Unicode(false)]
    public string FAPVC_CODIGO_PRODUCTO_SIN { get; set; } = null!;

    [StringLength(20)]
    [Unicode(false)]
    public string FAPVC_CODIGO_METODO_PAGO { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string FAPVC_NUMERO_TARJETA { get; set; } = null!;

    [Column(TypeName = "decimal(18, 2)")]
    public decimal FAPDC_MONTO_GIFCARD { get; set; }

    [Column(TypeName = "decimal(18, 2)")]
    public decimal FAPDC_DESCUENTO_ADICIONAL { get; set; }

    [Column(TypeName = "decimal(18, 2)")]
    public decimal FAPDC_MONTO_DESCUENTO { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string FAPVC_NUMERO_SERIE { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string FAPVC_NUMERO_IMEI { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? FASVC_CODIGO_LEYENDA { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? FASVC_ACTIVIDAD_ECONOMICA { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? FAPDT_FECHA_INSERT { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? FASDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? FAPVC_ID_USER_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? FASVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string FAPVC_ESTADO { get; set; } = null!;

    public bool FAPBT_ACTIVO { get; set; }

    [InverseProperty("FAPIN_ID_FACTURANavigation")]
    public virtual ICollection<LINEA_FACTURA> LINEA_FACTURA { get; set; } = new List<LINEA_FACTURA>();
}
