﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("LOTE_FACTURAS", Schema = "fac")]
public partial class LOTE_FACTURAS
{
    [Key]
    [StringLength(11)]
    [Unicode(false)]
    public string LOPVC_ID_LOTE { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? LOPVC_NOMBRE_ARCHIVO { get; set; }

    public int LOPIN_NUMERO_FACTURAS { get; set; }

    public DateOnly? LOSDT_FECHA_FACTURA_INICIO { get; set; }

    public DateOnly? LOSDT_FECHA_FACTURA_FIN { get; set; }

    public DateOnly? LOPDT_FECHA_FACTURACION { get; set; }

    public bool LOPBT_PROCESADO { get; set; }

    public int? LOPIN_ID_FECHA_INSERT { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime LOPDT_FECHA_INSERT { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? LOPDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string LOPVC_ID_USER_INSERT { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? LOPVC_ID_USER_MODIF { get; set; }

    public bool LOPBT_ACTIVO { get; set; }
}
