﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("LEXICO", Schema = "fac")]
public partial class LEXICO
{
    [Key]
    public long LEPIN_ID_LEXICO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string LEPVC_TABLA { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string LESVC_TEMA { get; set; } = null!;

    [StringLength(500)]
    [Unicode(false)]
    public string LEPVC_VALOR { get; set; } = null!;

    [StringLength(500)]
    [Unicode(false)]
    public string LESVC_DESCRIPCION_1 { get; set; } = null!;

    [StringLength(500)]
    [Unicode(false)]
    public string LESVC_DESCRIPCION_2 { get; set; } = null!;

    [StringLength(500)]
    [Unicode(false)]
    public string? LESVC_DESCRIPCION_3 { get; set; }

    public bool LEPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime LESDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string LESVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? LESDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? LESVC_ID_USER_MODIF { get; set; }
}
