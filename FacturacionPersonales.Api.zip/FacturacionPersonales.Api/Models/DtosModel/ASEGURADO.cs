﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("ASEGURADO", Schema = "fac")]
public partial class ASEGURADO
{
    [Key]
    public long ASPBI_ID_ASEGURADO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string? ASPVC_TIPO_DOCUMENTO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ASPVC_NUMERO_DOCUMENTO { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string? ASPVC_COMPLEMENTO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ASPVC_CODIGO_CLIENTE_ASEGURADO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ASPVC_CORREO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ASPVC_ID_USER_INSERT { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? ASSVC_ID_USER_MODIF { get; set; }

    public bool ASPBT_ACTIVO { get; set; }
}
