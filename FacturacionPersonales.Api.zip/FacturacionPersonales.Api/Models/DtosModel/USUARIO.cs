﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("USUARIO", Schema = "usr")]
public partial class USUARIO
{
    [Key]
    [StringLength(50)]
    [Unicode(false)]
    public string USPVC_ID_USUARIO { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string USPVC_TIPO { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string USPVC_NOMBRE_COMPLETO { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string USPVC_CORREO { get; set; } = null!;

    [StringLength(3)]
    [Unicode(false)]
    public string USPCH_ID_DEPARTAMENTO { get; set; } = null!;

    public byte[]? USPBT_PASSWORD { get; set; }

    public byte[]? USPBT_PASSWORD_RESETEO { get; set; }

    public long ROPBI_ID_ROL { get; set; }

    public bool USPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime USSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string USSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? USSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? USSVC_ID_USER_MODIF { get; set; }

    [ForeignKey("ROPBI_ID_ROL")]
    [InverseProperty("USUARIO")]
    public virtual ROL ROPBI_ID_ROLNavigation { get; set; } = null!;

    [InverseProperty("USPVC_ID_USUARIONavigation")]
    public virtual ICollection<TOKEN> TOKEN { get; set; } = new List<TOKEN>();
}
