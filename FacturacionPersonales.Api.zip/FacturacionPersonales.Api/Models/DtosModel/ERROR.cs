﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("ERROR", Schema = "log")]
public partial class ERROR
{
    [Key]
    public long ERPBI_ID_ERROR { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string ERPVC_PAGINA { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string ERPVC_METODO { get; set; } = null!;

    [Unicode(false)]
    public string ERPVC_MENSAJE { get; set; } = null!;

    [Unicode(false)]
    public string ERPVC_STACK_TRACE { get; set; } = null!;

    [Unicode(false)]
    public string ERPVC_INNER_EXCEPTION { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? ERSVC_CODIGO_ERROR { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string? ERSVC_IP { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime ERSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ERSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? ERSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ERSVC_ID_USER_MODIF { get; set; }

    public bool ERPBT_ACTIVO { get; set; }
}
