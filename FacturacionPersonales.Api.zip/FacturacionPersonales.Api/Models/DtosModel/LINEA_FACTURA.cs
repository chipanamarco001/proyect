﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("LINEA_FACTURA", Schema = "fac")]
public partial class LINEA_FACTURA
{
    [Key]
    public long LFPIN_ID_LINEA_FACTURA { get; set; }

    public long? FAPIN_ID_FACTURA { get; set; }

    public int LFPIN_CANTIDAD { get; set; }

    [StringLength(500)]
    [Unicode(false)]
    public string? LFPVC_DETALLE { get; set; }

    [Column(TypeName = "money")]
    public decimal LFPDC_PRECIO_UNITARIO { get; set; }

    [ForeignKey("FAPIN_ID_FACTURA")]
    [InverseProperty("LINEA_FACTURA")]
    public virtual FACTURA? FAPIN_ID_FACTURANavigation { get; set; }
}
