﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_REGISTRAR_FACTURAS_Result
    {
        public long idFactura { get; set; }
        public string mensaje { get; set; } = string.Empty;
        public int exito { get; set; }
    }

    public class SPR_REGISTRAR_FACTURAS_Request
    {
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
        public string codigoClienteAsegurado { get; set; }
        public string correo { get; set; }
        public string idPoliza { get; set; }
        public long idAfiliacion { get; set; }
        public string idCertificado { get; set; }
        public string idProducto { get; set; }
        public long nit { get; set; }
        public string razonSocial { get; set; }
        public string moneda { get; set; }
        public DateTime fechaFactura { get; set; }
        public int cantidad { get; set; }
        public string detalle { get; set; }
        public decimal precioUnitario { get; set; }
    }

    public class SPR_REGISTRAR_FACTURAS_V2_Request
    {
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
        public string codigoClienteAsegurado { get; set; }
        public string correo { get; set; }
        public string idPoliza { get; set; }
        public long idAfiliacion { get; set; }
        public string idCertificado { get; set; }
        public string idProducto { get; set; }
        public long nit { get; set; }
        public string razonSocial { get; set; }
        public string moneda { get; set; }
        public DateTime fechaFactura { get; set; }
        public string numeroTarjeta { get; set; }
        public decimal montoGifcard { get; set; }
        public decimal descuentoAdicional { get; set; }
        public decimal montoDescuento { get; set; }
        public string numeroSerie { get; set; }
        public string numeroImei { get; set; }
        public int cantidad { get; set; }
        public string detalle { get; set; }
        public decimal precioUnitario { get; set; }
    }
}
