﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result
    {
        // ASEGURADO
        public long aseguradoId { get; set; }
        public string? tipoDocumento { get; set; }
        public string? numeroDocumento { get; set; }
        public string? complemento { get; set; }
        public string? codigoClienteAsegurado { get; set; }
        //public string? numeroTarjeta { get; set; }
        public string? correo { get; set; }

        // FACTURA
        public long facturaId { get; set; }
        public string? loteId { get; set; }
        public int? numeroFacturaLote { get; set; }
        public string? polizaId { get; set; }
        public long? afiliacionId { get; set; }
        public string? certificadoId { get; set; }
        public string? productoId { get; set; }
        public long? nit { get; set; }
        public string? razonSocial { get; set; }
        public string? observaciones { get; set; }
        public string? moneda { get; set; }
        public int? codigoUnidadMedida { get; set; }
        public DateTime? fecha { get; set; }
        public double? tipoCambio { get; set; }
        public string? tipo { get; set; }
        public string? codigoProductoSin { get; set; }
        public string? codigoMetodoPago { get; set; }
        public string? numeroTarjeta { get; set; }
        public decimal? montoGiftcard { get; set; }
        public decimal? descuentoAdicional { get; set; }
        public decimal? montoDescuento { get; set; }
        public string? numeroSerie { get; set; }
        public string? numeroImei { get; set; }
        public DateTime? fechaInsert { get; set; }
        public string? usuarioInsert { get; set; }
        public string? estado { get; set; }
    }

    public class SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request
    {
        /// <summary>
        /// Fecha inicial del rango de búsqueda
        /// </summary>
        public DateTime fechaInicio { get; set; }

        /// <summary>
        /// Fecha final del rango de búsqueda
        /// </summary>
        public DateTime fechaFin { get; set; }

        /// <summary>
        /// Estado de la factura a filtrar
        /// </summary>
        public string? estadoFactura { get; set; }
    }
}
