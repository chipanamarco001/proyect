using AutoMapper;
using Common.Parameters;
using Logics.ApiMapper;
using Logics.ConsumoConfiguracion;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ConsumoFacturacion;
using Logics.ConsumoFacturacion.IRepository;

using Logics.ServicioTransaccional;
using ManageDB.DapperRepository;

//using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using WebApi;

var builder = WebApplication.CreateBuilder(args);

//builder.Services.AddAutoMapper(typeof(ApiMapperAutenticacion));
// Obt�n la cadena de conexi�n desde appsettings.json
var connectionString = builder.Configuration.GetConnectionString("ConexionSql");

// Configura el logger con la cadena de conexi�n
Log.Configure(connectionString);
//Log.Info("Logger inicializado desde Common");

//Configuramos la conexion a sql server
builder.Services.AddDbContext<ApplicationDbContext>(opciones =>
{
    opciones.UseSqlServer(connectionString);
});
builder.Services.AddDbContext<ApplicationDbSpContext>(opciones =>
{
    opciones.UseSqlServer(connectionString);
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddScoped<IAutenticacion, Autenticacion>();
builder.Services.AddScoped<IConfiguracion, Configuracion>();
builder.Services.AddScoped<IAutenticacion, Autenticacion>();
builder.Services.AddScoped<IFacturacion, Facturacion>();
builder.Services.AddScoped<IFacturacionCliente, FacturacionCliente>();

//// Add services to the container.
builder.Services.AddScoped<AseguradoRepository>();

builder.Services.AddScoped<ErrorRepository>();
builder.Services.AddScoped<FacturaRepository>();
builder.Services.AddScoped<LexicoRepository>();
builder.Services.AddScoped<LineaFacturaRepository>();
builder.Services.AddScoped<LoteFacturasRepository>();
builder.Services.AddScoped<MenuRepository>();
builder.Services.AddScoped<TokenRepository>();
builder.Services.AddScoped<RolRepository>();

builder.Services.AddScoped<UsuarioRepository>();
builder.Services.AddScoped<CManejadorBaseDatos>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    return new CManejadorBaseDatos(connectionString);
});
//builder.Services.AddScoped<IDbConnection>(sp => new SqlConnection(connectionString));
//builder.Services.AddScoped<FacturaDRepository>();
builder.Services.AddScoped<IFacturacion, Facturacion>();

builder.Services.AddScoped<FacturaDRepository>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    return new FacturaDRepository(connectionString);
});
//builder.Services.AddScoped<ServicioDocumentos>();


//Agregar el automapper
builder.Services.AddAutoMapper(typeof(Program)); // Replace `Program` with the assembly containing your AutoMapper profiles
builder.Services.AddAutoMapper(typeof(ApiMapperAutenticacion));
builder.Services.AddAutoMapper(typeof(ApiMapperConfiguracion));
builder.Services.AddAutoMapper(typeof(ApiMapperFacturacion));

// Agregar configuraci�n de JWT
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidAudience = jwtSettings["Audience"],
        IssuerSigningKey = key,
        ClockSkew = TimeSpan.FromMinutes(5) // Tolerancia de 5 minutos
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            //Console.WriteLine("Token recibido por middleware: [" + context.Token + "]");
            // Extrae el token manualmente del header
            var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
            if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                context.Token = authHeader.Substring("Bearer ".Length).Trim();
            }
            Console.WriteLine("Token recibido por middleware (manual): [" + context.Token + "]");
            return Task.CompletedTask;            
        },     
        OnAuthenticationFailed = context =>
        {
            Console.WriteLine("Token inv�lido: " + context.Exception.Message);
            Console.WriteLine("Key: [" + jwtSettings["Key"] + "]");
            Console.WriteLine("Issuer: [" + jwtSettings["Issuer"] + "]");
            Console.WriteLine("Audience: [" + jwtSettings["Audience"] + "]");
            return Task.CompletedTask;
        }
    };
});

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Facturacion personales", Version = "v1" });

    // Configuraci�n para JWT
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Ingrese el token JWT"// en este formato: Bearer {token}"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});



var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger(options => options.OpenApiVersion = Microsoft.OpenApi.OpenApiSpecVersion.OpenApi3_0);
    app.UseSwaggerUI();
//}

app.UseCors();

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
