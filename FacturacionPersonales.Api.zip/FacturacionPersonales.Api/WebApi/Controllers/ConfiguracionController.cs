﻿using Common.Parameters;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioTransaccional;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using static Models.ModelCheck.OcCheck;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConfiguracionController : ControllerBase
    {
        private readonly IConfiguracion _configuracion;

        public ConfiguracionController(IConfiguracion configuracion)
        {
            _configuracion = configuracion;
        }

        #region Lexico

        //[Authorize]
        [HttpPost("ObtenerListaLexicoPorTabla")]
        public async Task<IActionResult> ObtenerListaLexicoPorTabla(CrsApiRequest<LexicoTablaRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaLexicoPorTabla(request.solicitud.tabla, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[Authorize]
        [HttpPost("ObtenerListaLexicoPorTablaTema")]
        public async Task<IActionResult> ObtenerListaLexicoPorTablaTema(CrsApiRequest<LexicoTablaTemaRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaLexicoPorTablaTema(request.solicitud.tabla, request.solicitud.tema, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion              

        #region Errores

        //[Authorize]
        [HttpPost("RegistrarError")]
        public async Task<IActionResult> RegistrarError(CrsApiRequest<ErrorRegistrarDto> request)
        {
            try
            {
                var response = await _configuracion.RegistrarError(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
