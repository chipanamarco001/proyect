﻿using Common.Parameters;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ConsumoFacturacion.IRepository;
using Microsoft.AspNetCore.Mvc;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturacionController : ControllerBase
    {
        private readonly IFacturacion _facturacion;

        public FacturacionController(IFacturacion facturacion)
        {
            _facturacion = facturacion;
        }

        #region Factura

        //[Authorize]
        [HttpPost("ObtenerFacturasPorFechasEstado")]
        public async Task<IActionResult> ObtenerFacturasPorFechasEstado(CrsApiRequest<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request> request)
        {
            try
            {
                var response = await _facturacion.ObtenerFacturasPorFechasEstado(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("RegistrarFacturacion")]
        public async Task<IActionResult> RegistrarFacturacion(CrsApiRequest<List<ActFacturasDto>> request)
        {
            try
            {
                var response = await _facturacion.RegistrarFacturacion(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("RegistrarAnulacion")]
        public async Task<IActionResult> RegistrarAnulacion(CrsApiRequest<List<ActFacturasDto>> request)
        {
            try
            {
                var response = await _facturacion.RegistrarAnulacion(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("ObtenerArchivoCsvIdLote")]
        public async Task<IActionResult> ObtenerArchivoCsvIdLote(CrsApiRequest<CsvLoteDto> request)
        {
            try
            {
                var response = await _facturacion.ObtenerArchivoCsvIdLote(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost("RegistrarFactura")]
        public async Task<IActionResult> SPR_REGISTRAR_FACTURA(CrsApiRequest<SPR_REGISTRAR_FACTURAS_Request> request)
        {
            try
            {
                var response = await _facturacion.SPR_REGISTRAR_FACTURA(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("RegistrarFacturaMasivo")]
        public async Task<IActionResult> SPR_REGISTRAR_FACTURAS_MASIVO(CrsApiRequest<List<SPR_REGISTRAR_FACTURAS_Request>> request)
        {
            try
            {
                var response = await _facturacion.SPR_REGISTRAR_FACTURAS_MASIVO(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Lote Facturas

        [HttpPost("ObtenerLotesPorFechas")]
        public async Task<IActionResult> ObtenerLotesPorFechas(CrsApiRequest<LoteBusquedaFechasDto> request)
        {
            try
            {
                var response = await _facturacion.ObtenerLotesPorFechas(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        #endregion
    }
}
