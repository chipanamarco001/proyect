﻿using Common.Parameters;
using Logics.ConsumoConfiguracion.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutenticacionController : ControllerBase
    {
        private readonly IAutenticacion _autenticacion;

        public AutenticacionController(IAutenticacion autenticacion)
        {
            _autenticacion = autenticacion;
        }

        #region Autenticacion

        [AllowAnonymous]
        [HttpPost("IniciarSesion")]
        public async Task<IActionResult> IniciarSesion(AutenticacionConsultarDto loginDto)
        {
            try
            {
                var response = await _autenticacion.GenerarToken(loginDto);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpGet("RegistrarUsuarioServicio")]
        public async Task<IActionResult> RegistrarUsuarioServicio()
        {
            try
            {
                var response = await _autenticacion.RegistrarUsuarioServicio();
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
