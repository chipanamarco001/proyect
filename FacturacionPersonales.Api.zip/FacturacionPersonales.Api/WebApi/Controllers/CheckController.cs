﻿using Common.Parameters;
using Logics.ServicioAuth;
using Logics.ServicioTransaccional;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json.Linq;
using static Models.ModelCheck.OcCheck;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CheckController : ControllerBase
    {
        
    }
}
