﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class FacturaRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public FacturaRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result> ObtenerFacturasPorFechasEstado(SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request objBusquedaFacturas, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_sp.SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO(objBusquedaFacturas.fechaInicio, objBusquedaFacturas.fechaFin, objBusquedaFacturas.estadoFactura).ToList();

            return queryResponse;
        }

        public List<SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result> ObtenerFacturasPorIdLote(string strIdLote)
        {
            var queryResponse = _context_sp.SPR_OBTENER_FACTURAS_POR_ID_LOTE(strIdLote).ToList();

            return queryResponse;
        }

        public RespActFacturasDto ActualizarFacturas(List<ActFacturasDto> lstIdFacturas, string strIdLote, string strEstadoFactura, OcCredenciales objCredenciales)
        {
            var response = new RespActFacturasDto();

            var facturaIds = lstIdFacturas.Select(dto => dto.idFacturas).ToList();
            var facturas = _context_c.FACTURA
                .Where(f => facturaIds.Contains(f.FAPIN_ID_FACTURA))
                .ToList();

            foreach (var factura in facturas)
            {
                var dto = lstIdFacturas.First(x => x.idFacturas == factura.FAPIN_ID_FACTURA);

                factura.LOPVC_ID_LOTE = strIdLote;
                factura.FAPVC_ESTADO = strEstadoFactura;
                factura.FASVC_ID_USER_MODIF = objCredenciales.usuario;
                factura.FASDT_FECHA_MODIF = DateTime.Now;
                factura.FASIN_NUMERO_FACTURA = dto.numeroFactura;

                _context_c.FACTURA.Update(factura);
            }
            response.idLoteFacturas = strIdLote;
            response.procesado = _context_c.SaveChanges() > 0;
            return response;
        }

        public SPR_REGISTRAR_FACTURAS_Result SPR_REGISTRAR_FACTURAS(SPR_REGISTRAR_FACTURAS_Request objRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = _context_sp.SPR_REGISTRAR_FACTURAS(
                  objRegistroFacturas.tipoDocumento
                , objRegistroFacturas.numeroDocumento
                , objRegistroFacturas.complemento
                , objRegistroFacturas.codigoClienteAsegurado
                , objRegistroFacturas.correo
                , objCredenciales.usuario
                , objRegistroFacturas.idPoliza
                , objRegistroFacturas.idAfiliacion
                , objRegistroFacturas.idCertificado
                , objRegistroFacturas.idProducto
                , objRegistroFacturas.nit
                , objRegistroFacturas.razonSocial
                , objRegistroFacturas.moneda
                , objRegistroFacturas.fechaFactura
                , null// objRegistroFacturas.numeroTarjeta
                , 0//objRegistroFacturas.montoGifcard
                , 0//objRegistroFacturas.descuentoAdicional
                , 0//objRegistroFacturas.montoDescuento
                , null//objRegistroFacturas.numeroSerie
                , null//objRegistroFacturas.numeroImei
                , objRegistroFacturas.cantidad
                , objRegistroFacturas.detalle
                , objRegistroFacturas.precioUnitario
                ).FirstOrDefault();
            return response ?? new SPR_REGISTRAR_FACTURAS_Result
            {
                idFactura = 0,
                mensaje = "Error al registrar la factura",
                exito = 0
            };
        }

        public SPR_REGISTRAR_FACTURAS_Result SPR_REGISTRAR_FACTURASV2(SPR_REGISTRAR_FACTURAS_V2_Request objRegistroFacturas, OcCredenciales objCredenciales)
        {
            var response = _context_sp.SPR_REGISTRAR_FACTURAS(
                  objRegistroFacturas.tipoDocumento
                , objRegistroFacturas.numeroDocumento
                , objRegistroFacturas.complemento
                , objRegistroFacturas.codigoClienteAsegurado
                , objRegistroFacturas.correo
                , objCredenciales.usuario
                , objRegistroFacturas.idPoliza
                , objRegistroFacturas.idAfiliacion
                , objRegistroFacturas.idCertificado
                , objRegistroFacturas.idProducto
                , objRegistroFacturas.nit
                , objRegistroFacturas.razonSocial
                , objRegistroFacturas.moneda
                , objRegistroFacturas.fechaFactura
                , objRegistroFacturas.numeroTarjeta
                , objRegistroFacturas.montoGifcard
                , objRegistroFacturas.descuentoAdicional
                , objRegistroFacturas.montoDescuento
                , objRegistroFacturas.numeroSerie
                , objRegistroFacturas.numeroImei
                , objRegistroFacturas.cantidad
                , objRegistroFacturas.detalle
                , objRegistroFacturas.precioUnitario
                ).FirstOrDefault();
            return response ?? new SPR_REGISTRAR_FACTURAS_Result
            {
                idFactura = 0,
                mensaje = "Error al registrar la factura",
                exito = 0
            };
        }
    }
}
