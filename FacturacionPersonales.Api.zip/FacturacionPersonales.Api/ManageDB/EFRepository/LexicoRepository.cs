﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class LexicoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public LexicoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public List<LEXICO> ObtenerListaLexicoPorTabla(string strTabla)
        {
            var response = _context_c.LEXICO.Where(w=>w.LEPVC_TABLA == strTabla && w.LEPBT_ACTIVO).ToList();
            return response;
        }
        public List<LEXICO> ObtenerListaLexicoPorTablaTema(string strTabla, string strTema)
        {
            var response = _context_c.LEXICO.Where(w => w.LEPVC_TABLA == strTabla && w.LESVC_TEMA == strTema && w.LEPBT_ACTIVO).ToList();
            return response;
        }
    }
}
