﻿using Models.OcDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class TokenRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public TokenRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public TOKEN AgregarToken(TOKEN objToken)
        {
            _context_c.TOKEN.Add(objToken);
            _context_c.SaveChanges();
            return objToken;
        }

        public bool DesactivarToken(string strIdUsuario)
        {
            var queryResponse = _context_c.TOKEN.Where(w => w.USPVC_ID_USUARIO == strIdUsuario).ToList();

            if (queryResponse == null || !queryResponse.Any())
            {
                return false;
            }
                        
            foreach (var token in queryResponse)
            {
                token.TOSDT_FECHA_MODIF = DateTime.Now;
                token.TOSVC_ID_USER_MODIF = strIdUsuario;
                token.TOPBT_ACTIVO = false; 
            }
                        
            _context_c.SaveChanges();
           
            return true;
        }

        public TOKEN ObtenerTokenPorId(string token)
        {
            var queryResponse = _context_c.TOKEN.Where(w => w.TOPVC_TOKEN == token && w.TOPBT_ACTIVO).FirstOrDefault();
            return queryResponse;
        }
    }
}
