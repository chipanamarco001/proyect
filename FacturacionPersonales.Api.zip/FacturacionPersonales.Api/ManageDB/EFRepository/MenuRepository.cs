﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class MenuRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public MenuRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public List<MENU> ObtenerMenusPorRol(long longIdRol)
        {
            var menus = _context_c.MENU
                .Where(m => m.ROPBI_ID_ROL == longIdRol && m.MEPBT_ACTIVO)                
                .ToList();
            return menus;
        }
    }
}
