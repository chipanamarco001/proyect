﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class LoteFacturasRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public LoteFacturasRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public LOTE_FACTURAS ObtenerUsuarioPorId(string strIdLote)
        {
            var queryResponse = _context_c.LOTE_FACTURAS.Where(w => w.LOPVC_ID_LOTE == strIdLote).FirstOrDefault();
            return queryResponse;
        }

        public LoteRespRegistroDto RegistrarLote(int intNumeroFacturas, OcCredenciales objCredenciales)
        {
            var response = new LoteRespRegistroDto();
            //var registroExistente = _context_c.LOTE_FACTURAS.FirstOrDefault(u => u.LOPVC_ID_LOTE == objLote.LOPVC_ID_LOTE && u.LOPBT_ACTIVO);
            //if (registroExistente != null)
            //{
            //    response.registrado = false;
            //    response.mensajeRespuesta = "El lote ya está registrado, no se puede registrar";
            //    response.loteId = registroExistente.LOPVC_ID_LOTE;
            //}
            //else
            //{
            int intIdFechaInsert = 0;

            var LoteId = GetIdentificadorLote(ref intIdFechaInsert);
            var objLote = new LOTE_FACTURAS();
            objLote.LOPVC_ID_LOTE = LoteId; // Asignar un identificador de lote único
            objLote.LOPIN_NUMERO_FACTURAS = intNumeroFacturas;// objLote.LOPIN_NUMERO_FACTURAS; // Asignar un departamento por defecto, puede ser parametrizado
            objLote.LOPBT_PROCESADO = false;
            objLote.LOPDT_FECHA_FACTURACION = DateOnly.FromDateTime(DateTime.Now);//objLote.LOPDT_FECHA_FACTURACION; // No se usa en este caso
            objLote.LOPIN_ID_FECHA_INSERT = intIdFechaInsert; // Asignar el ID de fecha de inserción
            objLote.LOPBT_ACTIVO = true;
            objLote.LOPDT_FECHA_INSERT = DateTime.Now;
            objLote.LOPVC_ID_USER_INSERT = objCredenciales.usuario;
            _context_c.LOTE_FACTURAS.Add(objLote);
            _context_c.SaveChanges();

            response.registrado = true;
            response.mensajeRespuesta = "El lote fue registrado correctamente";
            response.loteId = objLote.LOPVC_ID_LOTE;
            response.numeroFacturas = objLote.LOPIN_NUMERO_FACTURAS;
            response.fechaFacturacion = objLote.LOPDT_FECHA_FACTURACION == null ? null : objLote.LOPDT_FECHA_FACTURACION.Value.ToDateTime(TimeOnly.MinValue);
            //}

            return response;
        }

        public bool ActualizarEstadoProcesadoLote(string strIdLote, OcCredenciales objCredenciales)
        {
            var objetoLote = _context_c.LOTE_FACTURAS.FirstOrDefault(w => w.LOPVC_ID_LOTE == strIdLote);
            objetoLote.LOPBT_PROCESADO = true;
            objetoLote.LOPVC_ID_USER_MODIF = objCredenciales.usuario;
            objetoLote.LOPDT_FECHA_MODIF = DateTime.Now;
            _context_c.LOTE_FACTURAS.Update(objetoLote);
            var response = _context_c.SaveChanges() > 0;
            return response;            
        }

        public string GetIdentificadorLote(ref int intIdFechaInsert)
        {
            try
            {
                var dtTomorrow = DateTime.Today.AddDays(1);

                var result = _context_c.LOTE_FACTURAS
                    .Where(w => w.LOPDT_FECHA_INSERT > DateTime.Today && w.LOPDT_FECHA_INSERT < dtTomorrow)
                    .Select(oLote => oLote)
                    .ToList();

                var strDateIdentificador = DateTime.Now.ToString("yyyyMMdd");

                int intIdToday;

                string strIdentificador;
                if (result.Count > 0)
                {
                    intIdToday = result.Max(m => m.LOPIN_ID_FECHA_INSERT == null? 0: m.LOPIN_ID_FECHA_INSERT.Value) + 1;
                    strIdentificador = strDateIdentificador + "-" + intIdToday.ToString().PadLeft(2, '0');
                }
                else
                {
                    intIdToday = 1;
                    strIdentificador = strDateIdentificador + "-01";
                }
                intIdFechaInsert = intIdToday;

                return strIdentificador;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<LOTE_FACTURAS> ObtenerLotesPorFechas(DateOnly dtFechaInicio, DateOnly dtFechaFin)
        {
            var queryResponse = _context_c.LOTE_FACTURAS.Where(w=>w.LOPDT_FECHA_FACTURACION > dtFechaInicio && w.LOPDT_FECHA_FACTURACION < dtFechaFin && w.LOPBT_ACTIVO).ToList();

            return queryResponse;
        }
    }
}
