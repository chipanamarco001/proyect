﻿using Microsoft.EntityFrameworkCore;
using Models.DtosSp;
using System;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;

namespace WebApi;

public partial class ApplicationDbSpContext : DbContext
{
    public ApplicationDbSpContext()
    {
    }

    public ApplicationDbSpContext(DbContextOptions<ApplicationDbSpContext> options)
        : base(options)
    {
    }

    #region Custom DbSet 

        public virtual DbSet<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result> SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result { get; set; }

        public virtual DbSet<SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result> SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result { get; set; }

        public virtual DbSet<SPR_REGISTRAR_FACTURAS_Result> SPR_REGISTRAR_FACTURAS_Result { get; set; }

    #endregion

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {       

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_FACTURAS_Result>(entity => entity.HasNoKey());
        #region propiedad escalar               

        modelBuilder.Entity<ValReturn<bool>>().HasNoKey();
        modelBuilder.Entity<ValReturn<int>>().HasNoKey();
        modelBuilder.Entity<ValReturn<DateTime>>().HasNoKey();
        modelBuilder.Entity<ValReturn<string>>().HasNoKey();

        #endregion
    }

    public IEnumerable<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result> SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO(DateTime dtFechaInicio, DateTime dtFechafin, string strEstadoFactura)
    {
        return this.SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result
           .FromSql($"fac.SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO {dtFechaInicio},{dtFechafin},{strEstadoFactura}")
           .ToArray();
    }
    public IEnumerable<SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result> SPR_OBTENER_FACTURAS_POR_ID_LOTE(string strIdLote)
    {
        return this.SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result
           .FromSql($"fac.SPR_OBTENER_FACTURAS_POR_ID_LOTE {strIdLote}")
           .ToArray();
    }
    public IEnumerable<SPR_REGISTRAR_FACTURAS_Result> SPR_REGISTRAR_FACTURAS(string tipoDocumento, string numeroDocumento, string complemento, string codigoClienteAsegurado, string correo, string userInsert, string idPoliza, long idAfiliacion, string idCertificado, string idProducto, long nit, string razonSocial, string moneda, DateTime fechaFactura, string numeroTarjeta, decimal montoGifcard, decimal descuentoAdicional, decimal montoDescuento, string numeroSerie, string numeroImei, int cantidad, string detalle, decimal precioUnitario)
    {
        return this.SPR_REGISTRAR_FACTURAS_Result
           .FromSql($"fac.SPR_REGISTRAR_FACTURAS {tipoDocumento},{numeroDocumento},{complemento},{codigoClienteAsegurado},{correo},{userInsert},{idPoliza},{idAfiliacion},{idCertificado},{idProducto},{nit},{razonSocial},{moneda},{fechaFactura},{numeroTarjeta},{montoGifcard},{descuentoAdicional},{montoDescuento},{numeroSerie},{numeroImei},{cantidad},{detalle},{precioUnitario}")
           .ToArray();
    }
    public int testEscalar()
    {
        var result = this.Set<ValReturn<int>>()
        .FromSqlRaw("exec dbo.Scalar")
        .AsEnumerable()
        .First().Value;

        return result;
    }


    #region escalar

    public class ValReturn<T>
    {
        public T Value { get; set; }
    }

    #endregion
}
