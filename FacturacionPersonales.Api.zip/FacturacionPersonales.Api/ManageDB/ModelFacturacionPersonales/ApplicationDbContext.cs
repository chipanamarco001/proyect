﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

public partial class ApplicationDbContext : DbContext
{
    public ApplicationDbContext()
    {
    }

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<ASEGURADO> ASEGURADO { get; set; }

    public virtual DbSet<ERROR> ERROR { get; set; }

    public virtual DbSet<FACTURA> FACTURA { get; set; }

    public virtual DbSet<LEXICO> LEXICO { get; set; }

    public virtual DbSet<LINEA_FACTURA> LINEA_FACTURA { get; set; }

    public virtual DbSet<LOTE_FACTURAS> LOTE_FACTURAS { get; set; }

    public virtual DbSet<Logs> Logs { get; set; }

    public virtual DbSet<MENU> MENU { get; set; }

    public virtual DbSet<ROL> ROL { get; set; }

    public virtual DbSet<TOKEN> TOKEN { get; set; }

    public virtual DbSet<USUARIO> USUARIO { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ERROR>(entity =>
        {
            entity.HasKey(e => e.ERPBI_ID_ERROR).HasName("PK__ERROR__A3B34301B94DCB41");
        });

        modelBuilder.Entity<FACTURA>(entity =>
        {
            entity.HasKey(e => e.FAPIN_ID_FACTURA).HasName("PK_FACTURA_1");
        });

        modelBuilder.Entity<LINEA_FACTURA>(entity =>
        {
            entity.HasOne(d => d.FAPIN_ID_FACTURANavigation).WithMany(p => p.LINEA_FACTURA).HasConstraintName("FK_LINEA_FACTURA_FACTURA");
        });

        modelBuilder.Entity<MENU>(entity =>
        {
            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.MENU)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MENU_ROL");
        });

        modelBuilder.Entity<ROL>(entity =>
        {
            entity.HasKey(e => e.ROPBI_ID_ROL).HasName("PK__ROL__9A222ACFE0A1F3F3");
        });

        modelBuilder.Entity<TOKEN>(entity =>
        {
            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.TOKEN)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TOKEN_ROL");

            entity.HasOne(d => d.USPVC_ID_USUARIONavigation).WithMany(p => p.TOKEN)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TOKEN_USUARIO");
        });

        modelBuilder.Entity<USUARIO>(entity =>
        {
            entity.HasKey(e => e.USPVC_ID_USUARIO).HasName("PK__USUARIO__EE365385564FAFF6");

            entity.Property(e => e.USPCH_ID_DEPARTAMENTO).IsFixedLength();

            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.USUARIO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_USUARIO_ROL");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
