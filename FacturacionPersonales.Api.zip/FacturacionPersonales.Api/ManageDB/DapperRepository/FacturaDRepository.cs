﻿using Dapper;
using Microsoft.Data.SqlClient;
using Models.DtosSp;
using Models.OcDtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace ManageDB.DapperRepository
{
    public class FacturaDRepository
    {
        private readonly string _connectionString;
        public FacturaDRepository(string connectionString)
        {
            _connectionString = connectionString;
        }
        private IDbConnection CreateConnection() => new SqlConnection(_connectionString);

        public List<SPR_REGISTRAR_FACTURAS_Result> RegistrarFacturasMasivo(DataTable dtFacturas)
        {
            using var connection = CreateConnection();

            var parameters = new DynamicParameters();
            parameters.Add("@Facturas", dtFacturas.AsTableValuedParameter("fac.TVP_FACTURAS"));

            var result = connection.Query<SPR_REGISTRAR_FACTURAS_Result>(
                "fac.SPR_REGISTRAR_FACTURAS_MASIVO",
                parameters,
                commandType: CommandType.StoredProcedure
            ).ToList();
            return result;
        }
        //public List<SPR_REGISTRAR_FACTURAS_Result> RegistrarFacturasMasivo1(SPR_REGISTRAR_FACTURAS_Request request, OcCredenciales objCredenciales)
        //{
        //    var parameters = new DynamicParameters();
        //    parameters.Add("tipoDocumento", request.tipoDocumento, DbType.String);
        //    parameters.Add("numeroDocumento", request.numeroDocumento, DbType.String);
        //    parameters.Add("complemento", request.complemento, DbType.String);
        //    parameters.Add("codigoClienteAsegurado", request.codigoClienteAsegurado, DbType.String);
        //    parameters.Add("correo", request.correo, DbType.String);
        //    parameters.Add("userInsert", objCredenciales.usuario, DbType.String);
        //    parameters.Add("idPoliza", request.idPoliza, DbType.String);
        //    parameters.Add("idAfiliacion", request.idAfiliacion, DbType.Int64);
        //    parameters.Add("idCertificado", request.idCertificado, DbType.String);
        //    parameters.Add("idProducto", request.idProducto, DbType.String);
        //    parameters.Add("nit", request.nit, DbType.Int64);
        //    parameters.Add("razonSocial", request.razonSocial, DbType.String);
        //    parameters.Add("moneda", request.moneda, DbType.String);
        //    parameters.Add("fechaFactura", request.fechaFactura, DbType.DateTime);
        //    parameters.Add("numeroTarjeta", null, DbType.String);
        //    parameters.Add("montoGifcard", 0, DbType.Decimal);
        //    parameters.Add("descuentoAdicional", 0, DbType.Decimal);
        //    parameters.Add("montoDescuento", 0, DbType.Decimal);
        //    parameters.Add("numeroSerie", null, DbType.String);
        //    parameters.Add("numeroImei", null, DbType.String);
        //    parameters.Add("cantidad", request.cantidad, DbType.Int32);
        //    parameters.Add("detalle", request.detalle, DbType.String);
        //    parameters.Add("precioUnitario", request.precioUnitario, DbType.Decimal);

        //    // Llamada al procedimiento almacenado
        //    var result = _connection.Query<SPR_REGISTRAR_FACTURAS_Result>(
        //        "fac.SPR_REGISTRAR_FACTURAS_MASIVO",
        //        parameters,
        //        commandType: CommandType.StoredProcedure
        //    ).ToList();

        //    return result;
        //}

        //public List<SPR_REGISTRAR_FACTURAS_Result> RegistrarFacturasMasivoV21(SPR_REGISTRAR_FACTURAS_V2_Request request, OcCredenciales objCredenciales)
        //{
        //    var parameters = new DynamicParameters();
        //    parameters.Add("tipoDocumento", request.tipoDocumento, DbType.String);
        //    parameters.Add("numeroDocumento", request.numeroDocumento, DbType.String);
        //    parameters.Add("complemento", request.complemento, DbType.String);
        //    parameters.Add("codigoClienteAsegurado", request.codigoClienteAsegurado, DbType.String);
        //    parameters.Add("correo", request.correo, DbType.String);
        //    parameters.Add("userInsert", objCredenciales.usuario, DbType.String);
        //    parameters.Add("idPoliza", request.idPoliza, DbType.String);
        //    parameters.Add("idAfiliacion", request.idAfiliacion, DbType.Int64);
        //    parameters.Add("idCertificado", request.idCertificado, DbType.String);
        //    parameters.Add("idProducto", request.idProducto, DbType.String);
        //    parameters.Add("nit", request.nit, DbType.Int64);
        //    parameters.Add("razonSocial", request.razonSocial, DbType.String);
        //    parameters.Add("moneda", request.moneda, DbType.String);
        //    parameters.Add("fechaFactura", request.fechaFactura, DbType.DateTime);
        //    parameters.Add("numeroTarjeta", request.numeroTarjeta, DbType.String);
        //    parameters.Add("montoGifcard", request.montoGifcard, DbType.Decimal);
        //    parameters.Add("descuentoAdicional", request.descuentoAdicional, DbType.Decimal);
        //    parameters.Add("montoDescuento", request.montoDescuento, DbType.Decimal);
        //    parameters.Add("numeroSerie", request.numeroSerie, DbType.String);
        //    parameters.Add("numeroImei", request.numeroImei, DbType.String);
        //    parameters.Add("cantidad", request.cantidad, DbType.Int32);
        //    parameters.Add("detalle", request.detalle, DbType.String);
        //    parameters.Add("precioUnitario", request.precioUnitario, DbType.Decimal);

        //    // Llamada al procedimiento almacenado
        //    var result = _connection.Query<SPR_REGISTRAR_FACTURAS_Result>(
        //        "fac.SPR_REGISTRAR_FACTURAS_MASIVO",
        //        parameters,
        //        commandType: CommandType.StoredProcedure
        //    ).ToList();

        //    return result;
        //}
    }
}
