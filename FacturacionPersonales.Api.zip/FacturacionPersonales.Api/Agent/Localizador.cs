﻿using Common.Parameters;
using Microsoft.Extensions.Configuration;
using ServicioEnvioCorreo;
namespace Agent
{
    public class Localizador
    {      
        public static IServicioEnvioCorreo ServicioEnvioCorreo()
        {
            IServicioEnvioCorreo objServicio = new ServicioEnvioCorreoClient(ServicioEnvioCorreoClient.EndpointConfiguration.ServicioEnvioCorreoHttpEndPoint);
            return objServicio;
        }

        public static void Close(IServicioEnvioCorreo conexion)
        {
            ((ServicioEnvioCorreoClient)conexion).Close();
        }

        #region Metodos genericos
        private static IConfiguration GetConfiguration()
        {
            return new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
        }

        private static System.ServiceModel.BasicHttpBinding CreateBinding(string serviceKey, IConfiguration configuration)
        {
            var binding = new System.ServiceModel.BasicHttpBinding();

            binding.MaxBufferSize = Convert.ToInt32(configuration[$"ServiceUrls:{serviceKey}:binding:maxBufferSize"]);
            binding.MaxReceivedMessageSize = Convert.ToInt64(configuration[$"ServiceUrls:{serviceKey}:binding:maxReceivedMessageSize"]);
            binding.ReaderQuotas.MaxStringContentLength = Convert.ToInt32(configuration[$"ServiceUrls:{serviceKey}:binding:readerQuotas:maxStringContentLength"]);
            binding.ReaderQuotas.MaxArrayLength = Convert.ToInt32(configuration[$"ServiceUrls:{serviceKey}:binding:readerQuotas:maxArrayLength"]);
            binding.Security.Mode = GetSecurityMode(configuration[$"ServiceUrls:{serviceKey}:binding:security:mode"]);
            binding.Security.Transport.ClientCredentialType = GetSecurityTransport(configuration[$"ServiceUrls:{serviceKey}:binding:security:clientCredentialType"]);

            return binding;
        }

        public static System.ServiceModel.BasicHttpSecurityMode GetSecurityMode(string strMode)
        {
            if (string.IsNullOrEmpty(strMode))
            {
                throw new ArgumentNullException(nameof(strMode), "El modo de seguridad no puede ser nulo o vacío.");
            }
            switch (strMode)
            {
                case "None":
                    return System.ServiceModel.BasicHttpSecurityMode.None;
                case "Transport":
                    return System.ServiceModel.BasicHttpSecurityMode.Transport;
                case "TransportCredentialOnly":
                    return System.ServiceModel.BasicHttpSecurityMode.TransportCredentialOnly;                
                case "TransportWithMessageCredential":
                    return System.ServiceModel.BasicHttpSecurityMode.TransportWithMessageCredential;
                case "Message":
                    return System.ServiceModel.BasicHttpSecurityMode.Message;

                default:
                    return System.ServiceModel.BasicHttpSecurityMode.None;
            }              
        }

        public static System.ServiceModel.HttpClientCredentialType GetSecurityTransport(string strTransport)
        {
            if (string.IsNullOrEmpty(strTransport))
            {
                throw new ArgumentNullException(nameof(strTransport), "El tipo de credencial de transporte no puede ser nulo o vacío.");
            }

            switch (strTransport)
            {
                case "None":
                    return System.ServiceModel.HttpClientCredentialType.None;
                case "Certificate":
                    return System.ServiceModel.HttpClientCredentialType.Certificate;
                case "Windows":
                    return System.ServiceModel.HttpClientCredentialType.Windows;
                case "Basic":
                    return System.ServiceModel.HttpClientCredentialType.Basic;
                case "Digest":
                    return System.ServiceModel.HttpClientCredentialType.Digest;
                case "InheritedFromHost":
                    return System.ServiceModel.HttpClientCredentialType.InheritedFromHost;
                case "Ntlm":
                    return System.ServiceModel.HttpClientCredentialType.Ntlm;

                default:
                    return System.ServiceModel.HttpClientCredentialType.None;
            }
        }

        #endregion
    }
}
