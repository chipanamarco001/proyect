﻿using Serilog;
using Serilog.Sinks.MSSqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Parameters
{
    public class Log
    {
        private static bool _isConfigured = false;

        public static void Configure(string connectionString)
        {
            if (_isConfigured) return;

            //// Define custom columns
            //var columnOptions = new ColumnOptions();
            //columnOptions.AdditionalColumns = new List<SqlColumn>
            //{
            //    new SqlColumn { ColumnName = "IpConsumo", DataType = System.Data.SqlDbType.NVarChar, DataLength = 50 },
            //    new SqlColumn { ColumnName = "Usuario", DataType = System.Data.SqlDbType.NVarChar, DataLength = 50 },
            //    new SqlColumn { ColumnName = "ServicioConsultado", DataType = System.Data.SqlDbType.NVarChar, DataLength = 200 }
            //};

            Serilog.Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.File(
                    path: "C://Logs/logCheck.txt",
                    rollingInterval: RollingInterval.Day,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj} | IP={IpConsumo} | Usuario={Usuario} | Servicio={ServicioConsultado}{NewLine}{Exception}"
                )
                //.WriteTo.MSSqlServer(
                //    connectionString: connectionString,
                //    sinkOptions: new MSSqlServerSinkOptions
                //    {
                //        TableName = "LOGS",
                //        AutoCreateSqlTable = true
                //    },
                //    columnOptions: columnOptions
                //)
                .CreateLogger();

            _isConfigured = true;
        }
        public static void Info(string message) => Serilog.Log.Information(message);
        public static void Info(string message, params object[] args) => Serilog.Log.Information(message, args);

        public static void Error(string message) => Serilog.Log.Error(message);
        public static void Error(Exception ex, string message) => Serilog.Log.Error(ex, message);
        public static void Error(string message, params object[] args) => Serilog.Log.Error(message, args);

        public static void Warn(string message) => Serilog.Log.Warning(message);
        public static void Warn(string message, params object[] args) => Serilog.Log.Warning(message, args);

        public static void Debug(string message) => Serilog.Log.Debug(message);
        public static void Debug(string message, params object[] args) => Serilog.Log.Debug(message, args);

        public static void Fatal(string message) => Serilog.Log.Fatal(message);
        public static void Fatal(Exception ex, string message) => Serilog.Log.Fatal(ex, message);
        public static void Fatal(string message, params object[] args) => Serilog.Log.Fatal(message, args);
    }
}
