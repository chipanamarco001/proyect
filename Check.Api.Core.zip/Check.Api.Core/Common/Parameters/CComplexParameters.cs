﻿
using Models.Dtos;
using Models.OcDtos;
using System.Net;

namespace Common.Parameters
{
    public class CComplexParameters<T>
    {
        public static string GetKeyGenerator()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmssfff");
        }

        public static bool GetValidacionResult(ref CrsApiResponse<T?> ValidationResult, Exception ex, string strMethodName, string strPropertyName, string strErrorUsuario)
        {
            if (ValidationResult == null)
            {
                ValidationResult = new();
                ValidationResult.errors = new List<ErrorDetail>();
            }
            else if (ValidationResult.errors == null)
            {
                ValidationResult.errors = new List<ErrorDetail>();
            }

            ValidationResult.hasError = true;

            ValidationResult.errors.Add(new ErrorDetail
            {
                propertyName = strPropertyName,
                errorMessage = ex.Message,
                stackTrace = ex.StackTrace,
                innerException = Convert.ToString(ex.InnerException),
                methodName = strMethodName,
                errorUsuario = strErrorUsuario
            });

            return true;
        }
                
    }
}
