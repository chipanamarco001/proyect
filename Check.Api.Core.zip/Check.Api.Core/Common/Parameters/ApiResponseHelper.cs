﻿using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Common.Parameters
{
    public class ApiResponseHelper
    {
        public static IActionResult HandleApiResponse<T>(ControllerBase controller, CrsApiResponse<T> response)
        {
            if (response == null)
                // 500 Error interno del servidor: El servicio devolvió una respuesta nula.
                return controller.StatusCode(500, new { StatusCode = 500, ErrorType = "NullResponse", Message = "Respuesta nula del servicio." });

            // 200 OK: La solicitud fue exitosa y la respuesta contiene datos.
            if (response.status == HttpStatusCode.OK && !response.hasError)
                return controller.Ok(response);

            // 201 Creado: La solicitud fue exitosa y se creó un nuevo recurso.
            if (response.status == HttpStatusCode.Created)
                return controller.StatusCode(201, response);

            // 204 Sin contenido: La solicitud fue exitosa pero no hay contenido para retornar.
            if (response.status == HttpStatusCode.NoContent)
                return controller.NoContent();

            // 400 Solicitud incorrecta: La solicitud es inválida o no puede ser procesada.
            if (response.status == HttpStatusCode.BadRequest)
                return controller.BadRequest(response);

            // 401 No autorizado: La autenticación es requerida o falló.
            if (response.status == HttpStatusCode.Unauthorized)
                return controller.StatusCode(401, response); //return controller.Unauthorized();

            // 403 Prohibido: El servidor entendió la solicitud pero se niega a autorizarla.
            if (response.status == HttpStatusCode.Forbidden)
                return controller.StatusCode(403, response);

            // 404 No encontrado: El recurso solicitado no existe.
            if (response.status == HttpStatusCode.NotFound)
                return controller.NotFound(response);

            // 409 Conflicto: La solicitud no pudo ser completada debido a un conflicto con el estado actual del recurso.
            if (response.status == HttpStatusCode.Conflict)
                return controller.Conflict(response);

            // 422 Entidad no procesable: La solicitud está bien formada pero no se puede procesar por errores semánticos.
            if (response.status == HttpStatusCode.UnprocessableEntity)
                return controller.UnprocessableEntity(response);

            // 429 Demasiadas solicitudes: El usuario ha enviado demasiadas solicitudes en un periodo de tiempo.
            if (response.status == HttpStatusCode.TooManyRequests)
                return controller.StatusCode(429, response);

            // 500 Error interno del servidor: Error genérico cuando no hay un mensaje más específico.
            return controller.StatusCode(500, response);
        }

        //public static IActionResult HandleApiResponse<T>(ControllerBase controller, CrsApiResponse<T> response)
        //{
        //    if (response == null)
        //        // 500 Error interno del servidor: El servicio devolvió una respuesta nula.
        //        return controller.StatusCode(500, new { StatusCode = 500, ErrorType = "NullResponse", Message = "Respuesta nula del servicio." });

        //    // 200 OK: La solicitud fue exitosa y la respuesta contiene datos.
        //    if (response.status == "200" && !response.hasError)
        //        return controller.Ok(response);

        //    // 201 Creado: La solicitud fue exitosa y se creó un nuevo recurso.
        //    if (response.status == "201")
        //        return controller.StatusCode(201, response);

        //    // 204 Sin contenido: La solicitud fue exitosa pero no hay datos, se retorna el objeto con status 200 para mantener consistencia.
        //    if (response.status == "204")
        //        return controller.Ok(response);

        //    // 400 Solicitud incorrecta: La solicitud es inválida o no puede ser procesada.
        //    if (response.status == "400")
        //        return controller.BadRequest(response);

        //    // 401 No autorizado: La autenticación es requerida o falló, se retorna el objeto con status 401.
        //    if (response.status == "401")
        //        return controller.StatusCode(401, response);

        //    // 403 Prohibido: El servidor entendió la solicitud pero se niega a autorizarla.
        //    if (response.status == "403")
        //        return controller.StatusCode(403, response);

        //    // 404 No encontrado: El recurso solicitado no existe.
        //    if (response.status == "404")
        //        return controller.NotFound(response);

        //    // 409 Conflicto: La solicitud no pudo ser completada debido a un conflicto con el estado actual del recurso.
        //    if (response.status == "409")
        //        return controller.Conflict(response);

        //    // 422 Entidad no procesable: La solicitud está bien formada pero no se puede procesar por errores semánticos.
        //    if (response.status == "422")
        //        return controller.UnprocessableEntity(response);

        //    // 429 Demasiadas solicitudes: El usuario ha enviado demasiadas solicitudes en un periodo de tiempo.
        //    if (response.status == "429")
        //        return controller.StatusCode(429, response);

        //    // 500 Error interno del servidor: Error genérico cuando no hay un mensaje más específico.
        //    return controller.StatusCode(500, response);
        //}

        public static CrsApiResponse<T> GetGenericResponse<T>(T resultado)
        {
            var response = new CrsApiResponse<T>
            {
                hasError = false,
                status = HttpStatusCode.OK,
                result = resultado,
                messages = new List<Message>()
            };

            // Si es lista y está vacía
            if (resultado is IEnumerable enumerable && !(resultado is string))
            {
                var enumerator = enumerable.GetEnumerator();
                if (!enumerator.MoveNext())
                {
                    response.messages.Add(new Message { userMessage = "No hay registros." });
                    response.status = HttpStatusCode.NoContent; // No Content
                }
            }
            // Si es objeto y es null
            else if (resultado == null)
            {
                response.messages.Add(new Message { userMessage = "No se encontró el registro." });
                response.status = HttpStatusCode.NoContent; // Not Found // lo cambie a no Content
                response.hasError = true;
            }
            // Si es un tipo numérico y es cero
            else if ((resultado is int i && i == 0) ||
                     (resultado is long l && l == 0L) ||
                     (resultado is double d && Math.Abs(d) < double.Epsilon))
            {
                response.messages.Add(new Message { userMessage = "El valor es cero." });
                response.status = HttpStatusCode.NoContent; // No Content
            }

            else if (resultado != null)
            {
                var tipo = resultado.GetType();
                var exitoProp = tipo.GetProperties()
                    .FirstOrDefault(p => string.Equals(p.Name, "EXITO", StringComparison.OrdinalIgnoreCase));

                if (exitoProp != null && exitoProp.PropertyType == typeof(bool))
                {
                    var exitoValue = (bool)exitoProp.GetValue(resultado)!;
                    if (!exitoValue)
                    {
                        var mensajeProp = tipo.GetProperties()
                            .FirstOrDefault(p => string.Equals(p.Name, "MENSAJE", StringComparison.OrdinalIgnoreCase));
                        string mensaje = "Error interno del servicio.";
                        if (mensajeProp != null)
                        {
                            var mensajeValue = mensajeProp.GetValue(resultado);
                            if (mensajeValue != null)
                                mensaje = mensajeValue.ToString()!;
                        }
                        response.messages.Add(new Message { userMessage = mensaje });
                        response.status = HttpStatusCode.InternalServerError;
                        response.hasError = true;
                        return response;
                    }
                }
            }

            return response;
        }

        //public static async Task<CrsApiResponse<T>> EjecutarOperacionAsync<T>(
        //    Func<Task<T>> operacion,
        //    Func<bool> validarCredenciales,
        //    string nombreMetodo,
        //    string mensajeSinContenido = "No se encontraron datos.",
        //    string mensajeParametroInvalido = "Parámetro inválido o faltante.")
        //{
        //    var response = new CrsApiResponse<T>();
        //    try
        //    {
        //        if (!validarCredenciales())
        //        {
        //            response.status = "401";
        //            response.hasError = true;
        //            response.messages = new List<Message>
        //            {
        //                new Message { code = "CredencialesInvalidas", message = "Credenciales inválidas o faltantes." }
        //            };
        //            return response;
        //        }

        //        var resultado = await operacion();

        //        // Verifica si el resultado es nulo o una colección vacía
        //        if (resultado == null ||
        //            (resultado is ICollection collection && collection.Count == 0))
        //        {
        //            response.status = "204";
        //            response.hasError = false;
        //            response.result = default;
        //            response.messages = new List<Message>
        //            {
        //                new Message { code = "SinContenido", message = mensajeSinContenido }
        //            };
        //            return response;
        //        }

        //        response.status = "200";
        //        response.hasError = false;
        //        response.result = resultado;
        //        response.messages = null;
        //        return response;
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex.Message);
        //        CComplexParameters<T>.GetValidacionResult(ref response, ex, nombreMetodo, string.Empty, "Error interno");
        //        response.status = "500";
        //        response.hasError = true;
        //        return response;
        //    }
        //}

        //public static async Task<CrsApiResponse<T>> ResponderAsync<T>(
        //    Func<T> obtenerDato,
        //    Func<bool> validarCredenciales,
        //    bool validarCred = true)
        //{
        //    var response = new CrsApiResponse<T>();
        //    try
        //    {
        //        if (validarCred && !validarCredenciales())
        //        {
        //            response.hasError = true;
        //            response.status = "401";
        //            response.messages.Add(new Message { userMessage = "Credenciales inválidas." });
        //            return response;
        //        }

        //        var dato = obtenerDato();
        //        response.result = dato;
        //        response.status = "200";
        //        response.hasError = false;

        //        // Si es lista y está vacía
        //        if (dato is IEnumerable enumerable && !(dato is string))
        //        {
        //            var enumerator = enumerable.GetEnumerator();
        //            if (!enumerator.MoveNext())
        //                response.messages.Add(new Message { userMessage = "No hay registros." });
        //        }
        //        // Si es objeto y es null
        //        else if (dato == null)
        //        {
        //            response.messages.Add(new Message { userMessage = "No se encontró el registro." });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        response.hasError = true;
        //        response.status = "500";
        //        response.errors.Add(new ErrorDetail { errorMessage = ex.Message });
        //        response.messages.Add(new Message { userMessage = "Error interno." });
        //    }
        //    return response;
        //}
    }
}
