﻿
namespace Common.Decrypt
{
    public interface IEncryptadorHelpers
    {
        bool EncryptDecryptPublic(bool enDec, string strInput, ref string strOutput);
    }
}