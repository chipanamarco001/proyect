﻿using System.Runtime.InteropServices;

namespace Common.Decrypt
{
    public class EncryptadorHelpers : IEncryptadorHelpers
    {
        public EncryptadorHelpers()
        {
        }

        public bool EncryptDecryptPublic(bool enDec, string strInput, ref string strOutput)
        {
            return EncryptadorHelpers.EncryptDecrypt(enDec, strInput, ref strOutput);
        }

        /// <summary>
        /// Función wraper para encriptar y desencriptar valores - Segurinet
        /// </summary>
        /// <param name="EnDec">true - Encriptar, false - Desencriptar</param>
        /// <param name="InputString">String Valor</param>
        /// <param name="OutputRaw">Resultado</param>
        /// <param name="Length">Tamaño del string destino.</param>
        /// <returns></returns>
        unsafe private static bool EncryptDecrypt(bool enDec, string strInput, ref string strOutput)
        {
            bool res = false;

            int chrSize = strInput.Length * 10;
            byte[] byteRes = new byte[chrSize];
            strOutput = "";

            fixed (byte* pByteRes = &byteRes[0])
            {
                res = EncryptDecrypt(enDec, strInput, pByteRes, &chrSize);
                for (int i = 0; i < chrSize; i++)
                    strOutput += ((char)*(pByteRes + i));
            }
            return res;
        }


        /// <summary>
        /// Función para encriptar y desencriptar valores - Segurinet
        /// </summary>
        /// <param name="EnDec">true - Encriptar, false - Desencriptar</param>
        /// <param name="InputString">String Valor</param>
        /// <param name="OutputRaw">Resultado</param>
        /// <param name="Length">Tamaño del string destino.</param>
        /// <returns></returns>
        /// 

        //[DllImport(@"SegCryptCrediSeguros.dll")]       
        //[DllImport(@"C:\Windows\System32\SegCryptCrediSeguros.dll", CallingConvention = CallingConvention.Cdecl)]
        //[DllImport(@"C:\Windows\SysWOW64\SegCryptCrediSeguros.dll", CallingConvention = CallingConvention.Cdecl)]

        //[DllImport(@"D:\Eynar\otros\DecryptDLL\SegCryptCrediSeguros_x64.dll", CallingConvention = CallingConvention.Cdecl)]
        //[DllImport(@"D:\Eynar\otros\DecryptDLL\SegCryptCrediSeguros_x86.dll", CallingConvention = CallingConvention.Cdecl)]
        //[DllImport(@"SegCryptCrediSegurosx86.dll", CallingConvention = CallingConvention.Cdecl)]

        //este funciona en local pero no en devcrs02
        //[DllImport(@"SegCryptCrediSegurosx64.dll", CallingConvention = CallingConvention.Cdecl)]        
        //unsafe private static extern bool EncryptDecrypt(bool EnDec, string InputString, byte* OutputRaw, int* Length);

        //este funciona en el devcrs02 pero no en local
        //[DllImport(@"SegCryptCrediSeguros.dll")]

        //este funciona en local pero no en devcrs02
        [DllImport(@"SegCryptCrediSegurosx64.dll")]
        unsafe private static extern bool EncryptDecrypt(bool EnDec, string InputString, byte* OutputRaw, int* Length);
    }
}
    
