﻿using Common.Parameters;
using Logics.ConsumoAfiliacion;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ConsumoTransaccional.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CobrosController : ControllerBase
    {
        private readonly ICobros _iCobros;
        public CobrosController(ICobros iCobros)
        {
            _iCobros = iCobros;
        }

        #region Cobro

        [Authorize]
        [HttpPost("RegistrarCobroInicial")]
        public async Task<IActionResult> RegistrarCobroInicial(CrsApiRequest<CobroRegistroInicialDto> request)
        {
            try
            {
                var response = await _iCobros.RegistrarCobroInicial(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPut("ActualizarCobro")]
        public async Task<IActionResult> ActualizarCobro(CrsApiRequest<CobroActualizarDto> request)
        {
            try
            {
                var response = await _iCobros.ActualizarCobro(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
