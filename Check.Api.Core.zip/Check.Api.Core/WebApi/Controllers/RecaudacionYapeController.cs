﻿using Common.Parameters;
using Logics.ConsumoAfiliacion;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ConsumoRecaudacionBCP.IRepository;
using Logics.ConsumoRecaudacionYape;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Models.OcDtos.OcRecYapeDtos;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecaudacionYapeController : ControllerBase
    {
        private readonly IRecaudacionYape _iRecaudacionYape;
        public RecaudacionYapeController(IRecaudacionYape iRecaudacionYape)
        {
            _iRecaudacionYape = iRecaudacionYape;
        }

        #region Consulta

        [HttpPost("ObtenerDatosConsulta")]
        public async Task<IActionResult> ObtenerDatosConsulta(BcpApiRequest<ConsultaRequestDto> request)
        {
            try
            {
                var response = await _iRecaudacionYape.ObtenerDatosConsulta(request);
                return BcpResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region pago
        [HttpPost("RegistrarPago")]
        public async Task<IActionResult> ActualizarCobroBCP(BcpApiRequest<PagoRequest> request)
        {
            try
            {
                var response = await _iRecaudacionYape.ActualizarCobroBCP(request);
                return BcpResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region Reversion

        [HttpPost("RegistrarReversion")]
        public async Task<IActionResult> ReversionBCP(BcpApiRequest<ReversionRequest> request)
        {
            try
            {
                var response = await _iRecaudacionYape.ReversionBCP(request);
                return BcpResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion


    }
}
