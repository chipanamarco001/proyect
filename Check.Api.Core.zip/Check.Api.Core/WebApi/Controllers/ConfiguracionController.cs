﻿using Common.Parameters;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioTransaccional;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using static Models.ModelCheck.OcCheck;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConfiguracionController : ControllerBase
    {
        private readonly IConfiguracion _configuracion;

        public ConfiguracionController(IConfiguracion configuracion)
        {
            _configuracion = configuracion;
        }

        #region Lexico

        [Authorize]
        [HttpPost("ObtenerListaLexicoPorTabla")]
        public async Task<IActionResult> ObtenerListaLexicoPorTabla(CrsApiRequest<LexicoTablaRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaLexicoPorTabla(request.solicitud.tabla, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost("ObtenerListaLexicoPorTablaTema")]
        public async Task<IActionResult> ObtenerListaLexicoPorTablaTema(CrsApiRequest<LexicoTablaTemaRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaLexicoPorTablaTema(request.solicitud.tabla, request.solicitud.tema, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Base Yape

        [Authorize]
        [HttpPost("ObtenerListaClienteYapePorDocumentoCorreo")]
        public async Task<IActionResult> ObtenerListaClienteYapePorDocumentoCorreo(CrsApiRequest<ObtenerClienteBaseYapeRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaClienteYapePorDocumentoCorreo(request.solicitud.numeroDocumento, request.solicitud.correo, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Producto

        [Authorize]
        [HttpPost("ObtenerListaProductoActivo")]
        public async Task<IActionResult> ObtenerListaProductoActivo(CrsApiRequest request)
        {
            try
            {
                var response = await _configuracion.ObtenerListaProductoActivo(request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Producto Parametro

        [Authorize]
        [HttpPost("ObtenerProductoParametroPorIdSubProducto")]
        public async Task<IActionResult> ObtenerProductoParametroPorIdSubProducto(CrsApiRequest<ObtenerSubProductoParametroRequest> request)
        {
            try
            {
                var response = await _configuracion.ObtenerProductoParametroPorIdSubProducto(request.solicitud.idSubProducto, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Sub producto

        [Authorize]
        [HttpPost("ObtenerSubProductoPorIdProdDescripcion")]
        public async Task<IActionResult> ObtenerSubProductoPorIdProdDescripcion(CrsApiRequest<SubProductoBuscarIdProdDescripcion> request)
        {
            try
            {
                var response = await _configuracion.ObtenerSubProductoPorIdProdDescripcion(request.solicitud.idProducto, request.solicitud.descripcion, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Errores

        //[Authorize]
        [HttpPost("RegistrarError")]
        public async Task<IActionResult> RegistrarError(CrsApiRequest<ErrorRegistrarDto> request)
        {
            try
            {
                var response = await _configuracion.RegistrarError(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
