﻿using Common.Parameters;
using Logics.ConsumoAfiliacion.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AfiliacionController : ControllerBase
    {
        private readonly IAfiliacion _iAfiliacion;

        public AfiliacionController(IAfiliacion iAfiliacion)
        {
            _iAfiliacion = iAfiliacion;
        }

        #region Afiliacion

        [Authorize]
        [HttpPost("RegistrarAfiliacionColectiva")]
        public async Task<IActionResult> RegistrarAfiliacionColectiva(CrsApiRequest<AfiliacionColectivaRegistrarDto> request)
        {
            try
            {
                var response = await _iAfiliacion.RegistrarAfiliacionColectiva(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost("ObtenerAfiliacionPorId")]
        public async Task<IActionResult> ObtenerAfiliacionPorId(CrsApiRequest<AfiliacionIdAfiliacionDto> request)
        {
            try
            {
                var response = await _iAfiliacion.ObtenerAfiliacionPorId(request.solicitud.idAfiliacion, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPut("ActualizarEstadoAfiliacion")]
        public async Task<IActionResult> ActualizarEstadoAfiliacion(CrsApiRequest<AfiliacionActualizarEstadoDto> request)
        {
            try
            {
                var response = await _iAfiliacion.ActualizarEstadoAfiliacion(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Asegurado

        [Authorize]
        [HttpPost("RegistrarAsegurado")]
        public async Task<IActionResult> RegistrarAsegurado(CrsApiRequest<AseguradoRegistrarDto> request)
        {
            try
            {
                var response = await _iAfiliacion.RegistrarAsegurado(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Beneficiario

        [Authorize]
        [HttpPost("RegistrarBeneficiario")]
        public async Task<IActionResult> RegistrarBeneficiario(CrsApiRequest<BeneficiarioRegistrarDto> request)
        {
            try
            {
                var response = await _iAfiliacion.RegistrarBeneficiario(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}
