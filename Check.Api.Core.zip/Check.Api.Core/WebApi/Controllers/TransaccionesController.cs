  using Common.Parameters;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioTransaccional;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtos;
using Models.OcDtos.OcDtosModel;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransaccionesController : ControllerBase
    {
        private readonly ITransacciones _iTransacciones;

        public TransaccionesController(ITransacciones iTransacciones)
        {
            _iTransacciones = iTransacciones;           
        }

        #region OTP

        [Authorize]
        [HttpPost("ObtenerCodigoOtp")]
        public async Task<IActionResult> ObtenerCodigoOtp(CrsApiRequest<GeneraOtpRequest> request)
        {
            try
            {
                var response = await _iTransacciones.GenerateOtpCode(request.solicitud.correo, request.solicitud.numero, request.solicitud.numeroDocumento, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost("ValidarCodigoOtp")]
        public async Task<IActionResult> ValidarCodigoOtp(CrsApiRequest<ValidaOtpRequest> request)
        {
            try
            {
                var response = await _iTransacciones.ValidateOtpCode(request.solicitud.codigo, request.solicitud.numeroDocumento, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Qr

        [Authorize]
        [HttpPost("GenerarQrDebito")]
        public async Task<IActionResult> GenerarQrDebito(CrsApiRequest<GeneraQrRequest> request)
        {
            try
            {
                var response = await _iTransacciones.GenerarQrDebito(request.solicitud.moneda, request.solicitud.monto, request.solicitud.glosa, request.solicitud.coleccion, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Servicio Segip

        [Authorize]
        [HttpPost("ValidacionSegipCampoACampo")]
        public async Task<IActionResult> ValidacionSegipCampoACampo(CrsApiRequest<AseguradoSegipDto> request)
        {
            try
            {
                var response = await _iTransacciones.ValidacionSegipCampoACampo(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Servicio LInternacionales

        [Authorize]
        [HttpPost("ValidarLInternacionalesANegativo")]
        public async Task<IActionResult> ValidarLInternacionalesANegativo(CrsApiRequest<AseguradoLInternacionalesDto> request)
        {
            try
            {
                var response = await _iTransacciones.ValidarLInternacionalesANegativo(request.solicitud, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Correos

        [Authorize]
        [HttpPost("EnviarCorreoYape")]
        public async Task<IActionResult> EnviarCorreoYape(CrsApiRequest<EnviarCorreoDto> request)
        {
            try
            {
                var response = await _iTransacciones.EnviarCorreoYape(request.solicitud.idAfiliacion, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion

        #region Correos

        [Authorize]
        [HttpPost("ObtenerCertificadoYape")]
        public async Task<IActionResult> ObtenerCertificadoYape(CrsApiRequest<CertificadoObtenerDto> request)
        {
            try
            {
                var response = await _iTransacciones.ObtenerCertificadoYape(request.solicitud.idAfiliacion, request.credenciales);
                return ApiResponseHelper.HandleApiResponse(this, response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        #endregion
    }
}