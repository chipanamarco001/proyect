using Microsoft.AspNetCore.Http;
using Serilog.Context;
using System.Threading.Tasks;

public class LogEnrichmentMiddleware
{
    private readonly RequestDelegate _next;

    public LogEnrichmentMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        var ip = context.Connection.RemoteIpAddress?.ToString();
        var usuario = context.User?.Identity?.Name ?? "Anonimo";
        var url = context.Request.Path;

        using (LogContext.PushProperty("IpConsumo", ip))
        using (LogContext.PushProperty("Usuario", usuario))
        using (LogContext.PushProperty("ServicioConsultado", url))
        {
            await _next(context);
        }
    }
}