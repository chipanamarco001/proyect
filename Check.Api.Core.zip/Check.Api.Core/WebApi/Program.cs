using AutoMapper;
using Common.Parameters;
using Logics.ApiMapper;
using Logics.ConsumoAfiliacion;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ConsumoConfiguracion;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ConsumoRecaudacionBCP.IRepository;
using Logics.ConsumoRecaudacionYape;
using Logics.ConsumoTransaccional;
using Logics.ConsumoTransaccional.IRepository;
using Logics.ServicioTransaccional;
using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Models.Dtos;
using Newtonsoft;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Text;
using WebApi;

var builder = WebApplication.CreateBuilder(args);
//aqui configuramos para que los campos mantengan mayusculas o minusculas en su primera letra
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
    });

builder.Services.AddAutoMapper(typeof(ApiMapperAutenticacion));
// Obt�n la cadena de conexi�n desde appsettings.json
var connectionString = builder.Configuration.GetConnectionString("ConexionSql");

// Configura el logger con la cadena de conexi�n
Log.Configure(connectionString);
//Log.Info("Logger inicializado desde Common");

//Configuramos la conexion a sql server
builder.Services.AddDbContext<ApplicationDbContext>(opciones =>
{
    opciones.UseSqlServer(connectionString);
});

builder.Services.AddDbContext<ApplicationDbSpContext>(opciones =>
{
    opciones.UseSqlServer(connectionString);
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

//builder.Services.AddScoped<IAfiliacionAuth, AfiliacionAuth>();
builder.Services.AddScoped<IConfiguracion, Configuracion>();
builder.Services.AddScoped<ITransacciones, Transacciones>();
builder.Services.AddScoped<IAfiliacion, Afiliacion>();
builder.Services.AddScoped<ICobros, Cobros>();
builder.Services.AddScoped<IAutenticacion, Autenticacion>();
builder.Services.AddScoped<IRecaudacionYape, RecaudacionYape>();

// Add services to the container.
builder.Services.AddScoped<AfiliacionRepository>();
builder.Services.AddScoped<AseguradoRepository>();
builder.Services.AddScoped<BeneficiarioRepository>();
builder.Services.AddScoped<CobroRepository>();
builder.Services.AddScoped<DocumentoParametroRepository>();
builder.Services.AddScoped<DocumentoRepository>();
builder.Services.AddScoped<ErrorRepository>();
builder.Services.AddScoped<LexicoRepository>();
builder.Services.AddScoped<LogServicioRepository>();
builder.Services.AddScoped<MenuRepository>();
builder.Services.AddScoped<MovimientoRepository>();
builder.Services.AddScoped<NivelRepository>();
builder.Services.AddScoped<ProductoRepository>();
builder.Services.AddScoped<RecaudacionYapeRepository>();
builder.Services.AddScoped<RolRepository>();
builder.Services.AddScoped<SubProductoParametroRepository>();
builder.Services.AddScoped<SubProductoRepository>();
builder.Services.AddScoped<TokenRepository>();
builder.Services.AddScoped<UsuarioRepository>();

builder.Services.AddScoped<ServicioOTP>();
builder.Services.AddScoped<ServicioQr>();
builder.Services.AddScoped<CManejadorBaseDatos>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    //var connectionString =  configuration.GetConnectionString("DefaultConnection");
    return new CManejadorBaseDatos(connectionString);
});
builder.Services.AddScoped<BaseYapeDRepository>(provider =>
{
    var configuration = provider.GetRequiredService<IConfiguration>();
    return new BaseYapeDRepository(connectionString);
});
builder.Services.AddScoped<ServicioDocumentos>();


//Agregar el automapper
builder.Services.AddAutoMapper(typeof(ApiMapperAfiliacion));
builder.Services.AddAutoMapper(typeof(ApiMapperAutenticacion));
builder.Services.AddAutoMapper(typeof(ApiMapperCobros));
builder.Services.AddAutoMapper(typeof(ApiMapperConfiguracion));
builder.Services.AddAutoMapper(typeof(ApiMapperTransacciones));

// Agregar configuraci�n de JWT
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidAudience = jwtSettings["Audience"],
        IssuerSigningKey = key,
        ClockSkew = TimeSpan.FromMinutes(5) // Tolerancia de 5 minutos
    };
    options.Events = new JwtBearerEvents
    {
        OnMessageReceived = context =>
        {
            //Console.WriteLine("Token recibido por middleware: [" + context.Token + "]");
            // Extrae el token manualmente del header
            var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
            if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                context.Token = authHeader.Substring("Bearer ".Length).Trim();
            }
            //Console.WriteLine("Token recibido por middleware (manual): [" + context.Token + "]");
            return Task.CompletedTask;
        },
        OnTokenValidated = async context =>
        {
            // Intenta obtener el token desde el header Authorization
            var authHeader = context.HttpContext.Request.Headers["Authorization"].FirstOrDefault();
            string tokenString = null;

            if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                tokenString = authHeader.Substring("Bearer ".Length).Trim();
            }
            else if (context.SecurityToken is JwtSecurityToken jwtToken)
            {
                // Fallback: usa el RawData si el cast es v�lido
                tokenString = jwtToken.RawData;
            }

            // Obt�n el servicio de autenticaci�n desde el contenedor DI
            var authService = context.HttpContext.RequestServices.GetRequiredService<IAutenticacion>();

            // Llama a tu m�todo de validaci�n
            var result = await authService.ValidarToken(tokenString);

            // Si el token no es v�lido en base de datos, rechaza la autenticaci�n
            if (result == null || result.status != System.Net.HttpStatusCode.OK)
            {
                context.Fail("Token no v�lido en base de datos.");
            }
        },
        OnAuthenticationFailed = context =>
        {
            Console.WriteLine("Token inv�lido: " + context.Exception.Message);
            Console.WriteLine("Key: [" + jwtSettings["Key"] + "]");
            Console.WriteLine("Issuer: [" + jwtSettings["Issuer"] + "]");
            Console.WriteLine("Audience: [" + jwtSettings["Audience"] + "]");
            return Task.CompletedTask;
        },

        OnChallenge = context =>
        {
            context.HandleResponse();
            context.Response.StatusCode =(int)HttpStatusCode.Unauthorized;
            context.Response.ContentType = "application/json";

            var json = JsonConvert.SerializeObject(new CrsApiResponse<object>
            {
                status = HttpStatusCode.Unauthorized,
                hasError = false,
                errors = new List<ErrorDetail>(),
                messages = new List<Message>
                {
                    new Message
                    {
                        userMessage = "Token inv�lido o expirado. Por favor, inicie sesi�n nuevamente.",
                        messageTec="Token Invalid",
                        methodName = "JWT Authentication Middleware"
                    }
                },

            }, Formatting.Indented);
            return context.Response.WriteAsync(json);
        }

    };
});

//validamos los datos que estan llegando a la api y retornamos un error personalizado si hay errores de validaci�n
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        // Obtiene los errores de validaci�n, uno por cada campo con error
        var errors = context.ModelState
            .Where(e => e.Value.Errors.Count > 0)
            .SelectMany(e => e.Value.Errors.Select(x => new ErrorDetail
            {
                propertyName = e.Key,
                errorMessage = x.ErrorMessage
            }))
            .ToList();

        var response = new Models.Dtos.CrsApiResponse<object>
        {
            status = HttpStatusCode.BadRequest,
            hasError = true,
            errors = errors,
            messages = new List<Message>
            {
                new Message
                {
                    userMessage = "Error de validaci�n: por favor revise los datos que est� enviando."
                }
            },
            result = null
        };

        return new BadRequestObjectResult(response);
    };
});
/*******************/

builder.Services.AddControllers()
.ConfigureApiBehaviorOptions(
options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        var errorMessage = context.ModelState
        .Values
        .SelectMany(v => v.Errors)
        .Select(e => e.ErrorMessage)
        .FirstOrDefault() ?? "Invalid input.";
        var errorDetails = context.ModelState
        .Values
        .SelectMany(v => v.Errors)
        .Select(e => e.ErrorMessage)
        .LastOrDefault();


        var errorResponse = new CrsApiResponse<object>
        {
            status = HttpStatusCode.BadRequest,
            hasError = true,
            errors = new List<ErrorDetail>
            {
                new ErrorDetail
                {
                    errorMessage = errorMessage ,
                    propertyName = context.ModelState.Keys.FirstOrDefault() ?? "Unknown",
                    errorUsuario = "Invalid input",
                    innerException = context.HttpContext.Request.Path + " -->" + errorDetails,
                    methodName = "Model Validation",
                    stackTrace = string.Empty // Puedes agregar m�s informaci�n si es necesario

                }
            },
            messages = new List<Message>
            {
                new Message
                {
                    userMessage = "Error de validaci�n: por favor revise los datos que est� enviando.",
                    messageTec = errorMessage,
                    methodName = "Model Validation"
                }
            },
            result = null

        };

        return new BadRequestObjectResult(errorResponse);
    };
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "api crs check", Version = "v1" });

    // Configuraci�n para JWT
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Ingrese el token JWT"// en este formato: Bearer {token}"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});



var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger(options => options.OpenApiVersion = Microsoft.OpenApi.OpenApiSpecVersion.OpenApi3_0);
app.UseSwaggerUI();
//}

app.UseCors();

app.UseMiddleware<LogEnrichmentMiddleware>();

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
