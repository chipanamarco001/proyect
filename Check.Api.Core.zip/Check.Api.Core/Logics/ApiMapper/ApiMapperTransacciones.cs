﻿using AutoMapper;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperTransacciones : Profile
    {
        public ApiMapperTransacciones()
        {
            #region Qr

            // SERVICIO_QR <-> ServicioQrDto
            CreateMap<SERVICIO_QR, ServicioQrDto>()
                .ForMember(dest => dest.idLogServicio, opt => opt.MapFrom(src => src.SEPBI_ID_LOG_SERVICIO))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.SEPVC_TIPO))
                .ForMember(dest => dest.url, opt => opt.MapFrom(src => src.SEPVC_URL))
                .ForMember(dest => dest.request, opt => opt.MapFrom(src => src.SEPVC_REQUEST))
                .ForMember(dest => dest.response, opt => opt.MapFrom(src => src.SEPVC_RESPONSE))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.SEPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.SESDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.SESVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.SESDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.SESVC_ID_USER_MODIF))
                .ReverseMap();

            #endregion

            #region Segip

            //CreateMap<AseguradoSegipDto, ASEGURADO>()
            //  .ForMember(dest => dest.ASPVB_DOCUMENTO_NUMERO, opt => opt.MapFrom(src => src.numeroDocumento))
            //  .ForMember(dest => dest.ASSVB_DOCUMENTO_COMPLEMENTO, opt => opt.MapFrom(src => src.complemento))
            //  .ForMember(dest => dest.ASPDT_FECHA_NACIMIENTO, opt => opt.MapFrom(src => src.fechaNacimiento))
            //  .ForMember(dest => dest.ASPVB_NOMBRES, opt => opt.MapFrom(src => src.nombre))
            //  .ForMember(dest => dest.ASSVB_APELLIDO_PATERNO, opt => opt.MapFrom(src => src.apPaterno))
            //  .ForMember(dest => dest.ASSVB_APELLIDO_MATERNO, opt => opt.MapFrom(src => src.apMaterno))
            //  .ForMember(dest => dest.ASSVB_CIUDAD, opt => opt.MapFrom(src => src.ciudad))
            //  .ForMember(dest => dest.ASSVC_NACIONALIDAD, opt => opt.MapFrom(src => src.nacionalidad))
            //  .ForMember(dest => dest.ASPVC_DOCUMENTO_TIPO, opt => opt.MapFrom(src => src.tipoDocumento))
            //  .ReverseMap();

            //CreateMap<AseguradoSegipDto, AseguradoRegistrarDto>()
            //    .ForMember(dest => dest.numeroDocumento, opt => opt.MapFrom(src => src.numeroDocumento.ToString()))
            //    .ForMember(dest => dest.complementoDocumento, opt => opt.MapFrom(src => src.complemento))
            //    .ForMember(dest => dest.nombre, opt => opt.MapFrom(src => src.nombre))
            //    .ForMember(dest => dest.apellidoPaterno, opt => opt.MapFrom(src => src.apPaterno))
            //    .ForMember(dest => dest.apellidoMaterno, opt => opt.MapFrom(src => src.apMaterno))
            //    .ForMember(dest => dest.ciudad, opt => opt.MapFrom(src => src.ciudad))
            //    .ForMember(dest => dest.nacionalidad, opt => opt.MapFrom(src => src.nacionalidad))
            //    .ForMember(dest => dest.ocupacion, opt => opt.Ignore()) // Si no hay campo equivalente
            //    .ForMember(dest => dest.apellidoCasada, opt => opt.Ignore()) // Si no hay campo equivalente
            //                                                                 //.ForAllOtherMembers(opt => opt.Ignore());
            //    .ReverseMap();      

            #endregion

        }
    }
}
