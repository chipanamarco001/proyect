﻿using AutoMapper;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperAfiliacion : Profile
    {
        public ApiMapperAfiliacion()
        {

            CreateMap<AFILIACION, AfiliacionDto>()
               .ForMember(dest => dest.idAfiliacion, opt => opt.MapFrom(src => src.AFPBI_ID_AFILIACION))
               .ForMember(dest => dest.idPoliza, opt => opt.MapFrom(src => src.POPVC_ID_POLIZA))
               .ForMember(dest => dest.idNivel, opt => opt.MapFrom(src => src.NIPVC_ID_NIVEL))
               .ForMember(dest => dest.numeroCertificado, opt => opt.MapFrom(src => src.AFPVC_NUMERO_CERTIFICADO))
               .ForMember(dest => dest.inicioVigencia, opt => opt.MapFrom(src => src.AFPDT_INICIO_VIGENCIA))
               .ForMember(dest => dest.finVigencia, opt => opt.MapFrom(src => src.AFPDT_FIN_VIGENCIA))
               .ForMember(dest => dest.estadoAfiliacion, opt => opt.MapFrom(src => src.AFPVC_ESTADO_AFILIACION))
               .ForMember(dest => dest.fechaDesafiliacion, opt => opt.MapFrom(src => src.AFSDT_FECHA_DESAFILIACION))
               .ForMember(dest => dest.tipoDesafiliacion, opt => opt.MapFrom(src => src.AFSVC_TIPO_DESAFILIACION))
               .ForMember(dest => dest.descripcionDesafiliacion, opt => opt.MapFrom(src => src.AFSVC_DESCRIPCION_DESAFILIACION))
               .ForMember(dest => dest.idDepartamento, opt => opt.MapFrom(src => src.AFPCH_ID_DEPARTAMENTO))
               .ForMember(dest => dest.flagInnomindado, opt => opt.MapFrom(src => src.AFPBT_FLAG_INNOMINADO))
               .ForMember(dest => dest.comentarios, opt => opt.MapFrom(src => src.AFSVC_COMENTARIOS))
               .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.AFPBT_ACTIVO))
               .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.AFSDT_FECHA_INSERT))
               .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.AFSVC_ID_USER_INSERT))
               .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.AFSDT_FECHA_MODIF))
               .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.AFSVC_ID_USER_MODIF))
               .ForMember(dest => dest.idCarga, opt => opt.MapFrom(src => src.AFSIN_ID_CARGA))
               .ReverseMap();

            CreateMap<AFILIACION, AfiliacionActualizarEstadoDto>()
                .ForMember(dest => dest.idAfiliacion, opt => opt.MapFrom(src => src.AFPBI_ID_AFILIACION))
                .ForMember(dest => dest.estado, opt => opt.MapFrom(src => src.AFPVC_ESTADO_AFILIACION))
                .ReverseMap()
                .ForMember(dest => dest.AFPBI_ID_AFILIACION, opt => opt.MapFrom(src => src.idAfiliacion))
                .ForMember(dest => dest.AFPVC_ESTADO_AFILIACION, opt => opt.MapFrom(src => src.estado))
                .ForMember(dest => dest.SUPBI_ID_SUB_PRODUCTO, opt => opt.Ignore()) // Explicitly ignore unmapped members
                .ForMember(dest => dest.DOPVC_ID_DOCUMENTO_CERTIFICADO, opt => opt.Ignore()) // Explicitly ignore unmapped members
                .ForMember(dest => dest.ASEGURADO, opt => opt.Ignore()) // Explicitly ignore unmapped members
                .ForMember(dest => dest.BENEFICIARIO, opt => opt.Ignore()) // Explicitly ignore unmapped members
                .ForMember(dest => dest.NIPVC_ID_NIVELNavigation, opt => opt.Ignore()) // Explicitly ignore unmapped members
                .ForMember(dest => dest.POPVC_ID_POLIZANavigation, opt => opt.Ignore()); // Explicitly ignore unmapped members
        }
    }
}
