﻿using AutoMapper;
using Common.Decrypt;
using ManageDB.SqlRepository;
using Models.DtosSp;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperAutenticacion : Profile
    {

        public ApiMapperAutenticacion()
        {

            #region usuario
            // USUARIO <-> UsuarioDto
            CreateMap<USUARIO, UsuarioDto>()
                .ForMember(dest => dest.idUsuario, opt => opt.MapFrom(src => src.USPVC_ID_USUARIO))
                //.ForMember(dest => dest.apellidoPaterno, opt => opt.MapFrom(src => src.USSVC_APELLIDO_PATERNO))
                //.ForMember(dest => dest.apellidoMaterno, opt => opt.MapFrom(src => src.USSVC_APELLIDO_MATERNO))
                .ForMember(dest => dest.nombreCompleto, opt => opt.MapFrom(src => src.USPVC_NOMBRE_COMPLETO))
                .ForMember(dest => dest.correo, opt => opt.MapFrom(src => src.USPVC_CORREO))
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.USPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.USSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.USSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.USSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.USSVC_ID_USER_MODIF))
                .ReverseMap();

            CreateMap<UsuarioRegistroDto, USUARIO>()
               .ForMember(dest => dest.USPVC_ID_USUARIO, opt => opt.MapFrom(src => src.idUsuario))
               .ForMember(dest => dest.USPVC_TIPO, opt => opt.MapFrom(src => src.tipo))
               .ForMember(dest => dest.USPVC_NOMBRE_COMPLETO, opt => opt.MapFrom(src => src.nombreCompleto))
               .ForMember(dest => dest.USPVC_CORREO, opt => opt.MapFrom(src => src.correo))
               .ForMember(dest => dest.USPCH_ID_DEPARTAMENTO, opt => opt.MapFrom(src => src.departamento))
               .ForMember(dest => dest.USPBT_PASSWORD, opt => opt.MapFrom(src => Cryptography.Encrypt(src.password)))
               .ForMember(dest => dest.USPBT_PASSWORD_RESETEO, opt => opt.MapFrom(src => Cryptography.Encrypt(src.passwordReseteo)))
               .ForMember(dest => dest.ROPBI_ID_ROL, opt => opt.MapFrom(src => src.idRol))
               .ForMember(dest => dest.USPBT_ACTIVO, opt => opt.MapFrom(src => true))
               .ForMember(dest => dest.USSDT_FECHA_INSERT, opt => opt.MapFrom(src => DateTime.Now))
               .ForMember(dest => dest.USSVC_ID_USER_INSERT, opt => opt.Ignore())
               .ForMember(dest => dest.USSDT_FECHA_MODIF, opt => opt.Ignore())
               .ForMember(dest => dest.USSVC_ID_USER_MODIF, opt => opt.Ignore())
                .ReverseMap();

            // Mapeo de UsuarioRegistroCanalDto a USUARIO
            CreateMap<UsuarioRegistroCanalDto, USUARIO>()
                .ForMember(dest => dest.USPVC_ID_USUARIO, opt => opt.MapFrom(src => src.idUsuario))
                .ForMember(dest => dest.USPVC_NOMBRE_COMPLETO, opt => opt.MapFrom(src => src.nombreCompleto))
                .ForMember(dest => dest.USPBT_PASSWORD, opt => opt.MapFrom(src => Cryptography.Encrypt(src.password)))
                // Valores por defecto o requeridos por la entidad
                .ForMember(dest => dest.USPVC_TIPO, opt => opt.MapFrom(src => "CANAL"))
                .ForMember(dest => dest.USPVC_CORREO, opt => opt.MapFrom(src => string.Empty))
                .ForMember(dest => dest.USPCH_ID_DEPARTAMENTO, opt => opt.MapFrom(src => string.Empty))
                .ForMember(dest => dest.ROPBI_ID_ROL, opt => opt.MapFrom(src => 0L))
                .ForMember(dest => dest.USPBT_ACTIVO, opt => opt.MapFrom(src => true))
                .ForMember(dest => dest.USSDT_FECHA_INSERT, opt => opt.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.USSVC_ID_USER_INSERT, opt => opt.Ignore())
                .ForMember(dest => dest.USSDT_FECHA_MODIF, opt => opt.Ignore())
                .ForMember(dest => dest.USSVC_ID_USER_MODIF, opt => opt.Ignore());

            // Mapeo de USUARIO a UsuarioRegistroCanalDto (sin exponer la contraseña)
            CreateMap<USUARIO, UsuarioRegistroCanalDto>()
                .ForMember(dest => dest.idUsuario, opt => opt.MapFrom(src => src.USPVC_ID_USUARIO))
                .ForMember(dest => dest.nombreCompleto, opt => opt.MapFrom(src => src.USPVC_NOMBRE_COMPLETO))
                .ForMember(dest => dest.password, opt => opt.Ignore());

            #endregion

            // TOMADOR <-> TomadorDto
            CreateMap<TOMADOR, TomadorDto>()
                .ForMember(dest => dest.idTomador, opt => opt.MapFrom(src => src.TOPBI_ID_TOMADOR))
                .ForMember(dest => dest.idPoliza, opt => opt.MapFrom(src => src.POPVC_ID_POLIZA))
                .ForMember(dest => dest.tipoPersona, opt => opt.MapFrom(src => src.TOPVC_TIPO_PERSONA))
                .ForMember(dest => dest.documentoTipo, opt => opt.MapFrom(src => src.TOPVC_DOCUMENTO_TIPO))
                .ForMember(dest => dest.documentoNumero, opt => opt.MapFrom(src => src.TOPVB_DOCUMENTO_NUMERO != null ? System.Text.Encoding.UTF8.GetString(src.TOPVB_DOCUMENTO_NUMERO) : null))
                .ForMember(dest => dest.documentoComplemento, opt => opt.MapFrom(src => src.TOSVB_DOCUMENTO_COMPLEMENTO != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_DOCUMENTO_COMPLEMENTO) : null))
                .ForMember(dest => dest.documentoExtension, opt => opt.MapFrom(src => src.TOSVC_DOCUMENTO_EXTENSION))
                .ForMember(dest => dest.apellidoPaterno, opt => opt.MapFrom(src => src.TOSVB_APELLIDO_PATERNO != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_APELLIDO_PATERNO) : null))
                .ForMember(dest => dest.apellidoMaterno, opt => opt.MapFrom(src => src.TOSVB_APELLIDO_MATERNO != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_APELLIDO_MATERNO) : null))
                .ForMember(dest => dest.apellidoCasada, opt => opt.MapFrom(src => src.TOSVB_APELLIDO_CASADA != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_APELLIDO_CASADA) : null))
                .ForMember(dest => dest.nombres, opt => opt.MapFrom(src => src.TOPVB_NOMBRES != null ? System.Text.Encoding.UTF8.GetString(src.TOPVB_NOMBRES) : null))
                .ForMember(dest => dest.razonSocial, opt => opt.MapFrom(src => src.TOPVB_RAZON_SOCIAL != null ? System.Text.Encoding.UTF8.GetString(src.TOPVB_RAZON_SOCIAL) : null))
                .ForMember(dest => dest.fechaNacimiento, opt => opt.MapFrom(src => src.TOPDT_FECHA_NACIMIENTO))
                .ForMember(dest => dest.correo, opt => opt.MapFrom(src => src.TOSVB_CORREO != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_CORREO) : null))
                .ForMember(dest => dest.departamento, opt => opt.MapFrom(src => src.TOSVC_DEPARTAMENTO))
                .ForMember(dest => dest.ciudad, opt => opt.MapFrom(src => src.TOSVB_CIUDAD != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_CIUDAD) : null))
                .ForMember(dest => dest.zona, opt => opt.MapFrom(src => src.TOSVB_ZONA != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_ZONA) : null))
                .ForMember(dest => dest.direccion, opt => opt.MapFrom(src => src.TOSVB_DIRECCION != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_DIRECCION) : null))
                .ForMember(dest => dest.celular, opt => opt.MapFrom(src => src.TOSVB_CELULAR != null ? System.Text.Encoding.UTF8.GetString(src.TOSVB_CELULAR) : null))
                .ForMember(dest => dest.estadoCivil, opt => opt.MapFrom(src => src.TOSVC_ESTADO_CIVIL))
                .ForMember(dest => dest.genero, opt => opt.MapFrom(src => src.TOSVC_GENERO))
                .ForMember(dest => dest.nacionalidad, opt => opt.MapFrom(src => src.TOSVC_NACIONALIDAD))
                .ForMember(dest => dest.ocupacion, opt => opt.MapFrom(src => src.TOSVC_OCUPACION))
                .ForMember(dest => dest.actividadEconomica, opt => opt.MapFrom(src => src.TOPVB_ACTIVIDAD_ECONOMICA != null ? System.Text.Encoding.UTF8.GetString(src.TOPVB_ACTIVIDAD_ECONOMICA) : null))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.TOPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.TOSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.TOSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.TOSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.TOSVC_ID_USER_MODIF))
                .ForMember(dest => dest.idCarga, opt => opt.MapFrom(src => src.TOSIN_ID_CARGA))
                .ReverseMap();

            // ROL <-> RolDto
            CreateMap<ROL, RolDto>()
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.area, opt => opt.MapFrom(src => src.ROPVC_AREA))
                .ForMember(dest => dest.nombre, opt => opt.MapFrom(src => src.ROPVC_NOMBRE))
                .ForMember(dest => dest.descripcion, opt => opt.MapFrom(src => src.ROSVC_DESCRIPCION))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.ROPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.ROSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.ROSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.ROSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.ROSVC_ID_USER_MODIF))
                .ReverseMap();
                       

            // PARAMETRO <-> ParametroDto
            CreateMap<PARAMETRO, ParametroDto>()
                .ForMember(dest => dest.idParametro, opt => opt.MapFrom(src => src.PAPBI_ID_PARAMETRO))
                .ForMember(dest => dest.idPoliza, opt => opt.MapFrom(src => src.POPVC_ID_POLIZA))
                .ForMember(dest => dest.idNivel, opt => opt.MapFrom(src => src.NIPVC_ID_NIVEL))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.PAPVC_TIPO))
                .ForMember(dest => dest.tipoDescripcion, opt => opt.MapFrom(src => src.PAPVC_TIPO_DESCRIPCION))
                .ForMember(dest => dest.factor, opt => opt.MapFrom(src => src.PAPDC_FACTOR))
                .ForMember(dest => dest.aplicacion, opt => opt.MapFrom(src => src.PAPVC_APLICACION))
                .ForMember(dest => dest.aplicacionDescripcion, opt => opt.MapFrom(src => src.PAPVC_APLICACION_DESCRIPCION))
                .ForMember(dest => dest.comentario, opt => opt.MapFrom(src => src.PASVC_COMENTARIO))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.PAPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.PASDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.PASVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.PASDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.PASVC_ID_USER_MODIF))
                .ForMember(dest => dest.periodoCarga, opt => opt.MapFrom(src => src.PASVC_PERIODO_CARGA))
                .ReverseMap();

            // MOVIMIENTO <-> MovimientoDto
            CreateMap<MOVIMIENTO, MovimientoDto>()
                .ForMember(dest => dest.idMovimiento, opt => opt.MapFrom(src => src.MOPBI_ID_MOVIMIENTO))
                .ForMember(dest => dest.idPoliza, opt => opt.MapFrom(src => src.POPVC_ID_POLIZA))
                .ForMember(dest => dest.idNivel, opt => opt.MapFrom(src => src.NIPVC_ID_NIVEL))
                .ForMember(dest => dest.idAfiliacion, opt => opt.MapFrom(src => src.AFPBI_ID_AFILIACION))
                .ForMember(dest => dest.flagEmision, opt => opt.MapFrom(src => src.MOPBT_FLAG_EMISION))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.MOPVC_TIPO))
                .ForMember(dest => dest.fechaMovimiento, opt => opt.MapFrom(src => src.MOPDT_FECHA_MOVIMIENTO))
                .ForMember(dest => dest.moneda, opt => opt.MapFrom(src => src.MOPCH_MONEDA))
                .ForMember(dest => dest.remuneracion, opt => opt.MapFrom(src => src.MOSDC_REMUNERACION))
                .ForMember(dest => dest.primaComercial, opt => opt.MapFrom(src => src.MOPDC_PRIMA_COMERCIAL))
                .ForMember(dest => dest.primaAdicional, opt => opt.MapFrom(src => src.MOPDC_PRIMA_ADICIONAL))
                .ForMember(dest => dest.primaNeta, opt => opt.MapFrom(src => src.MOPDC_PRIMA_NETA))
                .ForMember(dest => dest.comisionBroker, opt => opt.MapFrom(src => src.MOPDC_COMISION_BROKER))
                .ForMember(dest => dest.comisionCanal, opt => opt.MapFrom(src => src.MOPDC_COMISION_CANAL))
                .ForMember(dest => dest.sumaAsegurada, opt => opt.MapFrom(src => src.MOPDC_SUMA_ASEGURADA))
                .ForMember(dest => dest.iva, opt => opt.MapFrom(src => src.MOPDC_IVA))
                .ForMember(dest => dest.it, opt => opt.MapFrom(src => src.MOPDC_IT))
                .ForMember(dest => dest.importeAsistencia, opt => opt.MapFrom(src => src.MOSDC_IMPORTE_ASISTENCIA))
                .ForMember(dest => dest.tipoCambio, opt => opt.MapFrom(src => src.MOSDC_TIPO_CAMBIO))
                .ForMember(dest => dest.fechaTipoCambio, opt => opt.MapFrom(src => src.MOSDT_FECHA_TIPO_CAMBIO))
                .ForMember(dest => dest.idBroker, opt => opt.MapFrom(src => src.BRPBI_ID_BROKER))
                .ForMember(dest => dest.idAsistencia, opt => opt.MapFrom(src => src.ASPBI_ID_ASISTENCIA))
                .ForMember(dest => dest.comentario, opt => opt.MapFrom(src => src.MOSVC_COMENTARIO))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.MOPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.MOSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.MOSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.MOSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.MOSVC_ID_USER_MODIF))
                .ForMember(dest => dest.idCarga, opt => opt.MapFrom(src => src.MOSIN_ID_CARGA))
                .ReverseMap();

            // MENU <-> MenuDto
            CreateMap<MENU, MenuDto>()
                .ForMember(dest => dest.idMenu, opt => opt.MapFrom(src => src.MEPBI_ID_MENU))
                .ForMember(dest => dest.idRol, opt => opt.MapFrom(src => src.ROPBI_ID_ROL))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.MEPVC_TIPO))
                .ForMember(dest => dest.nivel, opt => opt.MapFrom(src => src.MEPIN_NIVEL))
                .ForMember(dest => dest.nivelOrden, opt => opt.MapFrom(src => src.MEPIN_NIVEL_ORDEN))
                .ForMember(dest => dest.contenedor, opt => opt.MapFrom(src => src.MEPVC_CONTENEDOR))
                .ForMember(dest => dest.paginaOrden, opt => opt.MapFrom(src => src.MEPIN_PAGINA_ORDEN))
                .ForMember(dest => dest.paginaNombre, opt => opt.MapFrom(src => src.MEPVC_PAGINA_NOMBRE))
                .ForMember(dest => dest.paginaUrl, opt => opt.MapFrom(src => src.MEPVC_PAGINA_URL))
                .ForMember(dest => dest.idMenuPadre, opt => opt.MapFrom(src => src.MESBI_ID_MENU_PADRE))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.MEPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.MESDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.MESVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.MESDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.MESVC_ID_USER_MODIF))
                .ReverseMap();

            // LIQUIDACION <-> LiquidacionDto
            CreateMap<LIQUIDACION, LiquidacionDto>()
                .ForMember(dest => dest.idLiquidacion, opt => opt.MapFrom(src => src.LIPBI_ID_LIQUIDACION))
                .ForMember(dest => dest.idPoliza, opt => opt.MapFrom(src => src.POPVC_ID_POLIZA))
                .ForMember(dest => dest.mesProduccion, opt => opt.MapFrom(src => src.LIPCH_MES_PRODUCCION))
                .ForMember(dest => dest.comentario, opt => opt.MapFrom(src => src.LISVC_COMENTARIO))
                .ForMember(dest => dest.flagEmision, opt => opt.MapFrom(src => src.LISBT_FLAG_EMISION))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.LIPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.LISDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.LISVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.LISDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.LISVC_ID_USER_MODIF))
                .ForMember(dest => dest.periodoCarga, opt => opt.MapFrom(src => src.LISVC_PERIODO_CARGA))
                .ReverseMap();



            // DOCUMENTO_PARAMETRO <-> DocumentoParametroDto
            CreateMap<DOCUMENTO_PARAMETRO, DocumentoParametroDto>()
                .ForMember(dest => dest.idDocumentoParametro, opt => opt.MapFrom(src => src.DOPBI_ID_DOCUMENTO_PARAMETRO))
                .ForMember(dest => dest.idDocumento, opt => opt.MapFrom(src => src.DOPVC_ID_DOCUMENTO))
                .ForMember(dest => dest.indexTabla, opt => opt.MapFrom(src => src.PAPIN_INDEX_TABLA))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.PAPVC_TIPO))
                .ForMember(dest => dest.etiqueta, opt => opt.MapFrom(src => src.PAPVC_ETIQUETA))
                .ForMember(dest => dest.valor, opt => opt.MapFrom(src => src.PAPVC_VALOR))
                .ForMember(dest => dest.configuracion, opt => opt.MapFrom(src => src.DOSVC_CONFIGURACION))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.DOPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.DOSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.DOSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.DOSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.DOSVC_ID_USER_MODIF))
                .ReverseMap();

            // DOCUMENTO <-> DocumentoDto
            CreateMap<DOCUMENTO, DocumentoDto>()
                .ForMember(dest => dest.idDocumento, opt => opt.MapFrom(src => src.DOPVC_ID_DOCUMENTO))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.DOPVC_TIPO))
                .ForMember(dest => dest.nombre, opt => opt.MapFrom(src => src.DOPVC_NOMBRE))
                .ForMember(dest => dest.rutaPlantilla, opt => opt.MapFrom(src => src.DOPVC_RUTA_PLANTILLA))
                .ForMember(dest => dest.descripcion, opt => opt.MapFrom(src => src.DOPVC_DESCRIPCION))
                .ForMember(dest => dest.procedimiento, opt => opt.MapFrom(src => src.DOPVC_PROCEDIMIENTO))
                .ForMember(dest => dest.configuracionBase, opt => opt.MapFrom(src => src.DOSVC_CONFIGURACION_BASE))
                .ForMember(dest => dest.rutaRepositorio, opt => opt.MapFrom(src => src.DOPVC_RUTA_REPOSITORIO))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.DOPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.DOSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.DOSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.DOSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.DOSVC_ID_USER_MODIF))
                .ReverseMap();

            // COBERTURA <-> CoberturaDto
            CreateMap<COBERTURA, CoberturaDto>()
                .ForMember(dest => dest.idCobertura, opt => opt.MapFrom(src => src.COPVC_ID_COBERTURA))
                .ForMember(dest => dest.idNivel, opt => opt.MapFrom(src => src.NIPVC_ID_NIVEL))
                .ForMember(dest => dest.codigo, opt => opt.MapFrom(src => src.COPVC_CODIGO))
                .ForMember(dest => dest.descripcion, opt => opt.MapFrom(src => src.COPVC_DESCRIPCION))
                .ForMember(dest => dest.tipo, opt => opt.MapFrom(src => src.COPCH_TIPO))
                .ForMember(dest => dest.moneda, opt => opt.MapFrom(src => src.COPCH_MONEDA))
                .ForMember(dest => dest.sumaAsegurada, opt => opt.MapFrom(src => src.COPDC_SUMA_ASEGURADA))
                .ForMember(dest => dest.descripcionSumaAsegurada, opt => opt.MapFrom(src => src.COSVC_DESCRIPCION_SUMA_ASEGURADA))
                .ForMember(dest => dest.flagCoberturaPrincipal, opt => opt.MapFrom(src => src.COSBT_FLAG_COBERTURA_PRINCIPAL))
                .ForMember(dest => dest.diasCarencia, opt => opt.MapFrom(src => src.COSIN_DIAS_CARENCIA))
                .ForMember(dest => dest.tasaComercial, opt => opt.MapFrom(src => src.COPDC_TASA_COMERCIAL))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.COPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.COSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.COSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.COSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.COSVC_ID_USER_MODIF))
                .ForMember(dest => dest.periodoCarga, opt => opt.MapFrom(src => src.COSVC_PERIODO_CARGA))
                .ReverseMap();

            // BROKER <-> BrokerDto
            CreateMap<BROKER, BrokerDto>()
                .ForMember(dest => dest.idBroker, opt => opt.MapFrom(src => src.BRPBI_ID_BROKER))
                .ForMember(dest => dest.nit, opt => opt.MapFrom(src => src.BRPVC_NIT))
                .ForMember(dest => dest.razonSocial, opt => opt.MapFrom(src => src.BRPVC_RAZON_SOCIAL))
                .ForMember(dest => dest.actividadEconomica, opt => opt.MapFrom(src => src.BRPVC_ACTIVIDAD_ECONOMICA))
                .ForMember(dest => dest.codigoAps, opt => opt.MapFrom(src => src.BRPVC_CODIGO_APS))
                .ForMember(dest => dest.activo, opt => opt.MapFrom(src => src.BRPBT_ACTIVO))
                .ForMember(dest => dest.fechaInsert, opt => opt.MapFrom(src => src.BRSDT_FECHA_INSERT))
                .ForMember(dest => dest.idUserInsert, opt => opt.MapFrom(src => src.BRSVC_ID_USER_INSERT))
                .ForMember(dest => dest.fechaModif, opt => opt.MapFrom(src => src.BRSDT_FECHA_MODIF))
                .ForMember(dest => dest.idUserModif, opt => opt.MapFrom(src => src.BRSVC_ID_USER_MODIF))
                .ReverseMap();

        }
    }
}
