﻿using AutoMapper;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ApiMapper
{
    public class ApiMapperCobros : Profile
    {
        public ApiMapperCobros()
        {
            CreateMap<COBRO, CobroActualizarDto>()
            .ForMember(dest => dest.idCobro, opt => opt.MapFrom(src => src.COPBI_ID_COBRO))
            .ForMember(dest => dest.jsonRespuesta, opt => opt.MapFrom(src => src.COPVC_JSON_RESPUESTA))
            .ForMember(dest => dest.estado, opt => opt.MapFrom(src => src.COPVC_ESTADO))
            .ReverseMap()
            .ForMember(dest => dest.COPBI_ID_COBRO, opt => opt.MapFrom(src => src.idCobro))
            .ForMember(dest => dest.COPVC_JSON_RESPUESTA, opt => opt.MapFrom(src => src.jsonRespuesta))
            .ForMember(dest => dest.COPVC_ESTADO, opt => opt.MapFrom(src => src.estado));

            CreateMap<CobroRegistroInicialDto, COBRO>()
            .ForMember(dest => dest.AFPBI_ID_AFILIACION, opt => opt.MapFrom(src => src.idAfiliacion))
            .ForMember(dest => dest.CUPBI_ID_CUPON, opt => opt.MapFrom(src => src.idCupon))
            .ForMember(dest => dest.COPVC_TIPO_COBRO, opt => opt.MapFrom(src => src.tipoCobro))
            .ForMember(dest => dest.COPVC_CODIGO, opt => opt.MapFrom(src => src.codigo))
            .ForMember(dest => dest.COPVC_JSON_SOLICITUD, opt => opt.MapFrom(src => src.jsonSolicitud))
            .ForMember(dest => dest.COPBI_ID_COBRO, opt => opt.Ignore())
            .ForMember(dest => dest.COPVC_JSON_RESPUESTA, opt => opt.Ignore())
            .ForMember(dest => dest.COPVC_ESTADO, opt => opt.Ignore())
            .ForMember(dest => dest.COPBT_ACTIVO, opt => opt.Ignore())
            .ForMember(dest => dest.COSDT_FECHA_INSERT, opt => opt.Ignore())
            .ForMember(dest => dest.COSVC_ID_USER_INSERT, opt => opt.Ignore())
            .ForMember(dest => dest.COSDT_FECHA_MODIF, opt => opt.Ignore())
            .ForMember(dest => dest.COSVC_ID_USER_MODIF, opt => opt.Ignore());

            CreateMap<COBRO, CobroRespRegistroInicialDto>()
             .ForMember(dest => dest.idCobro, opt => opt.MapFrom(src => src.COPBI_ID_COBRO))
             .ForMember(dest => dest.idAfiliacion, opt => opt.MapFrom(src => src.AFPBI_ID_AFILIACION))
             .ReverseMap()
             .ForMember(dest => dest.COPBI_ID_COBRO, opt => opt.MapFrom(src => src.idCobro))
             .ForMember(dest => dest.AFPBI_ID_AFILIACION, opt => opt.MapFrom(src => src.idAfiliacion))
             .ForMember(dest => dest.COPVC_TIPO_COBRO, opt => opt.Ignore())
             .ForMember(dest => dest.COPVC_CODIGO, opt => opt.Ignore())
             .ForMember(dest => dest.COPVC_JSON_SOLICITUD, opt => opt.Ignore())
             .ForMember(dest => dest.COPVC_JSON_RESPUESTA, opt => opt.Ignore())
             .ForMember(dest => dest.COPVC_ESTADO, opt => opt.Ignore())
             .ForMember(dest => dest.COPBT_ACTIVO, opt => opt.Ignore())
             .ForMember(dest => dest.COSDT_FECHA_INSERT, opt => opt.Ignore())
             .ForMember(dest => dest.COSVC_ID_USER_INSERT, opt => opt.Ignore())
             .ForMember(dest => dest.COSDT_FECHA_MODIF, opt => opt.Ignore())
             .ForMember(dest => dest.COSVC_ID_USER_MODIF, opt => opt.Ignore());
        }
    }
}
