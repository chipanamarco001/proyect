﻿using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoConfiguracion.IRepository
{
    public interface IAutenticacion
    {
        Task<CrsApiResponse<AutenticacionRespuestaDto>> GenerarToken(AutenticacionConsultarDto loginDto);

        Task<CrsApiResponse<dynamic>> ValidaAccesoUsuario(AutenticacionConsultarDto loginDto);
        Task<CrsApiResponse<UsuarioRespRegistroDto>> RegistrarUsuarioServicio();
        Task<CrsApiResponse<AutenticacionRespuestaDto>> ValidarToken(string token);
    }
}
