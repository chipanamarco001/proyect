﻿using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoConfiguracion.IRepository
{
    public interface IConfiguracion
    {       
        #region lexico
        Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTabla(string strTabla, OcCredenciales objCredenciales);

        Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTablaTema(string strTabla, string strTema, OcCredenciales objCredenciales);

        #endregion
               

        #region Base Yape
        Task<CrsApiResponse<List<OcBaseYapeDto>>> ObtenerListaClienteYapePorDocumentoCorreo(string strNumDocumento, string strEmail, OcCredenciales objCredenciales);

        #endregion

        #region producto

        Task<CrsApiResponse<List<ProductoDto>>> ObtenerListaProductoActivo(OcCredenciales objCredenciales);

        #endregion

        #region Subproducto

        Task<CrsApiResponse<SubProductoDto>> ObtenerSubProductoPorIdProdDescripcion(string idProducto, string descripcion, OcCredenciales objCredenciales);

        #endregion

        #region sub Producto Parametro

        Task<CrsApiResponse<List<SubProductoParametroDto>>> ObtenerProductoParametroPorIdSubProducto(long idSubProducto, OcCredenciales objCredenciales);

        #endregion

        #region Errores

        Task<CrsApiResponse<ErrorRespuestaDto>> RegistrarError(ErrorRegistrarDto objErrorRegistrar, OcCredenciales objCredenciales);

        #endregion
    }
}
