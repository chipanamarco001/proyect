﻿using AutoMapper;
using Common.Parameters;
using DevExpress.XtraRichEdit.Import.Html;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioTransaccional;
using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.Extensions.Configuration;
using Models.Dtos;
using Models.ModelCheck;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using ServicioEnvioCorreo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Logics.ServicioTransaccional.ServicioEnvioCorreoClass;

namespace Logics.ConsumoConfiguracion
{
    public class Configuracion : IConfiguracion
    {
        private readonly IMapper _mapper;        
        private readonly BaseYapeDRepository _yapeRepository;
        private readonly ProductoRepository _productRepository;
        private readonly SubProductoRepository _subProductoRepository;
        private readonly SubProductoParametroRepository _subProductoParametroRepository;
        private readonly LexicoRepository _lexicoRepository;
        private readonly ErrorRepository _errorRepository;

        public Configuracion(
            IMapper mapper,
            BaseYapeDRepository yapeRepository,
            ProductoRepository productRepository,
            SubProductoRepository subProductoRepository,
            SubProductoParametroRepository subProductoParametroRepository,
            LexicoRepository lexicoRepository,
            ErrorRepository errorRepository
            )
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _yapeRepository = yapeRepository ?? throw new ArgumentNullException(nameof(yapeRepository));
            _productRepository = productRepository ?? throw new ArgumentNullException(nameof(productRepository));
            _subProductoRepository = subProductoRepository ?? throw new ArgumentNullException(nameof(subProductoRepository));
            _subProductoParametroRepository = subProductoParametroRepository ?? throw new ArgumentNullException(nameof(subProductoParametroRepository));
            _lexicoRepository = lexicoRepository ?? throw new ArgumentNullException(nameof(lexicoRepository));
            _errorRepository = errorRepository ?? throw new ArgumentNullException(nameof(errorRepository));
        }

        #region Lexico
        public async Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTabla(string strTabla, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<LexicoDto>>();
            try
            {

                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _lexicoRepository.ObtenerListaLexicoPorTabla(strTabla);
                    var responseDto = _mapper.Map<List<LexicoDto>>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(responseDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<LexicoDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }
        

        public async Task<CrsApiResponse<List<LexicoDto>>> ObtenerListaLexicoPorTablaTema(string strTabla, string strTema, OcCredenciales objCredenciales)
        {
            CrsApiResponse<List<LexicoDto>> response = new CrsApiResponse<List<LexicoDto>>();
            try
            {
                
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _lexicoRepository.ObtenerListaLexicoPorTablaTema(strTabla, strTema);
                    var responseDto = _mapper.Map<List<LexicoDto>>(responseQuery);                    
                    return ApiResponseHelper.GetGenericResponse(responseDto);

                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<LexicoDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Base Yape

        public async Task<CrsApiResponse<List<OcBaseYapeDto>>> ObtenerListaClienteYapePorDocumentoCorreo(string strNumDocumento, string strEmail, OcCredenciales objCredenciales)
        {
            CrsApiResponse<List<OcBaseYapeDto>> response = new CrsApiResponse<List<OcBaseYapeDto>>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _yapeRepository.ObtenerListaClienteYapePorDocumentoCorreo(strNumDocumento, strEmail);
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<OcBaseYapeDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status =HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Producto

        public async Task<CrsApiResponse<List<ProductoDto>>> ObtenerListaProductoActivo(OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<ProductoDto>>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _productRepository.ObtenerListaProductoActivo();
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<ProductoDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Subproducto

        public async Task<CrsApiResponse<SubProductoDto>> ObtenerSubProductoPorIdProdDescripcion(string idProducto, string descripcion, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SubProductoDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _subProductoRepository.ObtenerSubProductoPorIdProdDescripcion(idProducto, descripcion);
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SubProductoDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region SubProducto Parametro

        public async Task<CrsApiResponse<List<SubProductoParametroDto>>> ObtenerProductoParametroPorIdSubProducto(long idSubProducto, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<List<SubProductoParametroDto>>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _subProductoParametroRepository.ObtenerProductoParametroPorIdSubProducto(idSubProducto);
                    var responseDto = _mapper.Map<List<SubProductoParametroDto>>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(responseDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<List<SubProductoParametroDto>>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Errores

        public async Task<CrsApiResponse<ErrorRespuestaDto>> RegistrarError(ErrorRegistrarDto objErrorRegistrar, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<ErrorRespuestaDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objError = _mapper.Map<ERROR>(objErrorRegistrar);
                    objError.ERSVC_ID_USER_INSERT = objCredenciales.usuario;
                    objError.ERSVC_IP = objCredenciales.ip;
                    var responseQuery = _errorRepository.RegistrarError(objError, objCredenciales);

                    if (responseQuery != null)
                    {
                        var errorRespuestaDto = new ErrorRespuestaDto
                        {
                            registrado = responseQuery
                        };
                        return ApiResponseHelper.GetGenericResponse(errorRespuestaDto);
                    }
                    else
                    {
                        response.status = HttpStatusCode.InternalServerError;
                        response.errors = new List<ErrorDetail>
                        {
                            new ErrorDetail { errorMessage = "Error while registering error." }
                        };
                        return response;
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<ErrorRespuestaDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion
    }
}
