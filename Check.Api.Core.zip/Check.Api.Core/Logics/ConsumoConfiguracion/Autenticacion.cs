﻿using AutoMapper;
using Common.Decrypt;
using Common.Parameters;
using Logics.ConsumoConfiguracion.IRepository;
using Logics.ServicioAuth;
using Logics.ServicioTransaccional;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.Extensions.Configuration;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoConfiguracion
{
    public class Autenticacion : IAutenticacion
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly UsuarioRepository _usuarioRepository;
        private readonly RolRepository _rolRepository;
        private readonly MenuRepository _menuRepository;
        private readonly TokenRepository _tokenRepository;

        private readonly Lazy<JwtService> _autorizacionJwt;

        public Autenticacion(IMapper mapper, IConfiguration configuration, UsuarioRepository usuarioRepository, RolRepository rolRepository, MenuRepository menuRepository, TokenRepository tokenRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

            _autorizacionJwt = new Lazy<JwtService>(() => new JwtService(_configuration));
            _usuarioRepository = usuarioRepository ?? throw new ArgumentNullException(nameof(usuarioRepository));
            _rolRepository = rolRepository ?? throw new ArgumentNullException(nameof(rolRepository));
            _menuRepository = menuRepository ?? throw new ArgumentNullException(nameof(menuRepository));
            _tokenRepository = tokenRepository ?? throw new ArgumentNullException(nameof(tokenRepository));
        }
        public async Task<CrsApiResponse<AutenticacionRespuestaDto>> GenerarToken(AutenticacionConsultarDto loginDto)
        {
            var response = new CrsApiResponse<AutenticacionRespuestaDto>();
            try
            {
                //es necesario validar la credenciales
                if (loginDto.usuario == "admin" && loginDto.pass == "admin") // Ejemplo simple
                {
                    var responseQuery = _autorizacionJwt.Value.GenerateToken(loginDto.usuario);
                    if (string.IsNullOrEmpty(responseQuery))
                    {
                        CComplexParameters<AutenticacionRespuestaDto>.GetValidacionResult(ref response, new Exception("No se pudo generar el token"), MethodBase.GetCurrentMethod().Name, string.Empty, "Error al generar el token");
                        response.status = HttpStatusCode.InternalServerError;// "500"
                        return response;
                    }

                    response.hasError = false;
                    response.status = HttpStatusCode.OK;// "200"
                    response.result = new AutenticacionRespuestaDto
                    {
                        token = responseQuery,
                        username = loginDto.usuario
                    };

                    return response; // Directly return the response object
                }
                else
                {
                    response.hasError = true;
                    response.status = HttpStatusCode.Unauthorized;// "401";
                    //response.errors = new List<ErrorDetail>
                    //{
                    //    new ErrorDetail { errorMessage = "Credenciales inválidas" }
                    //};
                    response.messages = new List<Message>
                    {
                        new Message{ userMessage = "No tiene acceso al sistems por favor verifique sus credenciales", messageTec="Credenciales inválidas", methodName = "Authentication"}
                    };
                    return response; // Return response with error details
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<AutenticacionRespuestaDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        public async Task<CrsApiResponse<UsuarioRespRegistroDto>> RegistrarUsuarioServicio()
        {
            var response = new CrsApiResponse<UsuarioRespRegistroDto>();
            try
            {
                var usuarioRegistroDto = new UsuarioRegistroDto();
                usuarioRegistroDto.nombreCompleto = "YAPE";
                usuarioRegistroDto.idUsuario = "admin"; // Asignar un ID de usuario único
                usuarioRegistroDto.password = "admin";
                usuarioRegistroDto.idRol = 4; // Asignar un ID de rol válido
                usuarioRegistroDto.tipo = "INTERFAZ"; // Asignar el tipo de usuario como "CANAL"
                usuarioRegistroDto.correo = string.Empty; // No se usa en este caso

                byte[] passwordEncrypted = Cryptography.Encrypt(usuarioRegistroDto.password);

                var objCredenciales = new OcCredenciales();
                objCredenciales.usuario = "B04725";
                objCredenciales.ip = "172.31.103.99";
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {                  
                    var usuario = _mapper.Map<USUARIO>(usuarioRegistroDto);
                    usuario.USPBT_PASSWORD = passwordEncrypted;
                    var responseQuery = _usuarioRepository.RegistrarUsuarioServicio(usuario, objCredenciales);                   
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<UsuarioRespRegistroDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<dynamic>> ValidaAccesoUsuario(AutenticacionConsultarDto loginDto)
        {
            var response = new CrsApiResponse<dynamic>();
            try
            {
                var objUsuario = _usuarioRepository.ObtenerUsuarioPorId(loginDto.usuario);
                var bytePassword = Cryptography.Encrypt(loginDto.pass);
                bool boolUsuarioAutorizado = false;
                if (objUsuario != null)
                {
                    switch (objUsuario.USPVC_TIPO)
                    {
                        case "EXTERNO":
                            var objResponseExt = new AutenticacionRespuestaExternoDto();
                            //bool boolUsuarioAutorizado = false;

                            //if (objUsuario.USPBT_PASSWORD != null)
                            //{
                            //    if (objUsuario.USPBT_PASSWORD.SequenceEqual(bytePassword))
                            //    {
                            //        boolUsuarioAutorizado = true;
                            //    }
                            //}
                            //if (boolUsuarioAutorizado)
                            //{
                            //    _tokenRepository.DesactivarToken(loginDto.usuario);
                            //    var objToken = new TOKEN();
                            //    objToken.USPVC_ID_USUARIO = loginDto.usuario;
                            //    //objResponse.Matricula = loginDto.usuario;
                            //    //objResponse.NombreCompleto = objUsuario.USPVC_NOMBRE_COMPLETO.Trim();
                            //    //objResponse.Correo = objUsuario.USPVC_CORREO;
                            //    //objResponse.IdDepartamento = objUsuario.USPCH_ID_DEPARTAMENTO;
                            //    var objRol = _rolRepository.ObtenerRolPorId(objUsuario.ROPBI_ID_ROL);
                            //    //objResponse.Area = objRol.ROPVC_AREA;
                            //    //objResponse.NombreArea = objRol.ROPVC_NOMBRE;
                            //    objToken.ROPBI_ID_ROL = objUsuario.ROPBI_ID_ROL;
                            //    //var listaMenuResponse = new List<OCC_MENU>();
                            //    //var listaMenu = _menuRepository.ObtenerMenusPorRol;
                            //    //    _context.GetListMenu().Where(w => w.ROPBI_ID_ROL == objRol.ROPBI_ID_ROL && w.MEPBT_ACTIVO == true).ToList();
                            //    //foreach (var objMenu in listaMenu)
                            //    //{
                            //    //    listaMenuResponse.Add(new OCC_MENU
                            //    //    {
                            //    //        IdMenu = objMenu.MEPBI_ID_MENU,
                            //    //        ModuloNombre = objMenu.MEPVC_MODULO_NOMBRE,
                            //    //        ModuloOrden = objMenu.MEPIN_MODULO_ORDEN,
                            //    //        ObjetoTipo = objMenu.MEPVC_OBJETO_TIPO,
                            //    //        ObjetoNivel = objMenu.MEPIN_OBJETO_NIVEL,
                            //    //        ObjetoOrden = objMenu.MEPIN_OBJETO_ORDEN,
                            //    //        ObjetoNombre = objMenu.MEPVC_OBJETO_NOMBRE,
                            //    //        ObjetoUrl = objMenu.MEPVC_OBJETO_URL,
                            //    //        IdPadre = objMenu.MEPBI_ID_MENU_PADRE
                            //    //    });
                            //    //}
                            //    //objResponse.Menu = listaMenuResponse;
                            //    objToken.TOPVC_LLAVE = Cryptography.Token(loginDto.usuario);
                            //    objToken.TOSVC_OTP = Cryptography.OTP();
                            //    objToken.TOPBT_ACTIVO = true;
                            //    objToken.TOSDT_FECHA_INSERT = DateTime.Now;
                            //    objToken.TOSVC_ID_USER_INSERT = loginDto.usuario;
                            //    _tokenRepository.AgregarToken(objToken);
                            //    objResponse.token = objToken.TOPVC_LLAVE;
                            //    objResponse.username = loginDto.usuario;
                            //    return objResponseExt;
                            //}
                            response.result = objResponseExt;
                            break;
                        case "INTERFAZ":

                            var objResponse = new AutenticacionRespuestaDto();

                            if (objUsuario.USPBT_PASSWORD != null)
                            {
                                if (objUsuario.USPBT_PASSWORD.SequenceEqual(bytePassword))
                                {
                                    boolUsuarioAutorizado = true;
                                }
                            }
                            if (boolUsuarioAutorizado)
                            {
                                _tokenRepository.DesactivarToken(loginDto.usuario);

                                var objToken = new TOKEN();
                                objToken.USPVC_ID_USUARIO = loginDto.usuario;
                                objToken.ROPBI_ID_ROL = objUsuario.ROPBI_ID_ROL;
                                //objToken.TOPVC_LLAVE = Cryptography.Token(loginDto.usuario);
                                objToken.TOPVC_TOKEN = _autorizacionJwt.Value.GenerateToken(loginDto.usuario);
                                objToken.TOSVC_OTP = Cryptography.OTP();
                                objToken.TOPBT_ACTIVO = true;
                                objToken.TOSDT_FECHA_INSERT = DateTime.Now;
                                objToken.TOSVC_ID_USER_INSERT = loginDto.usuario;
                                _tokenRepository.AgregarToken(objToken);
                                objResponse.token = objToken.TOPVC_TOKEN;
                                objResponse.username = loginDto.usuario;

                                response.result = objResponse;
                                return response;
                            }
                            break;

                        case "CANAL":

                            var objResponseINTK = new AutenticacionRespuestaCanalDto();

                            if (objUsuario.USPBT_PASSWORD != null)
                            {
                                if (objUsuario.USPBT_PASSWORD.SequenceEqual(bytePassword))
                                {
                                    boolUsuarioAutorizado = true;
                                }
                            }
                            if (boolUsuarioAutorizado)
                            {
                                objResponseINTK.autenticado = boolUsuarioAutorizado;
                                objResponseINTK.username = loginDto.usuario;
                                response.result = objResponseINTK;
                                response.status = HttpStatusCode.OK;
                                return response;
                            }                            
                                break;
                        default:
                            break;
                    }
                }
                response.hasError = true;
                response.status = HttpStatusCode.Unauthorized;
                response.messages = new List<Message>
                {
                    new Message
                    {
                        userMessage = "No autenticado. Verifique sus credenciales.",
                        messageTec = "Credenciales inválidas",
                        methodName = "AccesoUsuario"
                    }
                };
                return response;                
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<dynamic>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }
        }

        public async Task<CrsApiResponse<AutenticacionRespuestaDto>> ValidarToken(string token)
        {
            var response = new CrsApiResponse<AutenticacionRespuestaDto>();
            try
            {
                var objToken = _tokenRepository.ObtenerTokenPorId(token);
                if (objToken != null)
                {
                //    var objUsuario = _usuarioRepository.ObtenerUsuarioPorId(objToken.USPVC_ID_USUARIO);
                //    if (objUsuario != null)
                //    {
                        var objResponse = new AutenticacionRespuestaDto
                        {
                            token = objToken.TOPVC_TOKEN,
                            username = objToken.USPVC_ID_USUARIO
                            //username = objUsuario.USPVC_NOMBRE_COMPLETO.Trim()
                        };
                        response.result = objResponse;
                        response.status = HttpStatusCode.OK;
                        return response;
                    //}
                }
                response.hasError = true;
                response.status = HttpStatusCode.Unauthorized;
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<AutenticacionRespuestaDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;// "500";
                return response;
            }

        }
    }
}
