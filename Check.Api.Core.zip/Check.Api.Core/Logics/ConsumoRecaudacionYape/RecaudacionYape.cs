﻿using Common.Decrypt;
using Common.Parameters;
using Logics.ConsumoRecaudacionBCP.IRepository;
using ManageDB.EFRepository;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Models.OcDtos.OcRecYapeDtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoRecaudacionYape
{
    public class RecaudacionYape : IRecaudacionYape
    {
        private readonly RecaudacionYapeRepository _recaudacionYapeRepository;
        private readonly UsuarioRepository _usuarioRepository;
        private readonly CobroRepository _cobroRepository;
        public RecaudacionYape(RecaudacionYapeRepository recaudacionBCPRepository, UsuarioRepository usuarioRepository, CobroRepository cobroRepository)
        {
            _recaudacionYapeRepository = recaudacionBCPRepository;
            _usuarioRepository = usuarioRepository;
            _cobroRepository = cobroRepository ?? throw new ArgumentNullException(nameof(cobroRepository));
        }
        public async Task<BcpApiResponse<ConsultaResponse>> ObtenerDatosConsulta(BcpApiRequest<ConsultaRequestDto> request)
        {
            var response = new BcpApiResponse<ConsultaResponse>();
            try
            {
                if (!ValidarCredenciales(request.Cabecera.Usuario, request.Cabecera.Contraseña))
                {     
                    response.Cabecera = new OcCabeceraRes
                    {
                        Descripcion = "CREDENCIALES INVÁLIDAS",
                        CodError = "309"
                    }; ;
                    response.CargaUtil = null;
                    return response;
                }
                var responseQuery = _recaudacionYapeRepository.ObtenerDatosConsulta(request.CargaUtil.CodigoBusqueda.ToString());
                if (!responseQuery.Any())
                {
                    return BcpResponseHelper.GetGenericResponse<ConsultaResponse>(null);
                }
                if(responseQuery.Count() > 1)
                {
                    response.Cabecera = new OcCabeceraRes
                    {
                        Descripcion = "TRACE DUPLICADO X FECHA/CANAL",
                        CodError = "302"
                    }; ;
                    response.CargaUtil = null;
                    return response;
                }
                var primerElemento = responseQuery.First();
                if (primerElemento.Estado == "AFILIADO")
                {
                    response.Cabecera = new OcCabeceraRes
                    {
                        Descripcion = "NO EXISTEN DEUDAS ASOCIADAS AL CODIGO DE DEPOSITANTE",
                        CodError = "303"
                    }; ;
                    response.CargaUtil = null;
                    return response;
                }
                else
                {
                    var result = new ConsultaResponse
                    {
                        CodigoBusqueda = primerElemento.CodigoBusqueda.ToString(),
                        CodigoServicio = request.CargaUtil.CodServicio,
                        ImporteAdeudado = primerElemento.ImporteAdeudado ?? 0,
                        ImporteMinimo = primerElemento.ImporteMinimo ?? 0,
                        ImporteComision = primerElemento.ImporteComision ?? 0,
                        NombreCliente = primerElemento.NombreCliente,
                        DetalleCuotas = responseQuery.Select(c => new Cuota
                        {
                            NumeroCuota = c.NumeroCuota ?? 0,
                            DetalleCuota = c.DetalleCuota ?? " ",
                            FechaVencimiento = c.FechaVencimiento,
                            ImporteCuota = c.ImporteCuota ?? 0,
                            ImporteMinimoCuota = c.ImporteMinimoCuota ?? 0,
                            MoraCuota = c.MoraCuota ?? 0,
                            ImporteComision = c.ImporteComisionCuota ?? 0
                        }).ToList()
                    };
                    return BcpResponseHelper.GetGenericResponse(result);

                }
                
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                BcpResponseHelper.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                return response;
            }
        }


        public async Task<BcpApiResponse<PagoResponse>> ActualizarCobroBCP(BcpApiRequest<PagoRequest> request)
        {
            var response = new BcpApiResponse<PagoResponse>();
            var objCredenciales = new OcCredenciales();
            try
            {
                if (!ValidarCredenciales(request.Cabecera.Usuario, request.Cabecera.Contraseña))
                {
                    response.Cabecera = new OcCabeceraRes
                    {
                        Descripcion = "CREDENCIALES INVÁLIDAS",
                        CodError = "309"
                    }; ;
                    response.CargaUtil = null;
                    return response;
                }

                response.CargaUtil ??= new PagoResponse();
                COBRO cobroEntity = new COBRO();
                string json = JsonConvert.SerializeObject(request);
                response.CargaUtil.CodigoBusqueda = request.CargaUtil?.CodigoBusqueda;
                response.CargaUtil.IdTxnEntidad = request.CargaUtil?.IdTransaccion?? 0;
                response.CargaUtil.IdTxnEmpresa = Convert.ToInt64(00000001);
                string responsejso = JsonConvert.SerializeObject(response);
                cobroEntity.COPVC_ESTADO = "AFILIADO";
                cobroEntity.COPBT_ACTIVO = true;
                cobroEntity.COSDT_FECHA_INSERT = DateTime.Now;
                cobroEntity.COSVC_ID_USER_INSERT = request.Cabecera.Usuario;
                cobroEntity.COPVC_JSON_SOLICITUD = json;
                cobroEntity.COPVC_JSON_RESPUESTA = responsejso;
                cobroEntity.COPVC_CODIGO = request.CargaUtil?.CodigoBusqueda;
                var responseQuery = _cobroRepository.ActualizarCobroBCP(cobroEntity);
                response.Cabecera = responseQuery;
                return response; 
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                BcpResponseHelper.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                return response;
            }
        }
        public async Task<BcpApiResponse<ReversionResponse>> ReversionBCP(BcpApiRequest<ReversionRequest> request)
        {
            var response = new BcpApiResponse<ReversionResponse>();
            try
            {
                if (!ValidarCredenciales(request.Cabecera.Usuario, request.Cabecera.Contraseña))
                {
                    response.Cabecera = new OcCabeceraRes
                    {
                        Descripcion = "CREDENCIALES INVÁLIDAS",
                        CodError = "309"
                    };
                    response.CargaUtil = null;
                    return response;
                }

                response.CargaUtil ??= new ReversionResponse();
                response.CargaUtil.CodigoBusqueda = request.CargaUtil.CodigoBusqueda.ToString();
                response.CargaUtil.IdTxnEmpresaReversion = 54564;
                response.CargaUtil.idTxnRevertida = request.CargaUtil.ID_Reversion;
                response.Cabecera = new OcCabeceraRes
                {
                    Descripcion = "PARA REVERSION POR FAVOR COMUNICARSE CON CREDISEGURO",
                    CodError = "308"
                };
                response.CargaUtil = null;
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                BcpResponseHelper.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                return response;
            }
        }
        private bool ValidarCredenciales(string usuario, string contraseña)
        {
            var objUsuario = _usuarioRepository.ObtenerUsuarioPorId(usuario);
            if (objUsuario == null || objUsuario.USPBT_PASSWORD == null)
                return false;

            var bytePassword = Cryptography.Encrypt(contraseña);
            return objUsuario.USPBT_PASSWORD.SequenceEqual(bytePassword);
        }        
    }
}
