﻿using Microsoft.AspNetCore.Mvc;
using Models.Dtos;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoRecaudacionYape
{
    public class BcpResponseHelper
    {
        public static IActionResult HandleApiResponse<T>(ControllerBase controller, Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T> response)
        {
            if (response == null)
                // 500 Error interno del servidor: El servicio devolvió una respuesta nula.
                return controller.StatusCode(500, new { StatusCode = 500, ErrorType = "NullResponse", Message = "Respuesta nula del servicio." });

            // 200 OK: La solicitud fue exitosa y la respuesta contiene datos.
            if (response.Cabecera.CodError == "000")
                return controller.Ok(response);            

            // 400 Solicitud incorrecta: La solicitud es inválida o no puede ser procesada.
            if (response.Cabecera.CodError == "399")
                return controller.BadRequest(response);            

            // 404 No encontrado: El recurso solicitado no existe.
            if (response.Cabecera.CodError == "301" || response.Cabecera.CodError == "303")
                return controller.NotFound(response);            

            // 500 Error interno del servidor: Error genérico cuando no hay un mensaje más específico.
            return controller.StatusCode(500, response);
        }

        public static Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T> GetGenericResponse<T>(T resultado)
        {
            var objCabecera = new Models.OcDtos.OcRecYapeDtos.OcCabeceraRes
            {
                Descripcion = "Proceso Conforme",
                CodError = "000"
            };

            // Caso: resultado nulo
            if (resultado == null)
            {
                objCabecera.CodError = "303";
                objCabecera.Descripcion = "CÓDIGO DE DEPOSITANTE NO EXISTE";
                return new Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T>
                {
                    Cabecera = objCabecera,
                    CargaUtil = default
                };
            }

            // Caso: resultado es lista vacía (pero no string)
            if (resultado is IEnumerable enumerable && !(resultado is string))
            {
                var enumerator = enumerable.GetEnumerator();
                if (!enumerator.MoveNext())
                {
                    objCabecera.CodError = "303";
                    objCabecera.Descripcion = "NO EXISTEN DEUDAS ASOCIADAS AL CODIGO DE DEPOSITANTE";
                    return new Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T>
                    {
                        Cabecera = objCabecera,
                        CargaUtil = resultado
                    };
                }
            }

            // Caso: resultado tiene propiedad EXITO y es false
            var tipo = resultado.GetType();
            var exitoProp = tipo.GetProperties()
                .FirstOrDefault(p => string.Equals(p.Name, "EXITO", StringComparison.OrdinalIgnoreCase));
            if (exitoProp != null && exitoProp.PropertyType == typeof(bool))
            {
                var exitoValue = exitoProp.GetValue(resultado) as bool?;
                if (exitoValue.HasValue && !exitoValue.Value)
                {
                    var mensajeProp = tipo.GetProperties()
                        .FirstOrDefault(p => string.Equals(p.Name, "MENSAJE", StringComparison.OrdinalIgnoreCase));
                    string mensaje = "Error interno del servicio.";
                    if (mensajeProp != null)
                    {
                        var mensajeValue = mensajeProp.GetValue(resultado);
                        if (mensajeValue != null)
                            mensaje = mensajeValue.ToString();
                    }
                    objCabecera.CodError = "399";
                    objCabecera.Descripcion = mensaje;
                    return new Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T>
                    {
                        Cabecera = objCabecera,
                        CargaUtil = resultado
                    };
                }
            }

            // Caso exitoso
            return new Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T>
            {
                Cabecera = objCabecera,
                CargaUtil = resultado
            };
        }

        public static bool GetValidacionResult<T>(ref Models.OcDtos.OcRecYapeDtos.BcpApiResponse<T> ValidationResult, Exception ex, string strMethodName, string strPropertyName, string strErrorUsuario)
        {
            if (ValidationResult == null)
            {
                ValidationResult = new();
                ValidationResult.Cabecera = new Models.OcDtos.OcRecYapeDtos.OcCabeceraRes();
            }
            if (ValidationResult.Cabecera == null)
            {
                ValidationResult.Cabecera = new Models.OcDtos.OcRecYapeDtos.OcCabeceraRes();
            }

            ValidationResult.Cabecera.CodError = "399";
            ValidationResult.Cabecera.Descripcion = "ERROR DE EJECUCIÓN";

            return true;
        }
    }
}
