﻿using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using Models.OcDtos.OcRecYapeDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoRecaudacionBCP.IRepository
{
    public interface IRecaudacionYape
    {
        Task<BcpApiResponse<ConsultaResponse>> ObtenerDatosConsulta(BcpApiRequest<ConsultaRequestDto> request);
        Task<BcpApiResponse<PagoResponse>> ActualizarCobroBCP(BcpApiRequest<PagoRequest> request);
        Task<BcpApiResponse<ReversionResponse>> ReversionBCP(BcpApiRequest<ReversionRequest> request);
    }
}
