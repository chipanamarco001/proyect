﻿using AutoMapper;
using Common.Parameters;
using DevExpress.CodeParser;
using Logics.ConsumoTransaccional.IRepository;
using ManageDB.EFRepository;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoTransaccional
{
    public class Cobros : ICobros
    {
        private readonly IMapper _mapper;
        private readonly CobroRepository _cobroRepository;
        private readonly MovimientoRepository _movimientoRepository;
        public Cobros(IMapper mapper, CobroRepository cobroRepository, MovimientoRepository movimientoRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _cobroRepository = cobroRepository ?? throw new ArgumentNullException(nameof(cobroRepository));
            _movimientoRepository = movimientoRepository ?? throw new ArgumentNullException(nameof(movimientoRepository));
        }
        public async Task<CrsApiResponse<CobroRespRegistroInicialDto>> RegistrarCobroInicial(CobroRegistroInicialDto objCobroInicial, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<CobroRespRegistroInicialDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var cobroEntity = _mapper.Map<COBRO>(objCobroInicial);

                    cobroEntity.COPVC_ESTADO = "PENDIENTE"; 
                    cobroEntity.COPBT_ACTIVO = true;
                    cobroEntity.COSDT_FECHA_INSERT = DateTime.Now;
                    cobroEntity.COSVC_ID_USER_INSERT = objCredenciales.usuario;

                    var responseQueryMovimiento = _movimientoRepository.RegistrarMovimientoSp(objCobroInicial.idAfiliacion, objCredenciales);

                    if (!responseQueryMovimiento.Exito)
                    {
                        response.status = HttpStatusCode.BadRequest;
                        response.errors = new List<ErrorDetail>() {
                            new ErrorDetail {
                                errorMessage = responseQueryMovimiento.Mensaje ?? "Error al registrar el movimiento.",
                                errorUsuario = "Error al registrar el movimiento.",
                            }
                        };
                        response.messages = new List<Message>() {                            
                            new Message {
                                methodName = MethodBase.GetCurrentMethod().Name,
                                messageTec = "No se pudo registrar el movimiento.",
                                userMessage = "No se pudo registrar el movimiento."
                            },
                            new Message {
                                methodName = MethodBase.GetCurrentMethod().Name,
                                messageTec = "No se pudo registrar el cobro inicial.",
                                userMessage = "No se pudo registrar el cobro inicial.",
                            }
                        };
                        response.hasError = true;
                        return response;
                    }

                    var responseQuery = _cobroRepository.RegistrarCobroInicial(cobroEntity);

                    var cobroRespRegistroDto = _mapper.Map<CobroRespRegistroInicialDto>(responseQuery);

                    return ApiResponseHelper.GetGenericResponse(cobroRespRegistroDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<CobroRespRegistroInicialDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }
        public async Task<CrsApiResponse<CobroRespActualizarDto>> ActualizarCobro(CobroActualizarDto objCobroRespuesta, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<CobroRespActualizarDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var cobroEntity = _mapper.Map<COBRO>(objCobroRespuesta);

                    cobroEntity.COPVC_ESTADO = "PENDIENTE";
                    cobroEntity.COPBT_ACTIVO = true;
                    cobroEntity.COSDT_FECHA_INSERT = DateTime.Now;
                    cobroEntity.COSVC_ID_USER_INSERT = objCredenciales.usuario;

                    var responseQuery = _cobroRepository.ActualizarCobro(cobroEntity, objCredenciales);

                    var cobroDto = new CobroRespActualizarDto();
                    cobroDto.actualizado = responseQuery;
                    cobroDto.idCobro = objCobroRespuesta.idCobro;
                    return ApiResponseHelper.GetGenericResponse(cobroDto);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<CobroRespActualizarDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }
    }
}
