﻿using Models.Dtos;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics.ConsumoTransaccional.IRepository
{
    public interface ICobros
    {
        Task<CrsApiResponse<CobroRespRegistroInicialDto>> RegistrarCobroInicial(CobroRegistroInicialDto objCobroInicial, OcCredenciales objCredenciales);

        Task<CrsApiResponse<CobroRespActualizarDto>> ActualizarCobro(CobroActualizarDto objCobroRespuesta, OcCredenciales objCredenciales);
    }
}
