﻿using Logics.ServicioTransaccional;
using ManageDB.EFRepository;
using Microsoft.EntityFrameworkCore;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioOTPV2
{
    public class ServicioOTPV2
    {
        public PREPARA_REQUEST preparaRequest { get; set; }
        public CONFIRMA_REQUEST confirmaRequest { get; set; }
        private HttpWebRequest httpWebRequest { get; set; }

        private List<LEXICO> lexicosServiceCode { get; set; }
        private readonly LexicoRepository cLexico;

        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public ServicioOTPV2(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
            
            cLexico = new LexicoRepository(_context_sp, _context_c);
        }

        public void AlistarAmbiente_PreparaRequest()
        {
            List<LEXICO> lexicos = cLexico.ObtenerListaLexicoPorTabla("OTP");
            string rutaPrepara = lexicos.Where(x => x.LESVC_TEMA == "RUTA_WEB_PREPARA").First().LEPVC_VALOR;
            string rutaCertificadoFisico = lexicos.Where(x => x.LESVC_TEMA == "RUTA_CERTIFICADO").First().LEPVC_VALOR;
            string passCertificadoFisico = lexicos.Where(x => x.LESVC_TEMA == "PASS_CERTIFICADO").First().LEPVC_VALOR;
            string usuario = lexicos.Where(x => x.LESVC_TEMA == "USER_NAME").First().LEPVC_VALOR;
            string password = lexicos.Where(x => x.LESVC_TEMA == "PASSWORD").First().LEPVC_VALOR;
            //////////////////////////////////////////////////////////////////////////////////////////////
            string _appUserId = lexicos.Where(x => x.LESVC_TEMA == "APP_USER_ID").First().LEPVC_VALOR;
            string _glosa = lexicos.Where(x => x.LESVC_TEMA == "GLOSA").First().LEPVC_VALOR;
            string _businessCode = lexicos.Where(x => x.LESVC_TEMA == "BUSINESS_CODE").First().LEPVC_VALOR;
            string _publicToken = lexicos.Where(x => x.LESVC_TEMA == "PUBLIC_TOKEN").First().LEPVC_VALOR;
            ///////////////////////////////////////////////////////////////////////////////////////////////
            lexicosServiceCode = cLexico.ObtenerListaLexicoPorTabla("SERVICE_CODE");
            ///prepara elementos del request
            //System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls13;


            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebRequest.DefaultWebProxy = null;
            httpWebRequest = (HttpWebRequest)WebRequest.Create(rutaPrepara);
            httpWebRequest.Proxy = null;
            X509Certificate2 certificate = new X509Certificate2(rutaCertificadoFisico, passCertificadoFisico);
            httpWebRequest.ClientCertificates.Add(certificate);
            httpWebRequest.ContentType = "application/json";
            var credenciales = Encoding.Default.GetBytes(usuario + ":" + password);
            httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(credenciales));
            httpWebRequest.Method = "POST";

            preparaRequest = new PREPARA_REQUEST();
            preparaRequest.appUserId = _appUserId;
            preparaRequest.soliNumber = string.Empty;
            preparaRequest.gloss = _glosa;
            preparaRequest.businessCode = _businessCode;
            preparaRequest.publicToken = _publicToken;


        }

        public OcResponseOtp EjecutarAmbiente_PreparaRequest(string producto, long idTransaccion, string idc, string ext, string complemento, string expiracionTarjeta, string moneda, decimal importe, string tipoTarjeta)
        {
            //preparamos datos faltantes para el consumo
            var extension = string.IsNullOrEmpty(ext) ? "XX" : ext;

            preparaRequest.idc = idc;
            preparaRequest.extension = extension;
            preparaRequest.complement = complemento;
            preparaRequest.expireDate = expiracionTarjeta;
            preparaRequest.currency = moneda; //BOB  o  USD

            //colocamos valor quedamo para pruebas
            preparaRequest.amount = importe;//1;//importe;

            preparaRequest.serviceCode = lexicosServiceCode.Where(x => x.LESVC_TEMA == tipoTarjeta).First().LEPVC_VALOR;
            preparaRequest.date = DateTime.Now.ToString("yyyyMMdd");
            preparaRequest.hour = DateTime.Now.ToString("HHmmss");
            string correlationId = producto + "-" + idTransaccion.ToString("0000000000.##");
            httpWebRequest.Headers.Add("Correlation-Id", correlationId);

            //ahora si consumimos el servicio
            return EjecucionGenerica(preparaRequest);
        }

        public OcResponseOtp EjecutarAmbiente_ConfirmaRequest(string producto, long idTransaccion, string otp, string autorizacionNumber)
        {
            //preparamos datos faltantes para el consumo
            confirmaRequest.otp = otp;
            confirmaRequest.authorizationNumber = autorizacionNumber;
            confirmaRequest.date = DateTime.Now.ToString("yyyyMMdd");
            confirmaRequest.hour = DateTime.Now.ToString("HHmmss");
            string correlationId = producto + "-" + idTransaccion.ToString("0000000000.##");
            confirmaRequest.correlationId = correlationId;
            httpWebRequest.Headers.Add("Correlation-Id", correlationId);

            //ahora si consumimos el servicio
            return EjecucionGenerica(confirmaRequest);
        }
                      
        public OcResponseOtp EjecucionGenerica(object entrada)
        {
            string result = string.Empty;
            //Log.Debug(JsonConvert.SerializeObject(entrada));

            using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(JsonConvert.SerializeObject(entrada));
                streamWriter.Flush();
                streamWriter.Close();
            }
            try
            {
                /**Conexion y respuesta de nuestro servicio */
                // System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;

                HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();
                /**Transformando la respuesta en formato Stream para su lectura */
                StreamReader streamReader = new StreamReader(response.GetResponseStream());
                /**Obteniendo la respuesta en formato String */
                result = streamReader.ReadToEnd();
                streamReader.Close();
            }
            catch (Exception e)
            {
                /**Verifica si existio un error en el servicio HTTP */
                if (e is WebException)
                {
                    /**Obtenine la exception que levanto */
                    WebException webException = e as WebException;
                    /**Buscamos la respuesta que envio el servidor */
                    WebResponse response = webException.Response;
                    /**Transformando la respuesta en formato Stream para su lectura */
                    StreamReader streamReader = new StreamReader(response.GetResponseStream());
                    /**Obteniendo la respuesta en formato String */
                    result = streamReader.ReadToEnd();
                    streamReader.Close();
                }
            }
            return JsonConvert.DeserializeObject<OcResponseOtp>(result);
        }

        public class PREPARA_REQUEST
        {
            public string idc { get; set; }
            public string extension { get; set; }
            public string complement { get; set; }
            public string currency { get; set; }
            public decimal amount { get; set; }
            public string gloss { get; set; }
            public string serviceCode { get; set; }
            public string businessCode { get; set; }
            public string date { get; set; }
            public string hour { get; set; }
            public string soliNumber { get; set; }
            public string expireDate { get; set; }
            public string publicToken { get; set; }
            public string appUserId { get; set; }
        }

        public class CONFIRMA_REQUEST
        {
            public string appUserId { get; set; }
            public string publicToken { get; set; }
            public string date { get; set; }
            public string hour { get; set; }
            public string otp { get; set; }
            public string correlationId { get; set; }
            public string authorizationNumber { get; set; }
        }
    }
}
