﻿using ManageDB.EFRepository;
using Microsoft.EntityFrameworkCore;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static System.Net.Mime.MediaTypeNames;

namespace Logics.ServicioTransaccional
{
    public class ServicioOTP
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public ServicioOTP(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public OtpResponseModel GenerateOtpCode(string email, string number, string documentNumber,ref LOG_SERVICIO objLogServicio)
        {
            var cLexico = new LexicoRepository(_context_sp, _context_c);

            List<LEXICO> lexicos = cLexico.ObtenerListaLexicoPorTabla("OTP");
            var _baseUrl = lexicos.Where(x => x.LESVC_TEMA == "OTP_BASE_URL").First().LEPVC_VALOR;
            var _generateEndpoint = "Generate";
            //_validateEndpoint = "Validate";
            var _application = lexicos.Where(x => x.LESVC_TEMA == "OTP_APPLICATION").First().LEPVC_VALOR;
            var _channel = lexicos.Where(x => x.LESVC_TEMA == "OTP_CHANNEL").First().LEPVC_VALOR;
            var _password = lexicos.Where(x => x.LESVC_TEMA == "OTP_PASSWORD").First().LEPVC_VALOR;
            //_estaCifrado = ConfigurationManager.AppSettings.Get("OTP_CIFRADO");

            if (string.IsNullOrEmpty(_baseUrl)
                || string.IsNullOrEmpty(_generateEndpoint)
                //|| string.IsNullOrEmpty(_validateEndpoint)
                || string.IsNullOrEmpty(_application)
                || string.IsNullOrEmpty(_channel)
                || string.IsNullOrEmpty(_password))
            {
                throw new Exception("Variables de comunicación al servicio OTP faltantes o nulas");
            }


            HttpClient _httpClient = new HttpClient();
            OtpResponseModel result = new OtpResponseModel();
            OtpGenerationRequest request = new OtpGenerationRequest
            {
                aplicativo = _application,
                canal = _channel,
                celular = number,
                correoElectronico = email,
                nroDocumentoIdentidad = documentNumber,
                password = _password,
            };

            string contentString = JsonConvert.SerializeObject(request);            
            objLogServicio.LOPVC_REQUEST = contentString;
            StringContent content = new StringContent(contentString.ToString(), System.Text.Encoding.UTF8, "application/json");

            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) =>
                {
                    return true;
                };


                var fullUri = new Uri(new Uri(_baseUrl), _generateEndpoint);
                var response = _httpClient.PostAsync(fullUri, content).Result;
                objLogServicio.LOPVC_REQUEST = contentString;
                objLogServicio.LOPVC_URL = fullUri.ToString();
                //if (System.Configuration.ConfigurationManager.AppSettings.Get("Entorno") == "DESARROLLO")
                //{
                //    string stringResponse = "{\"state\":\"000\",\"message\":\"Procesamiento exitoso.\",\"data\":{\"textToDisplay\":\"Código OTP enviado a SMS: XXXXXX27 Correo: XXXXXXXXXXXXXXXXXXXX @gmail.com WhatsApp: XXXXXX27\"}}";
                //    OtpGenerationResponse otpResult = JsonConvert.DeserializeObject<OtpGenerationResponse>(stringResponse);
                //    result.CodigoRespuesta = 200;
                //    result.Message = otpResult.Message;
                //    result.FechaConsulta = DateTime.Now;
                //    result.Information = new List<string> { otpResult.Data.TextToDisplay };
                //    return result;
                //}

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string stringResponse = response.Content.ReadAsStringAsync().Result;
                    objLogServicio.LOPVC_RESPONSE = stringResponse;
                    OtpGenerationResponse otpResult = JsonConvert.DeserializeObject<OtpGenerationResponse>(stringResponse);
                    result.codigoRespuesta = 200;
                    result.fechaConsulta = DateTime.Now;
                    result.message = otpResult.message;
                    result.information = new List<string> { otpResult.data.textToDisplay };
                }
                else
                {
                    string stringResponse = response.Content.ReadAsStringAsync().Result;
                    objLogServicio.LOPVC_RESPONSE = stringResponse;
                    OtpErrorResponse otpErrorResult = JsonConvert.DeserializeObject<OtpErrorResponse>(stringResponse);
                    switch (response.StatusCode)
                    {
                        case HttpStatusCode.BadRequest:
                            result.codigoRespuesta = 400;
                            result.message = "La petición tiene errores o no contiene los campos necesarios.";
                            if (otpErrorResult.Errors.Aplicativo != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Aplicativo);
                            }
                            if (otpErrorResult.Errors.Canal != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Canal);
                            }
                            if (otpErrorResult.Errors.Celular != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Celular);
                            }
                            if (otpErrorResult.Errors.CorreoElectronico != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.CorreoElectronico);
                            }
                            if (otpErrorResult.Errors.NroDocumentoIdentidad != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.NroDocumentoIdentidad);
                            }
                            if (otpErrorResult.Errors.Password != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Password);
                            }
                            break;
                        case HttpStatusCode.Unauthorized:
                            result.codigoRespuesta = 401;
                            result.message = "El recurso requiere autenticación o credenciales inválidas.";
                            break;
                        case HttpStatusCode.Forbidden:
                            result.codigoRespuesta = 403;
                            result.message = "El servidor rechaza atender la solicitud.";
                            break;
                        case HttpStatusCode.NotFound:
                            result.codigoRespuesta = 404;
                            result.message = "Recurso no encontrado o inexistente.";
                            break;
                        case HttpStatusCode.MethodNotAllowed:
                            result.codigoRespuesta = 405;
                            result.message = "Error de método para la petición.";
                            break;
                        case HttpStatusCode.InternalServerError:
                            result.codigoRespuesta = 500;
                            result.message = "Error interno de servidor.";
                            break;
                        default:
                            result.codigoRespuesta = -1;
                            result.message = "Error desconocido.";
                            break;
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                result.codigoRespuesta = -1;
                result.message = ex.Message;
                result.fechaConsulta = DateTime.Now;
                return result;
            }
        }

        public OtpResponseModel ValidateOtpCode(string code, string documentNumber,ref LOG_SERVICIO objLogServicio)
        {
            var cLexico = new LexicoRepository(_context_sp, _context_c);

            List<LEXICO> lexicos = cLexico.ObtenerListaLexicoPorTabla("OTP");
            var _baseUrl = lexicos.Where(x => x.LESVC_TEMA == "OTP_BASE_URL").First().LEPVC_VALOR;
            //_generateEndpoint = "Generate";
            var _validateEndpoint = "Validate";
            var _application = lexicos.Where(x => x.LESVC_TEMA == "OTP_APPLICATION").First().LEPVC_VALOR;
            var _channel = lexicos.Where(x => x.LESVC_TEMA == "OTP_CHANNEL").First().LEPVC_VALOR;
            var _password = lexicos.Where(x => x.LESVC_TEMA == "OTP_PASSWORD").First().LEPVC_VALOR;
            //_estaCifrado = ConfigurationManager.AppSettings.Get("OTP_CIFRADO");

            if (string.IsNullOrEmpty(_baseUrl)
                //|| string.IsNullOrEmpty(_generateEndpoint)
                || string.IsNullOrEmpty(_validateEndpoint)
                || string.IsNullOrEmpty(_application)
                || string.IsNullOrEmpty(_channel)
                || string.IsNullOrEmpty(_password))
            {
                throw new Exception("Variables de comunicación al servicio OTP faltantes o nulas");
            }

            HttpClient _httpClient = new HttpClient();
            OtpResponseModel result = new OtpResponseModel();
            OtpValidationRequest request = new OtpValidationRequest
            {
                canal = _channel,
                aplicativo = _application,
                password = _password,
                codigo = code,
                nroDocumentoIdentidad = documentNumber
            };

            string contentString = JsonConvert.SerializeObject(request);
            

            StringContent content = new StringContent(contentString.ToString(), System.Text.Encoding.UTF8, "application/json");

            //if (System.Configuration.ConfigurationManager.AppSettings.Get("Entorno") == "DESARROLLO")
            //{
            //    string stringResponse = "{\"state\":\"000\",\"message\":\"Procesamiento exitoso.\",\"data\":{\"isValid\":true,\"status\":\"P\",\"description\":\"PROCESADO\",\"hash\":\"1264846744\"}}";
            //    OtpValidationResponse otpResult = JsonConvert.DeserializeObject<OtpValidationResponse>(stringResponse);
            //    result.CodigoRespuesta = Convert.ToInt32(otpResult.State);
            //    result.Message = otpResult.Message;
            //    result.FechaConsulta = DateTime.Now;
            //    result.Information = new List<string>
            //        {
            //            "OTP: " + (otpResult.Data.IsValid ? "valido" : "no valido"),
            //            "Estado: " + (otpResult.Data.Status ?? ""),
            //            "Descripcion: " + (otpResult.Data.Description ?? ""),
            //            "Hash: " + (otpResult.Data.Hash ?? "")
            //        };
            //    return result;
            //}

            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) =>
                {
                    return true;
                };
                var fullUri = new Uri(new Uri(_baseUrl), _validateEndpoint);
                var response = _httpClient.PostAsync(fullUri, content).Result;
                objLogServicio.LOPVC_REQUEST = contentString;
                objLogServicio.LOPVC_URL = fullUri.ToString();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string stringResponse = response.Content.ReadAsStringAsync().Result;
                    objLogServicio.LOPVC_RESPONSE = stringResponse;
                    OtpValidationResponse otpResult = JsonConvert.DeserializeObject<OtpValidationResponse>(stringResponse);
                    result.codigoRespuesta = Convert.ToInt32(otpResult.state.ToString());
                    result.fechaConsulta = DateTime.Now;
                    result.message = otpResult.message;
                    result.information = new List<string>
                    {
                        "OTP: " + (otpResult.data.isValid ? "valido" : "no valido"),
                        "Estado: " + (otpResult.data.status ?? ""),
                        "Descripcion: " + (otpResult.data.description ?? ""),
                        "Hash: " + (otpResult.data.hash ?? "")
                    };
                }
                else
                {
                    string stringResponse = response.Content.ReadAsStringAsync().Result;
                    objLogServicio.LOPVC_RESPONSE = stringResponse;
                    OtpErrorResponse otpErrorResult = JsonConvert.DeserializeObject<OtpErrorResponse>(stringResponse);
                    switch (response.StatusCode)
                    {
                        case HttpStatusCode.BadRequest:
                            result.codigoRespuesta = 400;
                            result.message = "La petición tiene errores o no contiene los campos necesarios.";
                            if (otpErrorResult.Errors.Aplicativo != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Aplicativo);
                            }
                            if (otpErrorResult.Errors.Canal != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Canal);
                            }
                            if (otpErrorResult.Errors.Celular != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Celular);
                            }
                            if (otpErrorResult.Errors.CorreoElectronico != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.CorreoElectronico);
                            }
                            if (otpErrorResult.Errors.NroDocumentoIdentidad != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.NroDocumentoIdentidad);
                            }
                            if (otpErrorResult.Errors.Password != null)
                            {
                                result.information.AddRange(otpErrorResult.Errors.Password);
                            }
                            break;
                        case HttpStatusCode.Unauthorized:
                            result.codigoRespuesta = 401;
                            result.message = "El recurso requiere autenticación o credenciales inválidas.";
                            break;
                        case HttpStatusCode.Forbidden:
                            result.codigoRespuesta = 403;
                            result.message = "El servidor rechaza atender la solicitud.";
                            break;
                        case HttpStatusCode.NotFound:
                            result.codigoRespuesta = 404;
                            result.message = "Recurso no encontrado o inexistente.";
                            break;
                        case HttpStatusCode.MethodNotAllowed:
                            result.codigoRespuesta = 405;
                            result.message = "Error de método para la petición.";
                            break;
                        case HttpStatusCode.InternalServerError:
                            result.codigoRespuesta = 500;
                            result.message = "Error interno de servidor.";
                            break;
                        default:
                            result.codigoRespuesta = -1;
                            result.message = "Error desconocido.";
                            break;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.codigoRespuesta = -1;
                result.message = ex.Message;
                result.fechaConsulta = DateTime.Now;
                return result;
            }
        }


    }
    #region Dtos

    public class OcResponseOtp
    {
        public string estado { get; set; }
        public string mensaje { get; set; }
        public Autorizacion datos { get; set; }
    }

    public class GeneraOtpRequest
    {
        public string correo { get; set; }
        public string numero { get; set; }
        public string numeroDocumento { get; set; }
    }


    public class ValidaOtpRequest
    {
        public string codigo { get; set; }
        public string numeroDocumento { get; set; }
    }

    public class Autorizacion
    {
        public string numeroAutorizacion { get; set; }
    }

    public class OtpResponseModel
    {
        public int codigoRespuesta { get; set; }
        public DateTime fechaConsulta { get; set; }
        public string message { get; set; }
        public List<string> information = new List<string>();
    }

    public class OtpGenerationRequest
    {
        public string canal { get; set; }
        public string password { get; set; }
        public string aplicativo { get; set; }
        public string correoElectronico { get; set; }
        public string celular { get; set; }
        public string nroDocumentoIdentidad { get; set; }
    }

    //public class OtpGenerationRequest
    //{
    //    public string Canal { get; set; }
    //    public string Password { get; set; }
    //    public string Aplicativo { get; set; }
    //    public string CorreoElectronico { get; set; }
    //    public string Celular { get; set; }
    //    public string NroDocumentoIdentidad { get; set; }
    //}

    public class OtpGenerationResponse
    {
        public string state { get; set; }
        public string message { get; set; }
        public Information data { get; set; }
    }

    public class Information
    {
        public string textToDisplay { get; set; }
    }

    public class OtpErrorResponse
    {
        public string Type { get; set; }
        public string Title { get; set; }
        public int Status { get; set; }
        public ErrorsResponse Errors { get; set; }
        public string TraceId { get; set; }
    }

    public class ErrorsResponse
    {
        public List<string> Canal { get; set; }
        public List<string> Celular { get; set; }
        public List<string> Password { get; set; }
        public List<string> Aplicativo { get; set; }
        public List<string> CorreoElectronico { get; set; }
        public List<string> NroDocumentoIdentidad { get; set; }
    }

    public class OtpValidationRequest
    {
        public string canal { get; set; }
        public string password { get; set; }
        public string aplicativo { get; set; }
        public string codigo { get; set; }
        public string nroDocumentoIdentidad { get; set; }
    }

    public class OtpValidationResponse
    {
        public string state { get; set; }
        public string message { get; set; }
        public OtpValidationDataResponse data { get; set; }
    }

    public class OtpValidationDataResponse
    {
        public bool isValid { get; set; }
        public string status { get; set; }
        public string description { get; set; }
        public string hash { get; set; }
    }

    #endregion
}
