﻿using Common.Parameters;
using Microsoft.Extensions.Configuration;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ServicioAMLC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioTransaccional
{
    public class ServicioLInternacionales
    {
        private readonly string _entorno;

        public ServicioLInternacionales(IConfiguration configuration)
        {
            _entorno = configuration.GetValue<string>("ENTORNO");
        }
        public void ValidarListasInternacionalesArchivoNegativo(AseguradoLInternacionalesDto objAsegurado, ref ocRespuestaValidacionLista validacionAMLC, ref ocRespuestaValidacionLista validacionAN,ref LOG_SERVICIO objLogServicioAMLC ,ref LOG_SERVICIO objLogServicioAN)
        {
            try
            {
                // True = persona no está en listas; False = persona está en listas
                string[] extensiones = new string[] { "LP", "SC", "CB", "CH", "TA", "OR", "PO", "PA", "BE", "PE", "XX", };

                string complemento = objAsegurado.complemento;
                if (string.IsNullOrEmpty(objAsegurado.complemento))
                {
                    complemento = "00";
                }
                string matriculaArchivoNegativo = "";// ConfigurationManager.AppSettings.Get("MATRICULA_API_SEGIP");

                ConsultaWsdlPortTypeClient objCliente = new ConsultaWsdlPortTypeClient();
                ResPersona respuesta = null;

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => true;
                objLogServicioAMLC.LOPVC_REQUEST = JsonConvert.SerializeObject(objAsegurado, Formatting.Indented);
                objLogServicioAMLC.LOPVC_URL = objCliente.Endpoint.Address.Uri.ToString();
                foreach (string extension in extensiones)
                {
                    if (_entorno != "DESARROLLO")
                    {
                        respuesta = objCliente.getConsulta(objAsegurado.numeroDocumento, extension, "Q", complemento, matriculaArchivoNegativo, "", "", "", "1");
                    }
                    else
                    {

                        respuesta = new ResPersona();
                        respuesta.nrodocumento = objAsegurado.numeroDocumento;
                        respuesta.resmatch = "No se encuentra en listas";
                        respuesta.nombres = "";
                        respuesta.lista_negativa = "{\"archivoNegativo\":false}\n";
                        respuesta.coin = new ResConsulta[0];
                    }


                    if (respuesta != null && respuesta.resmatch != "No se encuentra en listas")
                    {
                        break;
                    }
                    objLogServicioAMLC.LOPVC_RESPONSE = JsonConvert.SerializeObject(respuesta, Formatting.Indented);
                    JObject jObject = JObject.Parse(respuesta.lista_negativa);
                    if ((bool)jObject["archivoNegativo"])
                    {
                        break;
                    }
                }

                if (respuesta != null)
                {
                    validacionAMLC.entidad = "AMLC";
                    validacionAMLC.respuesta = respuesta.resmatch;
                    validacionAMLC.estado = (respuesta != null && respuesta.resmatch == "No se encuentra en listas");
                    validacionAMLC.fechaHora = DateTime.Now;
                    validacionAMLC.respuestaAdjunto = JsonConvert.SerializeObject(respuesta, Formatting.Indented);

                    objLogServicioAN.LOPVC_REQUEST = JsonConvert.SerializeObject(validacionAMLC, Formatting.Indented);
                    objLogServicioAN.LOPVC_URL = objCliente.Endpoint.Address.Uri.ToString();

                    if (ValidarExistenciaListasRestringidas(respuesta, ObtenerListasRestringidas()) == false && ValidarExistenciaListasPermitidas(respuesta, ObtenerListasPermitidas()))
                    {
                        validacionAMLC.estado = true;
                    }

                    validacionAN.entidad = "ARCHIVO_NEGATIVO";
                    validacionAN.fechaHora = DateTime.Now;
                    validacionAN.respuestaAdjunto = respuesta.lista_negativa;

                    JObject jsonObject = JObject.Parse(respuesta.lista_negativa);
                    if (jsonObject.TryGetValue("status", out JToken token) && token.Type == JTokenType.Integer)
                    {
                        validacionAN.estado = false;
                        validacionAN.respuesta = (string)jsonObject["errors"];
                    }
                    else
                    {
                        validacionAN.estado = !(bool)jsonObject["archivoNegativo"];
                        validacionAN.respuesta = (bool)jsonObject["archivoNegativo"] ? "Se encuentra en Archivo Negativo" : "No se encuentra en Archivo Negativo";
                    }
                    objLogServicioAN.LOPVC_RESPONSE = JsonConvert.SerializeObject(validacionAN, Formatting.Indented);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
        }
        public class ocRespuestaValidacionLista
        {
            public string entidad { get; set; }
            public string respuesta { get; set; }
            public string respuestaAdjunto { get; set; }
            public DateTime fechaHora { get; set; }
            public bool estado { get; set; }

            public ocRespuestaValidacionLista()
            {
                entidad = null;
                respuesta = null;
                respuestaAdjunto = null;
                fechaHora = DateTime.Now;
                estado = false;
            }
        }
        public class ocRespuestaValidacionLIternacionales
        {
            public ocRespuestaValidacionLista validacionAMLC { get; set; }

            public ocRespuestaValidacionLista validacionAN { get; set; }

        }

            private bool ValidarExistenciaListasPermitidas(ResPersona objResPersona, string[] objListasPermitidas)
        {
            try
            {
                bool estado = false;
                foreach (ResConsulta item in objResPersona.coin)
                {
                    if (objListasPermitidas.Contains(item.codigo)) estado = true;
                }

                return estado;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return false;
            }
        }

        private bool ValidarExistenciaListasRestringidas(ResPersona objResPersona, string[] objListasRestringidas)
        {
            try
            {
                bool estado = false;
                foreach (ResConsulta item in objResPersona.coin)
                {
                    if (objListasRestringidas.Contains(item.codigo)) estado = true;
                }

                return estado;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return false;
            }
        }

        private string[] ObtenerListasPermitidas()
        {
            string cfgListasPermitidas = "";// ConfigurationManager.AppSettings.Get("LISTAS_PERMITIDAS");

            if (cfgListasPermitidas == null)
                throw new Exception("La variable LISTAS_PERMITIDAS no se encuentra definido en el archivo de configuración.");

            return cfgListasPermitidas != null ? cfgListasPermitidas.Split('|') : null;
        }

        private string[] ObtenerListasRestringidas()
        {
            string cfgListasRestringidas = "";// ConfigurationManager.AppSettings.Get("LISTAS_RESTRINGIDAS");

            if (cfgListasRestringidas == null)
                throw new Exception("La variable LISTAS_RESTRINGIDAS no se encuentra definido en el archivo de configuración.");

            return cfgListasRestringidas != null ? cfgListasRestringidas.Split('|') : null;
        }
    }
}
