﻿using Agent;
using Common.Parameters;
using DevExpress.XtraRichEdit.Import.Html;
using Microsoft.Extensions.Configuration;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using ServicioSegip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioTransaccional
{
    public class ServicioSegipClass
    {
        private readonly IServicioExternoInstitucion _servicioSegip = Localizador.ServicioExternoInstitucion();

        private readonly string _entorno;

        public ServicioSegipClass(IConfiguration configuration)
        {
            _entorno = configuration.GetValue<string>("ENTORNO");
        }

        public SegipCampoACampoRespuesta ValidacionSegipCampoACampo(AseguradoSegipDto persona, List<LEXICO> lstLexico,ref LOG_SERVICIO objLogServicio)
        {
            try
            {
                //ServicioExternoInstitucionClient servicioSegipCampoACampo = new ServicioExternoInstitucionClient();
                SegipCampoACampoRespuesta contrastacionRespuesta = new SegipCampoACampoRespuesta();
                int idInstitucional = 0;
                bool isNumeric = false;

                string usuario = lstLexico.Where(x => x.LESVC_TEMA == "SEGIP_USUARIO").First().LEPVC_VALOR;// ConfigurationManager.AppSettings.Get("SEGIP_USUARIO");
                string clave = lstLexico.Where(x => x.LESVC_TEMA == "SEGIP_CLAVE").First().LEPVC_VALOR;// ConfigurationManager.AppSettings.Get("SEGIP_CLAVE");
                string acceso = lstLexico.Where(x => x.LESVC_TEMA == "SEGIP_ACCESO").First().LEPVC_VALOR;// ConfigurationManager.AppSettings.Get("SEGIP_ACCESO");
                string idSegip = lstLexico.Where(x => x.LESVC_TEMA == "SEGIP_ID").First().LEPVC_VALOR;// ConfigurationManager.AppSettings.Get("SEGIP_ID");
                //string estaCifrado = lstLexico.Where(x => x.LESVC_TEMA == "SEGIP_CIFRADO").First().LEPVC_VALOR;// ConfigurationManager.AppSettings.Get("SEGIP_CIFRADO");

                if (string.IsNullOrEmpty(usuario)
                    || string.IsNullOrEmpty(clave)
                    || string.IsNullOrEmpty(acceso)
                    || string.IsNullOrEmpty(idSegip))
                {
                    throw new Exception("Variables de comunicación a SEGIP Campo a Campo faltantes o nulas");
                }

                //if (string.Equals("SI", estaCifrado, StringComparison.CurrentCultureIgnoreCase))
                //{
                //    encryptador encriptManager = new encryptador("");
                //    encriptManager.EncryptDecryptPublic(false, usuario, ref usuario);
                //    encriptManager.EncryptDecryptPublic(false, clave, ref clave);
                //    encriptManager.EncryptDecryptPublic(false, acceso, ref acceso);
                //    encriptManager.EncryptDecryptPublic(false, idSegip, ref idSegip);
                //    isNumeric = int.TryParse(idSegip, out idInstitucional);
                //}
                //if (isNumeric == false)
                //{
                //    throw new Exception("El Id Institucional es incorrecto");
                //}

                SegipCampoACampoRequest personaPeticion = new SegipCampoACampoRequest
                {
                    NumeroDocumento = persona.numeroDocumento,
                    Complemento = persona.complemento,
                    FechaNacimiento = persona.fechaNacimiento.ToString("dd/MM/yyyy"),
                    Nombres = persona.nombre,
                    PrimerApellido = persona.apPaterno,
                    SegundoApellido = persona.apMaterno,
                    LugarNacimientoDepartamento = persona.ciudad,
                    LugarNacimientoLocalidad = "",
                    LugarNacimientoPais = persona.nacionalidad,
                    LugarNacimientoProvincia = ""
                };

                int esNacional = (persona.tipoDocumento == "CIE") ? 2 : 1;
                string peticion = JsonConvert.SerializeObject(personaPeticion);
                objLogServicio.LOPVC_REQUEST = peticion;
                var url = (_servicioSegip as System.ServiceModel.ClientBase<IServicioExternoInstitucion>)?.Endpoint?.Address?.Uri?.ToString();
                objLogServicio.LOPVC_URL = url;

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => true;
                var respuesta = new RespuestaConsultaContrastacion();
                if (_entorno != "DESARROLLO")
                {
                    respuesta = _servicioSegip.ConsultaDatoPersonaContrastacion(idInstitucional, usuario, clave, acceso, "", peticion, esNacional);
                }
                else
                {
                    respuesta.CodigoRespuesta = 2;
                    respuesta.Mensaje = "La consulta se realizó satisfactoriamente";
                    respuesta.EsValido = true;
                    respuesta.CodigoUnico = "jxeeUd5H - 3905068";
                    respuesta.TipoMensaje = "Correcto";
                    respuesta.ContrastacionEnFormatoJson = "{\"ApellidoEsposo\":2,\"Complemento\":1,\"FechaNacimiento\":1,\"LugarNacimientoDepartamento\":2,\"LugarNacimientoLocalidad\":2,\"LugarNacimientoPais\":2,\"LugarNacimientoProvincia\":2,\"NumeroDocumento\":1,\"Nombres\":1,\"PrimerApellido\":1,\"ProfesionOcupacion\":2,\"SegundoApellido\":1,\"ComplementoVisible\":2}";
                    respuesta.DescripcionRespuesta = "Se encontró un registro";
                }

                contrastacionRespuesta.CodigoRespuesta = respuesta.CodigoRespuesta;
                contrastacionRespuesta.CodigoUnico = respuesta.CodigoUnico;
                contrastacionRespuesta.DescripcionRespuesta = respuesta.DescripcionRespuesta;
                contrastacionRespuesta.HoraRespuesta = DateTime.Now;
                contrastacionRespuesta.EsValido = respuesta.EsValido;
                contrastacionRespuesta.TipoMensaje = respuesta.TipoMensaje;
                contrastacionRespuesta.Mensaje = respuesta.Mensaje;

                objLogServicio.LOPVC_RESPONSE = respuesta.ContrastacionEnFormatoJson;

                if (!string.IsNullOrEmpty(respuesta.ContrastacionEnFormatoJson))
                {
                    SegipContrastacion contrastacion = JsonConvert.DeserializeObject<SegipContrastacion>(respuesta.ContrastacionEnFormatoJson);
                    contrastacionRespuesta.CoincidenciaNroDocumento = contrastacion.NumeroDocumento == 1;
                    contrastacionRespuesta.CoincidenciaComplemento = contrastacion.Complemento == 1;
                    contrastacionRespuesta.CoincidenciaPaterno = contrastacion.PrimerApellido == 1;
                    contrastacionRespuesta.CoincidenciaMaterno = contrastacion.SegundoApellido == 1;
                    contrastacionRespuesta.CoincidenciaNombres = contrastacion.Nombres == 1;
                    contrastacionRespuesta.CoincidenciaFechaNacimiento = contrastacion.FechaNacimiento == 1;
                    contrastacionRespuesta.CoincidenciaPaisNacimiento = contrastacion.LugarNacimientoPais == 1;
                    contrastacionRespuesta.ContratacionJson = respuesta.ContrastacionEnFormatoJson;
                }
                return contrastacionRespuesta;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw;
            }
        }

        public class SegipCampoACampoRequest
        {
            public string NumeroDocumento { get; set; }
            public string Complemento { get; set; }
            public string Nombres { get; set; }
            public string PrimerApellido { get; set; }
            public string SegundoApellido { get; set; }
            public string FechaNacimiento { get; set; }
            public string LugarNacimientoPais { get; set; }
            public string LugarNacimientoDepartamento { get; set; }
            public string LugarNacimientoProvincia { get; set; }
            public string LugarNacimientoLocalidad { get; set; }
        }

        public class SegipCampoACampoRespuesta
        {
            public int CodigoRespuesta { get; set; }
            public string CodigoUnico { get; set; }
            public string ContratacionJson { get; set; }
            public string DescripcionRespuesta { get; set; }
            public bool EsValido { get; set; }
            public string Mensaje { get; set; }
            public string TipoMensaje { get; set; }
            public DateTime? HoraRespuesta { get; set; }
            public bool CoincidenciaNroDocumento { get; set; }
            public bool CoincidenciaComplemento { get; set; }
            public bool CoincidenciaPaterno { get; set; }
            public bool CoincidenciaMaterno { get; set; }
            public bool CoincidenciaNombres { get; set; }
            public bool CoincidenciaPaisNacimiento { get; set; }
            public bool CoincidenciaDepartamentoNacimiento { get; set; }
            public bool CoincidenciaFechaNacimiento { get; set; }
        }

        public class SegipContrastacion
        {
            public int ApellidoEsposo { get; set; }
            public int Complemento { get; set; }
            public int FechaNacimiento { get; set; }
            public int LugarNacimientoDepartamento { get; set; }
            public int LugarNacimientoLocalidad { get; set; }
            public int LugarNacimientoPais { get; set; }
            public int LugarNacimientoProvincia { get; set; }
            public int NumeroDocumento { get; set; }
            public int Nombres { get; set; }
            public int PrimerApellido { get; set; }
            public int ProfesionOcupacion { get; set; }
            public int SegundoApellido { get; set; }
            public int ComplementoVisible { get; set; }
        }
                
    }
}
