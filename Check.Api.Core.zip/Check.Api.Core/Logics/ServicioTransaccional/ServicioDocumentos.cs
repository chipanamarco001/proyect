﻿using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Models.Dtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioTransaccional
{
    public class ServicioDocumentos
    {
        private readonly DocumentoRepository _documentoRepository;
        private readonly DocumentoParametroRepository _documentoParametroRepository;
        private readonly CManejadorBaseDatos _manejadorBD;

        public ServicioDocumentos(DocumentoRepository documentoRepository,
        DocumentoParametroRepository documentoParametroRepository,
        CManejadorBaseDatos manejadorBD)
        {
            _documentoRepository = documentoRepository ?? throw new ArgumentNullException(nameof(documentoRepository));
            _documentoParametroRepository = documentoParametroRepository ?? throw new ArgumentNullException(nameof(documentoParametroRepository));
            _manejadorBD = manejadorBD ?? throw new ArgumentNullException(nameof(manejadorBD));
        }

        public OC_RESPONSE_FILE GetWordDocument<T>(string strIdDocumento,
           List<Parameter> listaParametros,
           OC_RESPONSE_FILE objResponseFile,
           CrsApiResponse<T> response)
        {
            try
            {
                bool boolCrearDocumento = true;
                var objDocumento = _documentoRepository.ObtenerDocumentoPorId(strIdDocumento);
                //ValidationResult = new CRSValidationResult();
                //if (objDocumento == null)
                //{
                //    ValidationResult.Error = true;
                //    ValidationResult.ValidationErrors = new List<ListErrors>();
                //    ListErrors lstError = new ListErrors();
                //    lstError.ErrorMessage = "Error Objeto Ubicacion Plantilla";
                //    ValidationResult.ValidationErrors.Add(lstError);
                //    return objResponseFile;
                //}
                if (objDocumento == null)
                {
                    response.hasError = true;                     
                    var oError = new ErrorDetail();
                    oError.errorMessage = "Error Objeto Ubicacion Plantilla";
                    response.errors.Add(oError);
                    return objResponseFile;
                }

                if (objResponseFile.BoolHistorico)
                {
                    if (File.Exists(objDocumento.DOPVC_RUTA_REPOSITORIO +
                        ((objResponseFile.CarpetaSalida != string.Empty) ? objResponseFile.CarpetaSalida + @"\" : string.Empty) +
                        objResponseFile.NombreArchivo))
                    {
                        boolCrearDocumento = false;
                        objResponseFile.ContentType = OC_RESPONSE_FILE.ConvertFormatToContentType(objResponseFile.FormatoSalida);
                        string strRutaArchivoEnc = Convert.ToBase64String(Encoding.UTF8.GetBytes(
                            objDocumento.DOPVC_RUTA_REPOSITORIO +
                            ((objResponseFile.CarpetaSalida != string.Empty) ? objResponseFile.CarpetaSalida + @"\" : string.Empty) +
                            objResponseFile.NombreArchivo
                            ));
                        objResponseFile.RutaArchivoEnc = strRutaArchivoEnc;
                    }
                }
                if (boolCrearDocumento)
                {
                    List<DOCUMENTO_PARAMETRO> listaDocumentoParametro = _documentoParametroRepository.ObtenerLstDocumentoParametroPorId(objDocumento.DOPVC_ID_DOCUMENTO);
                    DataSet dsDatosDocumento = _manejadorBD.GetDataSet(objDocumento.DOPVC_PROCEDIMIENTO, listaParametros);
                    if (dsDatosDocumento == null || dsDatosDocumento.Tables.Count == 0)
                    {
                        //ValidationResult.Error = false;
                        //ValidationResult.ValidationErrors = new List<ListErrors>();
                        //ListErrors lstError = new ListErrors();
                        //lstError.ErrorMessage = "Error: dataset vacio y/o con tablas insuficientes.";
                        //ValidationResult.ValidationErrors.Add(lstError);
                        //return objResponseFile;

                        response.hasError = true;
                        var oError = new ErrorDetail();
                        oError.errorMessage = "Error: dataset vacio y/o con tablas insuficientes.";
                        response.errors.Add(oError);
                        return objResponseFile;
                    }
                    RichEditDocumentServer objDocumentServer = new RichEditDocumentServer();//null;
                    objDocumentServer.LoadDocument(objDocumento.DOPVC_RUTA_PLANTILLA + objDocumento.DOPVC_NOMBRE);
                    objDocumentServer.Options.Export.Html.EmbedImages = true;
                    for (int index = 0; index < dsDatosDocumento.Tables.Count; index++)
                    {
                        foreach (DOCUMENTO_PARAMETRO objDocumentoParametro in listaDocumentoParametro)
                        {
                            switch (objDocumentoParametro.PAPVC_TIPO)
                            {
                                case "TEXTO":
                                    if (objDocumentoParametro.PAPIN_INDEX_TABLA == index)
                                    {
                                        objDocumentServer = ReplaceAll(objDocumentServer, objDocumentoParametro.PAPVC_ETIQUETA, dsDatosDocumento.Tables[index].Rows[0][objDocumentoParametro.PAPVC_VALOR].ToString());
                                    }
                                    break;
                                case "SECCIONES":
                                    if (index == objDocumentoParametro.PAPIN_INDEX_TABLA)
                                        objDocumentServer = EliminarSecciones(objDocumentServer, dsDatosDocumento.Tables[index]);
                                    break;
                                case "SECCION_VINETAS":
                                    if (index == objDocumentoParametro.PAPIN_INDEX_TABLA)
                                    {
                                        string strListItem = string.Empty;
                                        for (int intRowNumber = 0; intRowNumber < dsDatosDocumento.Tables[index].Rows.Count; intRowNumber++)
                                            strListItem += ((!string.IsNullOrEmpty(strListItem)) ? "\r\n" : string.Empty) + dsDatosDocumento.Tables[index].Rows[intRowNumber][objDocumentoParametro.PAPVC_VALOR].ToString();
                                        Bookmark bm = objDocumentServer.Document.Bookmarks[objDocumentoParametro.PAPVC_ETIQUETA];
                                        DocumentPosition position = bm.Range.Start;
                                        DocumentRange rangeToDelete = null;
                                        Paragraph endParagraph = objDocumentServer.Document.Paragraphs.Get(bm.Range.End);
                                        if (endParagraph.Range.Start.ToInt() == bm.Range.End.ToInt())
                                            rangeToDelete = objDocumentServer.Document.CreateRange(position, bm.Range.Length - 1);
                                        else
                                            rangeToDelete = bm.Range;
                                        objDocumentServer.Document.Delete(rangeToDelete);
                                        objDocumentServer.Document.InsertText(position, strListItem);
                                    }
                                    break;
                                case "TABLA":
                                    if (index == objDocumentoParametro.PAPIN_INDEX_TABLA)
                                    {
                                        objDocumentServer = AgregarFilaTabla(objDocumentServer, objDocumentoParametro.PAPVC_ETIQUETA, dsDatosDocumento.Tables[index], objDocumentoParametro.DOSVC_CONFIGURACION ?? string.Empty);
                                        objDocumentServer = ReplaceAll(objDocumentServer, objDocumentoParametro.PAPVC_ETIQUETA, objDocumentoParametro.PAPVC_VALOR);
                                    }
                                    break;
                                case "HTML":
                                    if (objDocumentoParametro.PAPIN_INDEX_TABLA == index)
                                    {
                                        objDocumentServer = ReplaceHtml(objDocumentServer, objDocumentoParametro.PAPVC_ETIQUETA, dsDatosDocumento.Tables[index].Rows[0][objDocumentoParametro.PAPVC_VALOR].ToString());
                                    }
                                    break;
                            }
                        }
                    }
                    objDocumentServer = EliminarTags(objDocumentServer);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        if (objResponseFile.FormatoSalida == "PDF")
                        {
                            objDocumentServer.ExportToPdf(stream);
                        }
                        else
                        {
                            DevExpress.XtraRichEdit.DocumentFormat format = OC_RESPONSE_FILE.ConvertFormatToDocumentFormat(objResponseFile.FormatoSalida);
                            objDocumentServer.SaveDocument(stream, format);
                        }
                        objResponseFile.ContentType = OC_RESPONSE_FILE.ConvertFormatToContentType(objResponseFile.FormatoSalida);
                        objResponseFile.NombreArchivo += OC_RESPONSE_FILE.ConvertFormatToExtension(objResponseFile.FormatoSalida);
                        if (objResponseFile.CarpetaSalida != string.Empty)
                        {
                            string strRutaFinal = objDocumento.DOPVC_RUTA_REPOSITORIO;
                            string[] strCarpetas = objResponseFile.CarpetaSalida.Split('\\');
                            for (int index = 0; index < strCarpetas.Count(); index++)
                            {
                                if (strCarpetas[index].Trim() != string.Empty && !Directory.Exists(strRutaFinal + strCarpetas[index].Trim()))
                                    Directory.CreateDirectory(strRutaFinal + strCarpetas[index].Trim());
                                strRutaFinal += strCarpetas[index].Trim() + "\\";
                            }
                        }
                        //using (FileStream file = new FileStream(
                        //    objDocumento.DOPVC_RUTA_REPOSITORIO +
                        //    ((objResponseFile.CarpetaSalida != string.Empty) ? objResponseFile.CarpetaSalida + @"\" : string.Empty) +
                        //    objResponseFile.NombreArchivo, FileMode.Create, FileAccess.Write))
                        //{
                        //    stream.WriteTo(file);
                        //    file.Close();
                        //}

                        string rutaArchivo = Path.Combine(
                            objDocumento.DOPVC_RUTA_REPOSITORIO,
                            objResponseFile.CarpetaSalida ?? string.Empty,
                            objResponseFile.NombreArchivo
                        );

                        // Asegura que el directorio existe antes de crear el archivo
                        string directorio = Path.GetDirectoryName(rutaArchivo);
                        if (!Directory.Exists(directorio))
                        {
                            Directory.CreateDirectory(directorio);
                        }

                        using (FileStream file = new FileStream(rutaArchivo, FileMode.Create, FileAccess.Write))
                        {
                            stream.WriteTo(file);
                        }

                        string strRutaArchivoEnc = Convert.ToBase64String(Encoding.UTF8.GetBytes(
                            objDocumento.DOPVC_RUTA_REPOSITORIO +
                            ((objResponseFile.CarpetaSalida != string.Empty) ? objResponseFile.CarpetaSalida + @"\" : string.Empty) +
                            objResponseFile.NombreArchivo));
                        objResponseFile.RutaArchivoEnc = strRutaArchivoEnc;
                        stream.Close();
                    }
                }
                //Log.Fin();
                return objResponseFile;
            }
            catch (Exception ex)
            {
                //Log.Error(ex);
                throw;
            }
        }

        private RichEditDocumentServer ReplaceAll(RichEditDocumentServer objDocumentServer, string strFind, string strReplace)
        {
            if (!string.IsNullOrEmpty(strFind))
            {
                DocumentRange[] ranges = objDocumentServer.Document.FindAll(strFind, DevExpress.XtraRichEdit.API.Native.SearchOptions.None, objDocumentServer.Document.Range);
                for (int i = 0; i < ranges.Length; i++)
                {
                    if (strReplace == "null")
                        strReplace = string.Empty;
                    objDocumentServer.Document.Replace(ranges[i], strReplace);
                }
                ;

                for (int i = 0; i < objDocumentServer.Document.Sections.Count; i++)
                {
                    Section objSection = objDocumentServer.Document.Sections[i];
                    SubDocument header1 = objSection.BeginUpdateHeader(HeaderFooterType.First);
                    header1.ReplaceAll(strFind, strReplace, DevExpress.XtraRichEdit.API.Native.SearchOptions.None);
                    objSection.EndUpdateHeader(header1);

                    SubDocument header2 = objSection.BeginUpdateHeader(HeaderFooterType.Even);
                    header2.ReplaceAll(strFind, strReplace, DevExpress.XtraRichEdit.API.Native.SearchOptions.None);
                    objSection.EndUpdateHeader(header2);

                    SubDocument header3 = objSection.BeginUpdateHeader(HeaderFooterType.Odd);
                    header3.ReplaceAll(strFind, strReplace, DevExpress.XtraRichEdit.API.Native.SearchOptions.None);
                    objSection.EndUpdateHeader(header3);
                }
            }
            return objDocumentServer;
        }

        private RichEditDocumentServer ReplaceHtml(RichEditDocumentServer objDocumentServer, string strFind, string strReplace)
        {
            try
            {
                if (!string.IsNullOrEmpty(strFind))
                {
                    DocumentRange[] ranges = objDocumentServer.Document.FindAll(strFind, DevExpress.XtraRichEdit.API.Native.SearchOptions.None, objDocumentServer.Document.Range);
                    for (int i = 0; i < ranges.Length; i++)
                    {
                        if (strReplace == "null")
                        {
                            strReplace = string.Empty;
                        }
                        DocumentPosition currentPosition = ranges[i].Start;
                        objDocumentServer.Document.InsertHtmlText(currentPosition, strReplace, InsertOptions.UseDestinationStyles);
                        objDocumentServer.Document.Replace(ranges[i], string.Empty);
                    }
                }
                return objDocumentServer;
            }
            catch
            {
                throw;
            }
        }

        public RichEditDocumentServer EliminarSecciones(RichEditDocumentServer objDocumentServer, DataTable DtblSecciones)
        {
            try
            {
                for (int index = 0; index < DtblSecciones.Rows.Count; index++)
                {
                    if (DtblSecciones.Rows[index]["SECCION"].ToString().Trim() != string.Empty)
                    {
                        string strSeccion = DtblSecciones.Rows[index]["SECCION"].ToString().Trim();
                        var paragraphs = objDocumentServer.Document.Paragraphs;
                        List<DevExpress.XtraRichEdit.API.Native.Table> listaTablas = new List<DevExpress.XtraRichEdit.API.Native.Table>();
                        bool boolSeccion = false;
                        foreach (var objParagraph in paragraphs)
                        {
                            if (objDocumentServer.Document.GetText(objParagraph.Range).Contains(strSeccion))
                                boolSeccion = !boolSeccion;
                            if (boolSeccion)
                            {
                                TableCell currentTableCell = objDocumentServer.Document.Tables.GetTableCell(objParagraph.Range.Start);
                                if (currentTableCell != null)
                                {
                                    var objTable = listaTablas.Where(w => w.Range.Start == currentTableCell.Table.Range.Start).FirstOrDefault();
                                    if (objTable == null)
                                        listaTablas.Add(currentTableCell.Table);
                                }
                            }
                        }
                        foreach (var objTable in listaTablas)
                        {
                            objDocumentServer.Document.Tables.Remove(objTable);
                        }
                        paragraphs = objDocumentServer.Document.Paragraphs;
                        List<Paragraph> listaParrafos = new List<Paragraph>();
                        foreach (var objParagraph in paragraphs)
                        {
                            if (objDocumentServer.Document.GetText(objParagraph.Range).Contains(strSeccion))
                            {
                                if (boolSeccion) { listaParrafos.Add(objParagraph); }
                                boolSeccion = !boolSeccion;
                            }
                            if (boolSeccion)
                                listaParrafos.Add(objParagraph);
                        }
                        foreach (var objParagraph in listaParrafos)
                        {
                            objDocumentServer.Document.Delete(objParagraph.Range);
                        }
                    }
                }
                return objDocumentServer;
            }
            catch
            {
                throw;
            }
        }

        public RichEditDocumentServer EliminarTags(RichEditDocumentServer objDocumentServer)
        {
            try
            {
                var paragraphs = objDocumentServer.Document.Paragraphs;
                List<Paragraph> listaParrafos = new List<Paragraph>();
                foreach (var objParagraph in paragraphs)
                {
                    if (objDocumentServer.Document.GetText(objParagraph.Range).Contains("<#") && objDocumentServer.Document.GetText(objParagraph.Range).Contains("#>"))
                        listaParrafos.Add(objParagraph);
                }
                foreach (var objParagraph in listaParrafos)
                {
                    objDocumentServer.Document.Delete(objParagraph.Range);
                }
                return objDocumentServer;
            }
            catch
            {
                throw;
            }
        }

        public RichEditDocumentServer AgregarFilaTabla(RichEditDocumentServer objDocumentServer, string strPalabraClave, DataTable DtblFilas, string strConfiguracionTabla)
        {
            try
            {
                var paragraphs = objDocumentServer.Document.Paragraphs;
                foreach (var objParagraph in paragraphs)
                {
                    if (objDocumentServer.Document.GetText(objParagraph.Range).Contains(strPalabraClave))
                    {

                        occ_documento__tabla objConfiguracionTabla = null;
                        if (!string.IsNullOrEmpty(strConfiguracionTabla))
                            objConfiguracionTabla = JsonConvert.DeserializeObject<occ_documento__tabla>(strConfiguracionTabla);
                        TableCell currentTableCell = objDocumentServer.Document.Tables.GetTableCell(objParagraph.Range.Start);
                        if (currentTableCell != null)
                        {
                            var objTable = currentTableCell.Table;
                            int intNumeroCoolumnas = DtblFilas.Columns.Count;
                            for (int intFila = 0; intFila < DtblFilas.Rows.Count; intFila++)
                            {
                                var newRow = objTable.Rows.Append();
                                for (int intColumna = 0; intColumna < newRow.Cells.Count; intColumna++)
                                {
                                    TableCell tc = newRow[intColumna];
                                    occ_documento__tabla__columna confColumna = null;
                                    if (objConfiguracionTabla != null)
                                        if (objConfiguracionTabla.ListaColumnas != null)
                                            confColumna = objConfiguracionTabla.ListaColumnas.Find(f => f.Indice == intColumna);
                                    if (intColumna < intNumeroCoolumnas)
                                    {
                                        DocumentRange rangeCell = objDocumentServer.Document.InsertText(tc.Range.Start, DtblFilas.Rows[intFila][intColumna].ToString());
                                        var palColumna = ParagraphAlignment.Left;
                                        if (confColumna != null)
                                        {
                                            switch (confColumna.Alineacion)
                                            {
                                                case "Left": palColumna = ParagraphAlignment.Left; break;
                                                case "Center": palColumna = ParagraphAlignment.Center; break;
                                                case "Right": palColumna = ParagraphAlignment.Right; break;
                                            }
                                        }
                                        objDocumentServer.Document.Paragraphs.Get(rangeCell.Start).Alignment = palColumna;
                                    }
                                    tc.BackgroundColor = Color.White;
                                    var tcvaColumna = TableCellVerticalAlignment.Top;
                                    if (confColumna != null)
                                    {
                                        switch (confColumna.AlineacionVertical)
                                        {
                                            case "Top": tcvaColumna = TableCellVerticalAlignment.Top; break;
                                            case "Center": tcvaColumna = TableCellVerticalAlignment.Center; break;
                                            case "Bottom": tcvaColumna = TableCellVerticalAlignment.Bottom; break;
                                        }
                                    }
                                    tc.VerticalAlignment = tcvaColumna;

                                    CharacterProperties cpCell = objDocumentServer.Document.BeginUpdateCharacters(tc.Range);
                                    cpCell.Bold = false;
                                    objDocumentServer.Document.EndUpdateCharacters(cpCell);
                                }
                            }
                            break;
                        }
                    }
                }
                return objDocumentServer;
            }
            catch
            {
                throw;
            }
        }
    }
    public class occ_documento__tabla
    {
        public List<occ_documento__tabla__columna> ListaColumnas { get; set; }
    }
    public class occ_documento__tabla__columna
    {
        public int Indice { get; set; }
        public string Alineacion { get; set; }
        public string AlineacionVertical { get; set; }
    }

    public class OC_RESPONSE_FILE
    {
        public string ContentType { get; set; } = string.Empty;
        public byte[] ByteArray { get; set; }
        public string NombreArchivo { get; set; } = string.Empty;
        public string CarpetaSalida { get; set; } = string.Empty;
        public string FormatoSalida { get; set; } = string.Empty;
        public bool BoolHistorico { get; set; } = false;
        public string Mensaje { get; set; } = string.Empty;
        public string RutaArchivoEnc { get; set; } = string.Empty;

        public static string ConvertFormatToContentType(string strFormato)
        {
            switch (strFormato)
            {
                case "WORD":
                    return "application/msword";
                case "EXCEL":
                    return "application/vnd.ms-excel";
                case "PDF":
                    return "application/pdf";
                case "TXT":
                    return "text/plain";
                case "CSV":
                    return "text/csv";
                default:
                    return string.Empty;

            }
        }
        public static DocumentFormat ConvertFormatToDocumentFormat(string strFormato)
        {
            switch (strFormato)
            {
                case "WORD":
                case "EXCEL":
                    return DocumentFormat.OpenXml;
                case "TXT":
                    return DocumentFormat.PlainText;
                default:
                    return DocumentFormat.Undefined;

            }
        }
        public static string ConvertFormatToExtension(string strFormato)
        {
            switch (strFormato)
            {
                case "WORD":
                    return ".docx";
                case "EXCEL":
                    return ".xlsx";
                case "PDF":
                    return ".pdf";
                case "TXT":
                    return ".txt";
                case "CSV":
                    return ".csv";
                default:
                    return string.Empty;

            }
        }
    }

    //public class CParameter
    //{
    //    public string Key { get; set; }
    //    public object Value { get; set; }
    //}
}
