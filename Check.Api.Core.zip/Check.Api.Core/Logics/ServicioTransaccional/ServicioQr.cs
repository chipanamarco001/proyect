﻿using Azure;
using Common.Parameters;
using Logics.ConsumoConfiguracion.IRepository;
using ManageDB.EFRepository;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ServicioTransaccional
{
    public class ServicioQr
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        private readonly Lazy<List<LEXICO>> _lexicos;
        private readonly Lazy<string> _rutaCertificado;
        private readonly Lazy<byte[]> _Certificado;
        private readonly Lazy<string> _Usuario_Credencial;
        private readonly Lazy<string> _Password_Credencial;
        private readonly Lazy<string> _Password_Certificado;
        private readonly Lazy<string> _Public_Token;
        private readonly Lazy<string> _Service_Code;
        private readonly Lazy<string> _App_UserId;
        private readonly Lazy<string> _Url;
        private readonly Lazy<string> _Expiration;
        private readonly Lazy<string> _Bussiness_Code;
        private readonly string _CorrelationId;
        private readonly string _entorno;
        public ServicioQr(ApplicationDbSpContext context_sp, ApplicationDbContext context_c, IConfiguration configuration)
        {
            _context_sp = context_sp;
            _context_c = context_c;

            _lexicos = new Lazy<List<LEXICO>>(() =>
            {
                var cLexico = new LexicoRepository(_context_sp, _context_c);
                return cLexico.ObtenerListaLexicoPorTabla("CHECK");
            });

            _rutaCertificado = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "RUTA_CERTIFICADO").LEPVC_VALOR);
            Log.Debug(_lexicos.Value.First(x => x.LESVC_TEMA == "RUTA_CERTIFICADO").LEPVC_VALOR);
            _Certificado = new Lazy<byte[]>(() => File.ReadAllBytes(_rutaCertificado.Value));
            _Usuario_Credencial = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "USER_NAME").LEPVC_VALOR);
            _Password_Credencial = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "PASSWORD").LEPVC_VALOR);
            _Password_Certificado = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "PASS_CERTIFICADO").LEPVC_VALOR);
            _Public_Token = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "PUBLIC_TOKEN").LEPVC_VALOR);
            _Service_Code = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "SERVICE_CODE_QR").LEPVC_VALOR);
            _App_UserId = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "APP_USER_ID").LEPVC_VALOR);
            _Url = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "URL_WEB_QR").LEPVC_VALOR);
            _Expiration = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "EXPIRACION").LEPVC_VALOR);
            _Bussiness_Code = new Lazy<string>(() => _lexicos.Value.First(x => x.LESVC_TEMA == "BUSINESS_CODE_GEN_QR").LEPVC_VALOR);
            _CorrelationId = Guid.NewGuid().ToString();
            _entorno = configuration.GetValue<string>("ENTORNO");
        }

        public string ValidacionConstructor(string dato)
        {
            if (string.IsNullOrEmpty(dato))
                throw new Exception("La configuracion no contiene el dato para " + dato);
            return dato;
        }
        public byte[] ValidacionConstructor(byte[] dato)
        {
            if (dato == null)
                throw new Exception("La configuracion es nula para el dato " + "certificado");
            if (dato.Count() == 0)
                throw new Exception("La configuracion no contiene el dato para " + "certificado");
            return dato;
        }
        public string Ejecucion(string dataBody)
        {
            string result = null;
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;
                Log.Debug("Antes de Abrir el certificado");
                Log.Debug("Ruta del certificado: " + _Certificado.Value + " " + _Password_Certificado.Value);
                var certificate = new X509Certificate2(_Certificado.Value, _Password_Certificado.Value, X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
                Log.Debug("Abrio el certificado con el password " + _Password_Certificado);
                var credenciales = Encoding.Default.GetBytes(_Usuario_Credencial.Value + ":" + _Password_Credencial.Value);
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(_Url.Value);
                httpWebRequest.ClientCertificates.Add(certificate);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(credenciales));

                if (!string.IsNullOrEmpty(_CorrelationId))
                    httpWebRequest.Headers.Add("Correlation-Id", _CorrelationId);

                httpWebRequest.Method = "POST";
                Log.Debug("Configuro el httprequest con usr:" + _Usuario_Credencial.Value + " pass:" + _Password_Credencial.Value + " url:" + _Url);

                using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    streamWriter.Write(dataBody);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse())
                using (StreamReader streamReader = new StreamReader(response.GetResponseStream()))
                {
                    result = streamReader.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                /**Verifica si existio un error en el servicio HTTP */
                result = "Post excepcion:" + e.Message;
                Log.Debug(result);

                if (e.InnerException != null)
                {
                    result = result + "-->Inner excepcion:" + e.InnerException.Message;
                    Log.Debug(result);
                }
                result=result+ " --> Source: "+ e.Source + " -->StackTrace: "+ e.StackTrace;
                Log.Error(e.StackTrace.ToString());
                /**Verifica si existio un error en el servicio HTTP */
                if (e is WebException)
                {
                    /**Obtenine la exception que levanto */
                    WebException webException = e as WebException;
                    /**Buscamos la respuesta que envio el servidor */
                    if (webException.Response != null)
                    {
                        Log.Debug("Tiene webException.Response excepcion");
                        WebResponse response = webException.Response;
                        /**Transformando la respuesta en formato Stream para su lectura */
                        StreamReader streamReader = new StreamReader(response.GetResponseStream());
                        Log.Debug("Saca GetResponseStream excepcion");
                        /**Obteniendo la respuesta en formato String */
                        result = streamReader.ReadToEnd();
                        Log.Debug("result: " + result);
                        streamReader.Close();
                        Log.Debug("cierra excepcion");
                    }
                }
            }
            return result;
        }

        public bool IsJsonString(string str)
        {
            if (string.IsNullOrWhiteSpace(str)) { return false; }
            str = str.Trim();
            if ((str.StartsWith("{") && str.EndsWith("}")) ||
                (str.StartsWith("[") && str.EndsWith("]")))
            {
                try
                {
                    var obj = JToken.Parse(str);
                    return true;
                }
                catch (JsonReaderException)
                {
                    return false;
                }
                catch (Exception) //some other exception
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public QRResponse GenerarQrDebito(string moneda, decimal monto, string glosa, string expiracion, List<Collectors> collectors, ref LOG_SERVICIO objLogServicio)
        {
            if (string.IsNullOrEmpty(expiracion))
            {
                expiracion = _Expiration.Value;
            }
            string request = PreparacionQR(moneda, monto, glosa, expiracion, collectors);
            //string respuestaServicio = _conexionObtenerQR_Personales.Ejecucion(JsonConvert.SerializeObject(request));

            string respuestaServicio = Ejecucion(request);

            objLogServicio.LOPVC_URL = _Url.Value;
            objLogServicio.LOPVC_REQUEST = request;
            objLogServicio.LOPVC_RESPONSE = respuestaServicio;

            Log.Debug(respuestaServicio);
            if (string.IsNullOrEmpty(respuestaServicio))
                throw new Exception("respuesta vacia del servicio, revisar logs precedentes");
            if (IsJsonString(respuestaServicio) == false)
                throw new Exception(respuestaServicio);
            
            QRResponse response = JsonConvert.DeserializeObject<QRResponse>(respuestaServicio);
            return response;
        }


        private string PreparacionQR(string moneda, decimal monto, string glosa, string expiracion, List<Collectors> collectors)
        {
            QRRequest request = new QRRequest();
            request.AppUserId = _App_UserId.Value;
            request.BusinessCode = _Bussiness_Code.Value;
            request.PublicToken = _Public_Token.Value;
            request.serviceCode = _Service_Code.Value;
            request.expiration = ValidacionDato(expiracion, "TiempoExpiracion QR");
            request.currency = ValidacionDato(moneda, "Moneda QR");
            request.amount = ValidacionDatoDecimal(monto, "Monto QR");
            request.gloss = ValidacionDato(glosa, "Glosa QR");
            request.collectors = collectors;

            request.PhoneNumber = _entorno == "DESARROLLO" ? "75485456" : "1";


            string respuesta = JsonConvert.SerializeObject(request);
            Log.Debug(respuesta);
            return respuesta;
        }

        private string ValidacionDato(string valor, string nombre)
        {
            if (string.IsNullOrEmpty(valor))
                throw new Exception("Para el pago es necesario el  " + nombre);
            return valor;
        }

        private decimal ValidacionDatoDecimal(decimal valor, string nombre)
        {
            if (valor == 0)
                throw new Exception("Para el pago es necesario el  " + nombre);
            return valor;
        }
        //public Response GenerarQrDebito(string moneda, string monto, string glosa)//, ref CRSValidationResult ValidationResult)
        //{
        //    Response resultado;
        //    try
        //    {
        //        string rutaCertificado = AppDomain.CurrentDomain.BaseDirectory + @"bin\Resource\API_CRS.pfx";
        //        var headers = new SortedDictionary<string, string>
        //        {
        //            { "Correlation-Id", (new Random(10)).Next().ToString() } //Correlation Id debe ser un valor unico enviado por empresa
        //        };
        //        var cLexico = new LexicoRepository(_context_sp, _context_c);

        //        var url = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "URL_WEB_QR").FirstOrDefault().LEPVC_VALOR;
        //        var pssCert = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "PASS_CERTIFICADO").FirstOrDefault().LEPVC_VALOR;
        //        var userRequest = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "USER_NAME").FirstOrDefault().LEPVC_VALOR;
        //        var passRequest = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "PASSWORD").FirstOrDefault().LEPVC_VALOR;
        //        var serviceCode = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "SERVICE_CODE_QR").FirstOrDefault().LEPVC_VALOR;
        //        var businessCode = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "BUSINESS_CODE_GEN_QR").FirstOrDefault().LEPVC_VALOR;
        //        var publicToken = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "PUBLIC_TOKEN").FirstOrDefault().LEPVC_VALOR;
        //        var appUserId = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "APP_USER_ID").FirstOrDefault().LEPVC_VALOR;
        //        var expiration = cLexico.ObtenerListaLexicoPorTablaTema("CESAND", "EXPIRATION").FirstOrDefault().LEPVC_VALOR;
        //        var body = "{ \"currency\": \"" + moneda + "\",	\"amount\": \"" + monto + "\", \"gloss\": \"" + glosa + "\",\"serviceCode\": \"" + serviceCode + "\",\"businessCode\": \"" + businessCode + "\",\"expiration\": \"" + expiration + "\",\"publicToken\": \"" + publicToken + "\",\"appUserId\": \"" + appUserId + "\"}";

        //        resultado = Conexion(
        //           url,
        //            headers, //Cabezera de la Peticion
        //            "POST", //Metodo
        //                    //@"D:\CertificateSandBoxApi.pfx", //Ruta del Certificado
        //            rutaCertificado, //Ruta del Certificado
        //            pssCert, //Contraseña del Certificado SSL
        //            body, // Cuerpo de la Peticion
        //            userRequest, //Usuario
        //            passRequest //Contraseña usuario
        //            );

        //        return resultado;
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }
        //}
        //public Response Conexion(string ruta, SortedDictionary<string, string> header, string method, string filePfx, string passPfx, string body, string usuario, string password)
        //{
        //    ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

        //    string result = "";
        //    /**Concatenación del usuario y password */
        //    string user = usuario + ":" + password;
        //    /**Codificando de formato de Bytes */
        //    var enviar = Encoding.Default.GetBytes(user);
        //    /**Convirtiendo el certificado PFX en formato X509 */
        //    X509Certificate2 certificate2 = new X509Certificate2(@filePfx, passPfx);
        //    /**Empezamos a realizar la conexión con nuestra API */
        //    HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(ruta);
        //    /**Adiciona el certificado al servicio HTTP */
        //    httpWebRequest.ClientCertificates.Add(certificate2);
        //    /**Es el tipo de informacion que se manda y que recive */
        //    httpWebRequest.ContentType = "application/json";
        //    /**Se convierte el usuario en Base64 y se adiciona como token al servicio */
        //    httpWebRequest.Headers.Add(
        //        "Authorization", "Basic " + Convert.ToBase64String(enviar)
        //    );
        //    /**Adicionas requirimientos adicionales a la cabecera */
        //    foreach (var item in header)
        //    {
        //        httpWebRequest.Headers.Add(item.Key, item.Value);
        //    }
        //    /**Indicamos el metodo de envio en nuestro servio HTTP */
        //    httpWebRequest.Method = method;
        //    /**Adjuntamos el cuerpo a nuestro servicio HTTP */
        //    using (StreamWriter streamWriter = new StreamWriter(
        //           httpWebRequest.GetRequestStream()))
        //    {
        //        streamWriter.Write(body);
        //        streamWriter.Flush();
        //        streamWriter.Close();
        //    }
        //    try
        //    {
        //        /**Conexion y respuesta de nuestro servicio */
        //        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();
        //        /**Transformando la respuesta en formato Stream para su lectura */
        //        StreamReader streamReader = new StreamReader(response.GetResponseStream());
        //        /**Obteniendo la respuesta en formato String */
        //        result = streamReader.ReadToEnd();
        //        streamReader.Close();
        //    }
        //    catch (Exception e)
        //    {
        //        /**Verifica si existio un error en el servicio HTTP */
        //        if (e is WebException)
        //        {
        //            /**Obtenine la exception que levanto */
        //            WebException webException = e as WebException;
        //            /**Buscamos la respuesta que envio el servidor */
        //            WebResponse response = webException.Response;
        //            /**Transformando la respuesta en formato Stream para su lectura */
        //            StreamReader streamReader = new StreamReader(response.GetResponseStream());
        //            /**Obteniendo la respuesta en formato String */
        //            result = streamReader.ReadToEnd();
        //            streamReader.Close();
        //        }
        //    }
        //    return JsonConvert.DeserializeObject<Response>(result);
        //}

    }

    #region Dtos

    public class QRRequest
    {
        public string AppUserId { get; set; }
        public string currency { get; set; }
        public decimal amount { get; set; }
        public string gloss { get; set; }
        public string serviceCode { get; set; }
        public string BusinessCode { get; set; }

        public bool SingleUse { get; set; } = true;
        public string enableBank { get; set; } = "ALL";
        public string City { get; set; } = "LA PAZ";
        public string BranchOffice { get; set; } = "CHECK LA PAZ";
        public string Teller { get; set; } = "CHECK";
        public string PhoneNumber { get; set; } = "1";

        public string expiration { get; set; }
        public string PublicToken { get; set; }
        public List<Collectors> collectors { get; set; }

    }
    public class Collectors
    {
        public string name { get; set; }
        public string parameter { get; set; }
        public string paremeter { get; set; }
        public string value { get; set; }


    }
    public class QRResponse
    {
        public data data { get; set; }
        public string state { get; set; }
        public string message { get; set; }
    }
    public class data
    {
        public int id { get; set; }
        public byte[] qrImage { get; set; }
        public string expirationDate { get; set; }
        public string status { get; set; }
        public string description { get; set; }
    }
    public class Boton_Prepara_Request
    {
        public string idc { get; set; }
        public string extension { get; set; }
        public string complement { get; set; }
        public string currency { get; set; }
        public decimal amount { get; set; }
        public string gloss { get; set; }
        public string serviceCode { get; set; }
        public string businessCode { get; set; }
        public string date { get; set; }
        public string hour { get; set; }
        public string soliNumber { get; set; }
        public string expireDate { get; set; }
        public string publicToken { get; set; }
        public string appUserId { get; set; }
    }
    public class Boton_Confirma_Request
    {
        public string appUserId { get; set; }
        public string publicToken { get; set; }
        public string date { get; set; }
        public string hour { get; set; }
        public string otp { get; set; }
        public string correlationId { get; set; }
        public string authorizationNumber { get; set; }
    }
    public class Boton_Response
    {
        public string state { get; set; }
        public string message { get; set; }
        public Autorizacion data { get; set; }
    }
    //public class Autorizacion
    //{
    //    public string authorizationNumber { get; set; }
    //}

    public class ServicioQrRequest
    {
        public string url { get; set; }
        public byte[] certificado { get; set; }
        public string passwordCertificado { get; set; }
        public string usuarioCredendial { get; set; }
        public string passwordCredencial { get; set; }
        public string appUserID { get; set; }
        public string bussinesCode { get; set; }
        public string publicToken { get; set; }
        public string serviceCode { get; set; }
    }

    public class GeneraQrRequest
    {
        public string moneda { get; set; }

        public decimal monto { get; set; }

        public string glosa { get; set; }

        public List<Collectors> coleccion { get; set; }
    }

    #endregion
}
