﻿using AutoMapper;
using Azure;
using Common.Parameters;
using System.IO;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ServicioTransaccional;
using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using ManageDB.SqlRepository;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Models.Dtos;
using Models.DtosSp;
using Models.ModelCheck;
using Models.OcDtos;
using Models.OcDtos.OcDtos;
using Models.OcDtos.OcDtosModel;
using Newtonsoft.Json;
using ServicioEnvioCorreo;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Logics.ServicioTransaccional.ServicioLInternacionales;
using static Logics.ServicioTransaccional.ServicioSegipClass;
using static System.Runtime.InteropServices.JavaScript.JSType;
using DevExpress.Pdf;

namespace Logics.ConsumoAfiliacion
{
    public class Transacciones : ITransacciones
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly LexicoRepository _lexicoRepository;
        private readonly AfiliacionRepository _afiliacionRepository;
        private readonly DocumentoRepository _documentoRepository;
        private readonly DocumentoParametroRepository _documentoParametroRepository;
        private readonly LogServicioRepository _logServicioRepository;

        private readonly Lazy<ServicioOTP> _cServicioOtp;
        private readonly Lazy<ServicioQr> _cServicioQr;
        private readonly Lazy<ServicioSegipClass> _cServicioSegip;
        private readonly Lazy<ServicioLInternacionales> _cServicioLInternacionales;
        private readonly Lazy<CManejadorBaseDatos> _manejadorBD;
        private readonly Lazy<ServicioEnvioCorreoClass> _envioCorreo;
        private readonly Lazy<ServicioDocumentos> _documentos;

        private readonly string _rutaArchivosCheck;

        public Transacciones(
            IMapper mapper,
            IConfiguration configuration,
            LexicoRepository lexicoRepository,
            AfiliacionRepository afiliacionRepository,
            ServicioOTP cServicioOtp,
            ServicioQr cServicioQr,
            DocumentoRepository documentoRepository,
            DocumentoParametroRepository documentoParametroRepository,
            LogServicioRepository logServicioRepository,
            CManejadorBaseDatos manejadorBD
            )
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _configuration = configuration;
            if (configuration == null)
                throw new ArgumentNullException(nameof(configuration));            
            _lexicoRepository = lexicoRepository ?? throw new ArgumentNullException(nameof(lexicoRepository));
            _afiliacionRepository = afiliacionRepository ?? throw new ArgumentNullException(nameof(afiliacionRepository));
            _documentoRepository = documentoRepository ?? throw new ArgumentNullException(nameof(documentoRepository));
            _documentoParametroRepository = documentoParametroRepository ?? throw new ArgumentNullException(nameof(documentoParametroRepository));
            _logServicioRepository = logServicioRepository ?? throw new ArgumentNullException(nameof(logServicioRepository));
            _cServicioOtp = new Lazy<ServicioOTP>(() => cServicioOtp ?? throw new ArgumentNullException(nameof(cServicioOtp)));
            _cServicioQr = new Lazy<ServicioQr>(() => cServicioQr ?? throw new ArgumentNullException(nameof(cServicioQr)));
            _cServicioSegip = new Lazy<ServicioSegipClass>(() => new ServicioSegipClass(configuration));
            _cServicioLInternacionales = new Lazy<ServicioLInternacionales>(() => new ServicioLInternacionales(configuration));
            
            _manejadorBD = new Lazy<CManejadorBaseDatos>(() => manejadorBD ?? throw new ArgumentNullException(nameof(manejadorBD)));
            _envioCorreo = new Lazy<ServicioEnvioCorreoClass>(() => new ServicioEnvioCorreoClass());
            _documentos = new Lazy<ServicioDocumentos>(() => new ServicioDocumentos(
                _documentoRepository,
                _documentoParametroRepository,
                _manejadorBD.Value
            ));

            // Read the value from appsettings.json
            _rutaArchivosCheck = _configuration["RutaArchivosCheck"];
            if (string.IsNullOrWhiteSpace(_rutaArchivosCheck))
                throw new InvalidOperationException("La configuración 'RutaArchivosCheck' no está definida en appsettings.json.");
        }


        #region OTP

        public async Task<CrsApiResponse<OtpResponseModel>> GenerateOtpCode(string email, string number, string documentNumber, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<OtpResponseModel>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objLogServicio = new LOG_SERVICIO
                    {
                        LOPVC_TIPO = "POST",
                        LOPVC_TIPO_SERVICIO = "OTP_GEN",
                        LOPBT_ACTIVO = true,
                        LOSDT_FECHA_INSERT = DateTime.Now,
                        LOSVC_ID_USER_INSERT = objCredenciales.usuario
                    };

                    var responseQuery = _cServicioOtp.Value.GenerateOtpCode(email, number, documentNumber,ref objLogServicio);
                    _logServicioRepository.RegistrarLogServicio(objLogServicio);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);

                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<OtpResponseModel>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<OtpResponseModel>> ValidateOtpCode(string code, string documentNumber, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<OtpResponseModel>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objLogServicio = new LOG_SERVICIO
                    {
                        LOPVC_TIPO = "POST",
                        LOPVC_TIPO_SERVICIO = "OTP_VAL",
                        LOPBT_ACTIVO = true,
                        LOSDT_FECHA_INSERT = DateTime.Now,
                        LOSVC_ID_USER_INSERT = objCredenciales.usuario
                    };

                    var responseQuery = _cServicioOtp.Value.ValidateOtpCode(code, documentNumber,ref objLogServicio);
                    _logServicioRepository.RegistrarLogServicio(objLogServicio);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<OtpResponseModel>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Qr

        public async Task<CrsApiResponse<QRResponse>> GenerarQrDebito(string moneda, decimal monto, string glosa, List<Collectors> collectors, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<QRResponse>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var objLogServicio = new LOG_SERVICIO
                    {
                        LOPVC_TIPO = "POST",
                        LOPVC_TIPO_SERVICIO = "QR",
                        LOPBT_ACTIVO = true,
                        LOSDT_FECHA_INSERT = DateTime.Now,
                        LOSVC_ID_USER_INSERT = objCredenciales.usuario
                    };
                    var responseQuery = _cServicioQr.Value.GenerarQrDebito(moneda, monto, glosa, "",collectors,ref objLogServicio);
                    _logServicioRepository.RegistrarLogServicio(objLogServicio);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<QRResponse>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Segip

        public async Task<CrsApiResponse<SegipCampoACampoRespuesta>> ValidacionSegipCampoACampo(AseguradoSegipDto asegurado, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SegipCampoACampoRespuesta>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var lexico = _lexicoRepository.ObtenerListaLexicoPorTabla("SEGIP");
                    var objLogServicio = new LOG_SERVICIO
                    {
                        LOPVC_TIPO = "POST",
                        LOPVC_TIPO_SERVICIO = "SEGIP",
                        LOPBT_ACTIVO = true,
                        LOSDT_FECHA_INSERT = DateTime.Now,
                        LOSVC_ID_USER_INSERT = objCredenciales.usuario
                    };

                    var responseQuery = _cServicioSegip.Value.ValidacionSegipCampoACampo(asegurado, lexico, ref objLogServicio);
                    _logServicioRepository.RegistrarLogServicio(objLogServicio);

                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SegipCampoACampoRespuesta>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        #endregion

        #region Listas Internacionales

        public async Task<CrsApiResponse<ocRespuestaValidacionLIternacionales>> ValidarLInternacionalesANegativo(AseguradoLInternacionalesDto asegurado, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<ocRespuestaValidacionLIternacionales>();
            response.result = new ocRespuestaValidacionLIternacionales();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    LOG_SERVICIO CrearLogServicio(string tipoServicio) => new LOG_SERVICIO
                    {
                        LOPVC_TIPO = "POST",
                        LOPVC_TIPO_SERVICIO = tipoServicio,
                        LOPBT_ACTIVO = true,
                        LOSDT_FECHA_INSERT = DateTime.Now,
                        LOSVC_ID_USER_INSERT = objCredenciales.usuario
                    };

                    var objLogServicioAMLC = CrearLogServicio("AMLC");
                    var objLogServicioAN = CrearLogServicio("AN");

                    //var objOcAseguradoDto = _mapper.Map<OcAseguradoDto>(asegurado);
                    var validacionAMLC = new ocRespuestaValidacionLista();
                    var validacionAN = new ocRespuestaValidacionLista();
                    _cServicioLInternacionales.Value.ValidarListasInternacionalesArchivoNegativo(asegurado, ref validacionAMLC, ref validacionAN,ref objLogServicioAMLC,ref objLogServicioAN);

                    _logServicioRepository.RegistrarLogServicio(objLogServicioAMLC);
                    _logServicioRepository.RegistrarLogServicio(objLogServicioAN);

                    response.result.validacionAMLC = validacionAMLC;
                    response.result.validacionAN = validacionAN;

                    response.hasError = false;
                    response.status = HttpStatusCode.OK;
                    response.messages = null;
                    return response;
                }
                return response;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<ocRespuestaValidacionLIternacionales>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }


        #endregion

        #region Envio Correos

        public async Task<CrsApiResponse<EnviarCorreo>> EnviarCorreoYape(long longIdAfiliacion, OcCredenciales objCredenciales)
        {
            try
            {
                CrsApiResponse<EnviarCorreo> response = new CrsApiResponse<EnviarCorreo>();

                var dataCCYape = _afiliacionRepository.Obtener_CC_YAPE_01(longIdAfiliacion);

                #region Plantilla correo
                string rutaPlantilla = _rutaArchivosCheck + @"PlantillasHtml\CorreoCheckYape.html";
                string correoYapeAux = _configuration["CorreoYapeAux"];
                string copiaCorreoYapeAux = _configuration["CCorreoYape"];

                if (!File.Exists(rutaPlantilla))
                    throw new FileNotFoundException("No se encontró la plantilla de correo.", rutaPlantilla);

                // Lee el contenido del archivo
                string contenidoHtml = File.ReadAllText(rutaPlantilla);

                contenidoHtml = contenidoHtml.Replace("#ASEGURADO#", dataCCYape.ASEGURADO);
                //contenidoHtml = contenidoHtml.Replace("$$NOMBRE_CLIENTE$$", objPersona.PEPVC_NOMBRES + " " + objPersona.PEPVC_PATERNO + " " + objPersona.PEPVC_MATERNO);
                //contenidoHtml = contenidoHtml.Replace("$$CI_CLIENTE$$", objPersona.PEPVC_CI + "" + objPersona.LXPVC_EXTENSION + "" + objPersona.PEPVC_COMPLEMENTO_IDC);
                //cuerpoCorreo = cuerpoCorreo.Replace("$$MOTIVO_ADQUISICION$$", objDatos.AFPVC_DATO8);
                //cuerpoCorreo = cuerpoCorreo.Replace("$$FECHA_AFILIACION$$", objAfiliacion.AFSDT_FECHA_INSERT.ToString("dd/MM/yyyy HH:mm:ss"));
                //cuerpoCorreo = cuerpoCorreo.Replace("$$FECHA_FIN_VIGENCIA$$", objAfiliacion.AFPDT_FECHA_FIN_VIGENCIA != null ? objAfiliacion.AFPDT_FECHA_FIN_VIGENCIA?.ToString("dd/MM/yyyy HH:mm:ss") : string.Empty);

                #endregion

                var lstParametros = new List<Parameter>();
                var objParametro = new Parameter();
                objParametro.key = "@ID_AFILIACION";
                objParametro.value = longIdAfiliacion;
                lstParametros.Add(objParametro);

                #region Archivo Adjunto

                var objArchivoRespuesta = _documentos.Value.GetWordDocument("CC-YAPE-01", lstParametros, new OC_RESPONSE_FILE()
                {
                    NombreArchivo = "CC_YAPE_" + longIdAfiliacion + "_" + dataCCYape.CERTIFICADO,
                    CarpetaSalida = "",//strPeriodoContable,
                    BoolHistorico = false,
                    FormatoSalida = "PDF"
                }, response
                );

                string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));

                var archivo = CifrarPdfConDevExpress(File.ReadAllBytes(strRutaArchivoEnc), dataCCYape.DOCUMENTO);
                //var archivo = File.ReadAllBytes(strRutaArchivoEnc); // responseDocumento.ByteArray;

                List<OC_ATTACHMENT> listaAdjuntos = new List<OC_ATTACHMENT>();
                OC_ATTACHMENT objAdjunto = new OC_ATTACHMENT
                {
                    FILE_ATTACHMENT = archivo,
                    FILE_NAME = "CERTIFICADO_" + dataCCYape.CERTIFICADO + ".pdf"
                };
                listaAdjuntos.Add(objAdjunto);

                #endregion

                var strDestinatarios = correoYapeAux;
                if (!string.IsNullOrEmpty(dataCCYape.CORREO_ASEGURADO))
                {
                    strDestinatarios = dataCCYape.CORREO_ASEGURADO;
                }

                var objCorreo = new OC_ENVIO_CORREO()
                {
                    ASUNTO = "BIENVENIDO A CREDISEGURO",
                    DESTINATARIOS = strDestinatarios,
                    DESTINATARIOS_CCO = copiaCorreoYapeAux,
                    IS_BODY_HTML = true,
                    MENSAJE = contenidoHtml,
                    LST_ATTACHMENT = listaAdjuntos,
                    //LST_IMAGENES = listadoImagenes,
                };
                _envioCorreo.Value.EnviarCorreo(objCorreo, objCredenciales, response);

                return response;
            }
            catch
            {
                throw;
            }
        }


        #endregion

        #region Certificado Cobertura

        public async Task<CrsApiResponse<CertificadoRespuestaDto>> ObtenerCertificadoYape(long longIdAfiliacion, OcCredenciales objCredenciales)
        {
            try
            {
                CrsApiResponse<CertificadoRespuestaDto> response = new CrsApiResponse<CertificadoRespuestaDto>();

                var afiliacion = _afiliacionRepository.ObtenerAfiliacionAseguradoPorIdAfiliacion(longIdAfiliacion, objCredenciales);

                var lstParametros = new List<Parameter>();
                var objParametro = new Parameter();
                objParametro.key = "@ID_AFILIACION";
                objParametro.value = longIdAfiliacion;
                lstParametros.Add(objParametro);

                var objArchivoRespuesta = _documentos.Value.GetWordDocument(afiliacion.idDocumentoCertificado, lstParametros, new OC_RESPONSE_FILE()
                {
                    NombreArchivo = "Certificado_" + longIdAfiliacion + "_" + afiliacion.numeroCertificado,
                    CarpetaSalida = "",
                    BoolHistorico = false,
                    FormatoSalida = "PDF"
                }, response
                );

                string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));

                var archivo = CifrarPdfConDevExpress(File.ReadAllBytes(strRutaArchivoEnc), afiliacion.documentoNumero);
                //var archivo = File.ReadAllBytes(strRutaArchivoEnc);

                if (archivo == null || archivo.Length == 0)
                {
                    CComplexParameters<CertificadoRespuestaDto>.GetValidacionResult(ref response, new Exception("El archivo del certificado está vacío o no se pudo generar."), MethodBase.GetCurrentMethod().Name, string.Empty, "Error al generar el certificado");
                    response.status = HttpStatusCode.InternalServerError;
                    return response;
                }
                response.status = HttpStatusCode.OK;
                response.hasError = false;
                response.result = new CertificadoRespuestaDto
                {
                    archivo = archivo,
                    nombreArchivo = "Certificado_" + longIdAfiliacion + "_" + afiliacion.numeroCertificado + ".pdf"
                };

                return response;
            }
            catch
            {
                throw;
            }
        }

        #endregion

        public byte[] CifrarPdfConDevExpress(byte[] archivo, string password)
        {
            using (var inputStream = new MemoryStream(archivo))
            using (var pdfProcessor = new PdfDocumentProcessor())
            using (var outputStream = new MemoryStream())
            {
                pdfProcessor.LoadDocument(inputStream);
                var options = new PdfSaveOptions();
                options.EncryptionOptions = new PdfEncryptionOptions
                {
                    OwnerPasswordString = password,
                    UserPasswordString = password,
                    PrintingPermissions = PdfDocumentPrintingPermissions.Allowed // Corrected property name
                };
                pdfProcessor.SaveDocument(outputStream, options);
                return outputStream.ToArray();
            }
        }
    }
}
