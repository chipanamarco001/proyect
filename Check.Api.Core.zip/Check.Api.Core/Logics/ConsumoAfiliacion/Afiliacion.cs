﻿using AutoMapper;
using Common.Parameters;
using Logics.ConsumoAfiliacion.IRepository;
using Logics.ServicioTransaccional;
using ManageDB.DapperRepository;
using ManageDB.EFRepository;
using Microsoft.Extensions.Configuration;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Logics.ServicioTransaccional.ServicioSegipClass;

namespace Logics.ConsumoAfiliacion
{
    public class Afiliacion : IAfiliacion
    {
        private readonly IMapper _mapper;
        private readonly AseguradoRepository _aseguradoRepository;
        private readonly AfiliacionRepository _afiliacionRepository;
        private readonly BeneficiarioRepository _beneficiarioRepository;
        
        public Afiliacion(
            IMapper mapper,
            AseguradoRepository aseguradoRepository,
            AfiliacionRepository afiliacionRepository,
            BeneficiarioRepository beneficiarioRepository)
        {
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _aseguradoRepository = aseguradoRepository ?? throw new ArgumentNullException(nameof(aseguradoRepository));
            _afiliacionRepository = afiliacionRepository ?? throw new ArgumentNullException(nameof(afiliacionRepository));
            _beneficiarioRepository = beneficiarioRepository ?? throw new ArgumentNullException(nameof(beneficiarioRepository));
        }

        public async Task<CrsApiResponse<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result>> RegistrarAfiliacionColectiva(AfiliacionColectivaRegistrarDto objAfiliacionRegistro, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _afiliacionRepository.RegistrarAfiliacionColectiva(objAfiliacionRegistro, objCredenciales);
                    //var responseQuery = await Task.Run(() => _afiliacionRepository.RegistrarAfiliacionColectiva(objAfiliacionRegistro, objCredenciales));
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;
                
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<AfiliacionDto>> ObtenerAfiliacionPorId(long idAfiliacion, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<AfiliacionDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _afiliacionRepository.ObtenerAfiliacionPorId(idAfiliacion, objCredenciales);
                    var afiliacionDto = _mapper.Map<AfiliacionDto>(responseQuery);
                    return ApiResponseHelper.GetGenericResponse(afiliacionDto);
                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<AfiliacionDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<SPR_REGISTRAR_ASEGURADO_Result>> RegistrarAsegurado(AseguradoRegistrarDto objAsegurado, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SPR_REGISTRAR_ASEGURADO_Result>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _aseguradoRepository.RegistrarAsegurado(objAsegurado, objCredenciales);
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SPR_REGISTRAR_ASEGURADO_Result>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }              

        public async Task<CrsApiResponse<SPR_REGISTRAR_BENEFICIARIO_Result>> RegistrarBeneficiario(BeneficiarioRegistrarDto objBeneficiario, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<SPR_REGISTRAR_BENEFICIARIO_Result>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var responseQuery = _beneficiarioRepository.RegistrarBeneficiario(objBeneficiario, objCredenciales);
                    return ApiResponseHelper.GetGenericResponse(responseQuery);
                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<SPR_REGISTRAR_BENEFICIARIO_Result>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }

        public async Task<CrsApiResponse<AfiliacionRespActualizarEstadoDto>> ActualizarEstadoAfiliacion(AfiliacionActualizarEstadoDto objAfiliacion, OcCredenciales objCredenciales)
        {
            var response = new CrsApiResponse<AfiliacionRespActualizarEstadoDto>();
            try
            {
                if (CComplexParameter.IsCredentialsValidated(objCredenciales, response))
                {
                    var afiliacionEntity = _mapper.Map<AFILIACION>(objAfiliacion); 
                    var responseQuery = _afiliacionRepository.ActualizarEstadoAfiliacion(afiliacionEntity, objCredenciales);
                    var afiliacionDto = new AfiliacionRespActualizarEstadoDto();
                    afiliacionDto.actualizado = responseQuery;
                    afiliacionDto.idAfiliacion = objAfiliacion.idAfiliacion;
                    return ApiResponseHelper.GetGenericResponse(afiliacionDto);
                }
                return response;

            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                CComplexParameters<AfiliacionRespActualizarEstadoDto>.GetValidacionResult(ref response, ex, MethodBase.GetCurrentMethod().Name, string.Empty, "Error interno");
                response.status = HttpStatusCode.InternalServerError;
                return response;
            }
        }
    }
}
