﻿using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Logics.ConsumoAfiliacion.IRepository
{
    public interface IAfiliacion
    {
        Task<CrsApiResponse<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result>> RegistrarAfiliacionColectiva(AfiliacionColectivaRegistrarDto objAfiliacionRegistro, OcCredenciales objCredenciales);

        Task<CrsApiResponse<SPR_REGISTRAR_ASEGURADO_Result>> RegistrarAsegurado(AseguradoRegistrarDto objAsegurado, OcCredenciales objCredenciales);

        Task<CrsApiResponse<SPR_REGISTRAR_BENEFICIARIO_Result>> RegistrarBeneficiario(BeneficiarioRegistrarDto objBeneficiario, OcCredenciales objCredenciales);

        Task<CrsApiResponse<AfiliacionDto>> ObtenerAfiliacionPorId(long idAfiliacion, OcCredenciales objCredenciales);

        Task<CrsApiResponse<AfiliacionRespActualizarEstadoDto>> ActualizarEstadoAfiliacion(AfiliacionActualizarEstadoDto objAfiliacion, OcCredenciales objCredenciales);
    }
}
