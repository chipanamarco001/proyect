﻿using Azure;
using Logics.ServicioTransaccional;
using Models.Dtos;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Logics.ServicioTransaccional.ServicioLInternacionales;
using static Logics.ServicioTransaccional.ServicioSegipClass;

namespace Logics.ConsumoAfiliacion.IRepository
{
    public interface ITransacciones
    {      

        #region OTP

        Task<CrsApiResponse<OtpResponseModel>> GenerateOtpCode(string email, string number, string documentNumber, OcCredenciales objCredenciales);

        Task<CrsApiResponse<OtpResponseModel>> ValidateOtpCode(string code, string documentNumber, OcCredenciales objCredenciales);

        #endregion

        #region Qr

        Task<CrsApiResponse<QRResponse>> GenerarQrDebito(string moneda, decimal monto, string glosa, List<Collectors> collectors, OcCredenciales objCredenciales);

        #endregion

        #region Segip

        Task<CrsApiResponse<SegipCampoACampoRespuesta>> ValidacionSegipCampoACampo(AseguradoSegipDto asegurado, OcCredenciales objCredenciales);

        #endregion

        #region LInternacionales

        Task<CrsApiResponse<ocRespuestaValidacionLIternacionales>> ValidarLInternacionalesANegativo(AseguradoLInternacionalesDto asegurado, OcCredenciales objCredenciales);

        #endregion

        #region Envio Correos

        Task<CrsApiResponse<EnviarCorreo>> EnviarCorreoYape(long longIdAfiliacion, OcCredenciales objCredenciales);

        #endregion

        #region Certificado cobertura

        Task<CrsApiResponse<CertificadoRespuestaDto>> ObtenerCertificadoYape(long longIdAfiliacion, OcCredenciales objCredenciales);

        #endregion
    }
}
