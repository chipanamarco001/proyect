﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_CONSULTA_CUOTAS_Result
    {
        public string? CodigoBusqueda { get; set; }
        public decimal? ImporteAdeudado { get; set; }
        public decimal? ImporteMinimo { get; set; }
        public decimal? ImporteComision { get; set; }
        public string? NombreCliente { get; set; }
        public int? NumeroCuota { get; set; }
        public string? DetalleCuota { get; set; }
        public string? FechaVencimiento { get; set; } // formato 'yyyyMMdd'
        public decimal? ImporteCuota { get; set; }
        public decimal? ImporteMinimoCuota { get; set; }
        public decimal? MoraCuota { get; set; }
        public decimal? ImporteComisionCuota { get; set; }
        public string? Estado { get; set; }
    }
}
