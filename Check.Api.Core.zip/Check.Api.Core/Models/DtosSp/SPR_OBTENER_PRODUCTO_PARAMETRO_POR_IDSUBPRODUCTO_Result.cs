﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result
    {
        public long SUPBI_ID_SUB_PRODUCTO { get; set; }

        public string SUPVC_TIPO { get; set; }

        public string SUPVC_VALOR { get; set; }

        public string SUSVC_ACLARACION { get; set; }

        public bool SUPBT_ACTIVO { get; set; }

        public DateTime SUSDT_FECHA_INSERT { get; set; }

        public string SUSVC_ID_USER_INSERT { get; set; }

        public DateTime? SUSDT_FECHA_MODIF { get; set; }

        public string? SUSVC_ID_USER_MODIF { get; set; }

        public int SUPIN_NUMERO_NIVEL { get; set; }

        public string SUPVC_DESCRIPCION { get; set; }
    }
}
