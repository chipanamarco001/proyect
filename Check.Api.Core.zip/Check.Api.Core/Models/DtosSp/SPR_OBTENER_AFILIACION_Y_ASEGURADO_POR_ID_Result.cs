﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result
    {
        // AFILIACION
        public long idAfiliacion { get; set; }
        public long idSubProducto { get; set; }
        public string idPoliza { get; set; }
        public string numeroCertificado { get; set; }
        public bool estadoAfiliacion { get; set; }
        public bool activo { get; set; }
        public DateTime? fechaDesafiliacion { get; set; }
        public string tipoDesafiliacion { get; set; }
        public string descripcionDesafiliacion { get; set; }
        public string idDepartamento { get; set; }
        public bool flagInnomindado { get; set; }
        public string comentarios { get; set; }
        public string idDocumentoCertificado { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; }
        public int? idCarga { get; set; }

        // ASEGURADO
        public long idAsegurado { get; set; }
        public long idAfiliacionAsegurado { get; set; }
        public int numeroAsegurado { get; set; }
        public string documentoTipo { get; set; }
        public string documentoNumero { get; set; }
        public string documentoComplemento { get; set; }
        public string documentoExtension { get; set; }
        public string apellidoPaterno { get; set; }
        public string apellidoMaterno { get; set; }
        public string apellidoCasada { get; set; }
        public string nombres { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public string correo { get; set; }
        public string departamento { get; set; }
        public string ciudad { get; set; }
        public string zona { get; set; }
        public string direccion { get; set; }
        public string celular { get; set; }
        public string estadoCivil { get; set; }
        public string genero { get; set; }
        public string nacionalidad { get; set; }
        public string ocupacion { get; set; }
        public bool activoAsegurado { get; set; }
        public DateTime fechaInsertAsegurado { get; set; }
        public string idUserInsertAsegurado { get; set; }
        public DateTime? fechaModifAsegurado { get; set; }
        public string idUserModifAsegurado { get; set; }
        public int? idCargaAsegurado { get; set; }

        //// AFILIACION
        //public long AFPBI_ID_AFILIACION { get; set; }
        //public long SUPBI_ID_SUB_PRODUCTO { get; set; }
        //public string POPVC_ID_POLIZA { get; set; }
        //public string AFPVC_NUMERO_CERTIFICADO { get; set; }
        //public DateTime AFPDT_INICIO_VIGENCIA { get; set; }
        //public DateTime AFPDT_FIN_VIGENCIA { get; set; }
        //public bool AFPBT_ESTADO { get; set; }
        //public bool AFPBT_ACTIVO { get; set; }
        //public DateTime? AFSDT_FECHA_DESAFILIACION { get; set; }
        //public string AFSVC_TIPO_DESAFILIACION { get; set; }
        //public string AFSVC_DESCRIPCION_DESAFILIACION { get; set; }
        //public string AFPCH_ID_DEPARTAMENTO { get; set; }
        //public bool AFPBT_FLAG_INNOMINADO { get; set; }
        //public string AFSVC_COMENTARIOS { get; set; }
        //public DateTime AFSDT_FECHA_INSERT { get; set; }
        //public string AFSVC_ID_USER_INSERT { get; set; }
        //public int? AFSIN_ID_CARGA { get; set; }

        //// ASEGURADO
        //public long ASPBI_ID_ASEGURADO { get; set; }
        //public long AFPBI_ID_AFILIACION_ASEGURADO { get; set; }
        //public int ASPIN_NUMERO_ASEGURADO { get; set; }
        //public string ASPVC_DOCUMENTO_TIPO { get; set; }
        //public string ASPVB_DOCUMENTO_NUMERO { get; set; }
        //public string ASSVB_DOCUMENTO_COMPLEMENTO { get; set; }
        //public string ASSVC_DOCUMENTO_EXTENSION { get; set; }
        //public string ASSVB_APELLIDO_PATERNO { get; set; }
        //public string ASSVB_APELLIDO_MATERNO { get; set; }
        //public string ASSVB_APELLIDO_CASADA { get; set; }
        //public string ASPVB_NOMBRES { get; set; }
        //public DateTime ASPDT_FECHA_NACIMIENTO { get; set; }
        //public string ASSVB_CORREO { get; set; }
        //public string ASSVC_DEPARTAMENTO { get; set; }
        //public string ASSVB_CIUDAD { get; set; }
        //public string ASSVB_ZONA { get; set; }
        //public string ASSVB_DIRECCION { get; set; }
        //public string ASSVB_CELULAR { get; set; }
        //public string ASSVC_ESTADO_CIVIL { get; set; }
        //public string ASSVC_GENERO { get; set; }
        //public string ASSVC_NACIONALIDAD { get; set; }
        //public string ASSVC_OCUPACION { get; set; }
        //public bool ASPBT_ACTIVO { get; set; }
        //public DateTime ASSDT_FECHA_INSERT { get; set; }
        //public string ASSVC_ID_USER_INSERT { get; set; }
        //public DateTime? ASSDT_FECHA_MODIF { get; set; }
        //public string ASSVC_ID_USER_MODIF { get; set; }
        //public int? ASSIN_ID_CARGA { get; set; }
    }
}
