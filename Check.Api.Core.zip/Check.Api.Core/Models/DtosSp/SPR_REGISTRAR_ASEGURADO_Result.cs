﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class SPR_REGISTRAR_ASEGURADO_Result
    {
        public long IdAsegurado { get; set; }

        public string Mensaje { get; set; } = null!;

        public bool Exito { get; set; }
    }
}
