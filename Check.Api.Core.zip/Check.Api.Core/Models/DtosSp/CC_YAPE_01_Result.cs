﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DtosSp
{
    public class CC_YAPE_01_Result
    {
        public long ID_AFILIACION { get; set; }
        public DateTime INICIO_VIGENCIA { get; set; }
        public DateTime FIN_VIGENCIA { get; set; }
        public string CERTIFICADO { get; set; } = null!;
        public string POLIZA { get; set; } = null!;
        public string LUGAR_FECHA { get; set; } = null!;
        public string ASEGURADO { get; set; } = null!;
        public string DOCUMENTO { get; set; } = null!;
        public string DOCUMENTO_EXTENSION { get; set; } = null!;
        public string FECHA_NACIMIENTO { get; set; } = null!;
        public string CORREO_ASEGURADO { get; set; } = null!;        
    }
}
