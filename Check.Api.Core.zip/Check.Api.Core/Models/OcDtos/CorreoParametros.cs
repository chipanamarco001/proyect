﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Dtos
{
    public class CorreoParametros
    {
        public string DATO1 { get; set; }
        public string DATO2 { get; set; }
        public string DATO3 { get; set; }
        public string DATO4 { get; set; }
        public string DATO5 { get; set; }
    }

    public class EnviarCorreo
    {
        public bool enviado { get; set; }
    }

    public class EnviarCorreoDto
    {
        public long idAfiliacion { get; set; }
    }
}
