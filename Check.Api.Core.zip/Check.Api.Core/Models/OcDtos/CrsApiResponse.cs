﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Models.Dtos
{
    public class CrsApiResponse<T>
    {
        public HttpStatusCode? status { get; set; }
        public bool hasError { get; set; } = false;
        public List<ErrorDetail> errors { get; set; } = new List<ErrorDetail>();
        public List<Message> messages { get; set; } = new List<Message>();
        public T? result { get; set; }//= new object();
        
    }
    public class ErrorDetail
    {
        public string errorMessage { get; set; } = "";

        public string innerException { get; set; } = "";

        public string stackTrace { get; set; } = "";

        public string errorUsuario { get; set; } = "";

        public string propertyName { get; set; } = "";

        public string methodName { get; set; } = "";
    }

    public class Message
    {
        public string userMessage { get; set; } = "";

        public string messageTec { get; set; } = "";

        public string methodName { get; set; } = "";
    }
}
