﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcRecYapeDtos
{
    public class BcpApiRequest<T>
    {
        public OcCabeceraReq Cabecera { get; set; }
        public T? CargaUtil { get; set; }      
    }


    public class OcCabeceraReq
    {
        public string Entidad { get; set; }
        public string Usuario { get; set; }
        public string Contraseña { get; set; }
    }
}
