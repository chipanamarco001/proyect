﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcRecYapeDtos
{
    public class BcpApiResponse<T>
    {
        public OcCabeceraRes Cabecera { get; set; }
        public T? CargaUtil { get; set; }        
    }

    public class OcCabeceraRes
    {
        public string CodError { get; set; }
        public string Descripcion { get; set; }
    }
}
