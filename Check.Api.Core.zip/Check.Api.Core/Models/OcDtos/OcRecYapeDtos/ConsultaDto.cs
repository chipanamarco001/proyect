﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcRecYapeDtos
{
    public class ConsultaRequestDto
    {
        public string CodServicio { get; set; }
        public string CodigoBusqueda { get; set; }
    }

    public class ConsultaResponse
    {
        public ErrorDetail errors { get; set; }
        public string CodigoBusqueda { get; set; }
        public string CodigoServicio { get; set; }
        public decimal? ImporteAdeudado { get; set; }
        public decimal ImporteMinimo { get; set; }
        public decimal ImporteComision { get; set; }
        public string NombreCliente { get; set; }
        public List<Cuota> DetalleCuotas { get; set; } = new List<Cuota>();
    }
    public class Cuota
    {
        public int NumeroCuota { get; set; }
        public string DetalleCuota { get; set; }
        public string FechaVencimiento { get; set; }
        public decimal ImporteCuota { get; set; }
        public decimal ImporteMinimoCuota { get; set; }
        public decimal MoraCuota { get; set; }
        public decimal ImporteComision { get; set; }
    }
    public class ErrorDetail
    {
        public string CodError { get; set; } = "";
        public string Descripcion { get; set; } = "";
    }
}
