﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosBCP
{
    public class CrsApiPagoRequest
    {
        public OcCredenciales credenciales {  get; set; }
        public long IdTransaccion { get; set; }
        public string FechaPago { get; set; }
        public string CodigoBusqueda { get; set; }
        public decimal MontoTotal { get; set; }
        public string NombreFactura { get; set; } = "";
        public string NIT { get; set; } = "";
        public string LugarPago { get; set; } = "";
        public List<DetallePago> DetallePagos { get; set; }
    }
    public class DetallePago
    {
        public int NumeroCuota { get; set; }
        public decimal ImporteCuota { get; set; }
    }
   
}
