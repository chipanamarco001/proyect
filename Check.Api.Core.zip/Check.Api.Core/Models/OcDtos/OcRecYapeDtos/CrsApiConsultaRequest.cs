﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosBCP
{
    public class CrsApiConsultaRequest
    {
        public OcCredenciales credenciales { get; set; }
        public string CodServicio { get; set; }
        public string CodigoBusqueda { get; set; }


    }
    public class OcCredenciales
    {
        public string Entidad { get; set; }
        public string Usuario { get; set; }
        public string Contraseña { get; set; }
    }
}
