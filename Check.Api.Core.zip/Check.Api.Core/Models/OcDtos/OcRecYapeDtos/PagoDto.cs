﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcRecYapeDtos
{
    public class PagoRequest
    {
        public long? IdTransaccion { get; set; }
        public string? FechaPago { get; set; }
        public string? CodigoBusqueda { get; set; }
        public decimal? MontoTotal { get; set; }
        public string? NombreFactura { get; set; } = "";
        public string? NIT { get; set; } = "";
        public string? LugarPago { get; set; } = "";
        public List<DetallePago> DetallePagos { get; set; }
    }
    public class DetallePago
    {
        public int? NumeroCuota { get; set; }
        public decimal? ImporteCuota { get; set; }
    }
    public class PagoResponse
    {
        public string? CodigoBusqueda { get; set; }
        public long? IdTxnEmpresa { get; set; }
        public long? IdTxnEntidad { get; set; }

    }
}
