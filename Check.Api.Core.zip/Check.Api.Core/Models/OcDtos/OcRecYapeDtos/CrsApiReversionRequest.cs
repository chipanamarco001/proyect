﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosBCP
{
    public class CrsApiReversionRequest
    {
        public OcCredenciales credenciales { get; set; }
        public string CodigoBusqueda { get; set; }
        public long ID_Pago { get; set; }
        public long ID_Reversion { get; set; }
        public string FechaReversion { get; set; }
    }
}
