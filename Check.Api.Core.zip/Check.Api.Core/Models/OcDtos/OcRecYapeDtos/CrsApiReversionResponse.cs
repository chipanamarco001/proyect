﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosBCP
{
    public class CrsApiReversionResponse
    {
        public ErrorDetail Errors { get; set; }
        public string CodigoBusqueda { get; set; }
        public long IdTxnEmpresaReversion { get; set; }
        public long idTxnRevertida { get; set; }
    }
}
