﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosBCP
{
    public class CrsApiPagoResponse
    {
        public ErrorDetail Errors {  get; set; }
        public string CodigoBusqueda { get; set; }
        public long IdTxnEmpresa { get; set; }
        public long IdTxnEntidad { get; set; }

    }
}
