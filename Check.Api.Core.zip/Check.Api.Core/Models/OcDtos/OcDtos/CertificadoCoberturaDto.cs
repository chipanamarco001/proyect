﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtos
{
    public class CertificadoCoberturaDto
    {
    }

    public class CertificadoObtenerDto
    {
        public long idAfiliacion { get; set; }
    }

    public class CertificadoRespuestaDto
    {
        public byte[] archivo { get; set; }

        public string nombreArchivo { get; set; } = null!;
    }
}
