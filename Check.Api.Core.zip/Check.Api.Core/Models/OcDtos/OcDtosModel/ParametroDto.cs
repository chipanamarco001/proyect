﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class ParametroDto
    {
        public long idParametro { get; set; }
        public string idPoliza { get; set; } = null!;
        public string idNivel { get; set; } = null!;
        public string tipo { get; set; } = null!;
        public string tipoDescripcion { get; set; } = null!;
        public decimal factor { get; set; }
        public string aplicacion { get; set; } = null!;
        public string aplicacionDescripcion { get; set; } = null!;
        public string comentario { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? periodoCarga { get; set; }
    }
}
