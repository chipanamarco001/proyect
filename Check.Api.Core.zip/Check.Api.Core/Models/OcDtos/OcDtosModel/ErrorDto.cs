﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class ErrorDto
    {
        public long idError { get; set; }
        public string pagina { get; set; } = null!;
        public string metodo { get; set; } = null!;
        public string mensaje { get; set; } = null!;
        public string stackTrace { get; set; } = null!;
        public string innerException { get; set; } = null!;
        public HttpStatusCode codigoError { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }

    public class ErrorRegistrarDto
    {
        public string pagina { get; set; } = null!;
        public string metodo { get; set; } = null!;
        public string mensaje { get; set; } = null!;
        public string stackTrace { get; set; } = null!;
        public string innerException { get; set; } = null!;
        public HttpStatusCode? codigoError { get; set; }
    }

    public class ErrorRespuestaDto
    {
        public bool registrado { get; set; }
    }

}
