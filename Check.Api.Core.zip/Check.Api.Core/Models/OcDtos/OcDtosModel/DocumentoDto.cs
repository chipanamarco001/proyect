﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class DocumentoDto
    {
        public string idDocumento { get; set; } = null!;
        public string tipo { get; set; } = null!;
        public string nombre { get; set; } = null!;
        public string rutaPlantilla { get; set; } = null!;
        public string descripcion { get; set; } = null!;
        public string procedimiento { get; set; } = null!;
        public string configuracionBase { get; set; } = null!;
        public string rutaRepositorio { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }
}
