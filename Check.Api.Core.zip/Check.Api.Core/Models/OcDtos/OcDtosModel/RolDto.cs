﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class RolDto
    {
        public long idRol { get; set; }
        public string area { get; set; } = null!;
        public string nombre { get; set; } = null!;
        public string descripcion { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }
}
