﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Models.OcDtos.OcDtosModel
{
    public class BeneficiarioRegistrarDto
    {       
        public long idAfiliacion { get; set; }

        public string tipoDocumento { get; set; } = null!;

        public string? numeroDocumento { get; set; }

        public string? complementoDocumento { get; set; }

        public string extensionDocumento { get; set; } = null!;

        public string? apellidoPaterno { get; set; }

        public string? apellidoMaterno { get; set; }

        public string? apellidoCasada { get; set; }

        public string? nombre { get; set; }

        public DateTime? fechaNacimiento { get; set; }

        public string parentesco { get; set; } = null!;

        public decimal factorParticipacion { get; set; }

        public string entidadFinanciera { get; set; } = null!;

        public string? numeroCuenta { get; set; }

        public string telefono { get; set; } = null!;

        public int? idCarga { get; set; }

    }
}
