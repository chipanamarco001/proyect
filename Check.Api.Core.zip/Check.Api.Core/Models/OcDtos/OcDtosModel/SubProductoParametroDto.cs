﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class SubProductoParametroDto
    {
        public long idSubProducto { get; set; }

        public string tipo { get; set; }

        public string valor { get; set; }

        public string aclaracion { get; set; }

        public int numeroNivel { get; set; }

        public string descripcion { get; set; }
    }

    public class ObtenerSubProductoParametroRequest
    {
        public long idSubProducto { get; set; } = 0!;
    }
}
