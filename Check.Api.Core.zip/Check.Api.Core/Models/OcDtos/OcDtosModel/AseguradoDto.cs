﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Models.OcDtos.OcDtosModel
{
    public class AseguradoRegistrarDto
    {
        public long idAfiliacion { get; set; }

        public int numeroAsegurado { get; set; }

        public string tipoDocumento { get; set; } = null!;

        public string numeroDocumento { get; set; }

        public string complementoDocumento { get; set; }

        public string extensionDocumento { get; set; } = null!;

        public string apellidoPaterno { get; set; }

        public string apellidoMaterno { get; set; }

        public string apellidoCasada { get; set; }

        public string nombre { get; set; }

        public DateTime? fechaNacimiento { get; set; }

        public string correo { get; set; }

        public string departamento { get; set; } = null!;

        public string ciudad { get; set; }

        public string zona { get; set; }

        public string direccion { get; set; }

        public string numeroCelular { get; set; }

        public string estadoCivil { get; set; } = null!;

        public string genero { get; set; } = null!;

        public string nacionalidad { get; set; } = null!;

        public string ocupacion { get; set; } = null!;

        public int? idCarga { get; set; }

    }

    public class AseguradoSegipDto
    {
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public string nombre { get; set; }
        public string apPaterno { get; set; }
        public string apMaterno { get; set; }
        public string ciudad { get; set; }
        public string nacionalidad { get; set; }
        public string tipoDocumento { get; set; }
    }

    public class AseguradoLInternacionalesDto
    {
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }      
    }
}
