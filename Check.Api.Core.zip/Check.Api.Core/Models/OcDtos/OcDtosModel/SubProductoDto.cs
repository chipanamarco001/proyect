﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class SubProductoDto
    {
        public long idSubProducto { get; set; }

        public string idProducto { get; set; } = null!;

        public int numeroNivel { get; set; }

        public string descripcion { get; set; } = null!;

        //public bool EstadoActivo { get; set; }

        //public DateTime FechaRegistro { get; set; }

        //public string UsuarioRegistro { get; set; } = null!;

        //public DateTime? FechaModificacion { get; set; }

        //public string? UsuarioModificacion { get; set; }
    }

    public class SubProductoBuscarIdProdDescripcion
    {
        public string  idProducto { get; set; }

        public string descripcion { get; set; }
    }
}
