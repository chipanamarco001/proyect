﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class AfiliacionDto
    {
        public long idAfiliacion { get; set; }
        public string idPoliza { get; set; } = null!;
        public string idNivel { get; set; } = null!;
        public string? numeroCertificado { get; set; }
        public DateOnly inicioVigencia { get; set; }
        public DateOnly? finVigencia { get; set; }
        public string estadoAfiliacion { get; set; }
        public DateOnly? fechaDesafiliacion { get; set; }
        public string? tipoDesafiliacion { get; set; }
        public string? descripcionDesafiliacion { get; set; }
        public string? idDepartamento { get; set; }
        public bool flagInnomindado { get; set; }
        public string? comentarios { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public int? idCarga { get; set; }
    }

    public class AfiliacionRegistrarDto
    {
        public long idAfiliacion { get; set; }

        public string idPoliza { get; set; } = null!;

        public string idNivel { get; set; } = null!;

        public string? numeroCertificado { get; set; }

        public DateOnly inicioVigencia { get; set; }

        public DateOnly? finVigencia { get; set; }

        public string estadoAfiliacion { get; set; }

        public DateOnly? fechaDesafiliacion { get; set; }

        public string? tipoDesafiliacion { get; set; }

        public string? descripcionDesafiliacion { get; set; }

        public string? departamento { get; set; }

        public bool flagInnominado { get; set; }

        public string? comentarios { get; set; }

        public bool estadoActivo { get; set; }

        public int? idCarga { get; set; }
    }

    public class AfiliacionColectivaRegistrarDto
    {
        public long idSubProducto { get; set; }

        public int numeroNivel { get; set; }

        public string estadoAfiliacion { get; set; }

        public string? departamento { get; set; }

        public bool flagInnominado { get; set; }

        public string? comentarios { get; set; }

        public bool estadoActivo { get; set; }

        public int? idCarga { get; set; }
    }

    public class AfiliacionGrupalRegistrarDto
    {
        public long idSubProducto { get; set; }

        public string idNivel { get; set; } = null!;

        public string estadoAfiliacion { get; set; }

        public string? departamento { get; set; }

        public bool flagInnominado { get; set; }

        public string? comentarios { get; set; }

        public bool estadoActivo { get; set; }

        public int? idCarga { get; set; }
    }
    public class AfiliacionIdAfiliacionDto
    {
        public long idAfiliacion { get; set; }
    }

    public class AfiliacionActualizarEstadoDto
    {
        public long idAfiliacion { get; set; }
        public string estado { get; set; } = null!;
    }

    public class AfiliacionRespActualizarEstadoDto
    {
        public long idAfiliacion { get; set; }
        public bool actualizado { get; set; } = false!;
    }

    public class AfiliacionAseguradoDto
    {
        // AFILIACION
        public long idAfiliacion { get; set; }
        public long idSubProducto { get; set; }
        public string idPoliza { get; set; }
        public string numeroCertificado { get; set; }
        public bool estadoAfiliacion { get; set; }
        public bool activo { get; set; }
        public DateTime? fechaDesafiliacion { get; set; }
        public string tipoDesafiliacion { get; set; }
        public string descripcionDesafiliacion { get; set; }
        public string idDepartamento { get; set; }
        public bool flagInnomindado { get; set; }
        public string comentarios { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; }
        public int? idCarga { get; set; }

        // ASEGURADO
        public long idAsegurado { get; set; }
        public long idAfiliacionAsegurado { get; set; }
        public int numeroAsegurado { get; set; }
        public string documentoTipo { get; set; }
        public string documentoNumero { get; set; }
        public string documentoComplemento { get; set; }
        public string documentoExtension { get; set; }
        public string apellidoPaterno { get; set; }
        public string apellidoMaterno { get; set; }
        public string apellidoCasada { get; set; }
        public string nombres { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public string correo { get; set; }
        public string departamento { get; set; }
        public string ciudad { get; set; }
        public string zona { get; set; }
        public string direccion { get; set; }
        public string celular { get; set; }
        public string estadoCivil { get; set; }
        public string genero { get; set; }
        public string nacionalidad { get; set; }
        public string ocupacion { get; set; }
        public bool activoAsegurado { get; set; }
        public DateTime fechaInsertAsegurado { get; set; }
        public string idUserInsertAsegurado { get; set; }
        public DateTime? fechaModifAsegurado { get; set; }
        public string idUserModifAsegurado { get; set; }
        public int? idCargaAsegurado { get; set; }
    }

}
