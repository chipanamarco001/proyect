﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class BrokerDto
    {
        public long idBroker { get; set; }
        public string nit { get; set; } = null!;
        public string razonSocial { get; set; } = null!;
        public string actividadEconomica { get; set; } = null!;
        public string codigoAps { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }
}
