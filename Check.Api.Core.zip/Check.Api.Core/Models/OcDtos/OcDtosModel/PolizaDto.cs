﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class PolizaDto
    {
        public string idPoliza { get; set; } = null!;
        public string idProducto { get; set; } = null!;
        public long? idBroker { get; set; }
        public long? idAsistencia { get; set; }
        public string tipoEmision { get; set; } = null!;
        public string numeroPoliza { get; set; } = null!;
        public DateTime inicioVigencia { get; set; }
        public DateTime finVigencia { get; set; }
        public string moneda { get; set; } = null!;
        public string idDepartamento { get; set; } = null!;
        public string idDocumentoPoliza { get; set; } = null!;
        public string idDocumentoCertificado { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? periodoCarga { get; set; }
    }
}
