﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class ServicioQrDto
    {
        public long idLogServicio { get; set; }
        public string tipo { get; set; } = null!;
        public string url { get; set; } = null!;
        public string request { get; set; } = null!;
        public string response { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }
}
