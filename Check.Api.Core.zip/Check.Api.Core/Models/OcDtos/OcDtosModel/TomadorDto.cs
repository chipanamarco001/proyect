﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class TomadorDto
    {
        public long idTomador { get; set; }
        public string idPoliza { get; set; } = null!;
        public string tipoPersona { get; set; } = null!;
        public string documentoTipo { get; set; } = null!;
        public string? documentoNumero { get; set; }
        public string? documentoComplemento { get; set; }
        public string documentoExtension { get; set; } = null!;
        public string? apellidoPaterno { get; set; }
        public string? apellidoMaterno { get; set; }
        public string? apellidoCasada { get; set; }
        public string? nombres { get; set; }
        public string? razonSocial { get; set; }
        public DateOnly? fechaNacimiento { get; set; }
        public string? correo { get; set; }
        public string departamento { get; set; } = null!;
        public string? ciudad { get; set; }
        public string? zona { get; set; }
        public string? direccion { get; set; }
        public string? celular { get; set; }
        public string estadoCivil { get; set; } = null!;
        public string genero { get; set; } = null!;
        public string nacionalidad { get; set; } = null!;
        public string ocupacion { get; set; } = null!;
        public string? actividadEconomica { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public int? idCarga { get; set; }
    }
}
