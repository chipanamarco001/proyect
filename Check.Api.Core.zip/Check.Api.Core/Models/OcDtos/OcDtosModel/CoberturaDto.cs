﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class CoberturaDto
    {
        public string idCobertura { get; set; } = null!;
        public string idNivel { get; set; } = null!;
        public string codigo { get; set; } = null!;
        public string descripcion { get; set; } = null!;
        public string tipo { get; set; } = null!;
        public string moneda { get; set; } = null!;
        public decimal sumaAsegurada { get; set; }
        public string descripcionSumaAsegurada { get; set; } = null!;
        public bool flagCoberturaPrincipal { get; set; }
        public int diasCarencia { get; set; }
        public decimal tasaComercial { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? periodoCarga { get; set; }
    }
}
