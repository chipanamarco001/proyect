﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class CobroDto
    {
        public long idCobro { get; set; }
        public long idAfiliacion { get; set; }
        public long? idCupon { get; set; }
        public string tipoCobro { get; set; } = null!;
        public string codigo { get; set; } = null!;
        public string jsonSolicitud { get; set; } = null!;
        public string? jsonRespuesta { get; set; }
        public string estado { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }

    public class CobroRegistroDto
    {
        public long idAfiliacion { get; set; }
        public long? idCupon { get; set; }
        public string tipoCobro { get; set; } = null!;
        public string codigo { get; set; } = null!;
        public string jsonSolicitud { get; set; } = null!;
        public string? jsonRespuesta { get; set; }
        public string estado { get; set; } = null!;
    }

    public class CobroRegistroInicialDto
    {
        public long idAfiliacion { get; set; }
        public long? idCupon { get; set; }
        public string tipoCobro { get; set; } = null!;
        public string codigo { get; set; } = null!;
        public string jsonSolicitud { get; set; } = null!;
    }

    public class CobroRespRegistroInicialDto
    {
        public long idCobro { get; set; }
        public long idAfiliacion { get; set; }

        public static implicit operator CobroRespRegistroInicialDto(CobroRespActualizarDto v)
        {
            throw new NotImplementedException();
        }
    }

    public class CobroActualizarDto
    {
        public long idCobro { get; set; }
        public string? jsonRespuesta { get; set; }
        public string estado { get; set; } = null!;
    }
    public class CobroRespActualizarDto
    {
        public long idCobro { get; set; }
        public bool actualizado { get; set; }
    }
}
