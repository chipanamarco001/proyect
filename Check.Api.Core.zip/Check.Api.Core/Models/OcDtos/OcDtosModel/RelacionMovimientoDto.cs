﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class RelacionMovimientoDto
    {
        public long idRelacionMovimiento { get; set; }
        public long idMovimiento { get; set; }
        public long idLiquidacion { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? periodoCarga { get; set; }
    }
}
