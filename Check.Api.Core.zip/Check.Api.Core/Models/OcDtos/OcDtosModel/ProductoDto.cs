﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace Models.OcDtos.OcDtosModel
{
    public class ProductoDto
    {
        public string idProducto { get; set; }

        public string nombreComercial { get; set; }               

        public string modalidad { get; set; } = null!;

        public string ramo { get; set; } = null!;

        public string tipo { get; set; } = null!;

        public bool flagFacturacion { get; set; }       

        // Otros campos que necesites
        public List<SubProductoDto> subProducto { get; set; }
    }
}
