﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class MovimientoDto
    {
        public long idMovimiento { get; set; }
        public string idPoliza { get; set; } = null!;
        public string idNivel { get; set; } = null!;
        public long idAfiliacion { get; set; }
        public bool flagEmision { get; set; }
        public string tipo { get; set; } = null!;
        public DateOnly fechaMovimiento { get; set; }
        public string moneda { get; set; } = null!;
        public decimal remuneracion { get; set; }
        public decimal primaComercial { get; set; }
        public decimal primaAdicional { get; set; }
        public decimal primaNeta { get; set; }
        public decimal comisionBroker { get; set; }
        public decimal comisionCanal { get; set; }
        public decimal sumaAsegurada { get; set; }
        public decimal iva { get; set; }
        public decimal it { get; set; }
        public decimal importeAsistencia { get; set; }
        public decimal tipoCambio { get; set; }
        public DateOnly fechaTipoCambio { get; set; }
        public long? idBroker { get; set; }
        public long? idAsistencia { get; set; }
        public string comentario { get; set; } = null!;
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? idCarga { get; set; }
    }


    public class MovimientoRegistrarDto
    {
        public string idPoliza { get; set; } = null!;
        public string idNivel { get; set; } = null!;
        public long idAfiliacion { get; set; }
        public bool flagEmision { get; set; }
        public string tipo { get; set; } = null!;
        public DateOnly fechaMovimiento { get; set; }
        public string moneda { get; set; } = null!;
        public decimal remuneracion { get; set; }
        public decimal primaComercial { get; set; }
        public decimal primaAdicional { get; set; }
        public decimal primaNeta { get; set; }
        public decimal comisionBroker { get; set; }
        public decimal comisionCanal { get; set; }
        public decimal sumaAsegurada { get; set; }
        public decimal iva { get; set; }
        public decimal it { get; set; }
        public decimal importeAsistencia { get; set; }
        public decimal tipoCambio { get; set; }
        public DateOnly fechaTipoCambio { get; set; }
        public long? idBroker { get; set; }
        public long? idAsistencia { get; set; }
        public string comentario { get; set; } = null!;        
        public string? idCarga { get; set; }
    }
}
