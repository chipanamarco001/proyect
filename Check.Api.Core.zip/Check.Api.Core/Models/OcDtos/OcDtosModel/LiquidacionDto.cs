﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class LiquidacionDto
    {
        public long idLiquidacion { get; set; }
        public string idPoliza { get; set; } = null!;
        public string mesProduccion { get; set; } = null!;
        public string comentario { get; set; } = null!;
        public bool flagEmision { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
        public string? periodoCarga { get; set; }
    }
}
