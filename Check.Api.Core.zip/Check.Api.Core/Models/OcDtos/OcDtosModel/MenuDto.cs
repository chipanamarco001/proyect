﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.OcDtos.OcDtosModel
{
    public class MenuDto
    {
        public long idMenu { get; set; }
        public long idRol { get; set; }
        public string tipo { get; set; } = null!;
        public int nivel { get; set; }
        public int nivelOrden { get; set; }
        public string contenedor { get; set; } = null!;
        public int paginaOrden { get; set; }
        public string paginaNombre { get; set; } = null!;
        public string paginaUrl { get; set; } = null!;
        public long? idMenuPadre { get; set; }
        public bool activo { get; set; }
        public DateTime fechaInsert { get; set; }
        public string idUserInsert { get; set; } = null!;
        public DateTime? fechaModif { get; set; }
        public string? idUserModif { get; set; }
    }

    public class MenuAutenticacionDto
    {
        public long idMenu { get; set; }
        public string tipo { get; set; } = null!;
        public int nivel { get; set; }
        public int nivelOrden { get; set; }
        public string contenedor { get; set; } = null!;
        public int paginaOrden { get; set; }
        public string paginaNombre { get; set; } = null!;
        public string paginaUrl { get; set; } = null!;
        public long? idMenuPadre { get; set; }
    }
}
