﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

public partial class LOG_SERVICIO
{
    [Key]
    public long LOPBI_ID_LOG_SERVICIO { get; set; }

    [StringLength(150)]
    [Unicode(false)]
    public string? LOPVC_TIPO_SERVICIO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string LOPVC_TIPO { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string LOPVC_URL { get; set; } = null!;

    [Unicode(false)]
    public string LOPVC_REQUEST { get; set; } = null!;

    [Unicode(false)]
    public string LOPVC_RESPONSE { get; set; } = null!;

    public bool LOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime LOSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string LOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? LOSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? LOSVC_ID_USER_MODIF { get; set; }
}
