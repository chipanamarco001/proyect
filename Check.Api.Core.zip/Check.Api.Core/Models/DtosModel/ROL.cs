﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("ROL", Schema = "usr")]
public partial class ROL
{
    [Key]
    public long ROPBI_ID_ROL { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ROPVC_AREA { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string ROPVC_NOMBRE { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string ROSVC_DESCRIPCION { get; set; } = null!;

    public bool ROPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime ROSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ROSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? ROSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ROSVC_ID_USER_MODIF { get; set; }

    [InverseProperty("ROPBI_ID_ROLNavigation")]
    public virtual ICollection<MENU> MENU { get; set; } = new List<MENU>();

    [InverseProperty("ROPBI_ID_ROLNavigation")]
    public virtual ICollection<TOKEN> TOKEN { get; set; } = new List<TOKEN>();

    [InverseProperty("ROPBI_ID_ROLNavigation")]
    public virtual ICollection<USUARIO> USUARIO { get; set; } = new List<USUARIO>();
}
