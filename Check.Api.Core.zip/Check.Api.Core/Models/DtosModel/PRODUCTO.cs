﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("PRODUCTO", Schema = "pol")]
public partial class PRODUCTO
{
    [Key]
    [StringLength(10)]
    [Unicode(false)]
    public string PRPVC_ID_PRODUCTO { get; set; } = null!;

    [StringLength(2)]
    [Unicode(false)]
    public string PRPCH_MODALIDAD { get; set; } = null!;

    [StringLength(2)]
    [Unicode(false)]
    public string PRPCH_RAMO { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string PRPVC_NOMBRE_COMERCIAL { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string PRSVC_TIPO { get; set; } = null!;

    public bool PRSBT_FLAG_FACTURACION { get; set; }

    public bool PRPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime PRSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string PRSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? PRSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? PRSVC_ID_USER_MODIF { get; set; }

    [InverseProperty("PRPVC_ID_PRODUCTONavigation")]
    public virtual ICollection<POLIZA> POLIZA { get; set; } = new List<POLIZA>();

    [InverseProperty("PRPVC_ID_PRODUCTONavigation")]
    public virtual ICollection<SUB_PRODUCTO> SUB_PRODUCTO { get; set; } = new List<SUB_PRODUCTO>();
}
