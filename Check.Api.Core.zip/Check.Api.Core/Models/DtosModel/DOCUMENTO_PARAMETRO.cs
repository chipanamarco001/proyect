﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("DOCUMENTO_PARAMETRO", Schema = "doc")]
public partial class DOCUMENTO_PARAMETRO
{
    [Key]
    public long DOPBI_ID_DOCUMENTO_PARAMETRO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string DOPVC_ID_DOCUMENTO { get; set; } = null!;

    public int? PAPIN_INDEX_TABLA { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? PAPVC_TIPO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? PAPVC_ETIQUETA { get; set; }

    [Unicode(false)]
    public string? PAPVC_VALOR { get; set; }

    [Unicode(false)]
    public string? DOSVC_CONFIGURACION { get; set; }

    public bool DOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime DOSDT_FECHA_INSERT { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string DOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? DOSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? DOSVC_ID_USER_MODIF { get; set; }

    [ForeignKey("DOPVC_ID_DOCUMENTO")]
    [InverseProperty("DOCUMENTO_PARAMETRO")]
    public virtual DOCUMENTO DOPVC_ID_DOCUMENTONavigation { get; set; } = null!;
}
