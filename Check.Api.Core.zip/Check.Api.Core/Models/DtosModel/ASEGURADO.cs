﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("ASEGURADO", Schema = "pol")]
public partial class ASEGURADO
{
    [Key]
    public long ASPBI_ID_ASEGURADO { get; set; }

    public long AFPBI_ID_AFILIACION { get; set; }

    public int ASPIN_NUMERO_ASEGURADO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string ASPVC_DOCUMENTO_TIPO { get; set; } = null!;

    [MaxLength(120)]
    public byte[]? ASPVB_DOCUMENTO_NUMERO { get; set; }

    [MaxLength(120)]
    public byte[]? ASSVB_DOCUMENTO_COMPLEMENTO { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string ASSVC_DOCUMENTO_EXTENSION { get; set; } = null!;

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_PATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_MATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_CASADA { get; set; }

    [MaxLength(400)]
    public byte[]? ASPVB_NOMBRES { get; set; }

    public DateOnly? ASPDT_FECHA_NACIMIENTO { get; set; }

    [MaxLength(800)]
    public byte[]? ASSVB_CORREO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_DEPARTAMENTO { get; set; } = null!;

    [MaxLength(800)]
    public byte[]? ASSVB_CIUDAD { get; set; }

    [MaxLength(800)]
    public byte[]? ASSVB_ZONA { get; set; }

    public byte[]? ASSVB_DIRECCION { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_CELULAR { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_ESTADO_CIVIL { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_GENERO { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_NACIONALIDAD { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_OCUPACION { get; set; } = null!;

    public bool ASPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime ASSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? ASSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ASSVC_ID_USER_MODIF { get; set; }

    public int? ASSIN_ID_CARGA { get; set; }

    [ForeignKey("AFPBI_ID_AFILIACION")]
    [InverseProperty("ASEGURADO")]
    public virtual AFILIACION AFPBI_ID_AFILIACIONNavigation { get; set; } = null!;
}
