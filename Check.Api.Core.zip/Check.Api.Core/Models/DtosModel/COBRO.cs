﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("COBRO", Schema = "pol")]
public partial class COBRO
{
    [Key]
    public long COPBI_ID_COBRO { get; set; }

    public long AFPBI_ID_AFILIACION { get; set; }

    public long? CUPBI_ID_CUPON { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string COPVC_TIPO_COBRO { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string COPVC_CODIGO { get; set; } = null!;

    [Unicode(false)]
    public string COPVC_JSON_SOLICITUD { get; set; } = null!;

    [Unicode(false)]
    public string? COPVC_JSON_RESPUESTA { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string COPVC_ESTADO { get; set; } = null!;

    public bool COPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime COSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string COSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? COSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? COSVC_ID_USER_MODIF { get; set; }
}
