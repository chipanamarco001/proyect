﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("MOVIMIENTO", Schema = "pol")]
public partial class MOVIMIENTO
{
    [Key]
    public long MOPBI_ID_MOVIMIENTO { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(35)]
    [Unicode(false)]
    public string NIPVC_ID_NIVEL { get; set; } = null!;

    public long AFPBI_ID_AFILIACION { get; set; }

    public bool MOPBT_FLAG_EMISION { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string MOPVC_TIPO { get; set; } = null!;

    public DateOnly MOPDT_FECHA_MOVIMIENTO { get; set; }

    [StringLength(3)]
    [Unicode(false)]
    public string MOPCH_MONEDA { get; set; } = null!;

    [Column(TypeName = "decimal(19, 2)")]
    public decimal MOSDC_REMUNERACION { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_PRIMA_COMERCIAL { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_PRIMA_ADICIONAL { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_PRIMA_NETA { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_COMISION_BROKER { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_COMISION_CANAL { get; set; }

    [Column(TypeName = "decimal(19, 2)")]
    public decimal MOPDC_SUMA_ASEGURADA { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_IVA { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOPDC_IT { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOSDC_IMPORTE_ASISTENCIA { get; set; }

    [Column(TypeName = "decimal(19, 8)")]
    public decimal MOSDC_TIPO_CAMBIO { get; set; }

    public DateOnly MOSDT_FECHA_TIPO_CAMBIO { get; set; }

    public long? BRPBI_ID_BROKER { get; set; }

    public long? ASPBI_ID_ASISTENCIA { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string MOSVC_COMENTARIO { get; set; } = null!;

    public bool MOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime MOSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string MOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? MOSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? MOSVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? MOSIN_ID_CARGA { get; set; }

    [InverseProperty("MOPBI_ID_MOVIMIENTONavigation")]
    public virtual ICollection<RELACION_MOVIMIENTO> RELACION_MOVIMIENTO { get; set; } = new List<RELACION_MOVIMIENTO>();
}
