﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("PARAMETRO", Schema = "pol")]
public partial class PARAMETRO
{
    [Key]
    public long PAPBI_ID_PARAMETRO { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(35)]
    [Unicode(false)]
    public string NIPVC_ID_NIVEL { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string PAPVC_TIPO { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string PAPVC_TIPO_DESCRIPCION { get; set; } = null!;

    [Column(TypeName = "decimal(19, 6)")]
    public decimal PAPDC_FACTOR { get; set; }

    [StringLength(25)]
    [Unicode(false)]
    public string PAPVC_APLICACION { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string PAPVC_APLICACION_DESCRIPCION { get; set; } = null!;

    [StringLength(250)]
    [Unicode(false)]
    public string PASVC_COMENTARIO { get; set; } = null!;

    public bool PAPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime PASDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string PASVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? PASDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? PASVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? PASVC_PERIODO_CARGA { get; set; }

    [ForeignKey("NIPVC_ID_NIVEL")]
    [InverseProperty("PARAMETRO")]
    public virtual NIVEL NIPVC_ID_NIVELNavigation { get; set; } = null!;
}
