﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("AFILIACION", Schema = "pol")]
[Index("SUPBI_ID_SUB_PRODUCTO", "AFPVC_NUMERO_CERTIFICADO", Name = "UX_AFILIACION_SUBPRODUCTO_CERTIFICADO", IsUnique = true)]
public partial class AFILIACION
{
    [Key]
    public long AFPBI_ID_AFILIACION { get; set; }

    public long SUPBI_ID_SUB_PRODUCTO { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(35)]
    [Unicode(false)]
    public string NIPVC_ID_NIVEL { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string AFPVC_NUMERO_CERTIFICADO { get; set; } = null!;

    public DateOnly AFPDT_INICIO_VIGENCIA { get; set; }

    public DateOnly AFPDT_FIN_VIGENCIA { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string AFPVC_ESTADO_AFILIACION { get; set; } = null!;

    public DateOnly? AFSDT_FECHA_DESAFILIACION { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? AFSVC_TIPO_DESAFILIACION { get; set; }

    [StringLength(500)]
    [Unicode(false)]
    public string? AFSVC_DESCRIPCION_DESAFILIACION { get; set; }

    [StringLength(3)]
    [Unicode(false)]
    public string AFPCH_ID_DEPARTAMENTO { get; set; } = null!;

    public bool AFPBT_FLAG_INNOMINADO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string AFSVC_COMENTARIOS { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string? DOPVC_ID_DOCUMENTO_CERTIFICADO { get; set; }

    public bool AFPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime AFSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string AFSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? AFSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? AFSVC_ID_USER_MODIF { get; set; }

    public int? AFSIN_ID_CARGA { get; set; }

    [InverseProperty("AFPBI_ID_AFILIACIONNavigation")]
    public virtual ICollection<ASEGURADO> ASEGURADO { get; set; } = new List<ASEGURADO>();

    [InverseProperty("AFPBI_ID_AFILIACIONNavigation")]
    public virtual ICollection<BENEFICIARIO> BENEFICIARIO { get; set; } = new List<BENEFICIARIO>();

    [ForeignKey("NIPVC_ID_NIVEL")]
    [InverseProperty("AFILIACION")]
    public virtual NIVEL NIPVC_ID_NIVELNavigation { get; set; } = null!;

    [ForeignKey("POPVC_ID_POLIZA")]
    [InverseProperty("AFILIACION")]
    public virtual POLIZA POPVC_ID_POLIZANavigation { get; set; } = null!;
}
