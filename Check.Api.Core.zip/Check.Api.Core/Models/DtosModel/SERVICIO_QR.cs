﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Keyless]
[Table("SERVICIO_QR", Schema = "log")]
public partial class SERVICIO_QR
{
    public long SEPBI_ID_LOG_SERVICIO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string SEPVC_TIPO { get; set; } = null!;

    [StringLength(100)]
    [Unicode(false)]
    public string SEPVC_URL { get; set; } = null!;

    [Unicode(false)]
    public string SEPVC_REQUEST { get; set; } = null!;

    [Unicode(false)]
    public string SEPVC_RESPONSE { get; set; } = null!;

    public bool SEPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime SESDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string SESVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? SESDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? SESVC_ID_USER_MODIF { get; set; }
}
