﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Keyless]
[Table("BASE_YAPE", Schema = "inf")]
public partial class BASE_YAPE
{
    public long BAPBI_ID_BASE_YAPE { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string ASPVC_DOCUMENTO_TIPO { get; set; } = null!;

    [MaxLength(120)]
    public byte[]? ASPVB_DOCUMENTO_NUMERO { get; set; }

    [MaxLength(120)]
    public byte[]? ASSVB_DOCUMENTO_COMPLEMENTO { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string ASSVC_DOCUMENTO_EXTENSION { get; set; } = null!;

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_PATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_MATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_APELLIDO_CASADA { get; set; }

    [MaxLength(400)]
    public byte[]? ASPVB_NOMBRES { get; set; }

    public DateOnly? ASPDT_FECHA_NACIMIENTO { get; set; }

    [MaxLength(800)]
    public byte[]? ASSVB_CORREO { get; set; }

    [MaxLength(400)]
    public byte[]? ASSVB_CELULAR { get; set; }

    public bool ASPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime ASSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string ASSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? ASSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? ASSVC_ID_USER_MODIF { get; set; }
}
