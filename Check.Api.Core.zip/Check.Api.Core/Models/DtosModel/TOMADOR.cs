﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("TOMADOR", Schema = "pol")]
public partial class TOMADOR
{
    [Key]
    public long TOPBI_ID_TOMADOR { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string TOPVC_TIPO_PERSONA { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string TOPVC_DOCUMENTO_TIPO { get; set; } = null!;

    [MaxLength(120)]
    public byte[]? TOPVB_DOCUMENTO_NUMERO { get; set; }

    [MaxLength(120)]
    public byte[]? TOSVB_DOCUMENTO_COMPLEMENTO { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string TOSVC_DOCUMENTO_EXTENSION { get; set; } = null!;

    [MaxLength(400)]
    public byte[]? TOSVB_APELLIDO_PATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? TOSVB_APELLIDO_MATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? TOSVB_APELLIDO_CASADA { get; set; }

    [MaxLength(400)]
    public byte[]? TOPVB_NOMBRES { get; set; }

    [MaxLength(1600)]
    public byte[]? TOPVB_RAZON_SOCIAL { get; set; }

    public DateOnly? TOPDT_FECHA_NACIMIENTO { get; set; }

    [MaxLength(800)]
    public byte[]? TOSVB_CORREO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_DEPARTAMENTO { get; set; } = null!;

    [MaxLength(800)]
    public byte[]? TOSVB_CIUDAD { get; set; }

    [MaxLength(800)]
    public byte[]? TOSVB_ZONA { get; set; }

    public byte[]? TOSVB_DIRECCION { get; set; }

    [MaxLength(400)]
    public byte[]? TOSVB_CELULAR { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_ESTADO_CIVIL { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_GENERO { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_NACIONALIDAD { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_OCUPACION { get; set; } = null!;

    [MaxLength(1600)]
    public byte[]? TOPVB_ACTIVIDAD_ECONOMICA { get; set; }

    public bool TOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime TOSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string TOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? TOSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? TOSVC_ID_USER_MODIF { get; set; }

    public int? TOSIN_ID_CARGA { get; set; }

    [ForeignKey("POPVC_ID_POLIZA")]
    [InverseProperty("TOMADOR")]
    public virtual POLIZA POPVC_ID_POLIZANavigation { get; set; } = null!;
}
