﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("BENEFICIARIO", Schema = "pol")]
public partial class BENEFICIARIO
{
    [Key]
    public long BEPBI_ID_BENEFICIARIO { get; set; }

    public long AFPBI_ID_AFILIACION { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string BEPVC_DOCUMENTO_TIPO { get; set; } = null!;

    [MaxLength(120)]
    public byte[]? BEPVB_DOCUMENTO_NUMERO { get; set; }

    [MaxLength(120)]
    public byte[]? BESVB_DOCUMENTO_COMPLEMENTO { get; set; }

    [StringLength(5)]
    [Unicode(false)]
    public string BESVC_DOCUMENTO_EXTENSION { get; set; } = null!;

    [MaxLength(400)]
    public byte[]? BESVB_APELLIDO_PATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? BESVB_APELLIDO_MATERNO { get; set; }

    [MaxLength(400)]
    public byte[]? BESVB_APELLIDO_CASADA { get; set; }

    [MaxLength(400)]
    public byte[]? BEPVB_NOMBRE { get; set; }

    public DateOnly? BESDT_FECHA_NACIMIENTO { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string BESVC_PARENTESCO { get; set; } = null!;

    [Column(TypeName = "decimal(10, 4)")]
    public decimal BEPDC_FACTOR_PARTICIPACION { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string BESVC_ENTIDAD_FINANCIERA { get; set; } = null!;

    [MaxLength(400)]
    public byte[]? BESVB_NUMERO_CUENTA { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? BESVC_TELEFONO { get; set; }

    public bool BEPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime BESDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string BESVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? BESDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? BESVC_ID_USER_MODIF { get; set; }

    public int? BESIN_ID_CARGA { get; set; }

    [ForeignKey("AFPBI_ID_AFILIACION")]
    [InverseProperty("BENEFICIARIO")]
    public virtual AFILIACION AFPBI_ID_AFILIACIONNavigation { get; set; } = null!;
}
