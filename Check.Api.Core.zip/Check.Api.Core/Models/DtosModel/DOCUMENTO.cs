﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("DOCUMENTO", Schema = "doc")]
public partial class DOCUMENTO
{
    [Key]
    [StringLength(10)]
    [Unicode(false)]
    public string DOPVC_ID_DOCUMENTO { get; set; } = null!;

    [StringLength(50)]
    public string DOPVC_TIPO { get; set; } = null!;

    [StringLength(50)]
    public string DOPVC_NOMBRE { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string DOPVC_RUTA_PLANTILLA { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string DOPVC_DESCRIPCION { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string DOPVC_PROCEDIMIENTO { get; set; } = null!;

    [Unicode(false)]
    public string DOSVC_CONFIGURACION_BASE { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string DOPVC_RUTA_REPOSITORIO { get; set; } = null!;

    public bool DOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime DOSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string DOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? DOSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? DOSVC_ID_USER_MODIF { get; set; }

    [InverseProperty("DOPVC_ID_DOCUMENTONavigation")]
    public virtual ICollection<DOCUMENTO_PARAMETRO> DOCUMENTO_PARAMETRO { get; set; } = new List<DOCUMENTO_PARAMETRO>();
}
