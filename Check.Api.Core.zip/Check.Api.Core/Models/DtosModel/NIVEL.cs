﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("NIVEL", Schema = "pol")]
public partial class NIVEL
{
    [Key]
    [StringLength(35)]
    [Unicode(false)]
    public string NIPVC_ID_NIVEL { get; set; } = null!;

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    public int NIPIN_EDAD_MIN_INGRESO { get; set; }

    public int NIPIN_EDAD_MAX_INGRESO { get; set; }

    public int NIPIN_EDAD_MAX_PERMANENCIA { get; set; }

    public bool NIPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime NISDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string NISVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? NISDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? NISVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? NISVC_PERIODO_CARGA { get; set; }

    [InverseProperty("NIPVC_ID_NIVELNavigation")]
    public virtual ICollection<AFILIACION> AFILIACION { get; set; } = new List<AFILIACION>();

    [InverseProperty("NIPVC_ID_NIVELNavigation")]
    public virtual ICollection<COBERTURA> COBERTURA { get; set; } = new List<COBERTURA>();

    [InverseProperty("NIPVC_ID_NIVELNavigation")]
    public virtual ICollection<PARAMETRO> PARAMETRO { get; set; } = new List<PARAMETRO>();

    [ForeignKey("POPVC_ID_POLIZA")]
    [InverseProperty("NIVEL")]
    public virtual POLIZA POPVC_ID_POLIZANavigation { get; set; } = null!;
}
