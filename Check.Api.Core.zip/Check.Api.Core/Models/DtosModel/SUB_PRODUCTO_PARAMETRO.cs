﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("SUB_PRODUCTO_PARAMETRO", Schema = "conf")]
public partial class SUB_PRODUCTO_PARAMETRO
{
    [Key]
    public long SUPBI_ID_SUB_PRODUCTO_PARAMETRO { get; set; }

    public long SUPBI_ID_SUB_PRODUCTO { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string SUPVC_TIPO { get; set; } = null!;

    [Unicode(false)]
    public string SUPVC_VALOR { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string SUSVC_ACLARACION { get; set; } = null!;

    public bool SUPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime SUSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string SUSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? SUSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? SUSVC_ID_USER_MODIF { get; set; }

    [ForeignKey("SUPBI_ID_SUB_PRODUCTO")]
    [InverseProperty("SUB_PRODUCTO_PARAMETRO")]
    public virtual SUB_PRODUCTO SUPBI_ID_SUB_PRODUCTONavigation { get; set; } = null!;
}
