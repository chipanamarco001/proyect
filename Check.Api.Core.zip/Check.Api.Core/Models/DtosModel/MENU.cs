﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("MENU", Schema = "usr")]
public partial class MENU
{
    [Key]
    public long MEPBI_ID_MENU { get; set; }

    public long ROPBI_ID_ROL { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string MEPVC_TIPO { get; set; } = null!;

    public int MEPIN_NIVEL { get; set; }

    public int MEPIN_NIVEL_ORDEN { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string MEPVC_CONTENEDOR { get; set; } = null!;

    public int MEPIN_PAGINA_ORDEN { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string MEPVC_PAGINA_NOMBRE { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string MEPVC_PAGINA_URL { get; set; } = null!;

    public long? MESBI_ID_MENU_PADRE { get; set; }

    public bool MEPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime MESDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string MESVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? MESDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? MESVC_ID_USER_MODIF { get; set; }

    [ForeignKey("ROPBI_ID_ROL")]
    [InverseProperty("MENU")]
    public virtual ROL ROPBI_ID_ROLNavigation { get; set; } = null!;
}
