﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("POLIZA", Schema = "pol")]
public partial class POLIZA
{
    [Key]
    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string PRPVC_ID_PRODUCTO { get; set; } = null!;

    public long? BRPBI_ID_BROKER { get; set; }

    public long? ASPBI_ID_ASISTENCIA { get; set; }

    [StringLength(20)]
    [Unicode(false)]
    public string POPVC_TIPO_EMISION { get; set; } = null!;

    [StringLength(20)]
    [Unicode(false)]
    public string POPVC_NUMERO_POLIZA { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime POPDT_INICIO_VIGENCIA { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime POPDT_FIN_VIGENCIA { get; set; }

    [StringLength(3)]
    [Unicode(false)]
    public string POPCH_MONEDA { get; set; } = null!;

    [StringLength(3)]
    [Unicode(false)]
    public string POSCH_ID_DEPARTAMENTO { get; set; } = null!;

    [StringLength(10)]
    [Unicode(false)]
    public string DOPVC_ID_DOCUMENTO_POLIZA { get; set; } = null!;

    public bool POPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime POSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string POSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? POSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? POSVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? POSVC_PERIODO_CARGA { get; set; }

    [InverseProperty("POPVC_ID_POLIZANavigation")]
    public virtual ICollection<AFILIACION> AFILIACION { get; set; } = new List<AFILIACION>();

    [ForeignKey("BRPBI_ID_BROKER")]
    [InverseProperty("POLIZA")]
    public virtual BROKER? BRPBI_ID_BROKERNavigation { get; set; }

    [InverseProperty("POPVC_ID_POLIZANavigation")]
    public virtual ICollection<LIQUIDACION> LIQUIDACION { get; set; } = new List<LIQUIDACION>();

    [InverseProperty("POPVC_ID_POLIZANavigation")]
    public virtual ICollection<NIVEL> NIVEL { get; set; } = new List<NIVEL>();

    [ForeignKey("PRPVC_ID_PRODUCTO")]
    [InverseProperty("POLIZA")]
    public virtual PRODUCTO PRPVC_ID_PRODUCTONavigation { get; set; } = null!;

    [InverseProperty("POPVC_ID_POLIZANavigation")]
    public virtual ICollection<TOMADOR> TOMADOR { get; set; } = new List<TOMADOR>();
}
