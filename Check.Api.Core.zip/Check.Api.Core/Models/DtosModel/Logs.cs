﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

public partial class LOGS
{
    [Key]
    public int Id { get; set; }

    public string? Message { get; set; }

    public string? MessageTemplate { get; set; }

    [StringLength(128)]
    public string? Level { get; set; }

    public DateTimeOffset? TimeStamp { get; set; }

    public string? Exception { get; set; }

    public string? Properties { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? Usuario { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? IpConsumo { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string? ServicioConsultado { get; set; }
}
