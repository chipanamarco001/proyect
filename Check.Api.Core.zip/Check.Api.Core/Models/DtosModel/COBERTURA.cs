﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("COBERTURA", Schema = "pol")]
public partial class COBERTURA
{
    [Key]
    [StringLength(40)]
    [Unicode(false)]
    public string COPVC_ID_COBERTURA { get; set; } = null!;

    [StringLength(35)]
    [Unicode(false)]
    public string NIPVC_ID_NIVEL { get; set; } = null!;

    [StringLength(20)]
    [Unicode(false)]
    public string COPVC_CODIGO { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string COPVC_DESCRIPCION { get; set; } = null!;

    [StringLength(2)]
    [Unicode(false)]
    public string COPCH_TIPO { get; set; } = null!;

    [StringLength(3)]
    [Unicode(false)]
    public string COPCH_MONEDA { get; set; } = null!;

    [Column(TypeName = "decimal(10, 2)")]
    public decimal COPDC_SUMA_ASEGURADA { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string COSVC_DESCRIPCION_SUMA_ASEGURADA { get; set; } = null!;

    public bool COSBT_FLAG_COBERTURA_PRINCIPAL { get; set; }

    public int COSIN_DIAS_CARENCIA { get; set; }

    [Column(TypeName = "decimal(12, 8)")]
    public decimal COPDC_TASA_COMERCIAL { get; set; }

    public bool COPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime COSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string COSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? COSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? COSVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? COSVC_PERIODO_CARGA { get; set; }

    [ForeignKey("NIPVC_ID_NIVEL")]
    [InverseProperty("COBERTURA")]
    public virtual NIVEL NIPVC_ID_NIVELNavigation { get; set; } = null!;
}
