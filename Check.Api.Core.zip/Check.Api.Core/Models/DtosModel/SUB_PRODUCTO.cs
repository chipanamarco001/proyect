﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("SUB_PRODUCTO", Schema = "conf")]
public partial class SUB_PRODUCTO
{
    [Key]
    public long SUPBI_ID_SUB_PRODUCTO { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string PRPVC_ID_PRODUCTO { get; set; } = null!;

    public int SUPIN_NUMERO_NIVEL { get; set; }

    [StringLength(200)]
    [Unicode(false)]
    public string SUPVC_DESCRIPCION { get; set; } = null!;

    public bool SUPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime SUSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string SUSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? SUSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? SUSVC_ID_USER_MODIF { get; set; }

    [ForeignKey("PRPVC_ID_PRODUCTO")]
    [InverseProperty("SUB_PRODUCTO")]
    public virtual PRODUCTO PRPVC_ID_PRODUCTONavigation { get; set; } = null!;

    [InverseProperty("SUPBI_ID_SUB_PRODUCTONavigation")]
    public virtual ICollection<SUB_PRODUCTO_PARAMETRO> SUB_PRODUCTO_PARAMETRO { get; set; } = new List<SUB_PRODUCTO_PARAMETRO>();
}
