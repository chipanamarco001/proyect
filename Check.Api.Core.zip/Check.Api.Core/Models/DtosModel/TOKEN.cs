﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("TOKEN", Schema = "usr")]
public partial class TOKEN
{
    [Key]
    public long TOPBI_ID_TOKEN { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string USPVC_ID_USUARIO { get; set; } = null!;

    public long ROPBI_ID_ROL { get; set; }

    [StringLength(1024)]
    [Unicode(false)]
    public string TOPVC_TOKEN { get; set; } = null!;

    [StringLength(50)]
    [Unicode(false)]
    public string? TOSVC_OTP { get; set; }

    public bool TOPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime TOSDT_FECHA_INSERT { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string TOSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? TOSDT_FECHA_MODIF { get; set; }

    [StringLength(10)]
    [Unicode(false)]
    public string? TOSVC_ID_USER_MODIF { get; set; }

    [ForeignKey("ROPBI_ID_ROL")]
    [InverseProperty("TOKEN")]
    public virtual ROL ROPBI_ID_ROLNavigation { get; set; } = null!;

    [ForeignKey("USPVC_ID_USUARIO")]
    [InverseProperty("TOKEN")]
    public virtual USUARIO USPVC_ID_USUARIONavigation { get; set; } = null!;
}
