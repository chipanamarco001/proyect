﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("LIQUIDACION", Schema = "pol")]
public partial class LIQUIDACION
{
    [Key]
    public long LIPBI_ID_LIQUIDACION { get; set; }

    [StringLength(30)]
    [Unicode(false)]
    public string POPVC_ID_POLIZA { get; set; } = null!;

    [StringLength(6)]
    [Unicode(false)]
    public string LIPCH_MES_PRODUCCION { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string LISVC_COMENTARIO { get; set; } = null!;

    public bool LISBT_FLAG_EMISION { get; set; }

    public bool LIPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime LISDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string LISVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? LISDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? LISVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? LISVC_PERIODO_CARGA { get; set; }

    [ForeignKey("POPVC_ID_POLIZA")]
    [InverseProperty("LIQUIDACION")]
    public virtual POLIZA POPVC_ID_POLIZANavigation { get; set; } = null!;

    [InverseProperty("LIPBI_ID_LIQUIDACIONNavigation")]
    public virtual ICollection<RELACION_MOVIMIENTO> RELACION_MOVIMIENTO { get; set; } = new List<RELACION_MOVIMIENTO>();
}
