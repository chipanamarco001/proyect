﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("RELACION_MOVIMIENTO", Schema = "pol")]
public partial class RELACION_MOVIMIENTO
{
    [Key]
    public long REPBI_ID_RELACION_MOVIMIENTO { get; set; }

    public long MOPBI_ID_MOVIMIENTO { get; set; }

    public long LIPBI_ID_LIQUIDACION { get; set; }

    public bool REPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime RESDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string RESVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? RESDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? RESVC_ID_USER_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? RESVC_PERIODO_CARGA { get; set; }

    [ForeignKey("LIPBI_ID_LIQUIDACION")]
    [InverseProperty("RELACION_MOVIMIENTO")]
    public virtual LIQUIDACION LIPBI_ID_LIQUIDACIONNavigation { get; set; } = null!;

    [ForeignKey("MOPBI_ID_MOVIMIENTO")]
    [InverseProperty("RELACION_MOVIMIENTO")]
    public virtual MOVIMIENTO MOPBI_ID_MOVIMIENTONavigation { get; set; } = null!;
}
