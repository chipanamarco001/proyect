﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

[Table("BROKER", Schema = "pol")]
public partial class BROKER
{
    [Key]
    public long BRPBI_ID_BROKER { get; set; }

    [StringLength(15)]
    [Unicode(false)]
    public string BRPVC_NIT { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string BRPVC_RAZON_SOCIAL { get; set; } = null!;

    [StringLength(200)]
    [Unicode(false)]
    public string BRPVC_ACTIVIDAD_ECONOMICA { get; set; } = null!;

    [StringLength(5)]
    [Unicode(false)]
    public string BRPVC_CODIGO_APS { get; set; } = null!;

    public bool BRPBT_ACTIVO { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime BRSDT_FECHA_INSERT { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string BRSVC_ID_USER_INSERT { get; set; } = null!;

    [Column(TypeName = "datetime")]
    public DateTime? BRSDT_FECHA_MODIF { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? BRSVC_ID_USER_MODIF { get; set; }

    [InverseProperty("BRPBI_ID_BROKERNavigation")]
    public virtual ICollection<POLIZA> POLIZA { get; set; } = new List<POLIZA>();
}
