﻿using Microsoft.EntityFrameworkCore;
using Models.DtosSp;
using System;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;

namespace WebApi;

public partial class ApplicationDbSpContext : DbContext
{
    public ApplicationDbSpContext()
    {
    }

    public ApplicationDbSpContext(DbContextOptions<ApplicationDbSpContext> options)
        : base(options)
    {
    }

    #region Custom DbSet 

    public virtual DbSet<SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result> SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result { get; set; }

    public virtual DbSet<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result> SPR_REGISTRAR_AFILIACION_COLECTIVA_Result { get; set; }

    public virtual DbSet<SPR_REGISTRAR_AFILIACION_GRUPAL_Result> SPR_REGISTRAR_AFILIACION_GRUPAL_Result { get; set; }

    public virtual DbSet<SPR_REGISTRAR_ASEGURADO_Result> SPR_REGISTRAR_ASEGURADO_Result { get; set; }

    public virtual DbSet<SPR_REGISTRAR_BENEFICIARIO_Result> SPR_REGISTRAR_BENEFICIARIO_Result { get; set; }
    public virtual DbSet<SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result> SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result { get; set; }

    public virtual DbSet<CC_YAPE_01_Result> CC_YAPE_01_Result { get; set; }
    public virtual DbSet<SPR_CONSULTA_CUOTAS_Result> SPR_CONSULTA_CUOTAS_Result { get; set; }
    public virtual DbSet<SPR_PAGO_BCP_Result> SPR_PAGO_BCP_Result { get; set; }
    public virtual DbSet<SPR_REGISTRAR_MOVIMIENTO_Result> SPR_REGISTRAR_MOVIMIENTO_Result { get; set; }

    #endregion

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {       

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_AFILIACION_GRUPAL_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_ASEGURADO_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_BENEFICIARIO_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<CC_YAPE_01_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_CONSULTA_CUOTAS_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_PAGO_BCP_Result>(entity => entity.HasNoKey());
        modelBuilder.Entity<SPR_REGISTRAR_MOVIMIENTO_Result>(entity => entity.HasNoKey());
        #region propiedad escalar               

        modelBuilder.Entity<ValReturn<bool>>().HasNoKey();
        modelBuilder.Entity<ValReturn<int>>().HasNoKey();
        modelBuilder.Entity<ValReturn<DateTime>>().HasNoKey();
        modelBuilder.Entity<ValReturn<string>>().HasNoKey();

        #endregion
    }


    //public IEnumerable<SPR_GET_PRODUCTO_PARAMETRO_BY_ID_SUB_PRODUCTO_Result> SPWB_GETLIST_DOSIFICACION_CICLO()
    //{
    //    return this.SPR_GET_PRODUCTO_PARAMETRO_BY_ID_SUB_PRODUCTO_Result
    //        .FromSqlInterpolated($"[dbo].[SPWB_GETLIST_DOSIFICACION_CICLO]")
    //        .ToArray();
    //}

    public IEnumerable<SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result> SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO(long longIdSubProducto)
    {
        return this.SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result
           .FromSql($"per.SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO {longIdSubProducto}")
           .ToArray();
    }

    public IEnumerable<SPR_REGISTRAR_AFILIACION_COLECTIVA_Result> SPR_REGISTRAR_AFILIACION_COLECTIVA(
        long SUPBI_ID_SUB_PRODUCTO,
        int NUMERO_NIVEL,
        string AFPVC_ESTADO_AFILIACION,
        //DateTime? AFSDT_FECHA_DESAFILIACION,
        //string AFSVC_TIPO_DESAFILIACION,
        //string AFSVC_DESCRIPCION_DESAFILIACION,
        string AFPCH_ID_DEPARTAMENTO,
        bool AFPBT_FLAG_INNOMINADO,
        string AFSVC_COMENTARIOS,
        bool AFPBT_ACTIVO,
        string AFSVC_ID_USER_INSERT,
        int? AFSIN_ID_CARGA)
    {
        return this.SPR_REGISTRAR_AFILIACION_COLECTIVA_Result
           .FromSql($"pol.SPR_REGISTRAR_AFILIACION_COLECTIVA {SUPBI_ID_SUB_PRODUCTO}, {NUMERO_NIVEL}, {AFPVC_ESTADO_AFILIACION}, {AFPCH_ID_DEPARTAMENTO}, {AFPBT_FLAG_INNOMINADO}, {AFSVC_COMENTARIOS}, {AFPBT_ACTIVO}, {AFSVC_ID_USER_INSERT}, {AFSIN_ID_CARGA}")
           .ToArray();
    }

    public IEnumerable<SPR_REGISTRAR_AFILIACION_GRUPAL_Result> SPR_REGISTRAR_AFILIACION_GRUPAL(
    long SUPBI_ID_SUB_PRODUCTO,
    string NIPVC_ID_NIVEL,
    string AFPVC_ESTADO_AFILIACION,
    //DateTime? AFSDT_FECHA_DESAFILIACION,
    //string AFSVC_TIPO_DESAFILIACION,
    //string AFSVC_DESCRIPCION_DESAFILIACION,
    string AFPCH_ID_DEPARTAMENTO,
    bool AFPBT_FLAG_INNOMINADO,
    string AFSVC_COMENTARIOS,
    bool AFPBT_ACTIVO,
    string AFSVC_ID_USER_INSERT,
    int? AFSIN_ID_CARGA)
    {
        return this.SPR_REGISTRAR_AFILIACION_GRUPAL_Result
           .FromSql($"pol.SPR_REGISTRAR_AFILIACION_GRUPAL {SUPBI_ID_SUB_PRODUCTO}, {NIPVC_ID_NIVEL}, {AFPVC_ESTADO_AFILIACION}, {AFPCH_ID_DEPARTAMENTO}, {AFPBT_FLAG_INNOMINADO}, {AFSVC_COMENTARIOS}, {AFPBT_ACTIVO}, {AFSVC_ID_USER_INSERT}, {AFSIN_ID_CARGA}")
           .ToArray();
    }



    public IEnumerable<SPR_REGISTRAR_ASEGURADO_Result> SPR_REGISTRAR_ASEGURADO(
            long ID_AFILIACION,           // bigint
            int NUMERO_ASEGURADO,         // int
            string DOCUMENTO_TIPO,        // varchar(10)
            string DOCUMENTO_NUMERO,      // varchar(15)
            string DOCUMENTO_COMPLEMENTO, // varchar(5)
            string DOCUMENTO_EXTENSION,   // varchar(5)
            string APELLIDO_PATERNO,      // varchar(50)
            string APELLIDO_MATERNO,      // varchar(50)
            string APELLIDO_CASADA,       // varchar(50)
            string NOMBRES,               // varchar(50)
            DateTime? FECHA_NACIMIENTO,    // date
            string CORREO,                // varchar(100)
            string DEPARTAMENTO,          // varchar(50)
            string CIUDAD,                // varchar(100)
            string ZONA,                  // varchar(100)
            string DIRECCION,             // varchar(500)
            string CELULAR,               // varchar(50)
            string ESTADO_CIVIL,          // varchar(50)
            string GENERO,                // varchar(50)
            string NACIONALIDAD,          // varchar(50)
            string OCUPACION,             // varchar(50)
            int? ID_CARGA,                 // int
            string USUARIO                // varchar(50)
        )
        {
            return this.SPR_REGISTRAR_ASEGURADO_Result
               .FromSql($"pol.SPR_REGISTRAR_ASEGURADO {ID_AFILIACION},{NUMERO_ASEGURADO},{DOCUMENTO_TIPO},{DOCUMENTO_NUMERO},{DOCUMENTO_COMPLEMENTO},{DOCUMENTO_EXTENSION},{APELLIDO_PATERNO},{APELLIDO_MATERNO},{APELLIDO_CASADA},{NOMBRES},{FECHA_NACIMIENTO},{CORREO},{DEPARTAMENTO},{CIUDAD},{ZONA},{DIRECCION},{CELULAR},{ESTADO_CIVIL},{GENERO},{NACIONALIDAD},{OCUPACION},{ID_CARGA},{USUARIO}")
               .ToArray();
        }

    public IEnumerable<SPR_REGISTRAR_BENEFICIARIO_Result> SPR_REGISTRAR_BENEFICIARIO(
            long ID_AFILIACION,                  // bigint
            string DOCUMENTO_TIPO,               // varchar(10)
            string DOCUMENTO_NUMERO,             // varchar(15)
            string DOCUMENTO_COMPLEMENTO,        // varchar(5)
            string DOCUMENTO_EXTENSION,          // varchar(5)
            string APELLIDO_PATERNO,             // varchar(50)
            string APELLIDO_MATERNO,             // varchar(50)
            string APELLIDO_CASADA,              // varchar(50)
            string NOMBRES,                      // varchar(50)            
            DateTime? FECHA_NACIMIENTO,           // date
            string PARENTESCO,                   // varchar(100)
            decimal FACTOR_PARTICIPACION,        // decimal(10,4)
            string ENTIDAD_FINANCIERA,           // varchar(200)
            string NUMERO_CUENTA,                // varchar(50)
            string TELEFONO,                     // varchar(100)
            int? ID_CARGA,                       // int
            string USUARIO                       // varchar(50)

        )
    {
        return this.SPR_REGISTRAR_BENEFICIARIO_Result
           .FromSql($"pol.SPR_REGISTRAR_BENEFICIARIO {ID_AFILIACION},{DOCUMENTO_TIPO},{DOCUMENTO_NUMERO},{DOCUMENTO_COMPLEMENTO},{DOCUMENTO_EXTENSION},{APELLIDO_PATERNO},{APELLIDO_MATERNO},{APELLIDO_CASADA},{NOMBRES},{FECHA_NACIMIENTO},{PARENTESCO},{FACTOR_PARTICIPACION},{ENTIDAD_FINANCIERA},{NUMERO_CUENTA},{TELEFONO},{ID_CARGA},{USUARIO}")
           .ToArray();
    }

    public IEnumerable<SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result> SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID(long IdAfiliacion)
    {
        return this.SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result
           .FromSql($"pol.SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID {IdAfiliacion}")
           .ToArray();
    }

    public IEnumerable<SPR_REGISTRAR_MOVIMIENTO_Result> SPR_REGISTRAR_MOVIMIENTO(
        long ID_AFILIACION,                  // bigint       
        string USUARIO                       // varchar(50)

    )
    {
        return this.SPR_REGISTRAR_MOVIMIENTO_Result
           .FromSql($"pol.SPR_REGISTRAR_MOVIMIENTO {ID_AFILIACION},{USUARIO}")
           .ToArray();
    }

    public IEnumerable<CC_YAPE_01_Result> CC_YAPE_01(long IdAfiliacion)
    {
        return this.CC_YAPE_01_Result
           .FromSql($"doc.CC_YAPE_01 {IdAfiliacion}")
           .ToArray();
    }
    public int testEscalar()
    {
        var result = this.Set<ValReturn<int>>()
        .FromSqlRaw("exec dbo.Scalar")
        .AsEnumerable()
        .First().Value;

        return result;
    }
    #region MetodoBCP

    public IEnumerable<SPR_CONSULTA_CUOTAS_Result> SPR_CONSULTA_CUOTAS(string codigoBusqueda)
    {
        return this.SPR_CONSULTA_CUOTAS_Result
        .FromSql($"pol.SPR_CONSULTA_CUOTAS @CodigoBusqueda = {codigoBusqueda}")
        .ToArray();
    }
    #endregion

    #region escalar

    public class ValReturn<T>
    {
        public T Value { get; set; }
    }

    #endregion
}
