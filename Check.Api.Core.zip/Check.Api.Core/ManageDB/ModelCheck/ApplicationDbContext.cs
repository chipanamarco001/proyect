﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApi;

public partial class ApplicationDbContext : DbContext
{
    public ApplicationDbContext()
    {
    }

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AFILIACION> AFILIACION { get; set; }

    public virtual DbSet<ASEGURADO> ASEGURADO { get; set; }

    public virtual DbSet<BASE_YAPE> BASE_YAPE { get; set; }

    public virtual DbSet<BENEFICIARIO> BENEFICIARIO { get; set; }

    public virtual DbSet<BROKER> BROKER { get; set; }

    public virtual DbSet<COBERTURA> COBERTURA { get; set; }

    public virtual DbSet<COBRO> COBRO { get; set; }

    public virtual DbSet<DOCUMENTO> DOCUMENTO { get; set; }

    public virtual DbSet<DOCUMENTO_PARAMETRO> DOCUMENTO_PARAMETRO { get; set; }

    public virtual DbSet<ERROR> ERROR { get; set; }

    public virtual DbSet<LEXICO> LEXICO { get; set; }

    public virtual DbSet<LIQUIDACION> LIQUIDACION { get; set; }

    public virtual DbSet<LOGS> LOGS { get; set; }

    public virtual DbSet<LOG_SERVICIO> LOG_SERVICIO { get; set; }

    public virtual DbSet<MENU> MENU { get; set; }

    public virtual DbSet<MOVIMIENTO> MOVIMIENTO { get; set; }

    public virtual DbSet<NIVEL> NIVEL { get; set; }

    public virtual DbSet<PARAMETRO> PARAMETRO { get; set; }

    public virtual DbSet<POLIZA> POLIZA { get; set; }

    public virtual DbSet<PRODUCTO> PRODUCTO { get; set; }

    public virtual DbSet<RELACION_MOVIMIENTO> RELACION_MOVIMIENTO { get; set; }

    public virtual DbSet<ROL> ROL { get; set; }

    public virtual DbSet<SERVICIO_QR> SERVICIO_QR { get; set; }

    public virtual DbSet<SUB_PRODUCTO> SUB_PRODUCTO { get; set; }

    public virtual DbSet<SUB_PRODUCTO_PARAMETRO> SUB_PRODUCTO_PARAMETRO { get; set; }

    public virtual DbSet<TOKEN> TOKEN { get; set; }

    public virtual DbSet<TOMADOR> TOMADOR { get; set; }

    public virtual DbSet<USUARIO> USUARIO { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AFILIACION>(entity =>
        {
            entity.Property(e => e.AFPCH_ID_DEPARTAMENTO).IsFixedLength();

            entity.HasOne(d => d.NIPVC_ID_NIVELNavigation).WithMany(p => p.AFILIACION)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AFILIACION_NIVEL");

            entity.HasOne(d => d.POPVC_ID_POLIZANavigation).WithMany(p => p.AFILIACION)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AFILIACION_POLIZA");
        });

        modelBuilder.Entity<ASEGURADO>(entity =>
        {
            entity.HasOne(d => d.AFPBI_ID_AFILIACIONNavigation).WithMany(p => p.ASEGURADO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ASEGURADO_AFILIACION");
        });

        modelBuilder.Entity<BASE_YAPE>(entity =>
        {
            entity.Property(e => e.BAPBI_ID_BASE_YAPE).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<BENEFICIARIO>(entity =>
        {
            entity.HasOne(d => d.AFPBI_ID_AFILIACIONNavigation).WithMany(p => p.BENEFICIARIO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_BENEFICIARIO_AFILIACION");
        });

        modelBuilder.Entity<COBERTURA>(entity =>
        {
            entity.Property(e => e.COPCH_MONEDA).IsFixedLength();
            entity.Property(e => e.COPCH_TIPO).IsFixedLength();

            entity.HasOne(d => d.NIPVC_ID_NIVELNavigation).WithMany(p => p.COBERTURA)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_COBERTURA_NIVEL");
        });

        modelBuilder.Entity<DOCUMENTO_PARAMETRO>(entity =>
        {
            entity.HasOne(d => d.DOPVC_ID_DOCUMENTONavigation).WithMany(p => p.DOCUMENTO_PARAMETRO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_DOCUMENTO_PARAMETRO_DOCUMENTO");
        });

        modelBuilder.Entity<ERROR>(entity =>
        {
            entity.HasKey(e => e.ERPBI_ID_ERROR).HasName("PK__tmp_ms_x__A3B3430168B31C37");
        });

        modelBuilder.Entity<LEXICO>(entity =>
        {
            entity.HasKey(e => e.LEPIN_ID_LEXICO).HasName("PK__LEXICO__88F1673EB139A82A");
        });

        modelBuilder.Entity<LIQUIDACION>(entity =>
        {
            entity.Property(e => e.LIPCH_MES_PRODUCCION).IsFixedLength();

            entity.HasOne(d => d.POPVC_ID_POLIZANavigation).WithMany(p => p.LIQUIDACION)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_LIQUIDACION_POLIZA");
        });

        modelBuilder.Entity<LOGS>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Logs__3214EC077EE718D8");
        });

        modelBuilder.Entity<MENU>(entity =>
        {
            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.MENU)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MENU_ROL");
        });

        modelBuilder.Entity<MOVIMIENTO>(entity =>
        {
            entity.HasKey(e => e.MOPBI_ID_MOVIMIENTO).HasName("PK_MOVIMIENTO_1");

            entity.Property(e => e.MOPCH_MONEDA).IsFixedLength();
        });

        modelBuilder.Entity<NIVEL>(entity =>
        {
            entity.HasKey(e => e.NIPVC_ID_NIVEL).HasName("PK_NIVEL_1");

            entity.HasOne(d => d.POPVC_ID_POLIZANavigation).WithMany(p => p.NIVEL)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_NIVEL_POLIZA");
        });

        modelBuilder.Entity<PARAMETRO>(entity =>
        {
            entity.Property(e => e.PASVC_COMENTARIO).HasDefaultValue("");

            entity.HasOne(d => d.NIPVC_ID_NIVELNavigation).WithMany(p => p.PARAMETRO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PARAMETRO_NIVEL");
        });

        modelBuilder.Entity<POLIZA>(entity =>
        {
            entity.Property(e => e.POPCH_MONEDA).IsFixedLength();
            entity.Property(e => e.POSCH_ID_DEPARTAMENTO).IsFixedLength();

            entity.HasOne(d => d.BRPBI_ID_BROKERNavigation).WithMany(p => p.POLIZA).HasConstraintName("FK_POLIZA_BROKER");

            entity.HasOne(d => d.PRPVC_ID_PRODUCTONavigation).WithMany(p => p.POLIZA)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_POLIZA_PRODUCTO");
        });

        modelBuilder.Entity<PRODUCTO>(entity =>
        {
            entity.Property(e => e.PRPCH_MODALIDAD).IsFixedLength();
            entity.Property(e => e.PRPCH_RAMO).IsFixedLength();
        });

        modelBuilder.Entity<RELACION_MOVIMIENTO>(entity =>
        {
            entity.HasKey(e => e.REPBI_ID_RELACION_MOVIMIENTO).HasName("PK_RELACION_MOVIMIENTO_1");

            entity.HasOne(d => d.LIPBI_ID_LIQUIDACIONNavigation).WithMany(p => p.RELACION_MOVIMIENTO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RELACION_MOVIMIENTO_LIQUIDACION");

            entity.HasOne(d => d.MOPBI_ID_MOVIMIENTONavigation).WithMany(p => p.RELACION_MOVIMIENTO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RELACION_MOVIMIENTO_MOVIMIENTO");
        });

        modelBuilder.Entity<ROL>(entity =>
        {
            entity.HasKey(e => e.ROPBI_ID_ROL).HasName("PK__ROL__9A222ACFE852D082");
        });

        modelBuilder.Entity<SERVICIO_QR>(entity =>
        {
            entity.Property(e => e.SEPBI_ID_LOG_SERVICIO).ValueGeneratedOnAdd();
        });

        modelBuilder.Entity<SUB_PRODUCTO>(entity =>
        {
            entity.HasOne(d => d.PRPVC_ID_PRODUCTONavigation).WithMany(p => p.SUB_PRODUCTO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SUB_PRODUCTO_PRODUCTO");
        });

        modelBuilder.Entity<SUB_PRODUCTO_PARAMETRO>(entity =>
        {
            entity.HasOne(d => d.SUPBI_ID_SUB_PRODUCTONavigation).WithMany(p => p.SUB_PRODUCTO_PARAMETRO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SUB_PRODUCTO_PARAMETRO_SUB_PRODUCTO");
        });

        modelBuilder.Entity<TOKEN>(entity =>
        {
            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.TOKEN)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TOKEN_ROL");

            entity.HasOne(d => d.USPVC_ID_USUARIONavigation).WithMany(p => p.TOKEN)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TOKEN_USUARIO");
        });

        modelBuilder.Entity<TOMADOR>(entity =>
        {
            entity.HasOne(d => d.POPVC_ID_POLIZANavigation).WithMany(p => p.TOMADOR)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TOMADOR_POLIZA");
        });

        modelBuilder.Entity<USUARIO>(entity =>
        {
            entity.HasKey(e => e.USPVC_ID_USUARIO).HasName("PK__USUARIO__EE365385564FAFF6");

            entity.Property(e => e.USPCH_ID_DEPARTAMENTO).IsFixedLength();

            entity.HasOne(d => d.ROPBI_ID_ROLNavigation).WithMany(p => p.USUARIO)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_USUARIO_ROL");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
