﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageDB.SqlRepository
{
    public class Connections
    {
        //private string dbServer = ConfigurationSettings.AppSettings["SQLDB_SERVER"];
        //private string dbName = ConfigurationSettings.AppSettings["SQLDB_DATABASE"];
        //private string dbUser = ConfigurationSettings.AppSettings["SQLDB_USER"];
        //private string dbPassword = ConfigurationSettings.AppSettings["SQLDB_PASSWORD"];

        //private string dbServerExt = ConfigurationSettings.AppSettings["SQLDB_SERVER_EXT"];
        //private string dbNameExt = ConfigurationSettings.AppSettings["SQLDB_DATABASE_EXT"];
        //private string dbUserExt = ConfigurationSettings.AppSettings["SQLDB_USER_EXT"];
        //private string dbPasswordExt = ConfigurationSettings.AppSettings["SQLDB_PASSWORD_EXT"];
               
        public Connections()
        {
            //encryptador encrypt = new encryptador("");
            //encrypt.EncryptDecryptPublic(false, dbPassword, ref dbPassword);

            //encrypt.EncryptDecryptPublic(false, solicitudPassword, ref solicitudPassword);
        }

        public string DefaultConnection()
        {
            string strDesencriptado = string.Empty;
            encryptador Encripta = new encryptador(string.Empty);
            if (ConfigurationSettings.AppSettings["PASS_ENCRIPTADO"] == "SI")
            {
                Encripta.EncryptDecryptPublic(false, dbPassword, ref strDesencriptado);
            }
            else
            {
                strDesencriptado = dbPassword;
            }

            SqlConnectionStringBuilder conn = new SqlConnectionStringBuilder("Server=" + dbServer + ";DataBase=" + dbName + "; User Id=" + dbUser + ";Password=" + strDesencriptado + ";");
            return conn.ConnectionString;
        }

        public string ConnectionExt()
        {
            SqlConnectionStringBuilder conn = new SqlConnectionStringBuilder("Server=" + dbServerExt + ";DataBase=" + dbNameExt + "; User Id=" + dbUserExt + ";Password=" + dbPasswordExt + ";");
            return conn.ConnectionString;
        }
    }
}
