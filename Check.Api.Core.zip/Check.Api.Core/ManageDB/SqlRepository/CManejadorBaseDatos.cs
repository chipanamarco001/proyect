﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageDB.SqlRepository
{
    public class CManejadorBaseDatos
    {
        private readonly string _connectionString;
        public CManejadorBaseDatos(string connectionString)
        {
            _connectionString = connectionString;
        }
        
        public DataSet GetDataSet(string strProcedureName, List<Parameter> listParameter)
        {
            try
            {
                DataSet DsetResult = new DataSet();
                using (var objSqlConnection = new SqlConnection(_connectionString))
                {
                    using (var objSqlCommand = new SqlCommand(strProcedureName, objSqlConnection))
                    {
                        objSqlCommand.CommandType = CommandType.StoredProcedure;
                        objSqlCommand.CommandTimeout = 0;
                        foreach (Parameter objParameter in listParameter)
                            objSqlCommand.Parameters.AddWithValue(objParameter.key, objParameter.value);
                        using (var objSqlDataAdapter = new SqlDataAdapter(objSqlCommand))
                        {
                            objSqlConnection.Open();
                            objSqlDataAdapter.Fill(DsetResult);
                        }
                    }
                }
                return DsetResult;
            }
            catch (SqlException sqlex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public bool RunProcedure(string strProcedureName, List<Parameter> listParameter)
        {
            try
            {
                using (var objSqlConnection = new SqlConnection(_connectionString))
                {
                    using (var objSqlCommand = new SqlCommand(strProcedureName, objSqlConnection))
                    {
                        objSqlCommand.CommandType = CommandType.StoredProcedure;
                        objSqlCommand.CommandTimeout = 0;
                        foreach (Parameter objParameter in listParameter)
                            objSqlCommand.Parameters.AddWithValue(objParameter.key, objParameter.value);
                        objSqlConnection.Open();
                        objSqlCommand.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (SqlException sqlex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }

    public class Parameter
    {
        public string key { get; set; }
        public object value { get; set; }
    }
}
