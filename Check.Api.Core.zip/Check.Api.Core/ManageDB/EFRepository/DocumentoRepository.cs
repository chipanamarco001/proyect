﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class DocumentoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public DocumentoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public DOCUMENTO ObtenerDocumentoPorId(string strIdDocumento)
        {
            var response = _context_c.DOCUMENTO.Where(w => w.DOPVC_ID_DOCUMENTO == strIdDocumento && w.DOPBT_ACTIVO).FirstOrDefault();
            return response;
        }
    }
}
