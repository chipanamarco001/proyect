﻿using Models.OcDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class ErrorRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public ErrorRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
            //_mapper = mapper;
        }
        public bool RegistrarError(ERROR objError, OcCredenciales objCredenciales)
        {
            objError.ERPBT_ACTIVO = true;
            objError.ERSVC_ID_USER_INSERT = objCredenciales.usuario;
            objError.ERSDT_FECHA_INSERT = DateTime.Now;
            var response = _context_c.ERROR.Add(objError);
            _context_c.SaveChanges();
            return true;
        }
    }
}
