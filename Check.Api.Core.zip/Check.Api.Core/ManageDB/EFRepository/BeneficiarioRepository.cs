﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class BeneficiarioRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public BeneficiarioRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public SPR_REGISTRAR_BENEFICIARIO_Result RegistrarBeneficiario(BeneficiarioRegistrarDto objBeneficiario, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_sp.SPR_REGISTRAR_BENEFICIARIO(
                objBeneficiario.idAfiliacion,
                objBeneficiario.tipoDocumento,
                objBeneficiario.numeroDocumento,
                objBeneficiario.complementoDocumento,
                objBeneficiario.extensionDocumento,
                objBeneficiario.apellidoPaterno,
                objBeneficiario.apellidoMaterno,
                objBeneficiario.apellidoCasada,
                objBeneficiario.nombre,
                objBeneficiario.fechaNacimiento,
                objBeneficiario.parentesco,
                objBeneficiario.factorParticipacion,
                objBeneficiario.entidadFinanciera,
                objBeneficiario.numeroCuenta,
                objBeneficiario.telefono,
                objBeneficiario.idCarga,
                objCredenciales.usuario                
                ).FirstOrDefault();

            return queryResponse;
        }
    }
}
