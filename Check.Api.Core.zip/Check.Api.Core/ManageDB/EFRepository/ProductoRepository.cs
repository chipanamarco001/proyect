﻿using Microsoft.EntityFrameworkCore;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{    
    public class ProductoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public ProductoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
            //_mapper = mapper;
        }

        public List<ProductoDto> ObtenerListaProductoActivo()
        {
            var productos = _context_c.PRODUCTO.Include(i=>i.SUB_PRODUCTO).AsNoTracking().Where(w=>w.PRPBT_ACTIVO).AsNoTracking().ToList();
                        
            var response = productos.Select(p => new ProductoDto
            {
                idProducto = p.PRPVC_ID_PRODUCTO,
                nombreComercial = p.PRPVC_NOMBRE_COMERCIAL,
                modalidad = p.PRPCH_MODALIDAD,
                ramo = p.PRPCH_MODALIDAD,
                tipo = p.PRPCH_MODALIDAD,
                flagFacturacion = p.PRSBT_FLAG_FACTURACION,
                //EstadoActivo = p.PRPBT_ACTIVO,
                //FechaRegistro = p.PRSDT_FECHA_INSERT,
                //UsuarioRegistro = p.PRSVC_ID_USER_INSERT,
                //FechaModificacion = p.PRSDT_FECHA_MODIF,
                //UsuarioModificacion = p.PRSVC_ID_USER_MODIF,
                subProducto = p.SUB_PRODUCTO.Select(s => new SubProductoDto
                {
                    idSubProducto = s.SUPBI_ID_SUB_PRODUCTO,
                    idProducto = s.PRPVC_ID_PRODUCTO,
                    numeroNivel = s.SUPIN_NUMERO_NIVEL,
                    descripcion = s.SUPVC_DESCRIPCION,
                    //EstadoActivo = s.SUPBT_ACTIVO,
                    //FechaRegistro = s.SUSDT_FECHA_INSERT,
                    //UsuarioRegistro = s.SUSVC_ID_USER_INSERT,
                    //FechaModificacion = s.SUSDT_FECHA_MODIF,
                    //UsuarioModificacion = s.SUSVC_ID_USER_MODIF
                }).ToList()
            }).ToList();
            return response;

        }
    }
}
