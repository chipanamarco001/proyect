﻿using Models.OcDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class NivelRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public NivelRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public NIVEL ObtenerNivelPorId(string idPoliza, int numeroNivel, OcCredenciales objCredenciales)
        {
            string numeroNivelStr = numeroNivel.ToString("D2"); 
            var niveles = _context_c.NIVEL
                .Where(w => w.POPVC_ID_POLIZA == idPoliza)
                .ToList();
            var queryResponse = niveles
                .FirstOrDefault(w => w.NIPVC_ID_NIVEL.Split('-').Last() == numeroNivelStr);

            return queryResponse;
        }
    }
}
