﻿using Common.Decrypt;
using Microsoft.EntityFrameworkCore;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class UsuarioRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        
        public UsuarioRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public USUARIO ObtenerUsuarioPorId(string strIdUsuario)
        {
            var queryResponse = _context_c.USUARIO.Where(w => w.USPVC_ID_USUARIO == strIdUsuario && w.USPBT_ACTIVO).FirstOrDefault();
            return queryResponse;
        }

        public UsuarioRespRegistroDto RegistrarUsuarioServicio(USUARIO objUsuario,OcCredenciales objCredenciales)
        {
            var response = new UsuarioRespRegistroDto();
            var usuarioExistente = _context_c.USUARIO.FirstOrDefault(u => u.USPVC_ID_USUARIO == objUsuario.USPVC_ID_USUARIO && u.USPBT_ACTIVO);
            if (usuarioExistente != null)
            {
                response.registrado = false;
                response.mensajeRespuesta = "El usuario ya está registrado, no se puede registrar";
                response.idUsuario = usuarioExistente.USPVC_ID_USUARIO;
            }
            else
            {                                
                
                objUsuario.USPCH_ID_DEPARTAMENTO = "201"; // Asignar un departamento por defecto, puede ser parametrizado
                objUsuario.USPBT_PASSWORD = objUsuario.USPBT_PASSWORD;
                objUsuario.USPBT_PASSWORD_RESETEO = null; // No se usa en este caso                
                objUsuario.USPBT_ACTIVO = true;
                objUsuario.USSDT_FECHA_INSERT = DateTime.Now;
                objUsuario.USSVC_ID_USER_INSERT = objCredenciales.usuario;
                _context_c.USUARIO.Add(objUsuario);
                _context_c.SaveChanges();

                response.registrado = true;
                response.mensajeRespuesta = "El usuario fue registrado correctamente";
                response.idUsuario = objUsuario.USPVC_ID_USUARIO;
            }                

            return response;
        }       
    }
}
