﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class AseguradoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public AseguradoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public SPR_REGISTRAR_ASEGURADO_Result RegistrarAsegurado(AseguradoRegistrarDto objAsegurado,OcCredenciales objCredenciales)
        {
            var queryResponse = _context_sp.SPR_REGISTRAR_ASEGURADO(
                objAsegurado.idAfiliacion,
                objAsegurado.numeroAsegurado,
                objAsegurado.tipoDocumento,
                objAsegurado.numeroDocumento,
                objAsegurado.complementoDocumento,
                objAsegurado.extensionDocumento,
                objAsegurado.apellidoPaterno,
                objAsegurado.apellidoMaterno,
                objAsegurado.apellidoCasada,
                objAsegurado.nombre,
                objAsegurado.fechaNacimiento,
                objAsegurado.correo,
                objAsegurado.departamento,
                objAsegurado.ciudad,
                objAsegurado.zona,
                objAsegurado.direccion,
                objAsegurado.numeroCelular,
                objAsegurado.estadoCivil,
                objAsegurado.genero,
                objAsegurado.nacionalidad,
                objAsegurado.ocupacion,                
                objAsegurado.idCarga,
                objCredenciales.usuario
                ).FirstOrDefault();

            return queryResponse;
        }
    }
}
