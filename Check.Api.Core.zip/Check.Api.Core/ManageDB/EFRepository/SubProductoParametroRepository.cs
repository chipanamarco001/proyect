﻿using Microsoft.EntityFrameworkCore;
using Models.DtosSp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class SubProductoParametroRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public SubProductoParametroRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
            //_mapper = mapper;
        }

        public List<SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO_Result> ObtenerProductoParametroPorIdSubProducto(long longIdSubProducto)
        {
            var response = _context_sp.SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO(longIdSubProducto).ToList();
            return response;
        }
    }
}
