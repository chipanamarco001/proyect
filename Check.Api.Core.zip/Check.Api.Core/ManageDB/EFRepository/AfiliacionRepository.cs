﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class AfiliacionRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public AfiliacionRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public SPR_REGISTRAR_AFILIACION_COLECTIVA_Result RegistrarAfiliacionColectiva(AfiliacionColectivaRegistrarDto objAfiliacion, OcCredenciales objCredenciales)
        {
            SPR_REGISTRAR_AFILIACION_COLECTIVA_Result queryResponse = _context_sp.SPR_REGISTRAR_AFILIACION_COLECTIVA(
                objAfiliacion.idSubProducto,
                objAfiliacion.numeroNivel,
                objAfiliacion.estadoAfiliacion,
                //objAfiliacion.FechaDesafiliacion,
                //objAfiliacion.TipoDesafiliacion,
                //objAfiliacion.DescripcionDesafiliacion,
                objAfiliacion.departamento,
                objAfiliacion.flagInnominado,
                objAfiliacion.comentarios,
                objAfiliacion.estadoActivo,
                objCredenciales.usuario,
                objAfiliacion.idCarga
                ).FirstOrDefault();

            return queryResponse;
        }

        public SPR_REGISTRAR_AFILIACION_GRUPAL_Result RegistrarAfiliacionGrupal(AfiliacionGrupalRegistrarDto objAfiliacion, OcCredenciales objCredenciales)
        {
            SPR_REGISTRAR_AFILIACION_GRUPAL_Result queryResponse = _context_sp.SPR_REGISTRAR_AFILIACION_GRUPAL(
                objAfiliacion.idSubProducto,
                objAfiliacion.idNivel,
                objAfiliacion.estadoAfiliacion,
                //objAfiliacion.FechaDesafiliacion,
                //objAfiliacion.TipoDesafiliacion,
                //objAfiliacion.DescripcionDesafiliacion,
                objAfiliacion.departamento,
                objAfiliacion.flagInnominado,
                objAfiliacion.comentarios,
                objAfiliacion.estadoActivo,
                objCredenciales.usuario,
                objAfiliacion.idCarga
                ).FirstOrDefault();

            return queryResponse;
        }

        public CC_YAPE_01_Result Obtener_CC_YAPE_01(long longIdAfiliacion)
        {
            CC_YAPE_01_Result queryResponse = _context_sp.CC_YAPE_01(
                longIdAfiliacion
                ).FirstOrDefault();

            return queryResponse;
        }

        public AFILIACION ObtenerAfiliacionPorId(long idAfiliacion, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_c.AFILIACION.Where(w=>w.AFPBI_ID_AFILIACION == idAfiliacion).FirstOrDefault();
            return queryResponse;
        }

        public bool ActualizarEstadoAfiliacion(AFILIACION objAfiliacion, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_c.AFILIACION.Where(w => w.AFPBI_ID_AFILIACION == objAfiliacion.AFPBI_ID_AFILIACION).FirstOrDefault();
            if (queryResponse == null)
            {
                throw new Exception("Registro no encontrado");
            }
            queryResponse.AFPVC_ESTADO_AFILIACION = objAfiliacion.AFPVC_ESTADO_AFILIACION;
            queryResponse.AFSDT_FECHA_MODIF = DateTime.Now;
            queryResponse.AFSVC_ID_USER_MODIF = objCredenciales.usuario;
            _context_c.AFILIACION.Update(queryResponse);
            _context_c.SaveChanges();

            return true;
        }

        public SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result ObtenerAfiliacionAseguradoPorIdAfiliacion(long idAfiliacion, OcCredenciales objCredenciales)
        {
            SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID_Result queryResponse = _context_sp.SPR_OBTENER_AFILIACION_Y_ASEGURADO_POR_ID(idAfiliacion).FirstOrDefault();

            return queryResponse;
        }
    }
}
