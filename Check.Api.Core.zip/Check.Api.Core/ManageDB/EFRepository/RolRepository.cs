﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class RolRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public RolRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public ROL ObtenerRolPorId(long longIdRol)
        {
            var queryResponse = _context_c.ROL.Where(w => w.ROPBI_ID_ROL == longIdRol && w.ROPBT_ACTIVO).FirstOrDefault();
            return queryResponse;
        }
    }
}
