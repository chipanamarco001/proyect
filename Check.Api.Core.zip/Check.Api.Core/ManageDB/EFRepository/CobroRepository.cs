﻿using Azure;
using Models.OcDtos;
using Models.OcDtos.OcRecYapeDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class CobroRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public CobroRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public COBRO RegistrarCobroInicial(COBRO objCobro)
        {
            _context_c.COBRO.Add(objCobro);
            _context_c.SaveChanges();
            return objCobro;
        }

        public bool ActualizarCobro(COBRO objCobro, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_c.COBRO.Where(w => w.COPBI_ID_COBRO == objCobro.COPBI_ID_COBRO).FirstOrDefault();
            if (queryResponse == null)
            {
                throw new Exception("Cobro no encontrado");
            }
            queryResponse.COPVC_JSON_RESPUESTA = objCobro.COPVC_JSON_RESPUESTA;
            queryResponse.COPVC_ESTADO = objCobro.COPVC_ESTADO;
            queryResponse.COSDT_FECHA_MODIF = DateTime.Now;
            queryResponse.COSVC_ID_USER_MODIF = objCredenciales.usuario;
            _context_c.COBRO.Update(queryResponse);
            _context_c.SaveChanges();

            return true;
        }
        public OcCabeceraRes ActualizarCobroBCP(COBRO objCobro)
        {
            var queryResponse = _context_c.COBRO.Where(w => w.COPVC_CODIGO == objCobro.COPVC_CODIGO).FirstOrDefault();
            var queryAfiliacion = _context_c.AFILIACION.Where(w => w.AFPBI_ID_AFILIACION == queryResponse.AFPBI_ID_AFILIACION).FirstOrDefault();

            var response = new OcCabeceraRes();
            if (queryResponse.COPVC_ESTADO == "AFILIADO")
            {
                response.CodError = "303";
                response.Descripcion = "NO EXISTEN DEUDAS ASOCIADAS AL CODIGO DE DEPOSITANTE";
               return response;
            }
            if (queryResponse == null || queryAfiliacion == null)
            {
                response.CodError = "301";
                response.Descripcion = "CÓDIGO DE DEPOSITANTE NO EXISTE";
                return response;
            }
            queryAfiliacion.AFPVC_ESTADO_AFILIACION = objCobro.COPVC_ESTADO;
            queryAfiliacion.AFSDT_FECHA_MODIF = DateTime.Now;
            queryAfiliacion.AFSVC_ID_USER_MODIF = objCobro.COSVC_ID_USER_INSERT;
            _context_c.AFILIACION.Update(queryAfiliacion);
            _context_c.SaveChanges();

            queryResponse.COPVC_JSON_RESPUESTA = objCobro.COPVC_JSON_RESPUESTA;
            queryResponse.COPVC_JSON_SOLICITUD = objCobro.COPVC_JSON_SOLICITUD;
            queryResponse.COPVC_ESTADO = objCobro.COPVC_ESTADO;
            queryResponse.COSDT_FECHA_MODIF = DateTime.Now;
            queryResponse.COSVC_ID_USER_MODIF = objCobro.COSVC_ID_USER_INSERT;
            _context_c.COBRO.Update(queryResponse);
            _context_c.SaveChanges();
            response.CodError = "000";
            response.Descripcion = "Proceso Conforme";

            return response;
        }
    }    
}
