﻿using Microsoft.EntityFrameworkCore;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class SubProductoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;

        public SubProductoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
            //_mapper = mapper;
        }
        public List<Models.OcDtos.OcDtosModel.SubProductoDto> ObtenerListaSubProductoActivoPorIdProducto(string idProducto)
        {
            var subProductos = _context_c.SUB_PRODUCTO.AsNoTracking().Where(w => w.PRPVC_ID_PRODUCTO == idProducto && w.SUPBT_ACTIVO).ToList();
            var response = subProductos.Select(s => new Models.OcDtos.OcDtosModel.SubProductoDto
            {
                idSubProducto = s.SUPBI_ID_SUB_PRODUCTO,
                idProducto = s.PRPVC_ID_PRODUCTO,
                numeroNivel = s.SUPIN_NUMERO_NIVEL,
                descripcion = s.SUPVC_DESCRIPCION,
                //EstadoActivo = s.SUPBT_ACTIVO,
                //FechaRegistro = s.SUSDT_FECHA_INSERT,
                //UsuarioRegistro = s.SUSVC_ID_USER_INSERT,
                //FechaModificacion = s.SUSDT_FECHA_MODIF,
                //UsuarioModificacion = s.SUSVC_ID_USER_MODIF
            }).ToList();
            return response;
        }

        public SubProductoDto ObtenerSubProductoPorIdProdDescripcion(string idProducto, string descripcion)
        {
            var subProductos = _context_c.SUB_PRODUCTO.AsNoTracking()
                .Where(w => w.PRPVC_ID_PRODUCTO == idProducto && w.SUPVC_DESCRIPCION.Contains(descripcion) && w.SUPBT_ACTIVO)
                .ToList();

            var response = subProductos.Select(s => new SubProductoDto
            {
                idSubProducto = s.SUPBI_ID_SUB_PRODUCTO,
                idProducto = s.PRPVC_ID_PRODUCTO,
                numeroNivel = s.SUPIN_NUMERO_NIVEL,
                descripcion = s.SUPVC_DESCRIPCION,
                //EstadoActivo = s.SUPBT_ACTIVO,
                //FechaRegistro = s.SUSDT_FECHA_INSERT,
                //UsuarioRegistro = s.SUSVC_ID_USER_INSERT,
                //FechaModificacion = s.SUSDT_FECHA_MODIF,
                //UsuarioModificacion = s.SUSVC_ID_USER_MODIF
            }).ToList();
            return response.FirstOrDefault();
        }
    }
}
