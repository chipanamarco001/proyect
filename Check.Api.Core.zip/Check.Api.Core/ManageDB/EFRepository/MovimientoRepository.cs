﻿using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class MovimientoRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public MovimientoRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public MOVIMIENTO RegistrarMovimiento(MOVIMIENTO objMovimiento)
        {
            _context_c.MOVIMIENTO.Add(objMovimiento);
            _context_c.SaveChanges();
            return objMovimiento;
        }

        public SPR_REGISTRAR_MOVIMIENTO_Result RegistrarMovimientoSp(long idAfiliacion, OcCredenciales objCredenciales)
        {
            var queryResponse = _context_sp.SPR_REGISTRAR_MOVIMIENTO(idAfiliacion,
                objCredenciales.usuario
                ).FirstOrDefault();

            return queryResponse ?? new SPR_REGISTRAR_MOVIMIENTO_Result
            {
                IdMovimiento = 0,
                Mensaje = "No hay datos para retornar",
                Exito = false
            };
        }
    }
}
