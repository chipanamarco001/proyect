﻿using Microsoft.EntityFrameworkCore;
using Models.DtosSp;
using Models.OcDtos;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class RecaudacionYapeRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public RecaudacionYapeRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }
        public List<SPR_CONSULTA_CUOTAS_Result> ObtenerDatosConsulta(string strCodigoBusqueda)
        {
            List<SPR_CONSULTA_CUOTAS_Result> queryResponse = _context_sp.SPR_CONSULTA_CUOTAS(
                strCodigoBusqueda.ToString()
                ).ToList();
            return queryResponse;
        }


        //public SPR_PAGO_BCP_Result Reporte_PagoBCP(string codigoBusqueda, string idUsuario, string json, string entidad)
        //{
        //    SPR_PAGO_BCP_Result queryResponse = _context_sp.SPR_PAGO_BCP(
        //        codigoBusqueda,
        //        idUsuario,
        //        json,
        //        entidad).FirstOrDefault();
        //    return queryResponse;
        //}




    }
}
