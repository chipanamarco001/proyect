﻿using Models.OcDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.EFRepository
{
    public class LogServicioRepository
    {
        private readonly ApplicationDbSpContext _context_sp;
        private readonly ApplicationDbContext _context_c;
        public LogServicioRepository(ApplicationDbSpContext context_sp, ApplicationDbContext context_c)
        {
            _context_sp = context_sp;
            _context_c = context_c;
        }

        public LOG_SERVICIO RegistrarLogServicio(LOG_SERVICIO objLogServicio)
        {
            _context_c.LOG_SERVICIO.Add(objLogServicio);
            _context_c.SaveChanges();

            return objLogServicio;
        }
    }
}
