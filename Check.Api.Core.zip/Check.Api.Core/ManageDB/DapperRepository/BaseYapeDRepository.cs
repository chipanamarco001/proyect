﻿using Dapper;
using Microsoft.Data.SqlClient;
using Models.OcDtos.OcDtosModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;

namespace ManageDB.DapperRepository
{
    public class BaseYapeDRepository
    {
        private readonly string _connectionString;
        public BaseYapeDRepository(string connectionString)
        {
            _connectionString = connectionString;
        }
        private IDbConnection CreateConnection() => new SqlConnection(_connectionString);
        public List<OcBaseYapeDto> ObtenerListaClienteYapePorDocumentoCorreo(string strNum, string strEmail)
        {
            using var connection = CreateConnection();
            var parameters = new DynamicParameters();

            parameters.Add("@DOCUMENTO_NUMERO", strNum);
            parameters.Add("@CORREO", strEmail);

            var response = connection.Query<OcBaseYapeDto>(
                "per.SPR_OBTENER_PRODUCTO_PARAMETRO_POR_IDSUBPRODUCTO",
                parameters,
                commandType: CommandType.StoredProcedure
            ).ToList();

            return response;    
        }
    }
}
