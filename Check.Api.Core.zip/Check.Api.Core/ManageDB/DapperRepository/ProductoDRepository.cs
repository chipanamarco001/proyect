﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApi;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ManageDB.DapperRepository
{
    public class ProductoDRepository
    {
        private readonly IDbConnection _connection;
        public ProductoDRepository(IDbConnection connection)
        {
            _connection = connection;
        }
        public List<PRODUCTO> ObtenerProductos()
        {

            string sql = @"SELECT * FROM PRODUCTO WHERE PRPBT_ACTIVO = @ACTIVO";
            var output = _connection.Query<PRODUCTO>(sql, new { ACTIVO = true }).ToList();
            return output;

        //    var _estudicantes = _connection.Query<PRODUCTO>("ObtenerTodosLosEstudiantes", CommandType.StoredProcedure);
        //var sqlcurso = "SELECT * FROM Cursos WHERE EstudianteID = @EstudianteID";
        //    foreach(var item in _estudicantes)
        //    {
        //        IEnumerable<Cursos> enumerable = await _connection.QueryAsync<Cursos>(sqlcurso, new { item.EstudianteID });
        //item.Cursos = enumerable.ToList();    

        //    }

           // return _estudicantes;
        }
    }
}
