﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.ApiFacturacion
{
    public class ParametrosFacturacion
    {
        public static string UrlBase = "http://localhost:5224/";

        public static string ObtenerFacturasPorFechasEstado = Path.Combine(UrlBase, "api/Facturacion/ObtenerFacturasPorFechasEstado");

        public static string ObtenerListaLexicoPorTabla = Path.Combine(UrlBase, "api/Configuracion/ObtenerListaLexicoPorTabla");

        public static string ObtenerListaLexicoPorTablaTema = Path.Combine(UrlBase, "api/Configuracion/ObtenerListaLexicoPorTablaTema");

        public static string RegistrarFacturacion = Path.Combine(UrlBase, "api/Facturacion/RegistrarFacturacion");

        public static string ObtenerArchivoCsvIdLote = Path.Combine(UrlBase, "api/Facturacion/ObtenerArchivoCsvIdLote");

        public static string RegistrarAnulacion = Path.Combine(UrlBase, "api/Facturacion/RegistrarAnulacion");

        public static string urlSaveError = Path.Combine(UrlBase, "/api/Configuracion/RegistrarError");

        #region Métodos de Utilidad

        public static string ContraseñaAplicativo = "PERSONALES";

        #endregion
    }
}
