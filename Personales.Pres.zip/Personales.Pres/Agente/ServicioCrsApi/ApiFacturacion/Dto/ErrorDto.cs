﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.ApiFacturacion.Dto
{
    public class ErrorDto
    {
    }

    public class ErrorRegistrarDto
    {
        public long idError { get; set; }
        public string pagina { get; set; }
        public string metodo { get; set; }
        public string mensaje { get; set; }
        public string stackTrace { get; set; }
        public string innerException { get; set; }
    }

    public class ErrorRespuestaDto
    {
        public bool registrado { get; set; }
    }
}
