﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioApi.ApiFacturacion.Dto
{
    public class SPR_OBTENER_FACTURAS_POR_ID_LOTE_Result
    {
        // ASEGURADO
        public long aseguradoId { get; set; }
        public string tipoDocumento { get; set; }
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
        public string codigoClienteAsegurado { get; set; }
        //public string numeroTarjeta { get; set; }
        public string correo { get; set; }

        // FACTURA
        public long facturaId { get; set; }
        public string loteId { get; set; }
        public int numeroFactura { get; set; }
        public string polizaId { get; set; }
        public long afiliacionId { get; set; }
        public string certificadoId { get; set; }
        public string productoId { get; set; }
        public string nit { get; set; }
        public string razonSocial { get; set; }
        public string observaciones { get; set; }
        public string descripcion { get; set; }
        public string moneda { get; set; }
        public string codigoUnidadMedida { get; set; }
        public DateTime fecha { get; set; }
        public double? tipoCambio { get; set; }
        public string tipo { get; set; }
        public string codigoProductoSin { get; set; }
        public string codigoMetodoPago { get; set; }
        public string numeroTarjeta { get; set; }
        public decimal montoGiftcard { get; set; }
        public decimal descuentoAdicional { get; set; }
        public decimal montoDescuento { get; set; }
        public string numeroSerie { get; set; }
        public string numeroImei { get; set; }
        public DateTime? fechaInsert { get; set; }
        public string usuarioInsert { get; set; }
        public string estado { get; set; }
        public string actividadEconomica { get; set; }
        public string codigoLeyenda { get; set; }

        //Detalle totales
        public decimal montoTotal { get; set; }
        public decimal montoTotalMoneda { get; set; }
        public decimal montoTotalSujetoIva { get; set; }
        public decimal precioUnitarioTotal { get; set; }
        public int cantidadTotal { get; set; }
        public decimal subTotal { get; set; }
    }

    public class SPR_OBTENER_FACTURAS_POR_ID_LOTE_Request
    {
        public string idLote { get; set; }
    }
}
