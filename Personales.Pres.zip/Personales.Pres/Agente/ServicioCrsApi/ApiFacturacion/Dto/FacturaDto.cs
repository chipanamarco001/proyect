﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.ApiFacturacion.Dto
{
    public class FacturaDto
    {
    }

    public class ActFacturasDto
    {
        public long idFacturas { get; set; }

        public int numeroFactura { get; set; }
    }

    public class RespActFacturasDto
    {
        public bool procesado { get; set; }
    }

    public class GenerarArchivCsvResponse
    {
        public bool procesado { get; set; }
        public byte[] byteCsvArchivo { get; set; }
        public List<ResumenCsv> lstResumen { get; set; }
        public string idLote { get; set; }
        public string nombreArchivo { get; set; }
    }
    public class ResumenCsv
    {
        public int intMoneda { get; set; }
        public decimal decMonto { get; set; }
        public int intCantidad { get; set; }
    }
}
