﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.ApiFacturacion.Dto
{
    public class LoteDto
    {
    }
    public class CsvLoteDto
    {
        public string idLoteFacturas { get; set; }
    }
}
