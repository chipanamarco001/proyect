﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.ApiFacturacion.Dto
{
    public class LexicoDto
    {
    }

    public class LexicoTablaRequest
    {
        public string tabla { get; set; } //= null!;
    }

    public class LexicoTablaTemaRequest
    {
        public string tabla { get; set; } //= null!;
        public string tema { get; set; } //= null!;
    }
    public class LexicoResponse
    {
        public string tabla { get; set; }
        public string tema { get; set; }
        public string valor { get; set; }
        public string descripcion1 { get; set; }
        public string descripcion2 { get; set; }
        public string descripcion3 { get; set; }
    }
}
