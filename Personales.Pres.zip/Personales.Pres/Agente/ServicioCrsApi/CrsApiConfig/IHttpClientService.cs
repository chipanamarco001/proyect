﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.CrsApiConfig
{
    public interface IHttpClientService
    {
        Task<TResponse> GetAsync<TResponse>(string url, string token);
        Task<CrsApiResponse<TResponse>> PostAsync<TRequest, TResponse>(string url, TRequest data, string token) where TResponse : class;
        Task<CrsApiResponse<TResponse>> PostAsync<TRequest, TResponse>(string url, TRequest data) where TResponse : class;
    }
}
