﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.CrsApiConfig
{
    public class CrsApiRequest<T>
    {
        public T solicitud { get; set; }//= new object();

        public OcCredenciales credenciales { get; set; }
    }
    public class CrsApiRequest
    {
        public OcCredenciales credenciales { get; set; }
    }
    public class OcCredenciales
    {
        public string usuario { get; set; }
        public string ip { get; set; }
        public string contraseña { get; set; }
    }
}
