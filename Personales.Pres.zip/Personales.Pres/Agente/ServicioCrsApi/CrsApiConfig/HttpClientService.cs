﻿using Agente.ServicioProduccion;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Agente.ServicioCrsApi.CrsApiConfig
{
    public class HttpClientService : IDisposable, IHttpClientService
    {
        private readonly HttpClient _httpClient;

        public HttpClientService()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<TResponse> GetAsync<TResponse>(string url, string token = null)
        {
            try
            {
                if (!string.IsNullOrEmpty(token))
                {
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }
                var response = await _httpClient.GetAsync(url).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                var jsonString = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<TResponse>(jsonString);


            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GENERAL ERROR] {ex.Message}");
            }

            return default;
        }

        public async Task<CrsApiResponse<TResponse>> PostAsync<TRequest, TResponse>(string url, TRequest data, string token = null) where TResponse : class
        {

            try
            {
                if (!string.IsNullOrEmpty(token))
                {
                    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }
                var json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(url, content).ConfigureAwait(false);
                var jsonString = await response.Content.ReadAsStringAsync();

                //TResponse responseData = null;

                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {


                    try
                    {
                        var result = JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                        return result;
                    }
                    catch
                    {
                        return new CrsApiResponse<TResponse>
                        {
                            status = response.StatusCode,
                            hasError = false,
                            messages = new List<Message> {
                                new Message {
                                                UserMessage = "Acceso no autorizado. Por favor revisa tu acceso.",
                                                TechnicalMessage = "Acceso no autorizado.",
                                                MethodName = url.Split('/').LastOrDefault()
                                } },
                            errors = new List<Error>(),
                            result = null,

                        };
                    }
                }

                if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    return new CrsApiResponse<TResponse>
                    {
                        status = response.StatusCode,
                        hasError = false,
                        errors = new List<Error>(),
                        messages = new List<Message> {
                            new Message {
                                UserMessage = "No hay contenido disponible.",
                                TechnicalMessage = "No hay contenido disponible.",
                                MethodName=url.Split('/').LastOrDefault()
                            } },
                    };

                }
                try
                {
                    var result = JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                    return result;
                }
                catch
                {
                    var resultError = JsonConvert.DeserializeObject<ResponseError>(jsonString);
                    var messages = new List<Message>();

                    if (resultError.errors is JObject errorObj)
                    {
                        foreach (var prop in errorObj)
                        {
                            foreach (var msg in prop.Value)
                            {
                                messages.Add(new Message
                                {
                                    UserMessage = msg.ToString(),
                                    TechnicalMessage = $"{prop.Key}: {msg}"
                                });
                            }
                        }
                    }
                    else if (resultError.errors is JArray errorArray)
                    {
                        foreach (var msg in errorArray)
                        {
                            messages.Add(new Message
                            {
                                UserMessage = msg.ToString(),
                                TechnicalMessage = msg.ToString()
                            });
                        }
                    }
                    return new CrsApiResponse<TResponse>
                    {
                        status = response.StatusCode,
                        hasError = true,
                        messages = messages,
                        errors = messages.Select(m => new Error { MessageError = m.TechnicalMessage }).ToList()
                    };
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GENERAL ERROR] {ex.Message}");
                return new CrsApiResponse<TResponse>
                {
                    status = HttpStatusCode.InternalServerError,
                    hasError = true,
                    errors = new List<Error> { new Error { MessageError = ex.Message
    }
},
                    messages = new List<Message> { new Message { UserMessage = "Se produjo un error al procesar su solicitud..", TechnicalMessage = ex.Message } }
                };

            }
        }

        public async Task<CrsApiResponse<TResponse>> PostAsync<TRequest, TResponse>(string url, TRequest data) where TResponse : class
        {

            try
            {                
                var json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(url, content).ConfigureAwait(false);
                var jsonString = await response.Content.ReadAsStringAsync();

                //TResponse responseData = null;

                if (response.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                }

                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {


                    try
                    {
                        var result = JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                        return result;
                    }
                    catch
                    {
                        return new CrsApiResponse<TResponse>
                        {
                            status = response.StatusCode,
                            hasError = false,
                            messages = new List<Message> {
                                new Message {
                                                UserMessage = "Acceso no autorizado. Por favor revisa tu acceso.",
                                                TechnicalMessage = "Acceso no autorizado.",
                                                MethodName = url.Split('/').LastOrDefault()
                                } },
                            errors = new List<Error>(),
                            result = null,

                        };
                    }
                }

                if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    return new CrsApiResponse<TResponse>
                    {
                        status = response.StatusCode,
                        hasError = false,
                        errors = new List<Error>(),
                        messages = new List<Message> {
                            new Message {
                                UserMessage = "No hay contenido disponible.",
                                TechnicalMessage = "No hay contenido disponible.",
                                MethodName=url.Split('/').LastOrDefault()
                            } },
                    };

                }
                try
                {
                    var result = JsonConvert.DeserializeObject<CrsApiResponse<TResponse>>(jsonString);
                    return result;
                }
                catch
                {
                    var resultError = JsonConvert.DeserializeObject<ResponseError>(jsonString);
                    var messages = new List<Message>();

                    if (resultError.errors is JObject errorObj)
                    {
                        foreach (var prop in errorObj)
                        {
                            foreach (var msg in prop.Value)
                            {
                                messages.Add(new Message
                                {
                                    UserMessage = msg.ToString(),
                                    TechnicalMessage = $"{prop.Key}: {msg}"
                                });
                            }
                        }
                    }
                    else if (resultError.errors is JArray errorArray)
                    {
                        foreach (var msg in errorArray)
                        {
                            messages.Add(new Message
                            {
                                UserMessage = msg.ToString(),
                                TechnicalMessage = msg.ToString()
                            });
                        }
                    }
                    return new CrsApiResponse<TResponse>
                    {
                        status = response.StatusCode,
                        hasError = true,
                        messages = messages,
                        errors = messages.Select(m => new Error { MessageError = m.TechnicalMessage }).ToList()
                    };
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GENERAL ERROR] {ex.Message}");
                return new CrsApiResponse<TResponse>
                {
                    status = HttpStatusCode.InternalServerError,
                    hasError = true,
                    errors = new List<Error> { new Error { MessageError = ex.Message
    }
},
                    messages = new List<Message> { new Message { UserMessage = "Se produjo un error al procesar su solicitud..", TechnicalMessage = ex.Message } }
                };

            }
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
        }
    }
}
