﻿using Agente.ServicioProduccion;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Agente.ServicioCrsApi.CrsApiConfig
{
    public class CrsApiResponse<T>
    {
        public HttpStatusCode status { get; set; }
        public bool hasError { get; set; }
        public List<Error> errors { get; set; }
        public List<Message> messages { get; set; }
        public T result { get; set; }
    }

    public class Error
    {
        public string MessageError { get; set; }

        public string InnerException { get; set; }

        public string StackTrace { get; set; }

        public string UserError { get; set; }

        public string PropertyName { get; set; }

        public string MethodName { get; set; }
    }

    public class Message
    {
        public string UserMessage { get; set; }

        public string TechnicalMessage { get; set; }

        public string MethodName { get; set; }
    }

    public class ResponseError
    {
        public string type { get; set; }
        public string title { get; set; }
        public int status { get; set; }
        public JToken errors { get; set; }
        public string traceId { get; set; }

    }
}
