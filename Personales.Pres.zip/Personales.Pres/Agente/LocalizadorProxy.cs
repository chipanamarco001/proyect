﻿using Agente.ServicioAzure;
using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using Agente.ServicioCrediseguro;
using Agente.ServicioArchivoNegativo;
using Agente.ServicioCore;
using Agente.ServicioProduccion;
using Agente.ServicioARegulatorios;
using Agente.ServicioCoreDocumentos;

namespace Agente
{
    public class LocalizadorProxy
    {
        public static IServicioPersonales ServicioPersonales()
        {
            IServicioPersonales objServicio = new ServicioPersonalesClient("ServicioPersonalesHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioPersonales conexion)
        {
            ((ServicioPersonalesClient)conexion).Close();
        }
        public static IServicioCore ServicioCore()
        {
            IServicioCore objServicio = new ServicioCoreClient("ServicioCoreHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioCore conexion)
        {
            ((ServicioCoreClient)conexion).Close();
        }
        #region Azure
        public static IServicioAzure ServicioAzure()
        {
            IServicioAzure objServicio = new ServicioAzureClient("ServicioAzureHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioAzure conexion)
        {
            ((ServicioAzureClient)conexion).Close();
        }
        #endregion
        public static ServicioDocumentos.IServicioDocumentos ServicioDocumentos()
        {
            ServicioDocumentos.IServicioDocumentos objServicio = new ServicioDocumentos.ServicioDocumentosClient("ServicioDocumentosHttpEndPoint");
            return objServicio;
        }
        public static void Close(ServicioDocumentos.IServicioDocumentos conexion)
        {
            ((ServicioDocumentos.ServicioDocumentosClient)conexion).Close();
        }
        public static IServicioCrediseguro ServicioCrediseguro()
        {
            IServicioCrediseguro objServicio = new ServicioCrediseguroClient("ServicioCrediseguroHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioCrediseguro conexion)
        {
            ((ServicioCrediseguroClient)conexion).Close();
        }

        #region Archivo Negativo
        public static IServicioNotasAps ServicioArchivoNegativo()
        {
            IServicioNotasAps objServicio = new ServicioNotasApsClient("ServicioNotasApsHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioNotasAps conexion)
        {
            ((ServicioNotasApsClient)conexion).Close();
        }
        #endregion
        #region Produccion
        public static IServicioProduccion ServicioProduccion()
        {
            IServicioProduccion objServicio = new ServicioProduccionClient("ServicioProduccionHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioProduccion conexion)
        {
            ((ServicioProduccionClient)conexion).Close();
        }
		#endregion

		#region Archivos regulatorios

		public static IServicioARegulatorios ServicioARegulatorios()
		{
			IServicioARegulatorios objServicio = new ServicioARegulatoriosClient("ServicioARegulatoriosHttpEndPoint");
			return objServicio;
		}

		public static void Close(IServicioARegulatorios conexion)
		{
			((ServicioARegulatoriosClient)conexion).Close();
		}

        #endregion
        public static ServicioCoreDocumentos.IServicioDocumentos ServicioCoreDocumentos()
        {
            ServicioCoreDocumentos.IServicioDocumentos objServicioDocumentos = new ServicioCoreDocumentos.ServicioDocumentosClient("ServicioDocumentosHttpEndPoint1");
            return objServicioDocumentos;
        }

    }
}
