﻿namespace Presentacion
{
    public class Global : System.Web.HttpApplication
    {
    }
}