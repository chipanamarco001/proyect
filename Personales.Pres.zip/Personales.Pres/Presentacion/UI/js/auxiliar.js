﻿function showLoader() {
    $('.preloader').show();
}
function hideLoader() {
    $('.preloader').fadeOut();
}