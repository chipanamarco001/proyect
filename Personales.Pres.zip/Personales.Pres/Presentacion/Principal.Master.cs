﻿using Agente.ServicioPersonales;
using Presentacion.Sitio.Controladores.Personales;
using System;
using System.Web.UI;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Configuration;
using System.Reflection;
using System.Web.Services;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace PresentacionWeb
{
    public partial class Principal : System.Web.UI.MasterPage
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;                
            }
            if (Session["SessionUsuario"] == null)
            {
                Response.Redirect("~/Sitio/Vista/Login/Default.aspx");
            }
            else
            {
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                LblNombreUsuario.Text = objUsuario.NombreCompleto + " (" + objUsuario.Matricula + ")";
                LblCorreoUsuario.Text = objUsuario.Correo;
                ImgUsuarioDominio.ImageUrl = "Usuario.ashx";
                AsignaNombrePagina(HttpContext.Current.Request.CurrentExecutionFilePath);
                sidebarnav.InnerHtml = new StringBuilder().Append(GenerarMenu()).ToString();
            }
            int intTimeout = Timeout();
            HidTimeout.Value = intTimeout.ToString();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + intTimeout + ");", true);
            CargarMesProduccion();
        }
        private static int Timeout()
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
            SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
            return Convert.ToInt32(section.Timeout.TotalMinutes * 1000 * 60);
        }
        public void AsignaNombrePagina(string strPagina)
        {
            try
            {
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                foreach (var objMenu in objUsuario.Menu)
                {
                    if (ResolveUrl(objMenu.PaginaUrl) == strPagina)
                    {
                        LblNombrePagina.Text = objMenu.PaginaNombre;
                        LblModloActivo.Text = objMenu.Contenedor;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void Page_Error(object sender, EventArgs e)
        {
            //string mensajeError = string.Empty;
            //Exception objErr = Server.GetLastError();
            //if (objErr.InnerException == null)
            //    mensajeError = objErr.Message;
            //else
            //    mensajeError = objErr.InnerException.Message;
            //Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=" + mensajeError.Replace("\r\n", ""));
        }
        public void RegistrarError(Exception objException, string strPagina, string strMetodo)
        {
            try
            {                
                if (Session["ERROR_LIST"] != null)
                {
                    var listaErrores = (dynamic)Session["ERROR_LIST"];
                    foreach (var objError in listaErrores)
                    {
                        var objResponseError = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                        {
                            ERPVC_PAGINA = listaErrores.GetType().FullName,
                            ERPVC_METODO = (string.IsNullOrEmpty(objError.MethodName) ? string.Empty : objError.MethodName),
                            ERPVC_MENSAJE = string.Concat(
                                string.IsNullOrEmpty(objError.ErrorMessage) ? string.Empty : "Mensaje: " + objError.ErrorMessage + ". ",
                                string.IsNullOrEmpty(objError.ErrorUsuario) ? string.Empty : "Error usuario: " + objError.ErrorUsuario + ". ",
                                string.IsNullOrEmpty(objError.PropertyName) ? string.Empty : "Propiedad: " + objError.PropertyName + ". "
                            ),
                            ERPVC_STACK_TRACE = (string.IsNullOrEmpty(objError.StackTrace) ? string.Empty : objError.StackTrace),
                            ERPVC_INNER_EXCEPTION = (string.IsNullOrEmpty(objError.InnerException) ? string.Empty : objError.InnerException)
                        });
                    }
                }
                var objResponse = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objException.Message == null) ? string.Empty : objException.Message,
                    ERPVC_STACK_TRACE = (objException.StackTrace == null) ? string.Empty : objException.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objException.InnerException == null) ? string.Empty : "Message: " + objException.InnerException.Message,
                        (objException.InnerException == null) ? string.Empty : " - ",
                        (objException.InnerException == null) ? string.Empty : "StackTrace: " + objException.InnerException.StackTrace)
                });
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=Se ha producido un error en el proceso, si el problema persiste, por favor comuníquese con el área de sistemas indicando el error número: " + objResponse.ERPBI_ID_ERROR.ToString(), false);
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=" + ex.Message);
            }
        }
        public void RegistrarErrorCallback(Exception objException, string strPagina, string strMetodo)
        {
            try
            {
                if (Session["ERROR_LIST"] != null)
                {
                    var listaErrores = (dynamic)Session["ERROR_LIST"];
                    foreach (var objError in listaErrores)
                    {
                        var objResponseError = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                        {
                            ERPVC_PAGINA = listaErrores.GetType().FullName,
                            ERPVC_METODO = (string.IsNullOrEmpty(objError.MethodName) ? string.Empty : objError.MethodName),
                            ERPVC_MENSAJE = string.Concat(
                                string.IsNullOrEmpty(objError.ErrorMessage) ? string.Empty : "Mensaje: " + objError.ErrorMessage + ". ",
                                string.IsNullOrEmpty(objError.ErrorUsuario) ? string.Empty : "Error usuario: " + objError.ErrorUsuario + ". ",
                                string.IsNullOrEmpty(objError.PropertyName) ? string.Empty : "Propiedad: " + objError.PropertyName + ". "
                            ),
                            ERPVC_STACK_TRACE = (string.IsNullOrEmpty(objError.StackTrace) ? string.Empty : objError.StackTrace),
                            ERPVC_INNER_EXCEPTION = (string.IsNullOrEmpty(objError.InnerException) ? string.Empty : objError.InnerException)
                        });
                    }
                }
                var objResponse = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objException.Message == null) ? string.Empty : objException.Message,
                    ERPVC_STACK_TRACE = (objException.StackTrace == null) ? string.Empty : objException.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objException.InnerException == null) ? string.Empty : "Message: " + objException.InnerException.Message,
                        (objException.InnerException == null) ? string.Empty : " - ",
                        (objException.InnerException == null) ? string.Empty : "StackTrace: " + objException.InnerException.StackTrace)
                });
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=" + ex.Message);
            }
        }
        protected string GenerarMenu()
        {
            try
            {
                var listaMenu = ((occ_usuario)Session["SessionUsuario"]).Menu;
                string strHtml = string.Empty;
                strHtml += "<li class=\"sidebar-item\"><a class=\"sidebar-link waves-effect waves-dark sidebar-link\" href=\"" + ResolveUrl("~/Sitio/Vista/Inicio/Default.aspx") + "\" aria-expanded=\"false\"><i class=\"mdi mdi-star-circle\"></i><span class=\"hide-menu\">Inicio</span></a></li>";
                int intCantidadNiveles = listaMenu.Max(m => m.Nivel);
                bool boolToggle = false;
                var listaNivel1 = listaMenu.Where(w => w.Nivel == 1 && w.IdMenuPadre == null).OrderBy(o => o.Contenedor).ThenBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                string strContenedor = string.Empty;
                foreach (var objMenu in listaNivel1)
                {
                    if (boolToggle && strContenedor != string.Empty && strContenedor != objMenu.Contenedor)
                    {
                        strHtml += "</ul></li>";
                        boolToggle = false;
                    }
                    if (!boolToggle && !string.IsNullOrEmpty(objMenu.Contenedor))
                    {
                        strHtml += "<li class=\"sidebar-item\">" + "<a class=\"sidebar-link has-arrow waves-effect waves-dark\" href=\"javascript:void(0)\" aria-expanded=\"false\"><i class=\"mdi mdi-folder-multiple mdi-18px\"></i><span class=\"hide-menu\">" + objMenu.Contenedor + "</span></a>" + "<ul aria-expanded=\"false\" class=\"collapse first-level\">";
                        strContenedor = objMenu.Contenedor;
                        boolToggle = true;
                    }
                    if (objMenu.Tipo == "PAGINA")
                        strHtml += "<li class=\"sidebar-item\"><a href=\"" + ResolveUrl(objMenu.PaginaUrl) + "\" class=\"sidebar-link\"><i class=\"mdi mdi-file-chart\"></i><span class=\"hide-menu\"> " + objMenu.PaginaNombre + " </span></a></li>";
                    else if (objMenu.Tipo == "CARPETA")
                    {
                        strHtml += "<li class=\"sidebar-item\">" + "<a class=\"sidebar-link has-arrow waves-effect waves-dark\" href=\"javascript:void(0)\" aria-expanded=\"false\"><i class=\"mdi mdi-folder-multiple mdi-18px\"></i><span class=\"hide-menu\">" + objMenu.PaginaNombre + "</span></a>" + "<ul aria-expanded=\"false\" class=\"collapse second-level\">";
                        var listaNivel2 = listaMenu.Where(w => w.IdMenuPadre == objMenu.IdMenu).OrderBy(o => o.Contenedor).ThenBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                        foreach (var objNivel1 in listaNivel2)
                            if (objNivel1.Tipo == "PAGINA")
                                strHtml += "<li class=\"sidebar-item\"><a href=\"" + ResolveUrl(objNivel1.PaginaUrl) + "\" class=\"sidebar-link\"><i class=\"mdi mdi-file-chart\"></i><span class=\"hide-menu\"> " + objNivel1.PaginaNombre + " </span></a></li>";
                            else if (objNivel1.Tipo == "CARPETA")
                            {
                                strHtml += "<li class=\"sidebar-item\">" + "<a class=\"sidebar-link has-arrow waves-effect waves-dark\" href=\"javascript:void(0)\" aria-expanded=\"false\"><i class=\"mdi mdi-folder-multiple mdi-18px\"></i><span class=\"hide-menu\">" + objNivel1.PaginaNombre + "</span></a>" + "<ul aria-expanded=\"false\" class=\"collapse third-level\">";
                                var listaNivel3 = listaMenu.Where(w => w.IdMenuPadre == objNivel1.IdMenu).OrderBy(o => o.Contenedor).ThenBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                                foreach (var objNivel2 in listaNivel3)
                                    if (objNivel2.Tipo == "PAGINA")
                                        strHtml += "<li class=\"sidebar-item\"><a href=\"" + ResolveUrl(objNivel2.PaginaUrl) + "\" class=\"sidebar-link\"><i class=\"mdi mdi-file-chart\"></i><span class=\"hide-menu\"> " + objNivel2.PaginaNombre + " </span></a></li>";
                                strHtml += "</ul></li>";
                            }
                        strHtml += "</ul></li>";
                    }
                }
                if (boolToggle)
                    strHtml += "</ul></li>";
                strHtml += "<li class=\"sidebar-item\"><a class=\"sidebar-link waves-effect waves-dark sidebar-link\" href=\"" + ResolveUrl("~/Sitio/Vista/Login/Default.aspx") + "\" aria-expanded=\"false\"><i class=\"mdi mdi-power\"></i><span class=\"hide-menu\">Salir</span></a></li>";
                return strHtml;
            }
            catch
            {
                throw;
            }
        }
        public void CargarMesProduccion()
        {
            try
            {
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                DateTime dtPeriodoProcesoActual = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                DateTime dtPeriodo = dtPeriodoProcesoActual.AddMonths(-18);
                CmbPeriodoContable.Items.Clear();
                while (dtPeriodo <= dtPeriodoProcesoActual)
                {
                    string strMesProduccionLiteral = dtPeriodo.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodo.AddMonths(1).Year.ToString();
                    CmbPeriodoContable.Items.Add(strMesProduccionLiteral, dtPeriodo.ToString("yyyyMM"));
                    dtPeriodo = dtPeriodo.AddMonths(1);
                }
                string strPeriodoActivo = (Session["PERIODO_CONTABLE"] == null) ? dtPeriodoProcesoActual.ToString("yyyyMM") : Session["PERIODO_CONTABLE"].ToString();
                DateTime dtPeriodoProceso = DateTime.ParseExact(strPeriodoActivo + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                CmbPeriodoContable.Value = dtPeriodoProceso.ToString("yyyyMM");
                LblMesProduccion.Text = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString();
                Session["PERIODO_CONTABLE"] = strPeriodoActivo;
            }
            catch (Exception ex)
            {
                RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strPeriodoContable = CmbPeriodoContable.SelectedItem.Value.ToString();
                Session["PERIODO_CONTABLE"] = strPeriodoContable;
                DateTime dtPeriodoProceso = DateTime.ParseExact(strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                LblMesProduccion.Text = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString();
                PopCambioPeriodo.ShowOnPageLoad = false;
                Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri, false);
            }
            catch (Exception ex)
            {
                RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void MostrarToastr(string strTipo, string strTitulo, string strMensaje)
        {
            ScriptManager.RegisterStartupScript(this.Page, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                "toastr." + strTipo  + "('" + strMensaje + "', '" + strTitulo + "', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
        }
    }
}