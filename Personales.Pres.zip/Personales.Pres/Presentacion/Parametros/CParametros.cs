﻿using Agente.ServicioPersonales;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using System.Net.Sockets;
using System.Web;
using System.Web.UI;

namespace Presentacion.Parametros
{
    public class CParametros : Page
    {
        private const string strNombreCortoEmpresa = "Crediseguro S.A.";
        private const string strNombreLargoEmpresa = "Crediseguro S.A. Seguros Personales";
        public static string GestionDesarrollo { get { return DateTime.Now.Year.ToString(); } }
        private const string strNombreSistema = "Sistema Core";
        public static List<string> ListaCorreoCopiaSistemas { get { return new List<string>() { "WHuanca@crediseguro.com.bo" }; } }
        public static string RutaArchivoValidacion
        {
            get
            {
                if (ConfigurationManager.AppSettings["Environment"] == "Sandbox")
                    return @"D:\Personales.Core\Validaciones\";
                else
                    return @"F:\Aplicativos\Personales.Core\Validaciones\";
            }
        }
        public static string RutaArchivoDatos
        {
            get
            {
                if (ConfigurationManager.AppSettings["Environment"] == "Sandbox")
                    return @"D:\Personales.Core\Archivos\";
                else
                    return @"F:\Aplicativos\Personales.Core\Archivos\";
            }
        }
        public static string RutaCertificados
        {
            get
            {
                if (ConfigurationManager.AppSettings["Environment"] == "Sandbox")
                    return @"D:\Personales.Core\Certificados\";
                else
                    return @"F:\Aplicativos\Personales.Core\Certificados\";
            }
        }
        public static string RutaReportes
        {
            get
            {
                if (ConfigurationManager.AppSettings["Environment"] == "Sandbox")
                    return @"D:\Personales.Core\Reportes\";
                else
                    return @"F:\Aplicativos\Personales.Core\Reportes\";
            }
        }
        public static string RutaAdjuntos
        {
            get
            {
                if (ConfigurationManager.AppSettings["Environment"] == "Sandbox")
                    return @"D:\Personales.Core\Adjuntos\";
                else
                    return @"F:\Aplicativos\Personales.Core\Adjuntos\";
            }
        }
        public static string GetEmpresaNombreCorto()
        {
            return strNombreCortoEmpresa;
        }
        public static string GetNombreSistema()
        {
            return strNombreSistema;
        }



        //public string GetCurrentUser()
        //{
        //    string strIdUsuario = string.Empty;
        //    var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
        //    if (windowsIdentity != null)
        //        strIdUsuario = (HttpContext.Current.User.Identity.Name != string.Empty) ? HttpContext.Current.User.Identity.Name : windowsIdentity.Name;
        //    strIdUsuario = strIdUsuario.Split(new[] { "\\" }, StringSplitOptions.None)[1];
        //    strIdUsuario = strIdUsuario.ToUpper();
        //    return strIdUsuario;
        //}
        //public string GetCurrentIp()
        //{
        //    string strIPv4 = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        //    if (string.IsNullOrEmpty(strIPv4))
        //        strIPv4 = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        //    return strIPv4;
        //}
        public string GetCurrentUser()
        {
            string strIdUsuario = string.Empty;
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (HttpContext.Current != null && HttpContext.Current.User != null && HttpContext.Current.User.Identity != null)
            {
                var name = HttpContext.Current.User.Identity.Name;
                strIdUsuario = !string.IsNullOrEmpty(name) ? name : windowsIdentity?.Name;
            }
            else if (windowsIdentity != null)
            {
                strIdUsuario = windowsIdentity.Name;
            }
            if (!string.IsNullOrEmpty(strIdUsuario) && strIdUsuario.Contains("\\"))
                strIdUsuario = strIdUsuario.Split(new[] { "\\" }, StringSplitOptions.None)[1];
            strIdUsuario = strIdUsuario.ToUpper();
            return strIdUsuario;
        }

        public string GetCurrentIp()
        {
            if (HttpContext.Current != null)
            {
                string strIPv4 = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (string.IsNullOrEmpty(strIPv4))
                    strIPv4 = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                return strIPv4;
            }
            return "IP_DESCONOCIDA";
        }

        #region Personales
        public Agente.ServicioPersonales.CREDENCIALES GetCredencialesPersonales()
        {
            var objCred = new Agente.ServicioPersonales.CREDENCIALES();
            try
            {
                objCred.USUARIO = GetCurrentUser();
                objCred.IP = GetCurrentIp();
            }
            catch
            {
                throw;
            }
            return objCred;
        }
        #endregion
        #region Crediseguro
        public Agente.ServicioCrediseguro.CREDENCIALES GetCredencialesCrediseguro()
        {
            var objCred = new Agente.ServicioCrediseguro.CREDENCIALES();
            try
            {
                objCred.USUARIO = GetCurrentUser();
                objCred.IP = GetCurrentIp();
            }
            catch
            {
                throw;
            }
            return objCred;
        }
        #endregion
        #region Documentos
        public Agente.ServicioDocumentos.CREDENCIALES GetCredencialesDocumentos()
        {
            var objCred = new Agente.ServicioDocumentos.CREDENCIALES();
            try
            {
                objCred.USUARIO = GetCurrentUser();
                objCred.IP = GetCurrentIp();
            }
            catch
            {
                throw;
            }
            return objCred;
        }
        #endregion
        #region Azure
        public Agente.ServicioAzure.CREDENCIALES GetCredencialesAzure()
        {
            var objCred = new Agente.ServicioAzure.CREDENCIALES();
            try
            {
                objCred.USUARIO = GetCurrentUser();
                objCred.IP = GetCurrentIp();
                objCred.BROKER = string.Empty;
                objCred.ENTIDAD = string.Empty;
                objCred.TOMADOR = string.Empty;
            }
            catch
            {
                throw;
            }
            return objCred;
        }
		#endregion

		#region Archivos Regulatorios
		public Agente.ServicioARegulatorios.CREDENCIALES GetCredencialesARegulatorios()
		{
			var objCred = new Agente.ServicioARegulatorios.CREDENCIALES();
			try
			{
				objCred.USUARIO = GetCurrentUser();
				objCred.IP = GetCurrentIp();
			}
			catch
			{
				throw;
			}
			return objCred;
		}

		#endregion
		#region Cybersource
		private static string strEnvironment = ConfigurationManager.AppSettings["Environment"];
        /*** Sandbox Environment ***/
        private const string strSandboxSecretKey = "jzZqbRoevgpMIfSYmjVPKt+yeYl+PVrtCHcKjEqAUvlQq6Gko5vXHZV/Gr2s+3Rwi/GzaQdCmzf9jPzRhVXYDaIyThxW00Ch/GkdSNaVCbrb1oHQhFoInrqUNtUfyZjy+T/zIvVv9Lr1MTSjrA18INjJxDKke/aevZTFoMxUfqPgXEKxXrcvI6qxnwyn3SyZG+rv9qLKuRWomIZw8k1oThu/Ckn5V4wfAcR3mIr0U2REDqZ98xoyKbCTxIsgCmqJU7sUDbB5eHidg4Z0igp/97ZXnpiVIh+RjfsAF9TCyqoew48lUDxOlw39R2cCmuzUcnTl1NvcEUR0IUifbjJKcgzVwdTawnY0r0Eutuer/l0=";
        private const string strSandboxOrganizationID = "ZdbIzqXDyCr3K6RlOwqePw==";
        private const string strSandboxMerchantID = "QWnfXxjOkIdO7UmC/7AE8eUMuKpb0tNm+TLy2lHo3ac=";
        private const string strSandboxAccessKey = "XyuVXVt1/KWOtmHylS7ROyobXQIty+aiW+M+dbyTXNk5EakKTOu6i+r1XZWXDCm/";
        private const string strSandboxProfileID = "MoxQtpxLLGEKusJg0kSzBdZcN+ItuwnPE3zfIVY100JWQo6+j6dQ6vWeullZiloA";
        private const string strSandboxPostURL = "https://testsecureacceptance.cybersource.com/pay";
        /*** Live Environment ***/
        private const string strLiveSecretKey = "ssoGPx3GXHiBmMgdQlofXEaeCsowl1xm7tpk3InFt60Pxox/FVBZmsx/H4WtNorqY+qElqLK4r0MVqcT6rXtv48AxgAllZ2axL3IjJk2RZPKiQW81ljF7hfjwLHDzYBMGSS3hoUcBrTc8sPx4+bR1ciIu3//Q4tovkksjTgBUAyolkqDu1FYJ9+S0McuM9WUIgREvqqRDvrluomAEb8siIhoZQwaaGYMf5rj3qKnqzE7NGXSF13hLUDbXqbzHGGk3HUpHW9HuiMQJd+7NAGCJ7pQBNP2rFDBeKRGt593nX8+y7jnDMJP3mLNXNDcNQ6lsBtxPO84HNg6j4DwvVSxZ9chxyYiABwsFOVwJaTiysg=";
        private const string strLiveOrganizationID = "DPjI5p+fce2kXSikXBd88Q==";
        private const string strLiveMerchantID = "QWnfXxjOkIdO7UmC/7AE8eUMuKpb0tNm+TLy2lHo3ac=";
        private const string strLiveAccessKey = "00/dUIyfpOnESeOBobRUUT8JwzPknSNclbMyGyI8VH+uBHFX7o+1Nfo5HYQMrU4f";
        private const string strLiveProfileID = "a1cS69WtJ+8lqUp3qRx49xJpawTrpab7ADcSfTm+4MKSmY+pyqiuT3KESluzK87k";
        private const string strLivePostURL = "https://secureacceptance.cybersource.com/pay";
        /*** Functions ***/
        public static string GetSecretKey()
        {
            return (strEnvironment == "Live") ? strLiveSecretKey : strSandboxSecretKey;
        }
        public static string GetOrganizationID()
        {
            return (strEnvironment == "Live") ? strLiveOrganizationID : strSandboxOrganizationID;
        }
        public static string GetMerchantID()
        {
            return (strEnvironment == "Live") ? strLiveMerchantID : strSandboxMerchantID;
        }
        public static string GetAccessKey()
        {
            return (strEnvironment == "Live") ? strLiveAccessKey : strSandboxAccessKey;
        }
        public static string GetProfileID()
        {
            return (strEnvironment == "Live") ? strLiveProfileID : strSandboxProfileID;
        }
        public static string GetPostURL()
        {
            return (strEnvironment == "Live") ? strLivePostURL : strSandboxPostURL;
        }
        #endregion
        #region Tramas
        private const string strTramaUserName = "ycfBaZ75LVRvVtVCZuoDXw==";
        private const string strTramaPassword = "QJ6EnGvoHCNo+wkzUsH5YA==";
        private const string strTramaApplication = "wgKxSw3RIeq62xm+uAW7R/r6d5z9Xkjh7VJh2f6IbjM=";
        private const string strTramaCompany = "wJTXwKEHm6WhEDSFxL7QKxWW6GVzpPfYs0M32mFS5AS+JT0rpk5Z4ljw1H0m0VxX";
        public static string GetTramaUserName()
        {
            return strTramaUserName;
        }
        public static string GetTramaPassword()
        {
            return strTramaPassword;
        }
        public static string GetTramaApplication()
        {
            return strTramaApplication;
        }
        public static string GetTramaCompany()
        {
            return strTramaCompany;
        }
        #endregion
    }
}