﻿using System;

namespace Presentacion.Parametros
{
    public class CParametrosComplejos
    {
        public void ValidationResult(dynamic objectResponse)
        {
            if (objectResponse.ValidationResult.Error)
            {
                System.Web.HttpContext.Current.Session["ERROR_LIST"] = objectResponse.ValidationResult.ValidationErrors;
                throw new Exception("Se ha presentado un error inesperado.");
            }
        }
    }
}