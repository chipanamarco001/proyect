﻿using System;
using System.Collections.Generic;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_cuadro_cierre
    {
        public List<ocp_cuadro_cierre__produccion> ListaProduccion { get; set; }
        public List<ocp_cuadro_cierre__anulacion> ListaAnulacion { get; set; }
        public ocp_cuadro_cierre()
        {
            this.ListaProduccion = new List<ocp_cuadro_cierre__produccion>();
            this.ListaAnulacion = new List<ocp_cuadro_cierre__anulacion>();
        }
    }
    public class ocp_cuadro_cierre__anulacion
    {
        public string Ramo { get; set; }
        public string LineaNegocio { get; set; }
        public string TipoTomador { get; set; }
        public string NitTomador { get; set; }
        public string NombreTomador { get; set; }
        public string NumeroPoliza { get; set; }
        public DateTime InicioVigenciaPoliza { get; set; }
        public DateTime FinVigenciaPoliza { get; set; }
        public string IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public int Nivel { get; set; }
        public string Moneda { get; set; }
        public decimal PrimaAnulada { get; set; }
        public string NombreBroker { get; set; }
        public string AplicacionComisionBroker { get; set; }
        public decimal FactorComisionBroker { get; set; }
        public decimal ComisionBroker { get; set; }
    }
    public class ocp_cuadro_cierre__produccion
    {
        public string Ramo { get; set; }
        public string LineaNegocio { get; set; }
        public string TipoTomador { get; set; }
        public string NitTomador { get; set; }
        public string NombreTomador { get; set; }
        public string NumeroPoliza { get; set; }
        public DateTime InicioVigenciaPoliza { get; set; }
        public DateTime FinVigenciaPoliza { get; set; }
        public string IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public int Nivel { get; set; }
        public string Moneda { get; set; }
        public decimal PrimaComercial { get; set; }
        public decimal FactorPrimaAdicional { get; set; }
        public decimal PrimaAdicional { get; set; }
        public decimal PrimaNeta { get; set; }
        public decimal ImporteIVA { get; set; }
        public decimal ImporteIT { get; set; }
        public string AplicacionComisionCobranza { get; set; }
        public decimal FactorComisionCobranza { get; set; }
        public decimal ComisionCobranza { get; set; }
        public string NombreBroker { get; set; }
        public string AplicacionComisionBroker { get; set; }
        public decimal FactorComisionBroker { get; set; }
        public decimal ComisionBroker { get; set; }
        public decimal SumaAsegurada { get; set; }

    }
}