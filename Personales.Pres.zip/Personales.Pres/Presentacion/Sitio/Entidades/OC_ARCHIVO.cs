﻿using DevExpress.Spreadsheet;
using System.IO;

namespace PresentacionWeb.Sitio.Entidades
{
    public class OC_ARCHIVO
    {
        public string CONTENT_TYPE { get; set; }
        public string EXTENSION { get; set; }
        public string NOMBRE_ARCHIVO { get; set; }
        public Stream FILE_STREAM { get; set; }
        public byte[] BYTE_ARRAY { get; set; }
    }
    public class OC_CARGA_BDP
    {
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public OC_ARCHIVO Archivo { get; set; }
        public Workbook Control { get; set; }
    }
}