﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_control_bdp
    {
        public List<ocp_control_bdp__bandeja> ListaProduccion { get; set; }
        public List<ocp_control_bdp__documento> ListaDocumentos { get; set; }
        public ocp_control_bdp()
        {
            this.ListaProduccion = new List<ocp_control_bdp__bandeja>();
            this.ListaDocumentos = new List<ocp_control_bdp__documento>();
        }
        public ocp_control_bdp CargarListas(DataSet dsDatos)
        {
            var objControlBDP = new ocp_control_bdp();
            for (int index = 0; index < dsDatos.Tables[0].Rows.Count; index++)
            {
                objControlBDP.ListaProduccion.Add(new ocp_control_bdp__bandeja {
                    PERIODO = dsDatos.Tables[0].Rows[index]["PERIODO"].ToString(),
                    MES_PRODUCCION = dsDatos.Tables[0].Rows[index]["MES_PRODUCCION"].ToString(),
                    CANTIDAD_OPERACIONES = Convert.ToInt32(dsDatos.Tables[0].Rows[index]["CANTIDAD_OPERACIONES"].ToString()),
                    MONEDA = dsDatos.Tables[0].Rows[index]["MONEDA"].ToString(),
                    PRIMA_COBRADA = Convert.ToDecimal(dsDatos.Tables[0].Rows[index]["PRIMA_COBRADA"].ToString()),
                    PRIMA_PRODUCIDA = Convert.ToDecimal(dsDatos.Tables[0].Rows[index]["PRIMA_PRODUCIDA"].ToString()),
                    PRIMA_NO_PRODUCIDA = Convert.ToDecimal(dsDatos.Tables[0].Rows[index]["PRIMA_NO_PRODUCIDA"].ToString()),
                    PRIMA_PENDIENTE = Convert.ToDecimal(dsDatos.Tables[0].Rows[index]["PRIMA_PENDIENTE"].ToString()),
                    PRIMA_ANTICIPADA = Convert.ToDecimal(dsDatos.Tables[0].Rows[index]["PRIMA_ANTICIPADA"].ToString())
                });
            }
            for (int index = 0; index < dsDatos.Tables[1].Rows.Count; index++)
            {
                objControlBDP.ListaDocumentos.Add(new ocp_control_bdp__documento
                {
                    ID_DOCUMENTO = dsDatos.Tables[1].Rows[index]["ID_DOCUMENTO"].ToString(),
                    NOMBRE = dsDatos.Tables[1].Rows[index]["NOMBRE"].ToString(),
                    FORMATO = dsDatos.Tables[1].Rows[index]["FORMATO"].ToString()
                });
            }
            return objControlBDP;
        }
    }
    public class ocp_control_bdp__bandeja
    {
        public string PERIODO { get; set; }
        public string MES_PRODUCCION { get; set; }
        public int CANTIDAD_OPERACIONES { get; set; }
        public string MONEDA { get; set; }
        public decimal PRIMA_COBRADA { get; set; }
        public decimal PRIMA_PRODUCIDA { get; set; }
        public decimal PRIMA_NO_PRODUCIDA { get; set; }
        public decimal PRIMA_PENDIENTE { get; set; }
        public decimal PRIMA_ANTICIPADA { get; set; }
    }
    public class ocp_control_bdp__documento
    {
        public string ID_DOCUMENTO { get; set; }
        public string NOMBRE { get; set; }
        public string FORMATO { get; set; }
    }
}