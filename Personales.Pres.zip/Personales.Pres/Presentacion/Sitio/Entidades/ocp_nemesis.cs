﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_nemesis
    {
    }

    public class ocp_nemesis_coincidencias
    {
        public DateTime DESDE { get; set; }

        public DateTime HASTA { get; set; }

        public string IDCLIENTE { get; set; }

        public string CI { get; set; }

        public string COMPLEMENTO { get; set; }

        public string EXTENSION { get; set; }

        public string PATERNO { get; set; }

        public string MATERNO { get; set; }

        public string NOMBRES { get; set; }

        public string NIT { get; set; }

        public string RAZON_SOCIAL { get; set; }
    }

    public class persona_carta_nemesis
    {
        public string ID_PERSONA { get; set; }

        public string NOMBRE_PERSONA { get; set; }

        public string PATERNO { get; set; }

        public string MATERNO { get; set; }

        public string NOMBRE { get; set; }

        public string NUMERO_DOCUMENTO { get; set; }

        public string EXTENSION { get; set; }

        public string COMPLEMENTO { get; set; }

        public string DOCUMENTO { get; set; }

        public string NIT { get; set; }

        public string RAZON_SOCIAL { get; set; }

        public List<afiliaciones_carta_nemesis> LST_AFILIACIONES { get; set; }
    }

    public class afiliaciones_carta_nemesis
    {
        //public string ID_PERSONA { get; set; }
        public string TIPO_PRODUCTO { get; set; }

        public string NUMERO_AFILIACION { get; set; }

        public DateTime FECHA_INICIO { get; set; }

        public DateTime? FECHA_FIN { get; set; }

        public string PERIODO_ALCANCE { get; set; }
    }
}