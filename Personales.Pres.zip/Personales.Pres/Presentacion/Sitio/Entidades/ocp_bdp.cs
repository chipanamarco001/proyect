﻿using System.Collections.Generic;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_bdp
    {
        public List<ocp_bdp__listaNegra> ListaNegra { get; set; }
    }
    public class ocp_bdp__listaNegra
    {
        public string Operacion { get; set; }
        public string Motivo { get; set; }
        public string MesExclusion { get; set; }
    }
}