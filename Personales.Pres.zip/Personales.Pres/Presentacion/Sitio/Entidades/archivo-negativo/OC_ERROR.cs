﻿namespace Presentacion.Sitio.Entidades.archivo_negativo
{
    public class OC_ERROR
    {
        public string ERROR { get; set; }
    }
}