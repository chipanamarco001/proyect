﻿using System;

namespace Presentacion.Sitio.Entidades.archivo_negativo
{
    public class OC_ASEGURADO
    {
        public Int32 NRO { get; set; }
        public string ID_CLIENTE { get; set; }
        public string CLIENTE { get; set; }
        public string MODALIDAD { get; set; }
        public string NRO_POLIZA { get; set; }
        public string NRO_CERTIFICADO { get; set; }
        public string TOMADOR { get; set; }
        public string FECHA_INICIO_VIGENCIA { get; set; }
        public string FECHA_FIN_VIGENCIA { get; set; }
        public string ESTADO { get; set; }
        public string ENTIDAD_EMPRESA { get; set; }
        public bool ENCONTRADO { get; set; }
        public string ENCONTRADO_TEXTO { get; set; }
    }
}