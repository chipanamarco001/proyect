﻿using System;

namespace Presentacion.Sitio.Entidades.archivo_negativo
{
    public class OC_ASEGURADO_ARCHIVO_NEGATIVO
    {
        public long ID_ARCHIVO_NEGATIVO { get; set; }
        public Int32 NRO { get; set; }
        public string NRO_DOCUMENTO { get; set; }
        public string CLIENTE { get; set; }
        public string TIPO { get; set; }
        public string ESTADO { get; set; }
        public string MOTIVO { get; set; }
        public string PRODUCTO { get; set; }
        public string COBERTURA { get; set; }
        public string NRO_POLIZA { get; set; }
        public string FECHA_INGRESO { get; set; }
        public string USUARIO { get; set; }
    }
}