﻿using Newtonsoft.Json;
using Presentacion.Sitio.Controladores.Personales;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Authentication;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_an_bcp
    {
        private static readonly CPersonales _cPersonales = new CPersonales();
        public static ocp_an_bcp__response ConsultaArchivoNegativo(ocp_an_bcp__request objRequest)
        {
            var objResponse = new ocp_an_bcp__response();
            try
            {
                if (objRequest.idcTipo == "Q" && objRequest.idcNumero.Length <= 5)
                {
                    string strDocumentoAlternativo = "000000" + objRequest.idcNumero;
                    objRequest.idcNumero = strDocumentoAlternativo.Substring(strDocumentoAlternativo.Length - 6, 6);
                }
                var objLexico = _cPersonales.Lexico_ObtenerListaActivos().Where(w => w.LEPVC_TABLA == "SERVICIO_BCP" && w.LEPVC_TEMA == "ARCHIVO_NEGATIVO").FirstOrDefault();
                var url = objLexico.LEPVC_VALOR;
                System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)((SslProtocols)0x00000C00);
                var request = (HttpWebRequest)WebRequest.Create(url);
                string json = JsonConvert.SerializeObject(objRequest, Formatting.Indented);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }
                using (WebResponse response = request.GetResponse())
                {
                    if (((HttpWebResponse)response).StatusCode == HttpStatusCode.OK)
                    { 
                        using (Stream strReader = response.GetResponseStream())
                        {
                            if (strReader == null)
                                throw new Exception("Error en servicio BCP, el objeto stream es nulo.");
                            using (StreamReader objReader = new StreamReader(strReader))
                            {
                                string responseBody = objReader.ReadToEnd();
                                objResponse = JsonConvert.DeserializeObject<ocp_an_bcp__response>(responseBody);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CPersonales _cPersonales = new CPersonales();
                var objErrorResponse = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                {
                    ERPVC_PAGINA = "ocp_an_bcp",
                    ERPVC_METODO = MethodBase.GetCurrentMethod().Name,
                    ERPVC_MENSAJE = (ex.Message == null) ? string.Empty : ex.Message,
                    ERPVC_STACK_TRACE = (ex.StackTrace == null) ? string.Empty : ex.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (ex.InnerException == null) ? string.Empty : "Message: " + ex.InnerException.Message,
                        (ex.InnerException == null) ? string.Empty : "StackTrace: " + ex.InnerException.StackTrace)
                });
            }
            return objResponse;
        }
    }
    public class ocp_an_bcp__request
    {
        public string idcNumero { get; set; }
        public string idcTipo { get; set; }
        public string idcExtension { get; set; }
        public string idcComplemento { get; set; }
        public string matricula { get; set; }
    }
    public class ocp_an_bcp__response
    {
        public ocp_an_bcp__response__data data { get; set; }
        public List<ocp_an_bcp__response__detalle> detalle { get; set; }
        public ocp_an_bcp__response()
        {
            this.data = new ocp_an_bcp__response__data();
            this.detalle = new List<ocp_an_bcp__response__detalle>();
        }
    }
    public class ocp_an_bcp__response__data
    {
        public bool encontrado { get; set; }
        public string detalle { get; set; }
        public ocp_an_bcp__response__data()
        {
            this.encontrado = false;
            this.detalle = string.Empty;
        }
    }
    public class ocp_an_bcp__response__detalle
    {
        public string motivo { get; set; }
        public string causal { get; set; }
        public DateTime fechaCarga { get; set; }
    }
}