﻿using System.Collections.Generic;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_reportes
    {
        public string IdDocumento { get; set; }
        public string Descripcion { get; set; }
        public string Tipo { get; set; }        
        public List<ocp_reportes__paramtetro> ListaParametros { get; set; }
    }
    public class ocp_reportes__paramtetro
    {
        public string Nombre { get; set; }
        public string Tipo { get; set; }
        public string Control { get; set; }
        public List<ocp_reportes__paramtetro__valor> ListaValores { get; set; }
    }
    public class ocp_reportes__paramtetro__valor
    {
        public string Valor { get; set; }
        public string Descripcion { get; set; }
    }
}