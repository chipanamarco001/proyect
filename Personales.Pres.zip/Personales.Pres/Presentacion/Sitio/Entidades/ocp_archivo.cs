﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_archivo
    {
        public string ContentType { get; set; }
        public string Extension { get; set; }
        public string Nombre { get; set; }
        public Stream FileStream { get; set; }
        public byte[] ByteArray { get; set; }
    }
}