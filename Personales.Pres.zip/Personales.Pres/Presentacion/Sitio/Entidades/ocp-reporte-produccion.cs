﻿using Agente.ServicioCrediseguro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.Sitio.Entidades
{
    public class ocp_reporte_produccion
    {
        public string Mes { get; set; }
        public decimal Anterior { get; set; }
        public decimal Actual { get; set; }
        public decimal Presupuesto { get; set; }
    }
    public class ocp_presupuesto
    {
        public string Tipo { get; set; }
        public string Producto { get; set; }
        public string Mes { get; set; }        
        public decimal Importe { get; set; }
    }
    public class ocp_base_reporte_produccion
    {
        public List<ocp_presupuesto> ListaPresupuesto { get; set; }
        public List<SPR_CORE_REPORTE_PRODUCCION_Result> ListaProduccionAnterior { get; set; }
        public List<SPR_CORE_REPORTE_PRODUCCION_Result> ListaProduccionActual { get; set; }
        public List<ocp_reporte_produccion> ListaReporteTotales { get; set; }
        public List<ocp_reporte_produccion> ListaReporteBancaSeguros { get; set; }
        public List<ocp_reporte_produccion> ListaReporteDesgravamen { get; set; }
        public List<ocp_reporte_produccion> ListaReporteGrupales { get; set; }
        public List<ocp_reporte_produccion> ListaReporteIndividuales { get; set; }
        public void GeneraBaseReporteProduccion()
        {
            this.ListaReporteTotales = DatosTotalesReporte(this.ListaPresupuesto, this.ListaProduccionAnterior, this.ListaProduccionActual);
            this.ListaReporteBancaSeguros = DatosTotalesReporte(
                this.ListaPresupuesto.Where(w => w.Tipo == "BANCA SEGUROS").ToList(),
                this.ListaProduccionAnterior.Where(w => w.LINEA_NEGOCIO == "BANCA SEGUROS").ToList(),
                this.ListaProduccionActual.Where(w => w.LINEA_NEGOCIO == "BANCA SEGUROS").ToList());
            this.ListaReporteDesgravamen = DatosTotalesReporte(
                this.ListaPresupuesto.Where(w => w.Tipo == "DESGRAVAMEN").ToList(),
                this.ListaProduccionAnterior.Where(w => w.LINEA_NEGOCIO == "DESGRAVAMEN").ToList(),
                this.ListaProduccionActual.Where(w => w.LINEA_NEGOCIO == "DESGRAVAMEN").ToList());
            this.ListaReporteGrupales = DatosTotalesReporte(
                this.ListaPresupuesto.Where(w => w.Tipo == "GRUPALES").ToList(),
                this.ListaProduccionAnterior.Where(w => w.LINEA_NEGOCIO == "GRUPALES").ToList(),
                this.ListaProduccionActual.Where(w => w.LINEA_NEGOCIO == "GRUPALES").ToList());
            this.ListaReporteIndividuales = DatosTotalesReporte(
                this.ListaPresupuesto.Where(w => w.Tipo == "INDIVIDUALES").ToList(),
                this.ListaProduccionAnterior.Where(w => w.LINEA_NEGOCIO == "INDIVIDUALES").ToList(),
                this.ListaProduccionActual.Where(w => w.LINEA_NEGOCIO == "INDIVIDUALES").ToList());
        }
        protected List<ocp_reporte_produccion> DatosTotalesReporte(List<ocp_presupuesto> listaPresupuesto, List<SPR_CORE_REPORTE_PRODUCCION_Result> listaAnterior, List<SPR_CORE_REPORTE_PRODUCCION_Result> listaActual)
        {
            try
            {
                var listaReporte = new List<ocp_reporte_produccion>();
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Enero", Anterior = listaAnterior.Sum(s => s.ENERO) ?? 0, Actual = listaActual.Sum(s => s.ENERO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "ENERO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Febrero", Anterior = listaAnterior.Sum(s => s.FEBRERO) ?? 0, Actual = listaActual.Sum(s => s.FEBRERO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "FEBRERO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Marzo", Anterior = listaAnterior.Sum(s => s.MARZO) ?? 0, Actual = listaActual.Sum(s => s.MARZO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "MARZO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Abril", Anterior = listaAnterior.Sum(s => s.ABRIL) ?? 0, Actual = listaActual.Sum(s => s.ABRIL) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "ABRIL").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Mayo", Anterior = listaAnterior.Sum(s => s.MAYO) ?? 0, Actual = listaActual.Sum(s => s.MAYO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "MAYO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Junio", Anterior = listaAnterior.Sum(s => s.JUNIO) ?? 0, Actual = listaActual.Sum(s => s.JUNIO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "JUNIO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Julio", Anterior = listaAnterior.Sum(s => s.JULIO) ?? 0, Actual = listaActual.Sum(s => s.JULIO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "JULIO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Agosto", Anterior = listaAnterior.Sum(s => s.AGOSTO) ?? 0, Actual = listaActual.Sum(s => s.AGOSTO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "AGOSTO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Septiembre", Anterior = listaAnterior.Sum(s => s.SEPTIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.SEPTIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "SEPTIEMBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Octubre", Anterior = listaAnterior.Sum(s => s.OCTUBRE) ?? 0, Actual = listaActual.Sum(s => s.OCTUBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "OCTUBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Noviembre", Anterior = listaAnterior.Sum(s => s.NOVIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.NOVIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "NOVIEMBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Diciembre", Anterior = listaAnterior.Sum(s => s.DICIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.DICIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "DICIEMBRE").Sum(s => s.Importe) });
                return listaReporte;
            }
            catch
            {
                throw;
            }
        }
        public List<ocp_reporte_produccion> DatosProductoReporte(string strIdProducto)
        {
            try
            {
                List<ocp_presupuesto> listaPresupuesto = this.ListaPresupuesto.Where(w => w.Producto == strIdProducto).ToList();
                List<SPR_CORE_REPORTE_PRODUCCION_Result> listaAnterior = this.ListaProduccionAnterior.Where(w => w.ID_PRODUCTO == strIdProducto).ToList();
                List<SPR_CORE_REPORTE_PRODUCCION_Result> listaActual = this.ListaProduccionActual.Where(w => w.ID_PRODUCTO == strIdProducto).ToList();
                var listaReporte = new List<ocp_reporte_produccion>();
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Enero", Anterior = listaAnterior.Sum(s => s.ENERO) ?? 0, Actual = listaActual.Sum(s => s.ENERO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "ENERO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Febrero", Anterior = listaAnterior.Sum(s => s.FEBRERO) ?? 0, Actual = listaActual.Sum(s => s.FEBRERO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "FEBRERO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Marzo", Anterior = listaAnterior.Sum(s => s.MARZO) ?? 0, Actual = listaActual.Sum(s => s.MARZO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "MARZO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Abril", Anterior = listaAnterior.Sum(s => s.ABRIL) ?? 0, Actual = listaActual.Sum(s => s.ABRIL) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "ABRIL").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Mayo", Anterior = listaAnterior.Sum(s => s.MAYO) ?? 0, Actual = listaActual.Sum(s => s.MAYO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "MAYO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Junio", Anterior = listaAnterior.Sum(s => s.JUNIO) ?? 0, Actual = listaActual.Sum(s => s.JUNIO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "JUNIO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Julio", Anterior = listaAnterior.Sum(s => s.JULIO) ?? 0, Actual = listaActual.Sum(s => s.JULIO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "JULIO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Agosto", Anterior = listaAnterior.Sum(s => s.AGOSTO) ?? 0, Actual = listaActual.Sum(s => s.AGOSTO) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "AGOSTO").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Septiembre", Anterior = listaAnterior.Sum(s => s.SEPTIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.SEPTIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "SEPTIEMBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Octubre", Anterior = listaAnterior.Sum(s => s.OCTUBRE) ?? 0, Actual = listaActual.Sum(s => s.OCTUBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "OCTUBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Noviembre", Anterior = listaAnterior.Sum(s => s.NOVIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.NOVIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "NOVIEMBRE").Sum(s => s.Importe) });
                listaReporte.Add(new ocp_reporte_produccion() { Mes = "Diciembre", Anterior = listaAnterior.Sum(s => s.DICIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.DICIEMBRE) ?? 0, Presupuesto = listaPresupuesto.Where(w => w.Mes == "DICIEMBRE").Sum(s => s.Importe) });
                return listaReporte;
            }
            catch
            {
                throw;
            }
        }
    }
}