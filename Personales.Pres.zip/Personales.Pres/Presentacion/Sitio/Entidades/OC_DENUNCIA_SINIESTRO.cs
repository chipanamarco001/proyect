﻿namespace Presentacion.Sitio.Entidades
{
    public class OC_DENUNCIA_SINIESTRO
    {
        public long NUMERO_DENUNCIA { get; set; }
        public string ASEGURADO { get; set; }
        public string CODIGO_PRODUCTO { get; set; }
        public string PRODUCTO { get; set; }
        public string TOMADOR { get; set; }
        public string CODIGO_BROKER { get; set; }
        public string BROKER { get; set; }
        public string CIUDAD_SINIESTRO { get; set; }
        public string CODIGO_CIUDAD_SINIESTRO { get; set; }
        public string FECHA_OCURRENCIA { get; set; }
        public string DESCRIPCION { get; set; }
    }
    public class OC_DENUNCIA_DOCUMENTO
    {
        public long ID_DENUNCIA_FORMULARIO { get; set; }
        public long ID_DENUNCIA_DOCUMENTO { get; set; }
        public string NOMBRE_ARCHIVO { get; set; }
        public string RUTA_ARCHIVO { get; set; }
        public string CONTENT_TYPE { get; set; }
    }
}