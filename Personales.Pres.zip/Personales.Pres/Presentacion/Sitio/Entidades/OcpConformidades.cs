﻿using System;

namespace Presentacion.Sitio.Entidades
{
    public class OcpConformidades
    {
        public string DescripcionNivel { get; set; }
        public string DescripcionConformidad { get; set; }
        public string Estado { get; set; }
        public string Usuario { get; set; }
        public string Fecha { get; set; }
        public int NumeroNivel { get; set; }
        public string IdNivel { get; set; }
        public string IdGrupo { get; set; }
        public string FechaInicio { get; set; }
    }
}