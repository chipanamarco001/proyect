﻿using Agente.ServicioArchivoNegativo;
using Agente.ServicioPersonales;
using Agente.ServicioProduccion;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Entidades.archivo_negativo;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class archivo_negativo : ControlUsuario
    {
        private readonly CArchivoNegativo _cArchivoNegativo = new CArchivoNegativo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session["archivo_negativo__listaUsuario"] = _cArchivoNegativo.ArchivoNegativo_ListaUsuario();
                GrvRegistrosUsuario.DataBind();
                ///
                var listaLexicos = _cArchivoNegativo.Lexico_ObtenerLista();
                Session["archivo_negativo__listaLexico"] = listaLexicos;
                EvaluarAutorizador();
            }
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
        }
        protected void EvaluarAutorizador()
        {
            try
            {
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
                var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                var boolAutorizador = listaLexicos.Exists(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "CORREO" && w.LESVC_DESCRIPCION_1.ToUpper().Contains(_objUsuario.Correo.ToUpper()));
                BpcArchivoNegativo.TabPages.FindByName("TabAutorizacion").Visible = boolAutorizador;
                if (boolAutorizador)
                {
                    Session["archivo_negativo__listaAutorizacion"] = _cArchivoNegativo.ArchivoNegativo_ListaAutorizacion(_objUsuario.Correo);
                    GrvAutoizacion.DataBind();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            try
            {
                txtCi.Text = string.Empty;
                txtPaterno.Text = string.Empty;
                txtMaterno.Text = string.Empty;
                txtNombre.Text = string.Empty;
                Session["archivo_negativo__listaRegistrosEncontrados"] = new List<ARCHIVO_NEGATIVO>();
                GrvRegistrosEnconrados.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        } 
        #region REGISTROS ACTIVOS
        protected void BtnBuscarRegistroActivo_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtCi.Text) && string.IsNullOrEmpty(txtPaterno.Text) && string.IsNullOrEmpty(txtMaterno.Text) && string.IsNullOrEmpty(txtNombre.Text))
                {
                    Master.MostrarToastr("error", "VALIDACIÓN", "Debe ingresar al menos el Nro. Documento para realizar la busqueda.");
                }
                else
                {
                    var listaRegistrosEncontrados = _cArchivoNegativo.ArchivoNegativo_ListaActiva(
                        txtCi.Text.Trim().ToUpper(),
                        txtPaterno.Text.Trim().ToUpper(),
                        txtMaterno.Text.Trim().ToUpper(),
                        txtNombre.Text.Trim().ToUpper());
                    Session["archivo_negativo__listaRegistrosEncontrados"] = listaRegistrosEncontrados;
                    if (listaRegistrosEncontrados.Count == 0)
                    {
                        Master.MostrarToastr("warning", "BUSQUEDA COMPLETADA", "No se encontró coincidencias con los parámetros indicados.");
                    }
                    GrvRegistrosEnconrados.DataBind();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvRegistrosEnconrados_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["archivo_negativo__listaRegistrosEncontrados"] == null)
                {
                    Session["archivo_negativo__listaRegistrosEncontrados"] = new List<ARCHIVO_NEGATIVO>();
                }
                var listaRegistrosEncontrados = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaRegistrosEncontrados"];
                GrvRegistrosEnconrados.DataSource = listaRegistrosEncontrados.OrderByDescending(o => o.ARSDT_FECHA_INSERT);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistroActivo_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidRegistroActivo.Contains("IdArchivoNegativo") && HidRegistroActivo.Contains("Tipo"))
                {
                    long longIdArchivoNegativo = Convert.ToInt64(HidRegistroActivo.Get("IdArchivoNegativo"));
                    string strTipo = HidRegistroActivo.Get("Tipo").ToString();
                    switch (strTipo)
                    {
                        case "Historial":
                            var listaRegistrosEncontrados = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaRegistrosEncontrados"];
                            string strDocumentoNumero = listaRegistrosEncontrados.Find(f => f.ARPIN_ID_ARCHIVO_NEGATIVO == longIdArchivoNegativo).ARSVC_NUMERO_IDC.Trim().ToUpper();
                            var listaHistorica = _cArchivoNegativo.ArchivoNegativo_ListaHistorico(strDocumentoNumero);
                            GrvHistorico.DataSource = listaHistorica.OrderByDescending(d => d.ARSDT_FECHA_INSERT);
                            GrvHistorico.DataBind();
                            PopHistorico.ShowOnPageLoad = true;
                            break;
                        case "Quitar":
                            if (Session["archivo_negativo__listaLexico"] == null)
                            {
                                Session["archivo_negativo__listaLexico"] = _cArchivoNegativo.Lexico_ObtenerLista();
                            }
                            var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                            CmbQuitarUnidadRegistro.Items.Clear();
                            CmbQuitarUnidadRegistro.DataSource = listaLexicos.Where(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "UNIDAD").ToList();
                            CmbQuitarUnidadRegistro.ValueField = "LEPVC_VALOR";
                            CmbQuitarUnidadRegistro.TextField = "LESVC_DESCRIPCION_1";
                            CmbQuitarUnidadRegistro.DataBind();
                            CmbQuitarUnidadRegistro.Value = null;
                            TxtQuitarMotivo.Value = null;
                            PopQuitarArchivoNegativo.ShowOnPageLoad = true;
                            break;
                    }
                }
                else
                {
                    throw new Exception("No puede ejecutarse esta acción.");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnQuitarRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidRegistroActivo.Contains("IdArchivoNegativo"))
                {
                    long longIdArchivoNegativo = Convert.ToInt64(HidRegistroActivo.Get("IdArchivoNegativo"));
                    var listaRegistrosEncontrados = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaRegistrosEncontrados"];
                    var objArchivoNegativo = listaRegistrosEncontrados.Find(f => f.ARPIN_ID_ARCHIVO_NEGATIVO == longIdArchivoNegativo);
                    var objEstadoHistorico = new ESTADO_HISTORICO
                    {
                        ARPIN_ID_ARCHIVO_NEGATIVO = longIdArchivoNegativo,
                        LEPVC_ID_UNIDAD_REGISTRO = CmbQuitarUnidadRegistro.SelectedItem.Value.ToString(),
                        ESPVC_ESTADO = "RETIRO",
                        ESSVC_COMENTARIO = TxtQuitarMotivo.Text.Trim().ToUpper()
                    };
                    var objEstadoHistoricoResult = _cArchivoNegativo.EstadoHistorico_Agregar(objEstadoHistorico);
                    if (objEstadoHistoricoResult != null)
                    {
                        PopQuitarArchivoNegativo.ShowOnPageLoad = false;
                        Session["archivo_negativo__listaUsuario"] = _cArchivoNegativo.ArchivoNegativo_ListaUsuario();
                        GrvRegistrosUsuario.DataBind();
                        EvaluarAutorizador();
                        Master.MostrarToastr("success", "ARCHIVO NEGATIVO", "Se ha completado el proceso de registro, ahora la solicitud se encuentra pendiente de autorización.");
                        /// envio de correo al autorizador
                        var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                        var objLexicoDestinatario = listaLexicos.Where(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "CORREO" && w.LEPVC_VALOR == CmbQuitarUnidadRegistro.SelectedItem.Value.ToString()).FirstOrDefault();
                        CProduccion _cProduccion = new CProduccion();
                        string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ARCHIVO_NEGATIVO.html"));
                        strHtml = strHtml.Replace("#UNIDAD#", CmbQuitarUnidadRegistro.SelectedItem.Text.ToString());
                        strHtml = strHtml.Replace("#TIPO_REGISTRO#", objArchivoNegativo.ARSVC_DESCRIPCION);strHtml = strHtml.Replace("#TIPO_SOLICITUD#", "RETIRO");
                        strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                        strHtml = strHtml.Replace("#CLIENTE#", objArchivoNegativo.ARPVC_NOMBRE);
                        strHtml = strHtml.Replace("#MOTIVO#", TxtQuitarMotivo.Text.Trim().ToUpper());
                        _cProduccion.Correo_Enviar(new Agente.ServicioProduccion.occ_correo
                        {
                            ListaCorreoDestinatario = (objLexicoDestinatario != null) ? objLexicoDestinatario.LESVC_DESCRIPCION_1.Split(';').ToList() : new List<string>() { _objUsuario.Correo },
                            ListaCorreoCopia = new List<string>() { _objUsuario.Correo },
                            Sistema = "CORE PERSONALES",
                            Asunto = "ARCHIVO NEGATIVO | REGISTRO NRO. " + longIdArchivoNegativo + " COMPLETADO (RETIRO)",
                            Prioridad = System.Net.Mail.MailPriority.High,
                            Contenido = strHtml,
                            FlagHtml = true,
                            ListaImagenes = new List<occ_correo__imagen>() { new occ_correo__imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } },
                            ListaArchivosAdjuntos = new List<occ_correo__archivo_adjunto>()
                        });
                        /// limpiamos la bandeja de busqueda
                        btnLimpiar_Click(null, null);
                    }
                    else
                    {
                        Master.MostrarToastr("error", "VALIDACIÓN", "Ha ocurrido un error al intentar registrar los datos ingresados");
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        #endregion
        protected void GrvRegistrosUsuario_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaUsuario = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaUsuario"];
                GrvRegistrosUsuario.DataSource = listaUsuario.OrderByDescending(o => o.ARSDT_FECHA_INSERT);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAutoizacion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaAutorizacion = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaAutorizacion"];
                GrvAutoizacion.DataSource = listaAutorizacion.OrderBy(o => o.ARSDT_FECHA_INSERT);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["archivo_negativo__listaLexico"] == null)
                {
                    Session["archivo_negativo__listaLexico"] = _cArchivoNegativo.Lexico_ObtenerLista();
                }
                var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                CmbAgregarUnidadRegistro.Items.Clear();
                CmbAgregarUnidadRegistro.DataSource = listaLexicos.Where(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "UNIDAD").ToList();
                CmbAgregarUnidadRegistro.ValueField = "LEPVC_VALOR";
                CmbAgregarUnidadRegistro.TextField = "LESVC_DESCRIPCION_1";
                CmbAgregarUnidadRegistro.DataBind();
                CmbAgregarUnidadRegistro.Value = null;
                CmbAgregarTipoRegistro.Items.Clear();
                CmbAgregarTipoRegistro.Value = null;
                TxtAgregarDocumentoNumero.Value = null;
                TxtAgregarDocumentoComplemento.Value = null;
                CmbAgregarTipoCliente.Value = null;
                TxtAgregarPaterno.Value = null;
                TxtAgregarMaterno.Value = null;
                TxtAgregarNombres.Value = null;
                TxtAgregarMotivo.Value = null;
                PopAgregar.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CmbAgregarUnidadRegistro_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var strIdUnidadRegistro = (CmbAgregarUnidadRegistro.SelectedItem != null) ? CmbAgregarUnidadRegistro.SelectedItem.Value.ToString() : string.Empty;
                var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                var listaTipoRegistro = listaLexicos.Where(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "TIPO" && w.LESVC_DESCRIPCION_2 == strIdUnidadRegistro).ToList();
                CmbAgregarTipoRegistro.Items.Clear();
                CmbAgregarTipoRegistro.DataSource = listaTipoRegistro;
                CmbAgregarTipoRegistro.ValueField = "LEPVC_VALOR";
                CmbAgregarTipoRegistro.TextField = "LESVC_DESCRIPCION_1";
                CmbAgregarTipoRegistro.ValueType = typeof(string);
                CmbAgregarTipoRegistro.DataBind();
                CmbAgregarTipoRegistro.Value = null;
                CmbAgregarTipoRegistro.Focus();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAgregarRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                if (!_cArchivoNegativo.ArchivoNegativo_Validar(TxtAgregarDocumentoNumero.Text.Trim(), TxtAgregarDocumentoComplemento.Text.Trim().ToUpper()))
                {
                    var objArchivoNegativo = new ARCHIVO_NEGATIVO {
                        ARSVC_IDCLIENTE = TxtAgregarDocumentoNumero.Text.Trim() + TxtAgregarDocumentoComplemento.Text.Trim().ToUpper(),
                        ARSVC_NUMERO_IDC = TxtAgregarDocumentoNumero.Text.Trim(),
                        ARSVC_EXTENSION_IDC = TxtAgregarDocumentoComplemento.Text.Trim().ToUpper(),
                        ARSVC_TIPO = CmbAgregarTipoRegistro.SelectedItem.Value.ToString(),
                        ARSVC_DESCRIPCION = CmbAgregarTipoRegistro.SelectedItem.Text.ToString(),
                        ARSVC_MOTIVO = TxtAgregarMotivo.Text.Trim().ToUpper(),
                        ARSVC_FECHINI = DateTime.Now.ToString("yyyyMMdd"),
                        ARSVC_FECHFIN = "99991231",
                        ARSVC_ESTADO = "P",
                        ARSVC_DESC_ESTADO = "PENDIENTE",
                        ARSVC_FECHA_ESTADO = DateTime.Now.ToString("yyyyMMdd"),
                        ARPVC_PATERNO = TxtAgregarPaterno.Text.Trim().ToUpper(),
                        ARPVC_MATERNO = TxtAgregarMaterno.Text.Trim().ToUpper(),
                        ARPVC_NOMBRE = TxtAgregarNombres.Text.Trim().ToUpper(),
                        ARPVC_ID_POLIZA = string.Empty,
                        ARPVC_ID_PRODUCTO = string.Empty,
                        ARPVC_PRODUCTO = string.Empty,
                        ARPVC_ID_COBERTURA = string.Empty,
                        ARPVC_COBERTURA = string.Empty,
                        ARPVC_ENTIDAD = string.Empty,
                        ARPBT_NO_CLIENTE = (CmbAgregarTipoCliente.SelectedItem.Value.ToString() == "0") ? false : true,
                        ARPVC_TIPO_CARGA = "INDIVIDUAL",
                        ARPVC_CLIENTE =
                            TxtAgregarPaterno.Text.Trim().ToUpper() + ((TxtAgregarPaterno.Text.Trim() != string.Empty) ? " " : string.Empty) +
                            TxtAgregarMaterno.Text.Trim().ToUpper() + ((TxtAgregarMaterno.Text.Trim() != string.Empty) ? " " : string.Empty) +
                            TxtAgregarNombres.Text.Trim().ToUpper()
                    };
                    var objArchivoNegativoResult = _cArchivoNegativo.ArchivoNegativo_Agregar(objArchivoNegativo);
                    if (objArchivoNegativoResult != null)
                    {
                        var objEstadoHistorico = new ESTADO_HISTORICO {
                            ARPIN_ID_ARCHIVO_NEGATIVO = objArchivoNegativoResult.ARPIN_ID_ARCHIVO_NEGATIVO,
                            LEPVC_ID_UNIDAD_REGISTRO = CmbAgregarUnidadRegistro.SelectedItem.Value.ToString(),
                            ESPVC_ESTADO = "PENDIENTE",
                            ESSVC_COMENTARIO = string.Empty
                        };
                        var objEstadoHistoricoResult = _cArchivoNegativo.EstadoHistorico_Agregar(objEstadoHistorico);
                        if (objEstadoHistoricoResult != null)
                        {
                            PopAgregar.ShowOnPageLoad = false;
                            Session["archivo_negativo__listaUsuario"] = _cArchivoNegativo.ArchivoNegativo_ListaUsuario();
                            GrvRegistrosUsuario.DataBind();
                            EvaluarAutorizador();
                            Master.MostrarToastr("success", "VALIDACIÓN", "Se ha completado el proceso de registro, ahora la solicitud se encuentra pendiente de autorización.");
                            var listaLexicos = (List<Agente.ServicioArchivoNegativo.LEXICO>)Session["archivo_negativo__listaLexico"];
                            var objLexicoDestinatario = listaLexicos.Where(w => w.LEPVC_TABLA == "ARCHIVO NEGATIVO" && w.LESVC_TEMA == "CORREO" && w.LEPVC_VALOR == CmbAgregarUnidadRegistro.SelectedItem.Value.ToString()).FirstOrDefault();
                            CProduccion _cProduccion = new CProduccion();
                            string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ARCHIVO_NEGATIVO.html"));
                            strHtml = strHtml.Replace("#UNIDAD#", CmbAgregarUnidadRegistro.SelectedItem.Text.ToString());
                            strHtml = strHtml.Replace("#TIPO_REGISTRO#", CmbAgregarTipoRegistro.SelectedItem.Text.ToString());
                            strHtml = strHtml.Replace("#TIPO_SOLICITUD#", "REGISTRO");
                            strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                            strHtml = strHtml.Replace("#CLIENTE#", TxtAgregarPaterno.Text.Trim().ToUpper() + ((TxtAgregarPaterno.Text.Trim() != string.Empty) ? " " : string.Empty) +
                            TxtAgregarMaterno.Text.Trim().ToUpper() + ((TxtAgregarMaterno.Text.Trim() != string.Empty) ? " " : string.Empty) +
                            TxtAgregarNombres.Text.Trim().ToUpper());
                            strHtml = strHtml.Replace("#MOTIVO#", TxtAgregarMotivo.Text.Trim().ToUpper());
                            _cProduccion.Correo_Enviar(new Agente.ServicioProduccion.occ_correo {
                                ListaCorreoDestinatario = (objLexicoDestinatario != null) ? objLexicoDestinatario .LESVC_DESCRIPCION_1.Split(';').ToList() : new List<string>() { _objUsuario.Correo },
                                ListaCorreoCopia = new List<string>() { _objUsuario.Correo },
                                Sistema = "CORE PERSONALES",
                                Asunto = "ARCHIVO NEGATIVO | REGISTRO NRO. " + objArchivoNegativoResult.ARPIN_ID_ARCHIVO_NEGATIVO + " COMPLETADO",
                                Prioridad = System.Net.Mail.MailPriority.High,
                                Contenido = strHtml,
                                FlagHtml = true,
                                ListaImagenes = new List<occ_correo__imagen>() { new occ_correo__imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } },
                                ListaArchivosAdjuntos = new List<occ_correo__archivo_adjunto>()
                            });
                        }
                        else
                        {
                            Master.MostrarToastr("error", "VALIDACIÓN", "Ha ocurrido un error al intentar registrar los datos ingresados");
                        }
                    }
                    else
                    {
                        Master.MostrarToastr("error", "VALIDACIÓN", "Ha ocurrido un error al intentar registrar los datos ingresados");
                    }
                }
                else
                {
                    Master.MostrarToastr("error", "VALIDACIÓN", "El documento de identidad ingresado ya existe en la base de Archivo Negativo (con estado activo o pendiente).");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnseleccionaAutorizacion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAutorizacion.Contains("IdArchivoNegativo") && HidAutorizacion.Contains("Tipo"))
                {
                    long longIdArchivoNegativo = Convert.ToInt64(HidAutorizacion.Get("IdArchivoNegativo"));
                    string strTipo = HidAutorizacion.Get("Tipo").ToString();
                    var listaAutorizacion = (List<ARCHIVO_NEGATIVO>)Session["archivo_negativo__listaAutorizacion"];
                    var objArchivoNegativo = listaAutorizacion.Find(f => f.ARPIN_ID_ARCHIVO_NEGATIVO == longIdArchivoNegativo);
                    var objEstadoHistorico = new ESTADO_HISTORICO
                    {
                        ARPIN_ID_ARCHIVO_NEGATIVO = longIdArchivoNegativo,
                        LEPVC_ID_UNIDAD_REGISTRO = string.Empty,
                        ESSVC_COMENTARIO = string.Empty
                    };
                    switch (strTipo)
                    {
                        case "Autorizar":
                            objEstadoHistorico.ESPVC_ESTADO = (objArchivoNegativo.ARSVC_TIPO == "REGISTRO") ? "ACTIVO" : "INACTIVO";
                            break;
                        case "Rechazar":
                            objEstadoHistorico.ESPVC_ESTADO = "RECHAZADO";
                            break;
                    }
                    var objEstadoHistoricoResult = _cArchivoNegativo.EstadoHistorico_Agregar(objEstadoHistorico);
                    EvaluarAutorizador();
                    Session["archivo_negativo__listaUsuario"] = _cArchivoNegativo.ArchivoNegativo_ListaUsuario();
                    GrvRegistrosUsuario.DataBind();
                    Master.MostrarToastr("success", "ARCHIVO NEGATIVO", "El proceso de autorización ha sido completado con éxito!");
                }
                else
                {
                    throw new Exception("No puede ejecutarse esta acción.");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}