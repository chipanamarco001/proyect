﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using System;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class administrar_coberturas : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
                GrvCoberturas.DataBind();
        }
        protected void GrvCoberturas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                GrvCoberturas.DataSource = _cPersonales.GetListLexicoPorTablaYTema("PARAMETRO", "COBERTURA").OrderBy(o => o.LEPVC_DESC_LARGA);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strCodigoCobertura = TxtCodigoCobertura.Text.Trim().ToUpper();
                var listaCoberturas = _cPersonales.GetListLexicoPorTablaYTema("PARAMETRO", "COBERTURA");
                if (listaCoberturas.Exists(f => f.LEPVC_VALOR == strCodigoCobertura))
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('El código de cobertura ingresado ya se encuentra registrado en el CORE de Producción.', 'ERROR', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                else {
                    var objLexico = new LEXICO() {
                        LEPVC_TABLA = "PARAMETRO",
                        LEPVC_TEMA = "COBERTURA",
                        LEPVC_VALOR = strCodigoCobertura,
                        LEPVC_DESC_CORTA = string.Empty,
                        LEPVC_DESC_LARGA = TxtDescripcionCobertura.Text.Trim().ToUpper()
                    };
                    var result = _cPersonales.Lexico_Registrar(objLexico);
                    if (result != null)
                    {
                        PopRegistro.ShowOnPageLoad = false;
                        GrvCoberturas.DataBind();
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El registro de la cobertura ha sido completado con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                    else
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se ha presentado un error al momento de registrar la cobertura.', 'ERROR', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAgregarCobertura_Click(object sender, EventArgs e)
        {
            try
            {
                TxtCodigoCobertura.Text = null;
                TxtDescripcionCobertura.Text = null;
                PopRegistro.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvCoberturas_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            try
            { 
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                string strCodigoCobertura = e.Keys[GrvCoberturas.KeyFieldName].ToString();
                string strDescripcionCobertura = e.NewValues["LEPVC_DESC_LARGA"].ToString().Trim().ToUpper();
                var listaCoberturas = _cPersonales.GetListLexicoPorTablaYTema("PARAMETRO", "COBERTURA");
                var objLexico = listaCoberturas.Where(w => w.LEPVC_VALOR == strCodigoCobertura).First();
                objLexico.LEPVC_DESC_LARGA = strDescripcionCobertura;
                if (_cPersonales.Lexico_Actualizar(objLexico))
                {
                    GrvCoberturas.DataBind();
                    CurrentGrid.CancelEdit();
                    e.Cancel = true;
                }
                else
                    e.Cancel = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}