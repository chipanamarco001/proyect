﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Web;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Produccion
{
    public partial class FormularioPCC04 : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                var DsetFormularios = _cPersonales.FormulariosPCC04PorPeriodo((string)Session["PERIODO_CONTABLE"]);
                var listaLexico = _cPersonales.GetListLexicoPorTabla("CATALOGO_UIF").Where(w => w.LEPBT_ACTIVO == true).ToList();
                Session["FormularioPCC04_Datos"] = DsetFormularios;
                Session["FormularioPCC04_Lexicos"] = listaLexico;
                GrvFormularios.DataBind();
                PopFormulario.ShowOnPageLoad = false;
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void CargarCombos()
        {
            try
            {
                if (Session["FormularioPCC04_Lexicos"] != null)
                {                
                    var listaLexico = (List<LEXICO>)Session["FormularioPCC04_Lexicos"];
                    CmbTipoPersona.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_TIPO_PERSONA").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbTipoPersona.TextField = "LEPVC_DESC_LARGA";
                    CmbTipoPersona.ValueField = "LEPVC_VALOR";
                    CmbTipoPersona.DataBind();

                    CmbPNTipoDocumento.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "PN_CLAVE_TIPO_DOCUMENTO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPNTipoDocumento.TextField = "LEPVC_DESC_LARGA";
                    CmbPNTipoDocumento.ValueField = "LEPVC_VALOR";
                    CmbPNTipoDocumento.DataBind();

                    CmbPNDocumentoExtension.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_DEPARTAMENTO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPNDocumentoExtension.TextField = "LEPVC_DESC_LARGA";
                    CmbPNDocumentoExtension.ValueField = "LEPVC_VALOR";
                    CmbPNDocumentoExtension.DataBind();

                    CmbCiudad.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_DEPARTAMENTO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbCiudad.TextField = "LEPVC_DESC_LARGA";
                    CmbCiudad.ValueField = "LEPVC_VALOR";
                    CmbCiudad.DataBind();

                    CmbTipoOperacion.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_OPERACION_UNICA").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbTipoOperacion.TextField = "LEPVC_DESC_LARGA";
                    CmbTipoOperacion.ValueField = "LEPVC_VALOR";
                    CmbTipoOperacion.DataBind();

                    CmbNaturalezaOperacion.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_OPERACION_PCC04").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbNaturalezaOperacion.TextField = "LEPVC_DESC_LARGA";
                    CmbNaturalezaOperacion.ValueField = "LEPVC_VALOR";
                    CmbNaturalezaOperacion.DataBind();

                    CmbTipoSeguro.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_SEGUROS_PCC04").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbTipoSeguro.TextField = "LEPVC_DESC_LARGA";
                    CmbTipoSeguro.ValueField = "LEPVC_VALOR";
                    CmbTipoSeguro.DataBind();

                    CmbPlazoSeguro.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_CORTO_PLAZO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPlazoSeguro.TextField = "LEPVC_DESC_LARGA";
                    CmbPlazoSeguro.ValueField = "LEPVC_VALOR";
                    CmbPlazoSeguro.DataBind();

                    CmbRamoSeguro.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_RAMOS_PCC04").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbRamoSeguro.TextField = "LEPVC_DESC_LARGA";
                    CmbRamoSeguro.ValueField = "LEPVC_VALOR";
                    CmbRamoSeguro.DataBind();

                    CmbMoneda.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_MONEDA").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbMoneda.TextField = "LEPVC_DESC_LARGA";
                    CmbMoneda.ValueField = "LEPVC_VALOR";
                    CmbMoneda.DataBind();

                    CmbSujetoObligado.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "SUJETO_OBLIGADO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbSujetoObligado.TextField = "LEPVC_DESC_LARGA";
                    CmbSujetoObligado.ValueField = "LEPVC_VALOR";
                    CmbSujetoObligado.DataBind();

                    CmbReposicion.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_REPOSICION").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbReposicion.TextField = "LEPVC_DESC_LARGA";
                    CmbReposicion.ValueField = "LEPVC_VALOR";
                    CmbReposicion.DataBind();

                    CmbDeclaranteExtension.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_DEPARTAMENTO").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbDeclaranteExtension.TextField = "LEPVC_DESC_LARGA";
                    CmbDeclaranteExtension.ValueField = "LEPVC_VALOR";
                    CmbDeclaranteExtension.DataBind();

                    CmbPNNacionalidad.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_PAIS").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPNNacionalidad.TextField = "LEPVC_DESC_LARGA";
                    CmbPNNacionalidad.ValueField = "LEPVC_VALOR";
                    CmbPNNacionalidad.DataBind();

                    CmbPNPaisResidencia.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CLAVE_PAIS").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPNPaisResidencia.TextField = "LEPVC_DESC_LARGA";
                    CmbPNPaisResidencia.ValueField = "LEPVC_VALOR";
                    CmbPNPaisResidencia.DataBind();

                    CmbPNProfesion.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "PN_CLAVE_PROFESION").OrderBy(o => o.LEPVC_DESC_LARGA);
                    CmbPNProfesion.TextField = "LEPVC_DESC_LARGA";
                    CmbPNProfesion.ValueField = "LEPVC_VALOR";
                    CmbPNProfesion.DataBind();
                    //CmbPNActividadEconomica.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CM_CLAVE_ACTIVIDAD_ECONOMICA").OrderBy(o => o.LEPVC_DESC_LARGA);
                    //CmbPNActividadEconomica.TextField = "LEPVC_DESC_LARGA";
                    //CmbPNActividadEconomica.ValueField = "LEPVC_VALOR";
                    //CmbPNActividadEconomica.DataBind();
                    //CmbPJActividadEconomica.DataSource = listaLexico.Where(w => w.LEPVC_TEMA == "CM_CLAVE_ACTIVIDAD_ECONOMICA").OrderBy(o => o.LEPVC_DESC_LARGA);
                    //CmbPJActividadEconomica.TextField = "LEPVC_DESC_LARGA";
                    //CmbPJActividadEconomica.ValueField = "LEPVC_VALOR";
                    //CmbPJActividadEconomica.DataBind();
                }                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                long longIdSujetoObligado = 0;
                bool boolValidaIdSujetoObligado = long.TryParse(CmbSujetoObligado.SelectedItem.Value.ToString(), out longIdSujetoObligado);
                var listaDatosCRS = _cPersonales.GetListLexicoPorTabla("FORMULARIO_PCC04").Where(w => w.LEPBT_ACTIVO == true).ToList();
                var objFormularioPCC04 = new FORMULARIO_PCC04();
                objFormularioPCC04.FOPDT_FECHA = DateTime.ParseExact(Session["FormularioPCC04_FechaLiquidacion"].ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
                objFormularioPCC04.FOPVC_CRS_FUNCIONARIO = listaDatosCRS.Where(w => w.LEPVC_TEMA == "SINIESTROS" && w.LEPVC_VALOR == "FUNCIONARIO").FirstOrDefault().LEPVC_DESC_LARGA;
                objFormularioPCC04.FOPVC_CRS_SUPERVISOR = listaDatosCRS.Where(w => w.LEPVC_TEMA == "SINIESTROS" && w.LEPVC_VALOR == "SUPERVISOR").FirstOrDefault().LEPVC_DESC_LARGA;
                objFormularioPCC04.FOPVC_CRS_CIUDAD = listaDatosCRS.Where(w => w.LEPVC_TEMA == "DIRECCION_CRS" && w.LEPVC_VALOR == "CIUDAD").FirstOrDefault().LEPVC_DESC_LARGA;
                objFormularioPCC04.FOPVC_CRS_ZONA = listaDatosCRS.Where(w => w.LEPVC_TEMA == "DIRECCION_CRS" && w.LEPVC_VALOR == "ZONA").FirstOrDefault().LEPVC_DESC_LARGA;
                objFormularioPCC04.FOPVC_CRS_DIRECCION = listaDatosCRS.Where(w => w.LEPVC_TEMA == "DIRECCION_CRS" && w.LEPVC_VALOR == "DIRECCION").FirstOrDefault().LEPVC_DESC_LARGA;
                objFormularioPCC04.FOSVC_CRS_TELEFONO = listaDatosCRS.Where(w => w.LEPVC_TEMA == "DIRECCION_CRS" && w.LEPVC_VALOR == "TELEFONO").FirstOrDefault().LEPVC_DESC_LARGA;
                //
                objFormularioPCC04.FOPVC_TIPO_PERSONA = CmbTipoPersona.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_PN_NOMBRES = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNNombres.Text.Trim().ToUpper() : null;
                objFormularioPCC04.FOPVC_PN_APELLIDO_PATERNO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNApellidoPaterno.Text.Trim().ToUpper() : null;
                objFormularioPCC04.FOSVC_PN_APELLIDO_MATERNO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNApellidoMaterno.Text.Trim()) ? null : TxtPNApellidoMaterno.Text.Trim().ToUpper()) : null;
                objFormularioPCC04.FOPVC_PN_DOCUMENTO_TIPO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNTipoDocumento.SelectedItem.Value.ToString() : null;
                objFormularioPCC04.FOPVC_PN_DOCUMENTO_NUMERO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNDocumentoNumero.Text.Trim().ToUpper() : null;
                objFormularioPCC04.FOSVC_PN_DOCUMENTO_EXTENSION = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? ((CmbPNDocumentoExtension.SelectedItem != null) ? CmbPNDocumentoExtension.SelectedItem.Value.ToString() : null) : null;
                objFormularioPCC04.FOPVC_PN_NACIONALIDAD = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNNacionalidad.SelectedItem.Value.ToString() : null;
                objFormularioPCC04.FOPVC_PN_PAIS_RESIDENCIA = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNPaisResidencia.SelectedItem.Value.ToString() : null;
                objFormularioPCC04.FOPVC_PN_PROFESION = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNProfesion.SelectedItem.Value.ToString() : null;
                objFormularioPCC04.FOPVC_ACTIVIDAD = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNActividadEconomica.Text.Trim().ToUpper() : TxtPJActividadEconomica.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_PN_LUGAR_TRABAJO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNEmpresa.Text.Trim()) ? null : TxtPNEmpresa.Text.Trim().ToUpper()) : null;
                objFormularioPCC04.FOSVC_PN_CARGO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNCargo.Text.Trim()) ? null : TxtPNCargo.Text.Trim().ToUpper()) : null;
                objFormularioPCC04.FOSVC_PN_DIRECCION_TRABAJO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNDireccionTrabajo.Text.Trim()) ? null : TxtPNDireccionTrabajo.Text.Trim().ToUpper()) : null;
                objFormularioPCC04.FOPVC_PJ_NIT = (CmbTipoPersona.SelectedItem.Value.ToString() == "J") ? TxtPJNit.Text.Trim().ToUpper() : null;
                objFormularioPCC04.FOPVC_PJ_RAZON_SOCIAL = (CmbTipoPersona.SelectedItem.Value.ToString() == "J") ? TxtPJRazonSocial.Text.Trim().ToUpper() : null;
                objFormularioPCC04.FOPVC_CIUDAD = CmbCiudad.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_ZONA = TxtZona.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_DIRECCION = TxtDireccion.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_TELEFONO = TxtTelefono.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_TIPO_OPERACION = CmbTipoOperacion.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_NATURALEZA_OPERACION = CmbNaturalezaOperacion.SelectedItem.Value.ToString();
                objFormularioPCC04.FOSVC_TIPO_SEGURO = (CmbTipoSeguro.SelectedItem == null) ? null : CmbTipoSeguro.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_CODIGO_PLAZO_SEGURO = CmbPlazoSeguro.SelectedItem.Value.ToString();
                objFormularioPCC04.FOSVC_CODIGO_RAMO = (CmbRamoSeguro.SelectedItem == null) ? null : CmbRamoSeguro.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_MONEDA = CmbMoneda.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPDC_MONTO = Convert.ToDecimal(TxtMontoOperacion.Text.Trim());
                objFormularioPCC04.FOSVC_NOMBRE_CORREDOR = string.IsNullOrEmpty(TxtNombreCorredor.Text.Trim()) ? null : TxtNombreCorredor.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_NOMBRE_INTERMEDIARIO = string.IsNullOrEmpty(TxtNombreIntermediario.Text.Trim()) ? null : TxtNombreIntermediario.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_NOMBRE_TOMADOR = TxtNombreTomador.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_NUMERO_POLIZA = TxtNumeroPoliza.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_NUMERO_CUENTA = string.IsNullOrEmpty(TxtNumeroCuenta.Text.Trim()) ? null : TxtNumeroCuenta.Text.Trim().ToUpper();
                objFormularioPCC04.FOSBI_CODIGO_ENTIDAD_FINANCIERA = (boolValidaIdSujetoObligado) ? longIdSujetoObligado : (long?)null;
                objFormularioPCC04.FOSVC_NUMERO_CHEQUE = string.IsNullOrEmpty(TxtNumeroCheque.Text.Trim()) ? null : TxtNumeroCheque.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_REPOSICION = (CmbReposicion.SelectedItem == null) ? null : CmbReposicion.SelectedItem.Value.ToString();
                objFormularioPCC04.FOPVC_ORIGEN_RECURSOS = TxtOrigenRecursos.Text.Trim().ToUpper();
                objFormularioPCC04.FOPVC_DESTINO_RECURSOS = TxtDestinoRecursos.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_DECLARANTE_NOMBRE = string.IsNullOrEmpty(TxtDeclaranteNombre.Text.Trim()) ? null : TxtDeclaranteNombre.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_DECLARANTE_DOCUMENTO_NUMERO = string.IsNullOrEmpty(TxtDeclaranteDocumento.Text.Trim()) ? null : TxtDeclaranteDocumento.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_DECLARANTE_DOCUMENTO_EXTENSION = (CmbDeclaranteExtension.SelectedItem == null) ? null : CmbDeclaranteExtension.SelectedItem.Value.ToString();
                objFormularioPCC04.FOSVC_DECLARANTE_CARGO = string.IsNullOrEmpty(TxtDeclaranteCargo.Text.Trim()) ? null : TxtDeclaranteCargo.Text.Trim().ToUpper();
                objFormularioPCC04.FOSVC_OBSERVACIONES = string.IsNullOrEmpty(TxtObservaciones.Text.Trim()) ? null : TxtObservaciones.Text.Trim().ToUpper();
                objFormularioPCC04.FOPCH_TIPO_FORMULARIO = "S";
                objFormularioPCC04.FOPVC_DESCRIPCION_ORIGEN = Session["FormularioPCC04_DescripcionOrigen"].ToString();
                objFormularioPCC04.FOPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objFormularioPCC04.FOSVC_ID_USER_INSERT = _objUsuario.Matricula;
                var objResult = _cPersonales.AgregarFormularioPCC04(objFormularioPCC04);
                if (objResult == null)
                {
                    throw new Exception("Se ha presentado un error al realizar el registro de los datos.");
                }
                Session["FormularioPCC04_Datos"] = _cPersonales.FormulariosPCC04PorPeriodo((string)Session["PERIODO_CONTABLE"]);
                GrvFormularios.DataBind();
                PopFormulario.ShowOnPageLoad = false;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('Se ha completado el registro del formulario PCC04.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvFormularios_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["FormularioPCC04_Datos"] != null)
                {
                    var DsetFormularios = (DataSet)Session["FormularioPCC04_Datos"];
                    if (DsetFormularios.Tables.Count > 0)
                        GrvFormularios.DataSource = DsetFormularios.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvFormularios_PreRender(object sender, EventArgs e)
        {
            try
            {
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                foreach (GridViewRow row in GrvFormularios.Rows)
                {
                    string strEstado = ((Label)row.FindControl("LblEstado")).Text.Trim();
                    Image ImgRegistrar = (Image)row.FindControl("ImgRegistrar");
                    Image ImgDescargar = (Image)row.FindControl("ImgDescargar");
                    Image ImgEditar = (Image)row.FindControl("ImgEditar");
                    Image ImgEliminar = (Image)row.FindControl("ImgEliminar");                    
                    ImgRegistrar.Visible = false;
                    ImgDescargar.Visible = false;
                    ImgEditar.Visible = false;
                    ImgEliminar.Visible = false;
                    if (_strPeriodoContable == strPeriodoProceso)
                    {
                        if (strEstado == "PENDIENTE")
                            ImgRegistrar.Visible = true;
                        else
                        {
                            ImgDescargar.Visible = true;
                            ImgEditar.Visible = true;
                            ImgEliminar.Visible = true;
                        }
                    }
                    else
                    {
                        if (strEstado == "PENDIENTE")
                        {
                            ImgRegistrar.Visible = true;
                        }
                        else
                        {
                            ImgDescargar.Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvFormularios_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                string strIdFormulario = ((Label)gvr.FindControl("LblIdFormulario")).Text.Trim();
                switch (e.CommandName)
                {
                    case "REGISTRAR":
                        ASPxEdit.ClearEditorsInContainer(BflFormularioPCC04, true);
                        CargarCombos();                        
                        BflFormularioPCC04.FindItemOrGroupByName("GruPersonaNatural").ClientVisible = false;
                        BflFormularioPCC04.FindItemOrGroupByName("GruPersonaJuridica").ClientVisible = false;
                        string strTipoOperacion = ((Label)gvr.FindControl("LblTipoOperacion")).Text.Trim();
                        string strNaturalezaOperacion = ((Label)gvr.FindControl("LblNaturalezaOperacion")).Text.Trim();
                        string strTipoSeguro = ((Label)gvr.FindControl("LblTipoSeguro")).Text.Trim();
                        string strPlazoSeguro = ((Label)gvr.FindControl("LblPlazoSeguro")).Text.Trim();
                        string strMoneda = ((Label)gvr.FindControl("LblMoneda")).Text.Trim();
                        string strMonto = ((Label)gvr.FindControl("LblMonto")).Text.Trim();
                        string strNombreCorredor = ((Label)gvr.FindControl("LblNombreCorredor")).Text.Trim();
                        string strNombreIntermediario = ((Label)gvr.FindControl("LblNombreIntermediario")).Text.Trim();
                        string strTomador = ((Label)gvr.FindControl("LblTomador")).Text.Trim();
                        string strNumeroPoliza = ((Label)gvr.FindControl("LblNumeroPoliza")).Text.Trim();
                        string strNumeroCuenta = ((Label)gvr.FindControl("LblNumeroCuenta")).Text.Trim();
                        string strSujetoObligado = ((Label)gvr.FindControl("LblSujetoObligado")).Text.Trim();
                        string strNumeroCheque = ((Label)gvr.FindControl("LblNumeroCheque")).Text.Trim();
                        string strBeneficiario = ((Label)gvr.FindControl("LblBeneficiario")).Text.Trim();
                        string strIdDenuncia = ((Label)gvr.FindControl("LblIdDenuncia")).Text.Trim();
                        string strIdFiniquito = ((Label)gvr.FindControl("LblIdFiniquito")).Text.Trim();
                        string strEstado = ((Label)gvr.FindControl("LblEstado")).Text.Trim();
                        string strFechaLiquidacion = ((Label)gvr.FindControl("LblFechaLiquidacion")).Text.Trim();                        
                        CmbTipoOperacion.Value = strTipoOperacion;
                        CmbNaturalezaOperacion.Value = strNaturalezaOperacion;
                        CmbTipoSeguro.Value = strTipoSeguro;
                        CmbPlazoSeguro.Value = strPlazoSeguro;
                        CmbMoneda.Value = strMoneda;
                        TxtMontoOperacion.Text = strMonto;
                        TxtNombreCorredor.Text = strNombreCorredor;
                        TxtNombreIntermediario.Text = strNombreIntermediario;
                        TxtNombreTomador.Text = strTomador;
                        TxtNumeroPoliza.Text = strNumeroPoliza;
                        TxtNumeroCuenta.Text = strNumeroCuenta;
                        CmbSujetoObligado.Value = strSujetoObligado;
                        TxtNumeroCheque.Text = strNumeroCheque;
                        TxtPJRazonSocial.Text = strBeneficiario;
                        TxtPNNombres.Text = strBeneficiario;
                        TxtDeclaranteNombre.Text = strBeneficiario;
                        PopFormulario.ShowOnPageLoad = true;
                        PopFormulario.FindControl("BtnActualizar").Visible = false;
                        PopFormulario.FindControl("BtnRegistrar").Visible = true;
                        Session["FormularioPCC04_FechaLiquidacion"] = strFechaLiquidacion;
                        Session["FormularioPCC04_DescripcionOrigen"] = strIdDenuncia + "|" + strMoneda + "|" + strIdFiniquito;
                        break;
                    case "EDITAR":
                        var objResultEditar = _cPersonales.ObtenerFormularioPCC04PorId(Convert.ToInt64(strIdFormulario));
                        ASPxEdit.ClearEditorsInContainer(BflFormularioPCC04, true);
                        CargarCombos();
                        BflFormularioPCC04.FindItemOrGroupByName("GruPersonaNatural").ClientVisible = (objResultEditar.FOPVC_TIPO_PERSONA == "J" ? false : true);
                        BflFormularioPCC04.FindItemOrGroupByName("GruPersonaJuridica").ClientVisible = (objResultEditar.FOPVC_TIPO_PERSONA == "J" ? true : false);
                        CmbTipoPersona.Value = objResultEditar.FOPVC_TIPO_PERSONA;
                        TxtPNNombres.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_NOMBRES : null;
                        TxtPNApellidoPaterno.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_APELLIDO_PATERNO : null;
                        TxtPNApellidoMaterno.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOSVC_PN_APELLIDO_MATERNO : null;
                        CmbPNTipoDocumento.Value = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_DOCUMENTO_TIPO : null;
                        TxtPNDocumentoNumero.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_DOCUMENTO_NUMERO : null;
                        CmbPNDocumentoExtension.Value = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOSVC_PN_DOCUMENTO_EXTENSION : null;
                        CmbPNNacionalidad.Value = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_NACIONALIDAD : null;
                        CmbPNPaisResidencia.Value = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_PAIS_RESIDENCIA : null;
                        CmbPNProfesion.Value = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_PN_PROFESION : null;
                        TxtPNActividadEconomica.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOPVC_ACTIVIDAD : null;
                        TxtPNEmpresa.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOSVC_PN_LUGAR_TRABAJO : null;
                        TxtPNCargo.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOSVC_PN_CARGO : null;
                        TxtPNDireccionTrabajo.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "N") ? objResultEditar.FOSVC_PN_DIRECCION_TRABAJO : null;
                        TxtPJNit.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "J") ? objResultEditar.FOPVC_PJ_NIT : null;
                        TxtPJRazonSocial.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "J") ? objResultEditar.FOPVC_PJ_RAZON_SOCIAL : null;
                        TxtPJActividadEconomica.Text = (objResultEditar.FOPVC_TIPO_PERSONA == "J") ? objResultEditar.FOPVC_ACTIVIDAD : null;
                        CmbCiudad.Value = objResultEditar.FOPVC_CIUDAD;
                        TxtZona.Text = objResultEditar.FOPVC_ZONA;
                        TxtDireccion.Text = objResultEditar.FOPVC_DIRECCION;
                        TxtTelefono.Text = objResultEditar.FOPVC_TELEFONO;
                        CmbTipoOperacion.Value = objResultEditar.FOPVC_TIPO_OPERACION;
                        CmbNaturalezaOperacion.Value = objResultEditar.FOPVC_NATURALEZA_OPERACION;
                        CmbTipoSeguro.Value = objResultEditar.FOSVC_TIPO_SEGURO;
                        CmbPlazoSeguro.Value = objResultEditar.FOPVC_CODIGO_PLAZO_SEGURO;
                        CmbRamoSeguro.Value = objResultEditar.FOSVC_CODIGO_RAMO;
                        CmbMoneda.Value = objResultEditar.FOPVC_MONEDA;
                        TxtMontoOperacion.Text = objResultEditar.FOPDC_MONTO.ToString();
                        TxtNombreCorredor.Text = objResultEditar.FOSVC_NOMBRE_CORREDOR;
                        TxtNombreIntermediario.Text = objResultEditar.FOSVC_NOMBRE_INTERMEDIARIO;
                        TxtNombreTomador.Text = objResultEditar.FOPVC_NOMBRE_TOMADOR;
                        TxtNumeroPoliza.Text = objResultEditar.FOPVC_NUMERO_POLIZA;
                        TxtNumeroCuenta.Text = objResultEditar.FOSVC_NUMERO_CUENTA;
                        CmbSujetoObligado.Value = objResultEditar.FOSBI_CODIGO_ENTIDAD_FINANCIERA.ToString();
                        TxtNumeroCheque.Text = objResultEditar.FOSVC_NUMERO_CHEQUE;
                        CmbReposicion.Value = objResultEditar.FOSVC_REPOSICION;
                        TxtOrigenRecursos.Text = objResultEditar.FOPVC_ORIGEN_RECURSOS;
                        TxtDestinoRecursos.Text = objResultEditar.FOPVC_DESTINO_RECURSOS;
                        TxtDeclaranteNombre.Text = objResultEditar.FOSVC_DECLARANTE_NOMBRE;
                        TxtDeclaranteDocumento.Text = objResultEditar.FOSVC_DECLARANTE_DOCUMENTO_NUMERO;
                        CmbDeclaranteExtension.Value = objResultEditar.FOSVC_DECLARANTE_DOCUMENTO_EXTENSION;
                        TxtDeclaranteCargo.Text = objResultEditar.FOSVC_DECLARANTE_CARGO;
                        TxtObservaciones.Text = objResultEditar.FOSVC_OBSERVACIONES;
                        PopFormulario.ShowOnPageLoad = true;
                        PopFormulario.FindControl("BtnActualizar").Visible = true;
                        PopFormulario.FindControl("BtnRegistrar").Visible = false;
                        Session["FormularioPCC04_Actualizacion"] = objResultEditar;
                        break;
                    case "ELIMINAR":
                        var objResultEliminar = _cPersonales.EliminarFormularioPCC04(Convert.ToInt64(strIdFormulario));
                        if (!objResultEliminar)
                        {
                            throw new Exception("Se ha presentado un error al intentar eliminar el registro seleccionado.");
                        }
                        Session["FormularioPCC04_Datos"] = _cPersonales.FormulariosPCC04PorPeriodo((string)Session["PERIODO_CONTABLE"]);
                        GrvFormularios.DataBind();                        
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El registro seleccionado ha sido eliminado.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        break;
                    case "DESCARGAR":
                        var objResultDescargar = _cDocumentos.GetFormularioPCC04(Convert.ToInt64(strIdFormulario));
                        if (objResultDescargar == null)
                            throw new Exception("Se ha presentado un error al intentar descargar el formulario seleccionado.");
                        Session["FormularioPCC04_Descarga"] = objResultDescargar;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
            finally
            {
                if (Session["FormularioPCC04_Descarga"] != null)
                {
                    var objArchivo = (OC_RESPONSE_FILE)Session["FormularioPCC04_Descarga"];
                    Session.Remove("FormularioPCC04_Descarga");
                    Response.Buffer = true;
                    Response.Clear();
                    Response.ContentType = objArchivo.ContentType;
                    Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NombreArchivo);
                    Response.BinaryWrite(objArchivo.ByteArray);
                    Response.Flush();
                    Response.End();
                }
            }
        }
        protected void BtnActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["FormularioPCC04_Actualizacion"] != null)
                {
                    var objFormularioPCC04 = (FORMULARIO_PCC04)Session["FormularioPCC04_Actualizacion"];
                    long longIdSujetoObligado = 0;
                    bool boolValidaIdSujetoObligado = long.TryParse(CmbSujetoObligado.SelectedItem.Value.ToString(), out longIdSujetoObligado);
                    objFormularioPCC04.FOPVC_TIPO_PERSONA = CmbTipoPersona.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_PN_NOMBRES = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNNombres.Text.Trim().ToUpper() : null;
                    objFormularioPCC04.FOPVC_PN_APELLIDO_PATERNO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNApellidoPaterno.Text.Trim().ToUpper() : null;
                    objFormularioPCC04.FOSVC_PN_APELLIDO_MATERNO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNApellidoMaterno.Text.Trim()) ? null : TxtPNApellidoMaterno.Text.Trim().ToUpper()) : null;
                    objFormularioPCC04.FOPVC_PN_DOCUMENTO_TIPO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNTipoDocumento.SelectedItem.Value.ToString() : null;
                    objFormularioPCC04.FOPVC_PN_DOCUMENTO_NUMERO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNDocumentoNumero.Text.Trim().ToUpper() : null;
                    objFormularioPCC04.FOSVC_PN_DOCUMENTO_EXTENSION = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNDocumentoExtension.SelectedItem.Value.ToString() : null;
                    objFormularioPCC04.FOPVC_PN_NACIONALIDAD = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNNacionalidad.SelectedItem.Value.ToString() : null;
                    objFormularioPCC04.FOPVC_PN_PAIS_RESIDENCIA = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNPaisResidencia.SelectedItem.Value.ToString() : null;
                    objFormularioPCC04.FOPVC_PN_PROFESION = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? CmbPNProfesion.SelectedItem.Value.ToString() : null;
                    objFormularioPCC04.FOPVC_ACTIVIDAD = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? TxtPNActividadEconomica.Text.Trim().ToUpper() : TxtPJActividadEconomica.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_PN_LUGAR_TRABAJO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNEmpresa.Text.Trim()) ? null : TxtPNEmpresa.Text.Trim().ToUpper()) : null;
                    objFormularioPCC04.FOSVC_PN_CARGO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNCargo.Text.Trim()) ? null : TxtPNCargo.Text.Trim().ToUpper()) : null;
                    objFormularioPCC04.FOSVC_PN_DIRECCION_TRABAJO = (CmbTipoPersona.SelectedItem.Value.ToString() == "N") ? (string.IsNullOrEmpty(TxtPNDireccionTrabajo.Text.Trim()) ? null : TxtPNDireccionTrabajo.Text.Trim().ToUpper()) : null;
                    objFormularioPCC04.FOPVC_PJ_NIT = (CmbTipoPersona.SelectedItem.Value.ToString() == "J") ? TxtPJNit.Text.Trim().ToUpper() : null;
                    objFormularioPCC04.FOPVC_PJ_RAZON_SOCIAL = (CmbTipoPersona.SelectedItem.Value.ToString() == "J") ? TxtPJRazonSocial.Text.Trim().ToUpper() : null;
                    objFormularioPCC04.FOPVC_CIUDAD = CmbCiudad.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_ZONA = TxtZona.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_DIRECCION = TxtDireccion.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_TELEFONO = TxtTelefono.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_TIPO_OPERACION = CmbTipoOperacion.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_NATURALEZA_OPERACION = CmbNaturalezaOperacion.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOSVC_TIPO_SEGURO = (CmbTipoSeguro.SelectedItem == null) ? null : CmbTipoSeguro.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_CODIGO_PLAZO_SEGURO = CmbPlazoSeguro.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOSVC_CODIGO_RAMO = (CmbRamoSeguro.SelectedItem == null) ? null : CmbRamoSeguro.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_MONEDA = CmbMoneda.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPDC_MONTO = Convert.ToDecimal(TxtMontoOperacion.Text.Trim());
                    objFormularioPCC04.FOSVC_NOMBRE_CORREDOR = string.IsNullOrEmpty(TxtNombreCorredor.Text.Trim()) ? null : TxtNombreCorredor.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_NOMBRE_INTERMEDIARIO = string.IsNullOrEmpty(TxtNombreIntermediario.Text.Trim()) ? null : TxtNombreIntermediario.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_NOMBRE_TOMADOR = TxtNombreTomador.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_NUMERO_POLIZA = TxtNumeroPoliza.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_NUMERO_CUENTA = string.IsNullOrEmpty(TxtNumeroCuenta.Text.Trim()) ? null : TxtNumeroCuenta.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSBI_CODIGO_ENTIDAD_FINANCIERA = (boolValidaIdSujetoObligado) ? longIdSujetoObligado : (long?)null;
                    objFormularioPCC04.FOSVC_NUMERO_CHEQUE = string.IsNullOrEmpty(TxtNumeroCheque.Text.Trim()) ? null : TxtNumeroCheque.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_REPOSICION = (CmbReposicion.SelectedItem == null) ? null : CmbReposicion.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOPVC_ORIGEN_RECURSOS = TxtOrigenRecursos.Text.Trim().ToUpper();
                    objFormularioPCC04.FOPVC_DESTINO_RECURSOS = TxtDestinoRecursos.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_DECLARANTE_NOMBRE = string.IsNullOrEmpty(TxtDeclaranteNombre.Text.Trim()) ? null : TxtDeclaranteNombre.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_DECLARANTE_DOCUMENTO_NUMERO = string.IsNullOrEmpty(TxtDeclaranteDocumento.Text.Trim()) ? null : TxtDeclaranteDocumento.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_DECLARANTE_DOCUMENTO_EXTENSION = (CmbDeclaranteExtension.SelectedItem == null) ? null : CmbDeclaranteExtension.SelectedItem.Value.ToString();
                    objFormularioPCC04.FOSVC_DECLARANTE_CARGO = string.IsNullOrEmpty(TxtDeclaranteCargo.Text.Trim()) ? null : TxtDeclaranteCargo.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_OBSERVACIONES = string.IsNullOrEmpty(TxtObservaciones.Text.Trim()) ? null : TxtObservaciones.Text.Trim().ToUpper();
                    objFormularioPCC04.FOSVC_ID_USER_MODIF = _objUsuario.Matricula;
                    var objResult = _cPersonales.ActualizarFormularioPCC04(objFormularioPCC04);
                    if (!objResult)
                    {
                        throw new Exception("Se ha presentado un error al realizar la actualización del formulario.");
                    }
                    Session["FormularioPCC04_Datos"] = _cPersonales.FormulariosPCC04PorPeriodo((string)Session["PERIODO_CONTABLE"]);
                    GrvFormularios.DataBind();
                    PopFormulario.ShowOnPageLoad = false;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('Se ha completado la actualización del formulario PCC04.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                    throw new Exception("Esta acción no esta permitida.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}