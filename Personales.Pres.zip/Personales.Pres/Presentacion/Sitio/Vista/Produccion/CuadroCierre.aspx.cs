﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Produccion
{
    public partial class CuadroCierre : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCore _cCore = new CCore();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                LblUsuarioConfirmacion.Text = _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto;
                CargaInicial();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                Session.Remove("DOWNLOAD");
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                var objResponse = _cPersonales.GetDatasetProcedimiento(
                    "pro.SPR_GETLIST_REPORTE_CUADRO_PRODUCCION",
                    new List<CParameter>() { new CParameter() { Key = "PERIODO_CONTABLE", Value = _strPeriodoContable } });
                Session["CUADRO_PRODUCCION"] = objResponse;
                GrvProduccion.DataBind();
                GrvAnulacion.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDescargar_Click(object sender, EventArgs e)
        {
            try
            {
                string strRutaPlantilla = Server.MapPath("~/UI/templates/CUADRO_PRODUCCION.xlsx");
                var objFileInfo = new FileInfo(strRutaPlantilla);
                var DsetDatos = (DataSet)Session["CUADRO_PRODUCCION"];
                if (DsetDatos.Tables.Count == 2)
                {
                    DevExpress.Spreadsheet.Workbook DEWorkbook = new DevExpress.Spreadsheet.Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (DevExpress.Spreadsheet.Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "PRODUCCION")
                        {
                            DataTable DtblProduccion = DsetDatos.Tables[0];
                            DtblProduccion.DefaultView.Sort = "NUMERO_POLIZA, ID_PRODUCTO, MONEDA";
                            DtblProduccion = DtblProduccion.DefaultView.ToTable();
                            DEWorksheet.Import(DtblProduccion, false, 1, 0);
                            CellRange objRange = DEWorksheet.Range["A1:U" + (DtblProduccion.Rows.Count + 1)];
                            objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                            DEWorksheet.Columns.Remove(21);
                            
                            
                            for (int index = 0; index < DtblProduccion.Rows.Count; index++) {
                                string strDatos =
                                    DtblProduccion.Rows[index]["NUMERO_POLIZA"].ToString() +
                                    DtblProduccion.Rows[index]["ID_PRODUCTO"].ToString() +
                                    DtblProduccion.Rows[index]["MONEDA"].ToString();
                                int intCoincidencias = 0;
                                bool boolCrearRango = false;
                                for (int validador = index + 1; validador < DtblProduccion.Rows.Count; validador++)
                                {
                                    if (strDatos ==
                                    DtblProduccion.Rows[validador]["NUMERO_POLIZA"].ToString() +
                                    DtblProduccion.Rows[validador]["ID_PRODUCTO"].ToString() +
                                    DtblProduccion.Rows[validador]["MONEDA"].ToString())
                                    {
                                        intCoincidencias++;
                                        boolCrearRango = true;
                                    }
                                }
                                if (boolCrearRango)
                                {
                                    CellRange objRangeMerge = DEWorksheet.Range["A" + (index + 2) + ":Q" + ((index + 2) + intCoincidencias)];
                                    objRangeMerge.Merge(MergeCellsMode.ByColumns);
                                }
                            }
                        }
                        if (DEWorksheet.Name == "ANULACION")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[1], false, 1, 0);
                            CellRange objRangeBorder = DEWorksheet.Range["A1:N" + (DsetDatos.Tables[1].Rows.Count + 1)];
                            objRangeBorder.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                        }
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "CuadroProduccion_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "Alerta_BtnReaseguroGenerico_Click", "toastr.error('Todavía no existe información para generar el reporte seleccionado, por favor intente de nuevo más tarde.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CONFORMIDADES"] != null)
                {
                    if (_objUsuario == null)
                        _objUsuario = (occ_usuario)Session["SessionUsuario"];
                    var objDataSet = (DataSet)Session["CONFORMIDADES"];
                    GrvConformidades.DataSource = objDataSet.Tables[1];
                    GrvConformidades.Columns[8].Visible = false;
                    GrvConformidades.Columns[9].Visible = false;
                    for (int index = 0; index < objDataSet.Tables[0].Rows.Count; index++)
                    {
                        if (objDataSet.Tables[0].Rows[index][0].ToString() == _objUsuario.Matricula)
                        {
                            GrvConformidades.Columns[8].Visible = true;
                            GrvConformidades.Columns[9].Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            var objKeyValue = (sender as BootstrapGridView).GetMasterRowKeyValue();
            var objDataSet = (DataSet)Session["CONFORMIDADES"];
            var GrvResponsables = (sender as BootstrapGridView);
            DataView dvResponsable = new DataView(objDataSet.Tables[2]);
            dvResponsable.RowFilter = "ID_GRUPO = '" + objKeyValue.ToString() + "'";
            GrvResponsables.DataSource = dvResponsable;
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = ((BootstrapButton)sender).CommandArgument;
                string strIdNivel = ((BootstrapButton)sender).CommandName;
                string strIdControl = ((BootstrapButton)sender).ID;
                PopDetalleConformidades.ShowOnPageLoad = false;
                PopConformidad.ShowOnPageLoad = false;
                PopObservacion.ShowOnPageLoad = false;
                switch (strIdControl)
                {
                    case "BtnObservacion":
                        TxtObservacion.Text = null;
                        PopObservacion.ShowOnPageLoad = true;
                        break;
                    case "BtnConformidad":
                        TxtPassword.Text = null;
                        PopConformidad.ShowOnPageLoad = true;
                        break;
                }
                Session["ID_GRUPO"] = strIdGrupo;
                Session["ID_NIVEL"] = strIdNivel;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CbPassword_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            string strIdUsuario = _objUsuario.Matricula;
            string strPasswordUsuario = TxtPassword.Text.Trim();
            e.Result = "false";
            if (_cCore.ValidarAutenticacion(strIdUsuario, strPasswordUsuario))
                e.Result = "true";
        }
        protected void BtnObservar_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = Session["ID_GRUPO"].ToString();
                string strDescripcionNivel = string.Empty,
                    strDescripcionConformidad = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                //registrar el estado
                string strIdResponsable = string.Empty;
                for (int index = 0; index < objDataSet.Tables[2].Rows.Count; index++)
                    if (objDataSet.Tables[2].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo && objDataSet.Tables[2].Rows[index]["USUARIO"].ToString().Contains(_objUsuario.Matricula))
                        strIdResponsable = objDataSet.Tables[2].Rows[index]["ID_RESPONSABLE"].ToString();
                var objLexico2 = _cPersonales.GetListLexicoPorTabla(strIdGrupo);
                CONFORMIDAD objConformidad = new CONFORMIDAD();
                objConformidad.COPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objConformidad.COPVC_USUARIO = _objUsuario.Matricula;
                objConformidad.COPVC_NOMBRE = _objUsuario.NombreCompleto;
                objConformidad.COPVC_AREA = objLexico2.FirstOrDefault().LEPVC_VALOR;
                objConformidad.COPVC_PROCESO = strDescripcionNivel + ": " + strDescripcionConformidad;
                objConformidad.COPVC_ID_RESPONSABLE = strIdResponsable;
                objConformidad.COPVC_ESTADO = "OBSERVADO";
                objConformidad.COPVC_OBSERVACION = TxtObservacion.Text.Trim().ToUpper();
                var objResult = _cPersonales.RegistrarConformidad(objConformidad);
                CorreoObservacionRegistrada(strIdGrupo);
                PopObservacion.ShowOnPageLoad = false;
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "toastr.warning", "toastr.warning('Se ha registrado la observación y se ha notificado al área de sistemas para su revisión..', 'CIERRE MENSUAL (" + _strPeriodoContable + ")', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }

        }
        protected void BtnDetalleConformidades_Click(object sender, EventArgs e)
        {
            try
            {
                var objConformidades = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_CIERRE",
                    new List<CParameter>() { new CParameter() { Key = "PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (objConformidades.Tables.Count >= 3)
                {
                    LblInicioProceso.Text = (!string.IsNullOrEmpty(objConformidades.Tables[1].Rows[0]["FECHA_INICIO"].ToString())) ? "El proceso de cierre ha iniciado el " + objConformidades.Tables[1].Rows[0]["FECHA_INICIO"].ToString() : string.Empty;
                    for (int index = 0; index < objConformidades.Tables[2].Rows.Count; index++)
                    {
                        var objUsuario = _cCore.DatosDirectorioActivo(objConformidades.Tables[2].Rows[index]["USUARIO"].ToString());
                        objConformidades.Tables[2].Rows[index]["USUARIO"] = objConformidades.Tables[2].Rows[index]["USUARIO"].ToString() + " - " + objUsuario.NombreCompleto;
                    }
                }
                Session["CONFORMIDADES"] = objConformidades;
                GrvConformidades.DataBind();
                //habilitamos el boton de inicio del proceso
                var objConformidad = _cPersonales.ListaConformidadesPorPeriodo(_strPeriodoContable).Where(w => w.COPVC_AREA == "SISTEMAS" && w.COPVC_ESTADO == "INICIO").FirstOrDefault();
                var BtnIniciarProceso = (BootstrapButton)PopDetalleConformidades.FindControl("BtnIniciarProceso");
                BtnIniciarProceso.ClientVisible = false;
                BtnIniciarProceso.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
                ///validacion del usuario, si es iniciador se habilita el boton de inicio de cierre
                var listaUsuariosIniciadores = _cPersonales.GetListLexicoPorTablaYTema("PRD-NIVEL-01", "RESPONSABLE") .Where(w => w.LEPVC_VALOR.StartsWith("PRD-NIVEL-01-OPE") == true).ToList();
                if (objConformidad == null && listaUsuariosIniciadores.Exists(f => f.LEPVC_DESC_CORTA == _objUsuario.Matricula))
                {
                    BtnIniciarProceso.ClientVisible = true;
                    BtnIniciarProceso.ClientSideEvents.Click = null;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnResponsable_Init(object sender, EventArgs e)
        {
            BootstrapButton btn = sender as BootstrapButton;
            GridViewDataItemTemplateContainer container = btn.NamingContainer as GridViewDataItemTemplateContainer;
            string value = DataBinder.Eval(container.DataItem, "ESTADO").ToString();
            if (value == "NO INICIADO" || value == "CONFORME")
            {
                btn.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
                btn.ClientVisible = false;
            }
            else
            {
                btn.ClientSideEvents.Click = null;
                btn.ClientVisible = true;
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = Session["ID_GRUPO"].ToString();
                string strIdNivel = Session["ID_NIVEL"].ToString();
                string strNivel = string.Empty;
                string strDescripcion = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcion = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                string strIdResponsable = string.Empty;
                for (int index = 0; index < objDataSet.Tables[2].Rows.Count; index++)
                    if (objDataSet.Tables[2].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo && objDataSet.Tables[2].Rows[index]["USUARIO"].ToString().Contains(_objUsuario.Matricula))
                        strIdResponsable = objDataSet.Tables[2].Rows[index]["ID_RESPONSABLE"].ToString();
                var objLexico2 = _cPersonales.GetListLexicoPorTabla(strIdGrupo);
                CONFORMIDAD objConformidad = new CONFORMIDAD();
                objConformidad.COPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objConformidad.COPVC_USUARIO = _objUsuario.Matricula;
                objConformidad.COPVC_NOMBRE = _objUsuario.NombreCompleto;
                objConformidad.COPVC_AREA = objLexico2.FirstOrDefault().LEPVC_VALOR;
                objConformidad.COPVC_PROCESO = strNivel + ": " + strDescripcion;
                objConformidad.COPVC_ID_RESPONSABLE = strIdResponsable;
                objConformidad.COPVC_ESTADO = "CONFORME";
                objConformidad.COPVC_OBSERVACION = TxtComentarioConformidad.Text.Trim().ToUpper();
                var objResult = _cPersonales.RegistrarConformidad(objConformidad);
                if (objResult != null)
                {
                    CorreoConformidadRegistrada(strIdGrupo);
                    ///Generamos el archivo TXT si es el ultimo nivel de conformidad registrado
                    if (objResult.COPVC_AREA == "FINANZAS" && objResult.COPVC_PROCESO.Contains("CONFORMIDAD DE FINANZAS"))
                    {
                        string strRutaServidor = @"F:\REPOSITORIO_ERP_CONTA\ERP\ARCHIVOS\";
                        if (File.Exists(strRutaServidor + "ASIENTO.txt"))
                            File.Move(strRutaServidor + "ASIENTO.txt", strRutaServidor + "ASIENTO_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt");
                        File.WriteAllBytes(strRutaServidor + "ASIENTO.txt", AsientosContables());
                    }                    
                    ///Evaluamos si se habilita un nuevo nivel
                    var objDSetCorreo = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_RESTANTES",
                    new List<CParameter>() {
                        new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new CParameter() { Key = "@ID_NIVEL", Value = strIdNivel } });
                    if (objDSetCorreo.Tables[0].Rows[0][1].ToString() == "0" && objDSetCorreo.Tables[0].Rows[0][2].ToString() != string.Empty)
                        CorreoHabilitacionNivel(objDSetCorreo.Tables[0].Rows[0][2].ToString());
                }
                PopConformidad.ShowOnPageLoad = false;                
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "toastr.success", "toastr.success('Se ha completado el registro de la conformidad.', 'CIERRE MENSUAL (" + _strPeriodoContable + ")', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        protected byte[] AsientosContables()
        {
            try
            {
                var listaAsientosContables = _cPersonales.GetListAsientosContablesPorPeriodo(_strPeriodoContable);
                using (var ms = new MemoryStream())
                {
                    TextWriter tw = new StreamWriter(ms);
                    tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}", "ldr_entity_id", "eff_date", "jrnl_id", "jrnl_seq_nbr", "jrnl_line_nbr", "line_ldr_entity_id", "sucursal", "cuenta", "agencia", "centro", "negocio", "producto", "trans_curr_code", "prim_dr_cr_code", "trans_amt", "descp", "jrnl_user_alpha_fld_1", "jrnl_user_alpha_fld_2"));
                    tw.Write(Environment.NewLine);
                    foreach (ASIENTO_CONTABLE objAsientoContable in listaAsientosContables)
                    {
                        tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}",
                            objAsientoContable.ASPVC_ENTIDAD,
                            objAsientoContable.ASPDT_FECHA.ToString("M/d/yyyy"),
                            objAsientoContable.ASPVC_ID_DIARIO,
                            objAsientoContable.ASPIN_NUMERO_SEQUENCIA.ToString(),
                            objAsientoContable.ASPIN_NUMERO_LINEA.ToString(),
                            objAsientoContable.ASPVC_ENTIDAD,
                            objAsientoContable.ASPCH_SUCURSAL,
                            objAsientoContable.ASPVC_CUENTA,
                            objAsientoContable.ASPCH_AGENCIA,
                            objAsientoContable.ASPCH_CENTRO,
                            objAsientoContable.ASPCH_NEGOCIO,
                            objAsientoContable.ASPVC_ID_PRODUCTO,
                            objAsientoContable.ASPCH_MONEDA,
                            objAsientoContable.ASPCH_TIPO_IMPORTE,
                            objAsientoContable.ASPDC_IMPORTE,
                            objAsientoContable.ASPVC_GLOSA,
                            objAsientoContable.ASPVC_NIT_TOMADOR,
                            objAsientoContable.ASPVC_ID_REAEGURADOR));
                        tw.Write(Environment.NewLine);
                    }
                    tw.Flush();
                    ms.Position = 0;
                    return ms.ToArray();
                }
            }
            catch
            {
                throw;
            }
        }
        protected void GrvAnulacion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var objDataSet = (DataSet)Session["CUADRO_PRODUCCION"];
                if (objDataSet.Tables.Count > 1)
                    GrvAnulacion.DataSource = objDataSet.Tables[1];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProduccion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var objDataSet = (DataSet)Session["CUADRO_PRODUCCION"];
                if (objDataSet.Tables.Count > 0)
                    GrvProduccion.DataSource = objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoHabilitacionNivel(string strIdNivel)
        {
            try
            {
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strMesProduccion = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString(),
                    strDescripcionNivel = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                    if (objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString() == strIdNivel)
                    {
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        break;
                    }
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                List<string> listaMailTO = new List<string>();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                List<string> listaMailCC = new List<string>();
                var listaLexicoMail = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-INF-CC");
                if (listaLexicoMail.Count > 0)
                    listaMailCC = listaLexicoMail.First().LEPVC_VALOR.Split(';').ToList();
                string strHtmlInf = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_NIVEL.html"));
                strHtmlInf = strHtmlInf.Replace("#MES_PRODUCCION#", dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString());
                strHtmlInf = strHtmlInf.Replace("#PERIODO#", _strPeriodoContable);
                strHtmlInf = strHtmlInf.Replace("#NIVEL#", strDescripcionNivel);
                strHtmlInf = strHtmlInf.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                var objResponse = Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL DE " + strMesProduccion + " | HABILITADO: " + strDescripcionNivel,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtmlInf,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoConformidadRegistrada(string strIdGrupo)
        {
            try
            {
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strMesProduccion = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString(),
                    strIdNivel = string.Empty, 
                    strDescripcionNivel = string.Empty, 
                    strDescripcionConformidad = string.Empty; 
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strIdNivel = objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString();
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                List<string> listaMailTO = new List<string>();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                List<string> listaMailCC = new List<string>();
                var listaLexicoMail = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-INF-CC");
                if (listaLexicoMail.Count > 0)
                    listaMailCC = listaLexicoMail.First().LEPVC_VALOR.Split(';').ToList();
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_PROCESO.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", strMesProduccion);
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#COMENTARIO#", TxtComentarioConformidad.Text.Trim().ToUpper());
                var objResponse = Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL DE " + strMesProduccion + " | CONFORMIDAD: " + strDescripcionNivel + " (" + strDescripcionConformidad + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoObservacionRegistrada(string strIdGrupo)
        {
            try
            {
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strMesProduccion = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString(),
                    strIdNivel = string.Empty,
                    strDescripcionNivel = string.Empty,
                    strDescripcionConformidad = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strIdNivel = objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString();
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                List<string> listaMailTO = new List<string>();
                var listaLexicoMailTO = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-OBS-TO");
                if (listaLexicoMailTO.Count > 0)
                    listaMailTO = listaLexicoMailTO.First().LEPVC_VALOR.Split(';').ToList();
                List<string> listaMailCC = new List<string>();
                var listaLexicoMailCC = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-OBS-CC");
                if (listaLexicoMailCC.Count > 0)
                    foreach (string strCorreo in listaLexicoMailCC.First().LEPVC_VALOR.Split(';').ToList())
                        listaMailCC.Add(strCorreo);
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                        listaMailCC.Add(objUsuario.USPVC_CORREO);
                }
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_OBSERVACION.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", strMesProduccion);
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#OBSERVACION#", TxtObservacion.Text.Trim());
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL DE " + strMesProduccion + " | OBSERVACIÓN: " + strDescripcionNivel + " (" + strDescripcionConformidad + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnIniciarProceso_Click(object sender, EventArgs e)
        {
            try
            {
                ChkTarea1.Checked = false;
                ChkTarea2.Checked = false;
                ChkTarea3.Checked = false;
                ChkTarea4.Checked = false;
                PopDetalleConformidades.ShowOnPageLoad = false;
                PopIniciarProceso.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAceptarIniciarProceso_Click(object sender, EventArgs e)
        {
            try
            {
                CONFORMIDAD objConformidad = new CONFORMIDAD();
                objConformidad.COPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objConformidad.COPVC_USUARIO = _objUsuario.Matricula;
                objConformidad.COPVC_NOMBRE = _objUsuario.NombreCompleto;
                objConformidad.COPVC_AREA = "SISTEMAS";
                objConformidad.COPVC_PROCESO = "NIVEL 0 - INICIO DEL PROCESO";
                objConformidad.COPVC_ID_RESPONSABLE = string.Empty;
                objConformidad.COPVC_ESTADO = "INICIO";
                objConformidad.COPVC_OBSERVACION = string.Empty;
                var objResult = _cPersonales.RegistrarConformidad(objConformidad);
                if (objResult != null)
                {
                    var objDataSet = (DataSet)Session["CONFORMIDADES"];
                    var objDSetCorreo = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_RESTANTES",
                    new List<CParameter>() {
                        new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new CParameter() { Key = "@ID_NIVEL", Value = "PRD-NIVEL-00" } });
                    string strNivelNuevo = string.Empty;
                    for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                        if (objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString() == objDSetCorreo.Tables[0].Rows[0][2].ToString())
                            strNivelNuevo = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                    var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(objDSetCorreo.Tables[0].Rows[0][2].ToString(), "RESPONSABLE");
                    var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                    List<string> listaMailTOInf = new List<string>();
                    foreach (var objResponsable in listaResponsables)
                    {
                        var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                        if (objUsuario != null)
                            listaMailTOInf.Add(objUsuario.USPVC_CORREO);
                    }
                    List<string> listaMailCCInf = new List<string>();
                    var listaLexicoMail = _cPersonales.GetListLexicoPorTablaYTema(objDSetCorreo.Tables[0].Rows[0][2].ToString(), "MAIL-INF-CC");
                    if (listaLexicoMail.Count > 0)
                        listaMailCCInf = listaLexicoMail.First().LEPVC_VALOR.Split(';').ToList();
                    string strHtmlInf = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_INICIO.html"));
                    strHtmlInf = strHtmlInf.Replace("#PERIODO#", _strPeriodoContable);
                    strHtmlInf = strHtmlInf.Replace("#NIVEL#", strNivelNuevo);
                    strHtmlInf = strHtmlInf.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    strHtmlInf = strHtmlInf.Replace("#NOTAS#", objDSetCorreo.Tables[0].Rows[0][3].ToString());
                    var objCorreo = Correo.Enviar(new ocp_correo
                    {
                        ListaCorreoDestinatario = listaMailTOInf,
                        ListaCorreoCopia = listaMailCCInf,
                        Asunto = "CIERRE MENSUAL (" + _strPeriodoContable + ") - HABILITADO: " + strNivelNuevo,
                        Prioridad = System.Net.Mail.MailPriority.High,
                        Contenido = strHtmlInf,
                        FlagHtml = true,
                        ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                    });
                    ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "toastr.success", "toastr.success('El proceso de conformidades ha sido iniciado.', 'CIERRE MENSUAL (" + _strPeriodoContable + ")', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                PopIniciarProceso.ShowOnPageLoad = false;
                PopDetalleConformidades.ShowOnPageLoad = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCancelarIniciarProceso_Click(object sender, EventArgs e)
        {
            try
            {
                PopIniciarProceso.ShowOnPageLoad = false;
                GrvConformidades.DataBind();
                PopDetalleConformidades.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}