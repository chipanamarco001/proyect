﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Web;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Presentacion.Sitio.Controladores.Documentos;
using DevExpress.Compression;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Lib;
using Presentacion.Parametros;
using Agente.ServicioCrediseguro;
using DevExpress.Web.Bootstrap;
using Agente.ServicioDocumentos;
using System.Text;
using System.Globalization;

namespace Presentacion.Sitio.Vista.Produccion
{
    public partial class BandejaOperaciones : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                //polizas vencidas
                Session.Remove("BandejaGestionarPoliza");
                var listaPolizasVencidas = _cPersonales.ListaPolizasRenovacionAmpliacion();
                PnlPolizasVencidas.Visible = false;
                if (listaPolizasVencidas.Count > 0)
                {
                    PnlPolizasVencidas.Visible = true;
                    Session["BandejaGestionarPoliza"] = listaPolizasVencidas;
                    GrvPolizas.DataBind();
                }
                //fin - polizas vencidas
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                var listaBandeja = _cPersonales.GetListaBandejaProduccion(_strPeriodoContable);
                foreach (var objPolizaVencida in listaPolizasVencidas)
                {
                    var objBandeja = listaBandeja.Find(e => e.ID_PRODUCTO == objPolizaVencida.IdProducto && e.FLAG_PRODUCCION == true);
                    if (objBandeja != null)
                        objBandeja.FLAG_PRODUCCION = false;
                }
                GrvBandeja.DataSource = listaBandeja;
                GrvBandeja.DataBind();
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                GrvBandeja.Columns[11].Visible = true;
                GrvBandeja.Columns[12].Visible = true;
                GrvBandeja.Columns[13].Visible = true;
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                DateTime dtPeriodoProcesoActual = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                if (objUsuario.Area != "OPERACIONES" || dtPeriodoProceso < dtPeriodoProcesoActual)
                {
                    GrvBandeja.Columns[11].Visible = false;
                    GrvBandeja.Columns[12].Visible = false;
                    GrvBandeja.Columns[13].Visible = false;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvBandeja_PreRender(object sender, EventArgs e)
        {
            try
            {
                foreach (GridViewRow row in GrvBandeja.Rows)
                {
                    Image ImgCargaCompleta = (Image)row.FindControl("ImgCargaCompleta");
                    Image ImgCargaIncompleta = (Image)row.FindControl("ImgCargaIncompleta");
                    Image ImgArchivo = (Image)row.FindControl("ImgArchivo");
                    Image ImgServicio = (Image)row.FindControl("ImgServicio");
                    Image ImgProduccion = (Image)row.FindControl("ImgProduccion");
                    Label LblIdProducto = (Label)row.FindControl("LblIdProducto");
                    Label LblCarga = (Label)row.FindControl("LblCarga");
                    Label LblProduccion = (Label)row.FindControl("LblProduccion");
                    Label LblFlagProducido = (Label)row.FindControl("LblFlagProducido");
                    Label LblDocumentos = (Label)row.FindControl("LblDocumentos");
                    Image ImgDocumentos = (Image)row.FindControl("ImgDocumentos");

                    ImgDocumentos.Visible = false;
                    ImgCargaCompleta.Visible = false;
                    ImgCargaIncompleta.Visible = true;
                    if (LblFlagProducido.Text == "1")
                    {
                        ImgCargaCompleta.Visible = true;
                        ImgCargaIncompleta.Visible = false;
                        ImgDocumentos.Visible = (LblDocumentos.Text != string.Empty) ? true : false;
                    }
                    else if (LblIdProducto.Text == "ECOAMP") { ImgDocumentos.Visible = true; }
                    ImgArchivo.Visible = false;
                    ImgServicio.Visible = false;
                    switch (LblIdProducto.Text)
                    {
                        case "MULBCP":
                        case "SEGRPT":
                        case "MSVBCP":
                        case "DERBCP":
                        case "SEGDES":
                        case "DESKCB":
                            if (LblCarga.Text.ToUpper() == "TRUE")
                                ImgServicio.Visible = true;
                            break;
                        default:
                            if (LblCarga.Text.ToUpper() == "TRUE")
                                ImgArchivo.Visible = true;
                            break;
                    }
                    ImgProduccion.Visible = false;

                    if (LblProduccion.Text.ToUpper() == "TRUE") { ImgProduccion.Visible = true; }

                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvBandeja_RowCommand(Object sender, GridViewCommandEventArgs e)
        {
            try
            {
                GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                string strIdProducto = ((Label)gvr.FindControl("LblIdProducto")).Text.Trim();
                string strNombreProducto = ((Label)gvr.FindControl("LblNombreProducto")).Text.Trim();
                Label LblFlagProducido = (Label)gvr.FindControl("LblFlagProducido");
                Session["PRODUCTO_PRODUCIDO"] = LblFlagProducido.Text == "1" ? "TRUE" : "FALSE";
                string script = string.Empty;
                LblCargarComentario.Text = string.Empty;
                switch (e.CommandName)
                {
                    case "CARGA":
                        switch (strIdProducto)
                        {
                            case "MSVBCP":
                            case "MULBCP":
                            case "SEGRPT":
                            case "SEGRDI":
                            case "SEGDES":
                            case "DERBCP":
                            case "DESKCB":
                                PopEjecutarServicio.HeaderText = strNombreProducto;
                                PopEjecutarServicio.ShowOnPageLoad = true;
                                break;                            
                            case "SEGECP":
                            case "SEGECV":
                                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt" };
                                PopCargarArchivo.HeaderText = strNombreProducto;
                                PopCargarArchivo.ShowOnPageLoad = true;
                                break;
                            case "DDIKCB":
                            case "DDIKCC":
                            case "DDIKCV":
                                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
                                PopCargarArchivo.HeaderText = strNombreProducto;
                                PopCargarArchivo.ShowOnPageLoad = true;
                                break;
                            default:
                                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
                                PopCargarArchivo.HeaderText = strNombreProducto;
                                PopCargarArchivo.ShowOnPageLoad = true;
                                LblCargarComentario.Text = (strIdProducto == "VGCECA" || strIdProducto == "VGCECR") ? "NOTA: Este archivo debe contener obligatoriamente las pestañas 'EMITIDOS' y 'DESISTIMIENTOS' o podría presentarse un error en la carga de datos." : string.Empty;
                                break;
                        }
                        Session["DatosProducto"] = strIdProducto + "|" + strNombreProducto;
                        break;
                    case "PRODUCCION":
                        string strProcedimiento = ((Label)gvr.FindControl("LblProcedimiento")).Text.Trim();
                        PopProduccion.ShowOnPageLoad = true;
                        Session["DatosProducto"] = strIdProducto + "|" + strProcedimiento;
                        PopProduccion.HeaderText = strNombreProducto;
                        break;
                    case "DOCUMENTOS":
                        string strDocumentos = ((Label)gvr.FindControl("LblDocumentos")).Text.Trim();
                        if (strDocumentos != string.Empty)
                        {
                            string[] strItems = strDocumentos.Split(',');
                            var DtblDocumentos = new DataTable();
                            DtblDocumentos.Columns.Clear();
                            DtblDocumentos.Columns.Add("ID_PRODUCTO", typeof(string));
                            DtblDocumentos.Columns.Add("ID_DOCUMENTO", typeof(string));
                            DtblDocumentos.Columns.Add("NOMBRE", typeof(string));
                            DtblDocumentos.Columns.Add("FORMATO", typeof(string));
                            for (int index = 0; index < strItems.Count(); index++)
                            {
                                DataRow dr = DtblDocumentos.NewRow();
                                dr["ID_PRODUCTO"] = strIdProducto;
                                dr["ID_DOCUMENTO"] = strItems[index].Split('|')[0];
                                dr["NOMBRE"] = strItems[index].Split('|')[1];
                                dr["FORMATO"] = strItems[index].Split('|')[2];
                                DtblDocumentos.Rows.Add(dr);
                            }
                            GrvDocumentos.DataSource = DtblDocumentos;
                            GrvDocumentos.DataBind();
                            PopDocumentos.HeaderText = strNombreProducto;
                            PopDocumentos.ShowOnPageLoad = true;
                        }
                        break;

                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvDocumentos_PreRender(object sender, EventArgs e)
        {
            try
            {
                foreach (GridViewRow row in GrvDocumentos.Rows)
                {
                    Label LblTipoDocumento = (Label)row.FindControl("LblTipoDocumento");
                    ImageButton ImgDownload = (ImageButton)row.FindControl("ImgDownload");
                    var c = Session["PRODUCTO_PRODUCIDO"].ToString();
                    if (Session["PRODUCTO_PRODUCIDO"].ToString() == "TRUE" || LblTipoDocumento.Text == "REPORTE")
                        ImgDownload.Visible = true;
                    else
                        ImgDownload.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvDocumentos_RowCommand(Object sender, GridViewCommandEventArgs e)
        {
            try
            {
                GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                string strIdProducto = ((Label)gvr.FindControl("LblIdProducto")).Text.Trim();
                string strIdDocumento = ((Label)gvr.FindControl("LblIdDocumento")).Text.Trim();
                string strFormato = ((Label)gvr.FindControl("LblFormato")).Text.Trim();
                string strTipoDocumento = ((Label)gvr.FindControl("LblTipoDocumento")).Text.Trim();
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                bool boolHistorico = false;
                if (_strPeriodoContable != strPeriodoProceso)
                    boolHistorico = true;
                switch (strTipoDocumento.Split('-')[0].Trim())
                {

                    case "REPORTE":
                        switch (strIdProducto)
                        {
                            case "ECOAMP":
                            case "MSVBCP":
                            case "CRSVSP":
                            case "VGSPBC":
                            case "ONCBCP":
                            case "SEGECP":
                            case "DESBDP":
                                Session["DOWNLOAD"] = ReportePorProducto(
                                    _strPeriodoContable,
                                    strIdProducto,
                                    strIdDocumento,
                                    _strPeriodoContable,
                                    strFormato);
                                break;
                            case "VDIACO":
                                Session["DOWNLOAD"] = new OC_ARCHIVO()
                                {
                                    BYTE_ARRAY = File.ReadAllBytes(CParametros.RutaArchivoDatos + "VDIACO_Afiliaciones_" + _strPeriodoContable + ".xlsx"),
                                    CONTENT_TYPE = "application/vnd.ms-excel",
                                    NOMBRE_ARCHIVO = "VDIACO_Reporte_" + _strPeriodoContable + ".xlsx"
                                };
                                break;
                        }
                        break;
                    case "LIQUIDACION":
                        switch (strIdProducto)
                        {
                            case "VGESCO":
                            case "CRSVSP":
                                Session["DOWNLOAD"] = LiquidacionPorPoliza(strIdProducto, strIdDocumento, strFormato, boolHistorico);
                                break;
                            case "DESBDP":
                                Session["DOWNLOAD"] = LiquidacionBDP(strIdDocumento);
                                break;
                            default:
                                Session["DOWNLOAD"] = LiquidacionPorProducto(strIdProducto, strIdDocumento, strFormato, boolHistorico);
                                break;
                        }
                        break;
                    case "ASISTENCIAS":
                        switch (strIdProducto)
                        {
                            case "SEGECP":
                            case "MASVJE":
                                Session["DOWNLOAD"] = DocumentoAsistencias(strIdProducto, strIdDocumento, strFormato, boolHistorico,
                                    _strPeriodoContable,
                                    (strTipoDocumento.Split('-').Count() > 1) ? strTipoDocumento.Split('-')[1].Trim() : string.Empty);
                                break;
                        }
                        break;
                    case "CERTIFICADOS":
                        if (strIdProducto == "VGESCO")
                            Session["DOWNLOAD"] = VGESCO_Certificados();
                        if (strIdProducto == "CHKAVE")
                        {
                            var objLiquidacion = _cPersonales.ObtenerListaLiquidacionesPorPeriodoYProducto(_strPeriodoContable, strIdProducto).OrderByDescending(o => o.LIPBI_ID_LIQUIDACION).First();
                            Session["DOWNLOAD"] = CHKAVE_Certificados(strIdDocumento, objLiquidacion.LIPBI_ID_LIQUIDACION);
                        }
                        break;
                    case "FORMULARIO PCC04":
                        DataSet dsetFormularios = _cPersonales.FormularioPCC04_ProduccionBancaSeguros(_strPeriodoContable, strIdProducto);
                        var objZipArchive = new ZipArchive();
                        if (dsetFormularios.Tables[0].Rows.Count > 0)
                        {
                            for (int index = 0; index < dsetFormularios.Tables[0].Rows.Count; index++)
                            {
                                long longIdFormulario = Convert.ToInt64(dsetFormularios.Tables[0].Rows[index][0].ToString());
                                var objDocumentoPCC04 = _cDocumentos.GetFormularioPCC04(longIdFormulario);
                                objZipArchive.AddByteArray(objDocumentoPCC04.NombreArchivo, objDocumentoPCC04.ByteArray);
                            }
                            using (MemoryStream stream = new MemoryStream())
                            {
                                objZipArchive.Save(stream);
                                Session["DOWNLOAD"] = new OC_ARCHIVO() { 
                                    BYTE_ARRAY = stream.ToArray(), 
                                    CONTENT_TYPE = "application/zip", 
                                    NOMBRE_ARCHIVO = strIdProducto + "_FormularioPCC04_" + _strPeriodoContable + ".zip" };
                                stream.Close();
                            }
                        }
                        else
                        {
                            Session.Remove("DOWNLOAD");
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                                "toastr.info('La prima del producto seleccionado no supera el límite para la emisión del Formulario PCC04.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        }
                        break;
                    default:
                         var objArchivoRespuesta = _cDocumentos.Documento_Generar(
                            strIdDocumento,
                            new List<occ_response_file__parametro>() {
                                new occ_response_file__parametro { Nombre = "strPeriodoContable", Valor = _strPeriodoContable },
                                new occ_response_file__parametro { Nombre = "strIdProducto", Valor = strIdProducto }
                            });
                        Session["DOWNLOAD"] = new OC_ARCHIVO {
                            BYTE_ARRAY = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc))),
                            CONTENT_TYPE = objArchivoRespuesta.ContentType,
                            NOMBRE_ARCHIVO = objArchivoRespuesta.NombreArchivo
                        };
                        break;
                }
                if (Session["DOWNLOAD"] != null)
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }                
        protected void BtnProduccion_Click(object sender, EventArgs e)
        {
            try
            {
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                if (Session["PERIODO_CONTABLE"] != null && Session["PERIODO_CONTABLE"].ToString() == strPeriodoProceso)
                {
                    string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
                    string strIdProducto = strDatosProducto[0];
                    bool boolEjecutarProceso = true;
                    string strMensaje = string.Empty;
                    if (strIdProducto == "SEGDES" || strIdProducto == "DERBCP")
                    {
                        if (Session["DATOS_ARCHIVO_CARGADO"] != null && Session["ARCHIVO_CARGADO"] != null)
                        {
                            var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
                            var DtblDatosArchivo = (DataTable)Session["DATOS_ARCHIVO_CARGADO"];
                            var boolResponseReproceso = false;
                            switch (strIdProducto)
                            {
                                case "DERBCP": boolResponseReproceso = _cCrediseguro.DERBCP_ReprocesarRecargos(_strPeriodoContable); break;
                                case "SEGDES": boolResponseReproceso = _cCrediseguro.SEGDES_ReprocesarRecargos(_strPeriodoContable); break;
                            }
                            if (boolResponseReproceso)
                            {
                                for (int index = 0; index < DtblDatosArchivo.Rows.Count; index++)
                                    if (DtblDatosArchivo.Rows[index][0].ToString().Trim() != string.Empty)
                                    {
                                        var boolResponseRecargo = false;
                                        switch (strIdProducto)
                                        {
                                            case "DERBCP":
                                                boolResponseRecargo = _cCrediseguro.DERBCP_RegistrarRecargo(
                                                    _strPeriodoContable,
                                                    (strIdProducto == "DERBCP" ? "R_" : string.Empty) + DtblDatosArchivo.Rows[index][0].ToString().Trim(),
                                                    Convert.ToDecimal(DtblDatosArchivo.Rows[index][1].ToString().Trim()),
                                                    Convert.ToDecimal(DtblDatosArchivo.Rows[index][2].ToString().Trim()));
                                                break;
                                            case "SEGDES":
                                                boolResponseRecargo = _cCrediseguro.SEGDES_RegistrarRecargo(
                                                    _strPeriodoContable,
                                                    DtblDatosArchivo.Rows[index][0].ToString().Trim(),
                                                    Convert.ToDecimal(DtblDatosArchivo.Rows[index][1].ToString().Trim()),
                                                    Convert.ToDecimal(DtblDatosArchivo.Rows[index][2].ToString().Trim()));
                                                break;
                                        }
                                        if (!boolResponseRecargo)
                                        {
                                            strMensaje = "El recargo de al menos una operación no pudo ser registrada en la base de datos, por favor revise la existencia de las operaciones en la liquidación del mes.";
                                            boolEjecutarProceso = false;
                                        }
                                    }
                                if (boolEjecutarProceso)
                                {
                                    if (File.Exists(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION))
                                        File.Delete(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION);
                                    File.WriteAllBytes(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION, objArchivo.BYTE_ARRAY);
                                }
                            }
                            else
                            {
                                strMensaje = "Se ha presentado un error al momento de preparar el proceso de recargos.";
                                boolEjecutarProceso = false;
                            }
                        }
                    }
                    //ejecutamos el procedimiento relacionado al producto
                    PopProduccion.ShowOnPageLoad = false;
                    if (boolEjecutarProceso)
                    {
                        var DsetDatos = _cPersonales.GetDatasetProcedimiento(strDatosProducto[1],
                            new List<Agente.ServicioPersonales.CParameter>() {
                                new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                                new Agente.ServicioPersonales.CParameter() { Key = "@USUARIO", Value = _objUsuario.Matricula } });
                        //string[] datosPagina = Request.CurrentExecutionFilePath.Split('/');
                        //string ruta = string.Empty;
                        //for (int index = 1; index < datosPagina.Length - 1; index++)
                        //{
                        //    if (ruta != string.Empty) { ruta += "/"; }
                        //    ruta += datosPagina[index];
                        //}
                        //string pagina = datosPagina[datosPagina.Length - 1];
                        //Conversor.RegistrarLogProcedimiento(ruta, pagina, nombreProcedimiento, _user.UserId);//log
                        PopProduccion.ShowOnPageLoad = false;
                        CargaInicial();
                        //LoadingPanel.Visible = false;
                        //PnlMessageSuccess.Visible = true;
                        //LblMessageSuccess.Text = "El proceso de producción del producto seleccionado ha finalizado con éxito.";
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "PRD", "toastr.success('El proceso de producción del producto seleccionado ha finalizado con éxito.', 'PRODUCCIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001",
                            "toastr.error('" + strMensaje + "', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "999", "toastr.error('La producción no puede ejecutarse en un periodo contable diferente al establecido para el mes en curso.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnEjecutarServicio_Click(object sender, EventArgs e)
        {
            try
            {
                string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
                string strIdProducto = strDatosProducto[0];
                var boolCargaCompleta = false;
                if (strIdProducto == "DESKCB")
                    boolCargaCompleta = _cCrediseguro.BCP_DesgravamenCapitalConstante(_strPeriodoContable);
                else
                    boolCargaCompleta = _cCrediseguro.BCP_RegistrarDatos(_strPeriodoContable, strIdProducto);
                if (boolCargaCompleta)
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El proceso de carga de datos ha sido completado exitosamente..', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                else
                    throw new Exception("Se ha presentado un error en la carga de los datos a la base de datos ('BtnEjecutarServicio_Click'). Revise el servicio Crediseguro.Core.");
                PopEjecutarServicio.ShowOnPageLoad = false;
                CargaInicial();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }

        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
                string strIdProducto = strDatosProducto[0];
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                DataTable DtblDatos = new DataTable();
                switch (strIdProducto)
                {
                    case "SEGECP":
                    case "SEGECV":
                        DtblDatos.Columns.Add(new DataColumn("Column1"));
                        using (StreamReader reader = new StreamReader(uploadedFile.FileContent))
                        {
                            do
                            {
                                string strTextLine = reader.ReadLine();
                                DataRow dr = DtblDatos.NewRow();
                                dr[0] = strTextLine;
                                DtblDatos.Rows.Add(dr);
                            } while (reader.Peek() != -1);
                        }
                        break;
                }
                Session["DATOS_ARCHIVO_CARGADO"] = DtblDatos;
                Session["ARCHIVO_CARGADO"] = new OC_ARCHIVO()
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void MostrarLogErrores(List<string> listaErrores, string strIdProducto)
        {
            try
            {
                string strNombreArchivo = strIdProducto + "_VALIDACION_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt";
                StreamWriter writer = new StreamWriter(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo, true);
                writer.Write("***** VALIDACIÓN DE DATOS: " + strIdProducto + " *****");
                writer.Write(Environment.NewLine);
                foreach (string strError in listaErrores)
                    writer.WriteLine(strError);
                writer.Write("***** FIN DE LA VALIDACIÓN *****");
                writer.Flush();
                writer.Close();
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ERROR_CARGA.html"));
                var objCorreo1 = Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = new List<string>() { _objUsuario.Correo },
                    ListaCorreoCopia = Parametros.CParametros.ListaCorreoCopiaSistemas,
                    Asunto = "ERROR EN ARCHIVO SELECCIONADO (" + strIdProducto + ") - SISTEMA DE PRODUCCIÓN",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } },
                    ListaArchivosAdjuntos = new List<ocp_correo_archivo_adjunto>() {
                        new ocp_correo_archivo_adjunto {
                            FlagBytes = true,
                            Bytes = File.ReadAllBytes(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo),
                            Nombre = strNombreArchivo } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
                string strIdProducto = strDatosProducto[0];
                if (Session["DATOS_ARCHIVO_CARGADO"] == null || Session["ARCHIVO_CARGADO"] == null)
                    throw new Exception("Se ha encontrado un problema con el archivo seleccionado ('BtnProcesarArchivo_Click').");
                DataTable DtblDatos = (DataTable)Session["DATOS_ARCHIVO_CARGADO"];
                var listaErrores = new List<string>();
                bool boolEsExcel = false;
                var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
                switch (strIdProducto)
                {
                    case "SEGECP":
                    case "SEGECV":
                        int intNumeroColumnas = (strIdProducto == "SEGECP") ? 43 : ((strIdProducto == "SEGECV") ? 37 : 0);
                        DataTable DtblDatosAuxiliar = new DataTable();
                        for (int index = 0; index < intNumeroColumnas; index++)
                            DtblDatosAuxiliar.Columns.Add(new DataColumn("Column" + (index + 1)));
                        for (int index = 0; index < DtblDatos.Rows.Count; index++)
                        {
                            string strTextLine = DtblDatos.Rows[index][0].ToString();
                            string[] datos = strTextLine.Split('|');
                            if (datos.Length != intNumeroColumnas)
                                listaErrores.Add("Error en la fila '" + (index + 1) + "': El número de columnas proporcionadas es incorrecto.");
                            else
                            {
                                DataRow dr = DtblDatosAuxiliar.NewRow();
                                for (int intColumna = 0; intColumna < intNumeroColumnas; intColumna++)
                                    dr[intColumna] = datos[intColumna];
                                DtblDatosAuxiliar.Rows.Add(dr);
                            }
                        }
                        var listaValidaciones = (strIdProducto == "SEGECP") ? _validacionCarga.Validacion_SEGECP(DtblDatosAuxiliar) : ((strIdProducto == "SEGECV") ? _validacionCarga.Validacion_SEGECV(DtblDatosAuxiliar) : new List<string>());
                        if (listaValidaciones.Count > 0)
                        {
                            foreach (var strError in listaValidaciones)
                                listaErrores.Add(strError);
                        }
                        break;
                    case "VGCECA":
                    case "VGCECR":
                        boolEsExcel = false; ///se saltara el proceso de seleccion de pestaña
                        break;
                    default:
                        boolEsExcel = true;
                        break;
                }
                if (!boolEsExcel)
                {
                    if (listaErrores.Count > 0)
                    {
                        MostrarLogErrores(listaErrores, strIdProducto);
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se han encontrado observaciones en el archivo seleccionado, se le ha enviado un correo con un detalle de las observaciones para su revisión.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                    else
                    {
                        string strNombreArchivo = strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION;
                        if (File.Exists(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION))
                            File.Delete(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION);
                        File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo, objArchivo.BYTE_ARRAY);
                        bool boolCargaCompleta = false;
                        switch (strIdProducto)
                        {
                            case "SEGECP":
                                boolCargaCompleta = _cCrediseguro.SEGECP_RegistrarDatos(_strPeriodoContable, true, strNombreArchivo);
                                break;
                            case "SEGECV":
                                boolCargaCompleta = _cCrediseguro.SEGECV_RegistrarDatos(_strPeriodoContable, true, strNombreArchivo);
                                break;
                            case "VGCECA":
                            case "VGCECR":
                                boolCargaCompleta = _cCrediseguro.Ecofuturo_RegistrarDatos(_strPeriodoContable, strIdProducto, strNombreArchivo);
                                if (!boolCargaCompleta)
                                {
                                    throw new Exception("Se ha presentado un error en la carga de los datos ('BtnProcesarArchivo_Click'). Revise el servicio Crediseguro.Core.");
                                }
                                boolCargaCompleta = _cCrediseguro.Ecofuturo_RegistrarAnulacion(_strPeriodoContable, strIdProducto, strNombreArchivo);
                                break;
                        }
                        if (boolCargaCompleta)
                        {
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El proceso de carga de datos ha sido completado exitosamente..', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        }
                        else
                        {
                            throw new Exception("Se ha presentado un error en la carga de los datos ('BtnProcesarArchivo_Click'). Revise el servicio Crediseguro.Core.");
                        }
                    }
                    PopCargarArchivo.ShowOnPageLoad = false;
                    CargaInicial();
                }
                else
                {
                    PopWorksheet.HeaderText = strDatosProducto[1];
                    PopCargarArchivo.ShowOnPageLoad = false;
                    //
                    ChkReprocesoWorksheet.Checked = false;
                    ChkReprocesoWorksheet.ClientEnabled = true;
                    string[] strListaProductos = { "VGDCVN", "VCDIAF", "VCDIAS", "VCDIAV", "VDIASM", "DESCSL", "DESECO", "VGCECA", "VGCECR", "VGTNEX" };
                    if (strListaProductos.Contains(strIdProducto))
                    {
                        ChkReprocesoWorksheet.Checked = true;
                        ChkReprocesoWorksheet.ClientEnabled = false;
                    }
                    if (strIdProducto == "VGESCO")
                    {
                        ChkReprocesoWorksheet.Checked = false;
                        ChkReprocesoWorksheet.ClientEnabled = false;
                    }
                    //
                    PopWorksheet.ShowOnPageLoad = true;
                    CmbWorksheet.Items.Clear();
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(objArchivo.BYTE_ARRAY, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        CmbWorksheet.Items.Add(new DevExpress.Web.Bootstrap.BootstrapListEditItem(DEWorksheet.Name, DEWorksheet.Name));
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarExcel_Click(object sender, EventArgs e)
        {
            try
            {
                string strMensajeCargaCompleta = "El proceso de carga de datos ha sido completado exitosamente.";
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
                string strIdProducto = strDatosProducto[0];
                var listaErrores = new List<string>();
                DataTable DtblDatosAuxiliar = new DataTable();
                var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
                switch (strIdProducto)
                {
                    case "VGESCO":
                        //validar informacion
                        break;
                    case "ECOMEV":
                        //validar informacion
                        break;
                }
                PopWorksheet.ShowOnPageLoad = false;
                if (listaErrores.Count > 0)
                {
                    MostrarLogErrores(listaErrores, strIdProducto);
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se han encontrado observaciones en el archivo seleccionado, se le ha enviado un correo con un detalle de las observaciones para su revisión.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                {
                    string strNombreArchivo = strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION;
                    if (File.Exists(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION))
                        File.Delete(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION);
                    File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo, objArchivo.BYTE_ARRAY);
                    bool boolCargaCompleta = false;
                    switch (strIdProducto)
                    {
                        case "VGESCO":
                            boolCargaCompleta = _cCrediseguro.VGESCO_RegistrarDatos(_strPeriodoContable, ChkReprocesoWorksheet.Checked, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "ECOMEV":
                            boolCargaCompleta = _cCrediseguro.ECOMEV_RegistrarDatos(_strPeriodoContable, ChkReprocesoWorksheet.Checked, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "VGDCVN":
                        case "VCDIAF":
                        case "VCDIAS":
                        case "VCDIAV":
                        case "VCDIBP":
                        case "VDIASM":
                        case "VDIAMT":
                            boolCargaCompleta = _cCrediseguro.RegistrarDatosDiaconiaVida(strIdProducto, _strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "DESDIA":
                            boolCargaCompleta = _cCrediseguro.DESDIA_RegistrarDatos(_strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "CHKAVE":
                            boolCargaCompleta = _cCrediseguro.CHKAVE_RegistrarDatos(_strPeriodoContable, ChkReprocesoWorksheet.Checked, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "DESCSL":
                            boolCargaCompleta = _cCrediseguro.DESCSL_RegistrarDatos(_strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "DESECO":
                            boolCargaCompleta = _cCrediseguro.DESECO_RegistrarDatos(_strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "VGTNEX":
                            boolCargaCompleta = _cCrediseguro.VGTNEX_RegistrarDatos(_strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                        case "DDIKCB":
                        case "DDIKCC":
                        case "DDIKCV":
                            boolCargaCompleta = _cCrediseguro.DESDIA_CAP_CONSTANTE_RegistrarDatos(_strPeriodoContable, strNombreArchivo, CmbWorksheet.SelectedItem.Value.ToString());
                            break;
                    }
                    if (boolCargaCompleta)
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('" + strMensajeCargaCompleta + "', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    else
                        throw new Exception("Se ha presentado un error en la carga de los datos a la base de datos ('BtnProcesarExcel_Click'). Revise el servicio Crediseguro.Core.");
                }
                CargaInicial();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }

        }        
        void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            if (e.CellValue.IsEmpty && e.DataColumn.DataType == typeof(DateTime))
            {
                e.DataTableValue = DBNull.Value;
                e.Action = DataTableExporterAction.Continue;
            }
        }
        protected OC_ARCHIVO LiquidacionBDP(string strIdDocumento)
        {
            try
            {
                var objZipArchive = new ZipArchive();
                var objOCArchivo = new OC_ARCHIVO();
                var listaDocumentos = _cDocumentos.GetLiquidacionDESBDP(strIdDocumento, _strPeriodoContable);
                foreach (var objDocumento in listaDocumentos)
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                    objZipArchive.AddByteArray(objDocumento.NombreArchivo, File.ReadAllBytes(strRutaArchivoEnc));
                }
                using (MemoryStream stream = new MemoryStream())
                {
                    objZipArchive.Save(stream);
                    objOCArchivo = new OC_ARCHIVO() { BYTE_ARRAY = stream.ToArray(), CONTENT_TYPE = "application/zip", NOMBRE_ARCHIVO = "DESBDP_Liquidacion_" + _strPeriodoContable + ".zip" };
                    stream.Close();
                }
                return objOCArchivo;
            }
            catch
            {
                throw;
            }
        }
        protected void GrvPolizas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["BandejaGestionarPoliza"] == null)
                    Session["BandejaGestionarPoliza"] = new List<OCC_Bandeja_Renovacion_Ampliacion>();
                GrvPolizas.DataSource = ((List<OCC_Bandeja_Renovacion_Ampliacion>)Session["BandejaGestionarPoliza"]).OrderBy(o => o.FinVigencia);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected OC_ARCHIVO CHKAVE_Certificados(string strIdDocumento, long longIdLiquidacion)
        {
            try
            {
                var objDocumento = _cDocumentos.CHKAVE_GenerarCertificados(strIdDocumento, longIdLiquidacion);
                string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                return new OC_ARCHIVO() { 
                    BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), 
                    CONTENT_TYPE = objDocumento.ContentType, 
                    NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO LiquidacionPorProducto(
            string strIdProducto,
            string strIdDocumento,
            string strFormato,
            bool boolHistorico)
        {
            try
            {
                var objDocumento = _cDocumentos.GetDocumento(
                    strIdDocumento,
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NUMERO_POLIZA", Value = string.Empty }
                    },
                    new Agente.ServicioDocumentos.OC_RESPONSE_FILE
                    {
                        NombreArchivo = strIdProducto + "_Liquidacion_" + _strPeriodoContable,
                        CarpetaSalida = _strPeriodoContable,
                        BoolHistorico = boolHistorico,
                        FormatoSalida = strFormato
                    });
                string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                return new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO LiquidacionPorProductoYPoliza(
           string strIdProducto,
           string strIdDocumento,
           string strFormato,
           bool boolHistorico)
        {
            try
            {
                var objDocumento = _cDocumentos.GetDocumento(
                    strIdDocumento,
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NUMERO_POLIZA", Value = string.Empty }
                    },
                    new OC_RESPONSE_FILE() { NombreArchivo = strIdProducto + "_Liquidacion_" + _strPeriodoContable, CarpetaSalida = _strPeriodoContable, BoolHistorico = boolHistorico, FormatoSalida = strFormato });
                return new OC_ARCHIVO() { BYTE_ARRAY = objDocumento.ByteArray, CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO LiquidacionPorPoliza(
            string strIdProducto,
            string strIdDocumento,
            string strFormato,
            bool boolHistorico
            )
        {
            try
            {
                var objZipArchive = new ZipArchive();
                var listaPolizas = _cPersonales.GetListaPolizasPorLiquidacion(_strPeriodoContable, strIdProducto);
                var objDocumento = new OC_RESPONSE_FILE();
                var objOCArchivo = new OC_ARCHIVO();
                foreach (var strNumeroPoliza in listaPolizas)
                {
                    objDocumento = _cDocumentos.GetDocumento(
                        strIdDocumento,
                        new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                                new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                                new Agente.ServicioDocumentos.CParameter() { Key = "@NUMERO_POLIZA", Value = strNumeroPoliza }
                        },
                        new OC_RESPONSE_FILE() { NombreArchivo = strIdProducto + "_Liquidacion_" + _strPeriodoContable + " (" + strNumeroPoliza + ")", CarpetaSalida = _strPeriodoContable, BoolHistorico = boolHistorico, FormatoSalida = strFormato });
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                    objZipArchive.AddByteArray(objDocumento.NombreArchivo, File.ReadAllBytes(strRutaArchivoEnc));
                }
                using (MemoryStream stream = new MemoryStream())
                {
                    objZipArchive.Save(stream);
                    objOCArchivo = new OC_ARCHIVO() { BYTE_ARRAY = stream.ToArray(), CONTENT_TYPE = "application/zip", NOMBRE_ARCHIVO = strIdProducto + "_Liquidacion_" + _strPeriodoContable + ".zip" };
                    stream.Close();
                }
                return objOCArchivo;
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO DocumentoAsistencias(
            string strIdProducto,
            string strIdDocumento,
            string strFormato,
            bool boolHistorico,
            string strCarpetaSalida,
            string strDescripcion)
        {
            try
            {
                var objDocumento = _cDocumentos.GetDocumento(
                    strIdDocumento,
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable }
                    },
                    new OC_RESPONSE_FILE() { NombreArchivo = strIdProducto + "_Asistencias_" + _strPeriodoContable + ((strDescripcion != string.Empty) ? " (" + strDescripcion + ")" : string.Empty), CarpetaSalida = strCarpetaSalida, BoolHistorico = boolHistorico, FormatoSalida = strFormato });
                string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                return new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO ReportePorProducto(
            string strPeriodoContable,
            string strIdProducto,
            string strIdDocumento,
            string strCarpetaSalida,
            string strFormato
            )
        {
            try
            {
                var objDocumento = _cDocumentos.GetReporteProducto(
                    strIdProducto,
                    strIdDocumento,
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = strPeriodoContable },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto }
                    },
                    new OC_RESPONSE_FILE() { NombreArchivo = strIdProducto + "_Reporte_" + _strPeriodoContable, CarpetaSalida = strCarpetaSalida, BoolHistorico = false, FormatoSalida = strFormato });
                return new OC_ARCHIVO() { BYTE_ARRAY = objDocumento.ByteArray, CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
            }
            catch
            {
                throw;
            }
        }
        protected OC_ARCHIVO VGESCO_Certificados()
        {
            try
            {
                var objOCArchivo = new OC_ARCHIVO();
                bool boolCrearCC = _cCrediseguro.VGESCO_GenerarCertificados(_strPeriodoContable);
                if (boolCrearCC)
                {
                    var objZipArchive = new ZipArchive();
                    objZipArchive.AddDirectory(CParametros.RutaCertificados + _strPeriodoContable, "/");
                    using (MemoryStream stream = new MemoryStream())
                    {
                        objZipArchive.Save(stream);
                        objOCArchivo = new OC_ARCHIVO() { BYTE_ARRAY = stream.ToArray(), CONTENT_TYPE = "application/zip", NOMBRE_ARCHIVO = "VGESCO_Certificados_" + _strPeriodoContable + ".zip" };
                        stream.Close();
                    }
                }
                return objOCArchivo;
            }
            catch
            {
                throw;
            }
        }
    }
}