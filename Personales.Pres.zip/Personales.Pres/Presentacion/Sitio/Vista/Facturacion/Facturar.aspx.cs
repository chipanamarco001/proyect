﻿using Agente.ServicioApi.ApiFacturacion.Dto;
using Agente.ServicioCrsApi.ApiFacturacion.Dto;
using Agente.ServicioCrsApi.CrsApiConfig;
using DocumentFormat.OpenXml.Wordprocessing;
using Presentacion.Sitio.Controladores.ApiFacturacion;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Facturacion
{
    public partial class Facturar : System.Web.UI.Page
    {
        FacturacionController _facturacion = new FacturacionController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }

            CargaInicial();
        }

        #region Metodos

        public void CargaInicial()
        {
            try
            {
                var lexicoRequest = new LexicoTablaTemaRequest();
                lexicoRequest.tabla = "FACTURA";
                lexicoRequest.tema = "ESTADO_FACTURA";

                var lstEstadosFactura = _facturacion.ObtenerListaLexicoPorTablaTema(lexicoRequest).GetAwaiter().GetResult();

                cmbEstadoFactura.DataSource = lstEstadosFactura;//.Result.result;
                cmbEstadoFactura.ValueField = "valor";
                cmbEstadoFactura.TextField = "valor";
                cmbEstadoFactura.DataBind();

                txtFechaInicio.Date = DateTime.Now.AddDays(-30);
                txtFechaFin.Date = DateTime.Now;
                cmbEstadoFactura.SelectedIndex = 0;

                txtFechaInicioLote.Date = DateTime.Now.AddDays(-30);
                txtFechaFinLote.Date = DateTime.Now;

                Session["FACTURAS"] = null;
                grdFacturas.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        #endregion

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                var estado = (string)(cmbEstadoFactura.SelectedItem != null ? cmbEstadoFactura.SelectedItem.Value : string.Empty);

                switch (estado)
                {
                    case "PENDIENTE":
                        //selectionLabel.Visible = true;
                        grdFacturas.Columns[0].Visible = true;
                        btnFacturar.Visible = true;
                        btnAnular.Visible = true;
                        break;
                    case "FACTURADO":
                        //selectionLabel.Visible = false;
                        grdFacturas.Columns[0].Visible = false;
                        btnFacturar.Visible = false;
                        btnAnular.Visible = false;
                        break;
                    case "ANULADO":
                        //selectionLabel.Visible = false;
                        grdFacturas.Columns[0].Visible = false;
                        btnFacturar.Visible = false;
                        btnAnular.Visible = false;
                        break;
                    default:
                        // code block
                        break;
                }

                var objRequestQuery = new SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request();
                objRequestQuery.fechaInicio = txtFechaInicio.Date;
                objRequestQuery.fechaFin = txtFechaFin.Date;
                objRequestQuery.estadoFactura = estado;
                var lstFacturas = _facturacion.ObtenerFacturasPorFechasEstado(objRequestQuery).GetAwaiter().GetResult();
                if (lstFacturas == null)
                {
                    Session["FACTURAS"] = null;
                    grdFacturas.DataBind();
                    Master.MostrarToastr("info", "BUSQUEDA COMPLETA", "No se encontraron registros.");
                    return;
                }
                Session["FACTURAS"] = lstFacturas;//.Result.result;
                //grdFacturas.DataSource = lstFacturas.Result.result;
                grdFacturas.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void grdFacturas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["FACTURAS"] != null)
                {
                    grdFacturas.DataSource = Session["FACTURAS"];
                }
                else
                {
                    grdFacturas.DataSource = new List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void BtnFacturar_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedIds = grdFacturas.GetSelectedFieldValues("facturaId");

                var lstFacturas = new List<ActFacturasDto>();
                var numeroFacturaCount = 0;
                foreach (object id in selectedIds)
                {
                    numeroFacturaCount = numeroFacturaCount + 1;

                    var objActFactura = new ActFacturasDto();
                    objActFactura.idFacturas = Convert.ToInt64(id);
                    objActFactura.numeroFactura = numeroFacturaCount;

                    lstFacturas.Add(objActFactura);
                }
                if (lstFacturas.Count == 0)
                {
                    Master.MostrarToastr("warning", "REGISTRO INCOMPLETO", "Es necesario que seleccione al menos un registro.");
                    return;
                }
                var objResponse = _facturacion.RegistrarFacturacion(lstFacturas).GetAwaiter().GetResult();
                if (objResponse.procesado)
                {                    
                    CargaInicial();
                }
                
                if (objResponse != null)
                {
                    Session["DOWNLOAD"] = new OC_ARCHIVO()
                    {
                        BYTE_ARRAY = objResponse.byteCsvArchivo,
                        CONTENT_TYPE = "text/csv",
                        NOMBRE_ARCHIVO = objResponse.idLote + ".csv"
                    };
                    ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                }
                Master.MostrarToastr("success", "REGISTRO COMPLETADO", "Los Registros fueron agregados correctamente.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void BtnAnular_Click(object sender, EventArgs e)
        {
            try
            {
                var selectedIds = grdFacturas.GetSelectedFieldValues("facturaId");

                var lstFacturas = new List<ActFacturasDto>();
                foreach (object id in selectedIds)
                {
                    var objActFactura = new ActFacturasDto();
                    objActFactura.idFacturas = Convert.ToInt64(id);
                    lstFacturas.Add(objActFactura);
                }
                if (lstFacturas.Count == 0)
                {
                    Master.MostrarToastr("warning", "REGISTRO INCOMPLETO", "Es necesario que seleccione al menos un registro.");
                    return;
                }
                var response = _facturacion.RegistrarAnulacion(lstFacturas).GetAwaiter().GetResult();
                if (response.procesado)
                {
                    Master.MostrarToastr("success", "REGISTRO COMPLETADO", "Los Registros fueron anulados correctamente.");
                    CargaInicial();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void grdLotes_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["LOTE_FACTURAS"] != null)
                {
                    grdLotes.DataSource = Session["LOTE_FACTURAS"];
                }
                else
                {
                    grdLotes.DataSource = new List<LoteDto>();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnBuscarLote_Click(object sender, EventArgs e)
        {
            //var lstFacturas = _facturacion.ObtenerFacturasPorFechasEstado(objRequestQuery).GetAwaiter().GetResult();
            //if (lstFacturas == null)
            //{
            //    Master.MostrarToastr("info", "BUSQUEDA COMPLETA", "No se encontraron registros.");
            //    return;
            //}
            //Session["FACTURAS"] = lstFacturas;//.Result.result;
            //                                  //grdFacturas.DataSource = lstFacturas.Result.result;
            //grdFacturas.DataBind();
        }

        protected void btnDescargarLote_Click(object sender, EventArgs e)
        {
            try
            {
                var idlote = txtIdLote.Text.Trim();

                CsvLoteDto csvLoteDto = new CsvLoteDto();

                csvLoteDto.idLoteFacturas = idlote;

                var objResponse = _facturacion.ObtenerArchivoCsvIdLote(csvLoteDto).GetAwaiter().GetResult();
                if (objResponse != null)
                {
                    //string strArchivo = Encoding.ASCII.GetString(objResponse.byteCsvArchivo);


                    Session["DOWNLOAD"] = new OC_ARCHIVO()
                    {
                        BYTE_ARRAY = objResponse.byteCsvArchivo,
                        CONTENT_TYPE = "text/csv",
                        NOMBRE_ARCHIVO = objResponse.idLote + ".csv"
                    };
                    ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO.Replace(",", string.Empty));
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
    }
}