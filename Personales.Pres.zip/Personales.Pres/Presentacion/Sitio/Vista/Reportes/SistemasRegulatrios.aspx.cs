﻿using Agente.ServicioCore;
using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Spreadsheet.Export;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using DevExpress.Web.Internal.Dialogs;
using Microsoft.Reporting.WebForms;
using Presentacion.Lib;
using Presentacion.Parametros;
using Presentacion.Sitio.Controladores.ArchivosRegulatorios;
//using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Reportes
{
    public partial class SistemasRegulatrios : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
		private readonly CCargarArchivo _cCargarArchivos = new CCargarArchivo();
        private readonly CArchivosRegulatorios _cArchivosRegulatorios = new CArchivosRegulatorios();

        private string _strIdArchivoContabilidad = "";
		//private string _strNameTableTemporal = "";
		private string _strNombreArchivo = "";
		private string _strRutaArchivo = "";
		private string _strArchivoExtension = "";
		private Agente.ServicioPersonales.occ_usuario _user = new Agente.ServicioPersonales.occ_usuario();
		protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
				CargaInicial();
            }
			_user = (Agente.ServicioPersonales.occ_usuario)Session["SessionUsuario"];
			_strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
			
		}
		private void CargaInicial()
		{
			_strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
			var lstArchivoContableCargado = _cPersonales.GetArchivoContableCargado(_strPeriodoContable);
			//var lstArchivoContableCargado = _cPersonales.GetArchivoContableCargado("202411");//(_strPeriodoContable);
			Session["ARCHIVO_PERIODO_CONTABLE"] = lstArchivoContableCargado;
			GrvArchivoContable.DataSource = lstArchivoContableCargado;
			GrvArchivoContable.DataBind();
		}

		protected void GrvArchivoContable_PreRender(object sender, EventArgs e)
		{
			try
			{
				foreach (GridViewRow row in GrvArchivoContable.Rows)
				{
					Image ImgCargaCompleta = (Image)row.FindControl("ImgCargaCompleta");
					Image ImgCargaIncompleta = (Image)row.FindControl("ImgCargaIncompleta");
					Image ImgArchivo = (Image)row.FindControl("ImgArchivo");
					Label LblCarga = (Label)row.FindControl("LblCarga");

					if (LblCarga.Text == "1")
					{
						ImgCargaCompleta.Visible = true;
						ImgCargaIncompleta.Visible = false;

                        btnPartesProduccionBolivianos.ClientEnabled = true;
                        btnPartesProduccionDolares.ClientEnabled = true;
                        btnPartesProduccionRamos.ClientEnabled = true;
                        btnPartesSiniestrosBolivianos.ClientEnabled = true;
                        btnPartesSiniestrosDolares.ClientEnabled = true;
                        btnPartesSiniestrosRamos.ClientEnabled = true;
                        btnPartesProducciontxt.ClientEnabled = true;
                        btnPartesSiniestrosTrimestralPersonales.ClientEnabled = true;
                        btnPartesProduccionPersonales.ClientEnabled = true;
                        btnPartesSiniestrosPersonales.ClientEnabled = true;
                        BtnAnexo1.ClientEnabled = true;
						BtnAnexo2.ClientEnabled = true;
                        BtnAnexo3.ClientEnabled = true;
                        BtnAnexo4.ClientEnabled = true;
                        BtnAnexo5.ClientEnabled = true;
                        btnPartesProduccionCorredoras.ClientEnabled = true;
                    }
					else
					{
						ImgCargaCompleta.Visible = false;
						ImgCargaIncompleta.Visible = true;

                        btnPartesProduccionBolivianos.ClientEnabled = false;
                        btnPartesProduccionDolares.ClientEnabled = false;
                        btnPartesProduccionRamos.ClientEnabled = false;
                        btnPartesSiniestrosBolivianos.ClientEnabled = false;
                        btnPartesSiniestrosDolares.ClientEnabled = false;
                        btnPartesSiniestrosRamos.ClientEnabled = false;
                        btnPartesProducciontxt.ClientEnabled = false;
                        btnPartesSiniestrosTrimestralPersonales.ClientEnabled = false;
                        btnPartesProduccionPersonales.ClientEnabled = false;
                        btnPartesSiniestrosPersonales.ClientEnabled = false;
                        BtnAnexo1.ClientEnabled = false;
                        BtnAnexo2.ClientEnabled = false;
                        BtnAnexo3.ClientEnabled = false;
                        BtnAnexo4.ClientEnabled = false;
                        BtnAnexo5.ClientEnabled = false;
                        btnPartesProduccionCorredoras.ClientEnabled = false;
                    }
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		protected void GrvArchivoContable_RowCommand(Object sender, GridViewCommandEventArgs e)
		{
			try
			{
				GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
				string LblIDArchivoCont = ((Label)gvr.FindControl("LblIDArchivoCont")).Text.Trim();
				//_strNameTableTemporal = LblIDArchivoCont;
				Session["strIdArchivoContabilidad"] = LblIDArchivoCont;
				switch (e.CommandName)
				{
					case "CARGA":
						UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt" };
						PopCargarArchivo.HeaderText = "Cargar Archivo Contable";
						PopCargarArchivo.ShowOnPageLoad = true;
						break;
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
		{
			try
			{				
				UploadedFile uploadedFile = e.UploadedFile;
				FileInfo fileInfo = new FileInfo(uploadedFile.FileName);				
				Session["ARCHIVO_CARGADO"] = new OC_ARCHIVO()
				{
					CONTENT_TYPE = uploadedFile.ContentType,
					EXTENSION = fileInfo.Extension,
					NOMBRE_ARCHIVO = uploadedFile.FileName,
					FILE_STREAM = uploadedFile.FileContent,
					BYTE_ARRAY = uploadedFile.FileBytes
				};
				e.IsValid = true;
			}
			catch (Exception ex)
			{
				Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
		{
			try
			{
				string strFileExtension = string.Empty;
				var archivoCargado = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];

				if (_cCargarArchivos.GetValidFile(archivoCargado, "txt,csv", ref strFileExtension))
				{
					VerificarArchivoCargado(archivoCargado, _user.Matricula, ',');
				}
				else
				{
					ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('El formato del Archivo no es valido.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
					return;
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}


		private void VerificarArchivoCargado(OC_ARCHIVO archivoCargado, string strUser, char chrSeparador)
		{
			_strIdArchivoContabilidad = (string)Session["strIdArchivoContabilidad"];
			var strNameTableTemporal = _strIdArchivoContabilidad;
			//List<string> linesError = null;
			var dtData = new DataTable();
			List<string> lstErroresArchivo = null;

			//Log.Debug("Action: Procesamiento del archivo TXT, CSV para su evaluacion ; Metod: btnUpload_Click");
			var lstColumnas = _cCargarArchivos.GetListColumnasByArchivo(_strIdArchivoContabilidad);
			var lstErrors = _cCargarArchivos.GetDatatableFileTxtFile(archivoCargado,
						   lstColumnas, ref dtData, ref lstErroresArchivo, chrSeparador);
			dtData.TableName = strNameTableTemporal;
			var prueba = new DataTable();

			const int intCantidadtrama = 10000;
			int cantfil = dtData.Rows.Count;
			int intTrama = cantfil / intCantidadtrama;
			int intTramaresiduo = cantfil % intCantidadtrama;
			if (intTramaresiduo != 0)
			{
				intTrama = intTrama + 1;
			}
			/* AGREGA COLUMNAS AL DATATABLE PARA ENVIO*/
			foreach (DataColumn data in dtData.Columns)
				prueba.Columns.Add(data.ColumnName, typeof(System.String));

			if (!_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
			{
				prueba.Columns.Add("APVC_ID_USER_INSERT", typeof(System.String));
				prueba.Columns.Add("APDT_FECHA_INSERT", typeof(System.String));
				prueba.Columns.Add("APVC_PERIODO", typeof(System.String));
			}
			int intIndex = 1;
			int intInicioData = 0;
			int intFinalData = intCantidadtrama;
			while (intIndex <= intTrama)
			{
				if (intIndex == intTrama)
				{
					for (int i = intInicioData; i < cantfil; i++)
					{
						DataRow row = prueba.NewRow();
						foreach (DataColumn datac in prueba.Columns)
						{
							string strValor = "";
							if (_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
							{
								strValor = dtData.Rows[i][datac.ColumnName].ToString();
								strValor = strValor.Replace("\"", "");

								row[datac.ColumnName] = strValor;
							}
							else
							{
								switch (datac.ColumnName)
								{
									case "APVC_ID_USER_INSERT":
										strValor = strUser;
										row[datac.ColumnName] = strValor;
										break;
									case "APDT_FECHA_INSERT":
										strValor = DateTime.Today.ToString("yyyy-MM-dd");
										row[datac.ColumnName] = strValor;
										break;
									case "APIN_Item":
										break;
									case "APVC_PERIODO":
										DateTime datPeriodo;
										bool bolRespuesta = DateTime.TryParseExact(_strPeriodoContable, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datPeriodo);
										string strYear = datPeriodo.Year.ToString();
										string strMes = string.Format("{0:00}", datPeriodo.Month);
										strValor = strYear + strMes;
										row[datac.ColumnName] = strValor;
										break;
									default:
										strValor = HttpUtility.HtmlDecode(dtData.Rows[i][datac.ColumnName].ToString());
										//strValor = strValor.Replace("\"", "");
										//strValor = strValor.Substring(1, strValor.Length - 1);
										row[datac.ColumnName] = strValor;
										break;

								}
							}
						}
						prueba.Rows.Add(row);
					}
				}
				else
				{
					for (int i = intInicioData; i < intFinalData; i++)
					{
						DataRow row = prueba.NewRow();
						foreach (DataColumn datac in prueba.Columns)
						{
							string strValor = "";
							if (_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
							{
								strValor = dtData.Rows[i][datac.ColumnName].ToString();
								strValor = strValor.Replace("\"", "");

								row[datac.ColumnName] = strValor;
							}
							else
							{
								switch (datac.ColumnName)
								{
									case "APVC_ID_USER_INSERT":
										strValor = strUser;
										row[datac.ColumnName] = strValor;
										break;
									case "APDT_FECHA_INSERT":
										strValor = DateTime.Today.ToString("yyyy-MM-dd");
										row[datac.ColumnName] = strValor;
										break;
									case "APIN_Item":
										break;
									case "APVC_PERIODO":
										DateTime datPeriodo;
										bool bolRespuesta = DateTime.TryParseExact(_strPeriodoContable, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datPeriodo);
										string strYear = datPeriodo.Year.ToString();
										string strMes = string.Format("{0:00}", datPeriodo.Month);
										strValor = strYear + strMes;
										row[datac.ColumnName] = strValor;
										break;
									default:
										strValor = HttpUtility.HtmlDecode(dtData.Rows[i][datac.ColumnName].ToString());
										//strValor = strValor.Replace("\"", "");
										//strValor = strValor.Substring(1, strValor.Length - 1);
										row[datac.ColumnName] = strValor;
										break;
								}
							}
						}
						prueba.Rows.Add(row);
					}
				}
				if (!_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
				{
					if (prueba.Columns.Contains("APIN_Item"))
					{
						prueba.Columns.Remove("APIN_Item");
					}

				}
				//bool oSaveArchivoRecibidoProcesoTxt = true;
				bool oSaveArchivoRecibidoProcesoTxt = _cCargarArchivos.SaveArchivoRecibido(strNameTableTemporal, prueba);
				if (oSaveArchivoRecibidoProcesoTxt)
				{
					intIndex = intIndex + 1;
					intInicioData = intFinalData;
					intFinalData = intFinalData + intCantidadtrama;
					prueba.Clear();
				}
			}

			ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El registro del archivo contable ha sido completado con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);

			PopCargarArchivo.HeaderText = string.Empty;
			PopCargarArchivo.ShowOnPageLoad = false;

			CargaInicial();
		}

		protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnAnexo_Click(object sender, EventArgs e)
        {
            string strNumeroAnexo = ((BootstrapButton)sender).CommandName;
            try
            {
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                Session.Remove("DOWNLOAD");
                string strIdDocumento = string.Empty;
                switch (strNumeroAnexo)
                {
                    case "1": strIdDocumento = "REP-005"; break;
                    case "2": strIdDocumento = "REP-006"; break;
                    case "3": strIdDocumento = "REP-007"; break;
                    case "4": strIdDocumento = "REP-012"; break;
                    case "5": strIdDocumento = "REP-008"; break;
                }
                var objDocumento = _cDocumentos.GetReporteRegulatorioTXT(
                    strIdDocumento,
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FLAG_REPROCESO", Value = (_strPeriodoContable == strPeriodoProceso) ? true : false }
                    },
                    new OC_RESPONSE_FILE() { NombreArchivo = "Anexo" + strNumeroAnexo, CarpetaSalida = string.Empty, BoolHistorico = (_strPeriodoContable == strPeriodoProceso) ? true : false, FormatoSalida = "TXT" });
                if (objDocumento != null)
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));                    
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se ha producido un error al obtener la información del reporte seleccionado.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReporte_Click(object sender, EventArgs e)
        {
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_PARTES_PRODUCCION_CORREDORAS", new List<Agente.ServicioPersonales.CParameter>() { new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                DateTime dtMesProduccion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                dtMesProduccion = dtMesProduccion.AddMonths(1);
                string strMesProduccion = dtMesProduccion.ToString("yyyyMM");
                if (DsetDatos.Tables.Count == 1)
                {
                    using (var ms = new MemoryStream())
                    {
                        TextWriter tw = new StreamWriter(ms);
                        foreach (DataRow objDataRow in DsetDatos.Tables[0].Rows)
                        {
                            if (objDataRow[0].ToString().Trim() != string.Empty)
                            {
                                string strRegistro = string.Empty;
                                strRegistro = string.Format("{1},{0},{2},{3},{4},{5},{6},{7}",
                                    objDataRow[0].ToString().Trim(),
                                    objDataRow[1].ToString().Trim(),
                                    objDataRow[2].ToString().Trim(),
                                    objDataRow[3].ToString().Trim(),
                                    objDataRow[4].ToString().Trim(),
                                    objDataRow[5].ToString().Trim(),
                                    objDataRow[6].ToString().Trim(),
                                    objDataRow[7].ToString().Trim());
                                tw.Write(strRegistro);
                                tw.Write(Environment.NewLine);
                            }
                        }
                        tw.Flush();
                        ms.Position = 0;
                        Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = ms.ToArray(), CONTENT_TYPE = "text/plain", NOMBRE_ARCHIVO = "Partes_Produccion_Corredoras_SE" + strMesProduccion + ".209.txt" };
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }



        protected void btnExportarExcel_Click(object sender, EventArgs e)
        {
            string strArchivoNombre = ((BootstrapButton)sender).CommandName;
            try
            {
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
				//_strPeriodoContable = "202409";

                var periodo = DateTime.ParseExact(_strPeriodoContable, "yyyyMM", CultureInfo.InvariantCulture, DateTimeStyles.None);
                periodo = periodo.AddMonths(1).AddDays(-1);

                OC_RESPONSE_FILE objArchivoRespuesta = null;

				string strNombreArchivo = string.Empty;
                string strArchivoExtension = string.Empty;
                switch (strArchivoNombre)
				{
					case "RepPartesProdPersonalesBs":

                        strNombreArchivo = "Partes produccion personales Bs_" + DateTime.Now.ToString("dd-MM-yyyy");
						strArchivoExtension = ".xlsx";
						                        
                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-001",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesProdPersonalesSus":

                        strNombreArchivo = "Partes produccion personales Sus_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";
                        
                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-002",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;
                    
                    case "RepPartesProdRamosPersonales":

                        strNombreArchivo = "Partes produccion ramos personales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-003",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesSiniestrosPersonalesBs":
                        strNombreArchivo = "Partes siniestros personales Bs_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-004",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesSiniestrosPersonalesSus":
                        strNombreArchivo = "Partes siniestros personales Sus_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-005",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;                                            

                    case "RepPartesSiniestrosRamosPersonales":
                        strNombreArchivo = "Partes siniestros ramos personales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-006",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "PARTES_PRODUCCION_TRIMESTRAL_PERSONALES":

                        strNombreArchivo = "Partes produccion trimestral_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-007",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = _strPeriodoContable }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_SINIESTROS_TRIMESTRAL_PERSONALES":

                        strNombreArchivo = "Partes siniestros trimestral_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-008",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = _strPeriodoContable }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_PRODUCCION_PERSONALES":

                        strNombreArchivo = "Partes produccion personales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-009",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = _strPeriodoContable }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_SINIESTROS_PERSONALES":

                        strNombreArchivo = "Partes siniestros personales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                            "AREG-010",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = _strPeriodoContable }
                            },
                            new OC_RESPONSE_FILE()
                            {
                                NombreArchivo = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                }

                string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));


                switch (objArchivoRespuesta.FormatoSalida)
                {
                    case "EXCEL":
                        Session["DOWNLOAD"] = new OC_ARCHIVO()
                        {
                            BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc),
                            CONTENT_TYPE = "application/vnd.ms-excel",
                            NOMBRE_ARCHIVO = strNombreArchivo + strArchivoExtension
                        };
                        break;
                    case "TXT":
                        Session["DOWNLOAD"] = new OC_ARCHIVO()
                        {
                            BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc),
                            CONTENT_TYPE = "text/plain",
                            NOMBRE_ARCHIVO = strNombreArchivo + strArchivoExtension
                        };
                        break;
                    default:
                        // code block
                        break;
                }               				

                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}