﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Web;

namespace Presentacion.Sitio.Vista.Reportes
{
    public partial class CuadroSiniestros : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargarDatos();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargarDatos()
        {
            try
            {
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_CUADRO_SINIESTROS", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (DsetDatos.Tables.Count == 3)
                {
                    PnlNotificacion.Visible = false;
                    PnlReporte.Visible = true;
                    Session["CUADRO_SINIESTROS_RESUMEN"] = DsetDatos.Tables[0];
                    Session["CUADRO_SINIESTROS_RESERVA"] = DsetDatos.Tables[1];
                    Session["CUADRO_SINIESTROS_LIQUIDACION"] = DsetDatos.Tables[2];
                    GrvResumen.DataBind();
                }
                else
                {
                    PnlNotificacion.Visible = true;
                    PnlReporte.Visible = false;
                    LblMensaje.Text = DsetDatos.Tables[0].Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvResumen_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CUADRO_SINIESTROS_RESUMEN"] != null)
                    GrvResumen.DataSource = (DataTable)Session["CUADRO_SINIESTROS_RESUMEN"];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDescargar_Click(object sender, EventArgs e)
        {
            string strRutaPlantilla = Server.MapPath("~/UI/templates/CUADRO_SINIESTROS.xlsx");
            try
            {
                var DtblResumen = (DataTable)Session["CUADRO_SINIESTROS_RESUMEN"];
                var DtblReserva = (DataTable)Session["CUADRO_SINIESTROS_RESERVA"];
                var DtblLiquidacion = (DataTable)Session["CUADRO_SINIESTROS_LIQUIDACION"];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Resumen")
                    {
                        DEWorksheet.Import(DtblResumen, false, 2, 0);
                        DEWorksheet.Range["A2:F" + (DtblResumen.Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        DEWorksheet.Columns.Remove(6, 2);
                        DEWorksheet.Range["D3:F" + (DtblResumen.Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                        DEWorksheet.Range["C3:C" + (DtblResumen.Rows.Count + 2)].NumberFormat = "#,##0"; //formato numerico
                        DEWorksheet.Cells["A1"].Value = DtblResumen.Rows[0]["CABECERA"].ToString();
                        DEWorksheet.MergeCells(DEWorksheet.Range["A" + (DtblResumen.Rows.Count + 3) + ":B" + (DtblResumen.Rows.Count + 3)]);
                        DEWorksheet.Cells["A" + (DtblResumen.Rows.Count + 3)].Value = "Totales";
                        DEWorksheet.Range["A" + (DtblResumen.Rows.Count + 3) + ":F" + (DtblResumen.Rows.Count + 3)].Font.Bold = true;
                        DEWorksheet.Range["A" + (DtblResumen.Rows.Count + 3) + ":F" + (DtblResumen.Rows.Count + 3)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        int intNumeroRegistros = 0;
                        decimal decValorAnalizado = 0, decImporteRetenido = 0, decImporteCedido = 0;
                        for (int index = 0; index < DtblResumen.Rows.Count; index++)
                        {
                            intNumeroRegistros = intNumeroRegistros + Convert.ToInt32(DtblResumen.Rows[index]["CANTIDAD_MOVIMIENTOS"].ToString());
                            decValorAnalizado = decValorAnalizado + Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_TOTAL_USD"].ToString());
                            if (Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_TOTAL_USD"].ToString()) < 0) { DEWorksheet.Cells["D" + (index + 3)].Font.Color = System.Drawing.Color.Red; }
                            decImporteRetenido = decImporteRetenido + Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_RETENCION_USD"].ToString());
                            if (Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_RETENCION_USD"].ToString()) < 0) { DEWorksheet.Cells["E" + (index + 3)].Font.Color = System.Drawing.Color.Red; }
                            decImporteCedido = decImporteCedido + Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_RASEGURO_USD"].ToString());
                            if (Convert.ToDecimal(DtblResumen.Rows[index]["IMPORTE_RASEGURO_USD"].ToString()) < 0) { DEWorksheet.Cells["F" + (index + 3)].Font.Color = System.Drawing.Color.Red; }
                        }
                        DEWorksheet.Cells["C" + (DtblResumen.Rows.Count + 3)].Value = intNumeroRegistros;
                        DEWorksheet.Cells["D" + (DtblResumen.Rows.Count + 3)].Value = decValorAnalizado;
                        DEWorksheet.Cells["E" + (DtblResumen.Rows.Count + 3)].Value = decImporteRetenido;
                        DEWorksheet.Cells["F" + (DtblResumen.Rows.Count + 3)].Value = decImporteCedido;
                        DEWorksheet.Range["D" + (DtblResumen.Rows.Count + 3) + ":F" + (DtblResumen.Rows.Count + 3)].NumberFormat = "#,##0.00";
                        DEWorksheet.Range["C" + (DtblResumen.Rows.Count + 3) + ":C" + (DtblResumen.Rows.Count + 3)].NumberFormat = "#,##0"; //formato numerico
                    }
                    if (DEWorksheet.Name == "Reservas")
                    {
                        DEWorksheet.Import(DtblReserva, false, 1, 0);
                        DEWorksheet.Range["A1:Z" + (DtblReserva.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        DEWorksheet.Range["H2:I" + (DtblReserva.Rows.Count + 1)].NumberFormat = "#,##0.00"; //formato numerico
                        DEWorksheet.Range["K2:N" + (DtblReserva.Rows.Count + 1)].NumberFormat = "#,##0.00"; //formato numerico
                        DEWorksheet.Range["O2:T" + (DtblReserva.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                    }
                    if (DEWorksheet.Name == "Liquidaciones")
                    {
                        DEWorksheet.Import(DtblLiquidacion, false, 1, 0);
                        DEWorksheet.Range["A1:Z" + (DtblLiquidacion.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        DEWorksheet.Range["H2:I" + (DtblLiquidacion.Rows.Count + 1)].NumberFormat = "#,##0.00"; //formato numerico
                        DEWorksheet.Range["K2:N" + (DtblLiquidacion.Rows.Count + 1)].NumberFormat = "#,##0.00"; //formato numerico
                        DEWorksheet.Range["O2:T" + (DtblLiquidacion.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                    }
                }
                byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                HidDownload.Clear();
                HidDownload.Add("Download", "true");
                Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "CuadroSiniestros_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}