﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Reportes
{
    public partial class ValidacionTecnica : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        #region Desgravamen
        protected void BtnDesgravamen_Click(object sender, EventArgs e)
        {
            string strIdProducto = ((BootstrapButton)sender).CommandName;
            try
            {
                var objDocumento = _cDocumentos.GetReporteValidacionDesgravamen(
                    strIdProducto,
                    "REP-010",
                    new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto }
                    },
                    new OC_RESPONSE_FILE() { NombreArchivo = strIdProducto + "_BaseDesgravamen_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddHHmm"), CarpetaSalida = _strPeriodoContable, BoolHistorico = false, FormatoSalida = "EXCEL" });
                if (string.IsNullOrEmpty(objDocumento.RutaArchivoEnc))
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Alerta_BtnDesgravamen_Click", "toastr.error('" + objDocumento.Mensaje + "', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                else
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
        #region Sistema de Beneficios
        protected void BtnSiniestros_Click(object sender, EventArgs e)
        {
            string strTipoDocumento = ((BootstrapButton)sender).CommandName;            
            try
            {
                if (strTipoDocumento == "Validacion")
                {
                    var strRutaReporte = _cDocumentos.ReporteValidacionCesion(_strPeriodoContable);
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(strRutaReporte));
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "ValidacionSiniestros_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
    }
}