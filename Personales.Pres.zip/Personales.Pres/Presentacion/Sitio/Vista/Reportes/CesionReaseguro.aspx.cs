﻿using Agente.ServicioDocumentos;
using DevExpress.Spreadsheet;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Reportes
{
    public partial class CesionReaseguro : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                GrvDocumentos.DataBind();
                /// tipo de cambio ASFI
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                DateTime dtFechaMes = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(2).AddDays(-1);
                decimal decTipoCambioASFI = new Controladores.CCore().TipoCambio_Obtener("APS", dtFechaMes, "COMPRA");
                LblTipoCambioASFI.Text = ((decTipoCambioASFI < 0) ? 0 : decTipoCambioASFI).ToString("N2", CultureInfo.InvariantCulture);

            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDocumentos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                string strJson = _cPersonales.GetListLexicoPorTablaYTema("JSON", "REPORTE_TENICA_REASEGURO").First().LEPVC_VALOR;
                var listaReportes = JsonConvert.DeserializeObject<List<ocp_reportes>>(strJson);
                Session["CesionReaseguro__listaReportes"] = listaReportes;
                GrvDocumentos.DataSource = listaReportes;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnEjecutaProceso_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidReporteSeleccionado.Contains("IdDocumento"))
                {
                    Workbook DEWorkbook = new Workbook();
                    var strIdDocumento = HidReporteSeleccionado["IdDocumento"].ToString();
                    switch (strIdDocumento)
                    {
                        case "REA-BEN":
                            string strRutaPlantilla = Server.MapPath("~/UI/templates/SINIESTROS_REASEGURADOS.xlsx");
                            var DsetSiniestros = _cPersonales.GetDatasetProcedimiento(
                                "pro.SPR_GETLIST_REPORTE_SINIESTROS_REASEGURADOS",
                                new List<Agente.ServicioPersonales.CParameter>() {
                                new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO", Value = _strPeriodoContable }
                                });
                            if (DsetSiniestros.Tables[0].Rows[0][0].ToString() == "TRUE" && DsetSiniestros.Tables[1].Rows.Count > 0)
                            {
                                DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                                {
                                    if (DEWorksheet.Name == "Reporte")
                                    {
                                        DEWorksheet.Cells["A1"].Value = "SINIESTROS REASEGURADOS - " + ((Label)Master.FindControl("LblMesProduccion")).Text;
                                        DEWorksheet.Import(DsetSiniestros.Tables[1], false, 2, 0);
                                        DEWorksheet.Range["P3:R" + (DsetSiniestros.Tables[1].Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                                        DEWorksheet.Columns[4].NumberFormat = "dd/mm/yyyy";
                                        DEWorksheet.Columns[7].NumberFormat = "dd/mm/yyyy";
                                        DEWorksheet.Columns[8].NumberFormat = "dd/mm/yyyy";
                                        DEWorksheet.Columns[11].NumberFormat = "dd/mm/yyyy";
                                        DEWorksheet.Columns[12].NumberFormat = "dd/mm/yyyy";
                                        DEWorksheet.Columns[25].NumberFormat = "dd/mm/yyyy"; //fecha nacimiento
                                        DEWorksheet.Columns[27].NumberFormat = "#,##0.00";
                                        DEWorksheet.Columns[28].NumberFormat = "#,##0.00";
                                        DEWorksheet.Columns[29].NumberFormat = "#,##0.00";
                                        DEWorksheet.Columns[30].NumberFormat = "#,##0.00";
                                    }
                                }
                                byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                                Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "SiniestrosReasegurados_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                            }
                            else
                            {
                                ScriptManager.RegisterStartupScript(this, typeof(Page), "BtnSiniestrosReaseguro_Click(ERROR)", "toastr.warning('El registro de siniestros para este mes todavía no ha sido cerrado, por favor intente a partir del día " + DsetSiniestros.Tables[0].Rows[0][1].ToString() + ".', 'Sistema de Beneficios', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                            }
                            break;
                        case "REA-ANU":
                            var DtblDatos = _cPersonales.Anulacion_Bandeja(_strPeriodoContable, false).Tables[2];
                            DEWorkbook.LoadDocument(Server.MapPath("~/UI/templates/reporte-anulaciones.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                            foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                            {
                                if (DEWorksheet.Name == "Reporte")
                                {
                                    DEWorksheet.DeleteCells(DEWorksheet.Cells["A1"], DeleteMode.EntireColumn);
                                    DEWorksheet.Import(DtblDatos, false, 1, 0);
                                    DEWorksheet.Columns[5].NumberFormat = "dd/mm/yyyy";
                                    DEWorksheet.Columns[6].NumberFormat = "dd/mm/yyyy";
                                    DEWorksheet.Columns[7].NumberFormat = "#,##0.00";
                                    DEWorksheet.Columns[8].NumberFormat = "#,##0.00";
                                    DEWorksheet.Columns[10].NumberFormat = "#,##0.00";
                                    DEWorksheet.Columns[2].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Columns[3].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Columns[4].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Columns[5].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Columns[6].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Columns[7].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                                    DEWorksheet.Range["N1:Q" + (DtblDatos.Rows.Count + 1)].NumberFormat = "#,##0.00";
                                    DEWorksheet.DeleteCells(DEWorksheet.Range["R1:AF" + (DtblDatos.Rows.Count + 1)], DeleteMode.EntireColumn);
                                    Session["DOWNLOAD"] = new OC_ARCHIVO()
                                    {
                                        BYTE_ARRAY = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                                        CONTENT_TYPE = "application/vnd.ms-excel",
                                        NOMBRE_ARCHIVO = "Anulaciones_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + "_CRSP.xlsx"
                                    };
                                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                                }
                            }
                            break;
                        default:
                            var listaReportes = (List<ocp_reportes>)Session["CesionReaseguro__listaReportes"];
                            var objReporte = listaReportes.Find(f => f.IdDocumento == strIdDocumento);
                            var listaParametros = objReporte.ListaParametros.Where(w => w.Tipo == "Interfaz").ToList();
                            if (listaParametros.Count() > 0)
                            {
                                foreach (var objControl in PopParametros.Controls)
                                {
                                    switch (objControl.GetType().Name)
                                    {
                                        case "BootstrapSpinEdit":
                                            ((BootstrapSpinEdit)objControl).ClientVisible = false;
                                            break;
                                        case "BootstrapComboBox":
                                            ((BootstrapComboBox)objControl).ClientVisible = false;
                                            break;
                                    }
                                }
                                foreach (var objParametro in listaParametros)
                                {
                                    switch (objParametro.Control)
                                    {
                                        case "ComboBox":
                                            if (PopParametros.FindControl(objParametro.Nombre) != null)
                                            {
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).ClientVisible = true;
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).DataSource = objParametro.ListaValores;
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).ValueField = "Valor";
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).TextField = "Descripcion";
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).DataBind();
                                                ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).Value = null;
                                            }
                                            break;
                                    }
                                }
                                PopParametros.ShowOnPageLoad = true;
                                Session["CesionReaseguro__IdDocumento"] = strIdDocumento;
                            }
                            else
                            {
                                GenerarReporte(strIdDocumento);
                            }
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GenerarReporte(string strIdDocumento)
        {
            try
            {
                var listaReportes = (List<ocp_reportes>)Session["CesionReaseguro__listaReportes"];
                var objReporte = listaReportes.Find(f => f.IdDocumento == strIdDocumento);                
                var listaParametros = new List<occ_response_file__parametro>();
                foreach (var objParametro in objReporte.ListaParametros)
                {
                    if (objParametro.Tipo == "Interno")
                    {
                        switch (objParametro.Nombre)
                        {
                            case "strPeriodoContable":
                                listaParametros.Add(new occ_response_file__parametro { Nombre = objParametro.Nombre, Valor = _strPeriodoContable });
                                break;
                        }
                    }
                    else
                    {
                        switch (objParametro.Control)
                        {
                            case "ComboBox":
                                if (PopParametros.FindControl(objParametro.Nombre) != null)
                                {
                                    listaParametros.Add(new occ_response_file__parametro { Nombre = objParametro.Nombre, Valor = ((BootstrapComboBox)PopParametros.FindControl(objParametro.Nombre)).SelectedItem.Value });
                                }
                                break;
                            case "SpinEdit":
                                if (PopParametros.FindControl(objParametro.Nombre) != null)
                                {
                                    listaParametros.Add(new occ_response_file__parametro { Nombre = objParametro.Nombre, Valor = ((BootstrapSpinEdit)PopParametros.FindControl(objParametro.Nombre)).Value });
                                }
                                break;
                        }
                    }
                }
                var objArchivoRespuesta = _cDocumentos.Documento_Generar(strIdDocumento, listaParametros);
                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc))),
                    CONTENT_TYPE = objArchivoRespuesta.ContentType,
                    NOMBRE_ARCHIVO = objArchivoRespuesta.NombreArchivo
                };
                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnGenerarReporte_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["CesionReaseguro__IdDocumento"] != null)
                {
                    GenerarReporte((string)Session["CesionReaseguro__IdDocumento"]);
                    Session.Remove("CesionReaseguro__IdDocumento");
                    PopParametros.ShowOnPageLoad = false;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnActualizarTipoCambio_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime dtFechaMes = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(2).AddDays(-1);
                decimal decTipoCambioASFI = Convert.ToDecimal(TxtTipoCambioASFI.Text);
                _cPersonales.TipoCambio_Registrar("APS", dtFechaMes, decTipoCambioASFI, decTipoCambioASFI);
                LblTipoCambioASFI.Text = decTipoCambioASFI.ToString("N2", CultureInfo.InvariantCulture);
                PopTipoCambio.ShowOnPageLoad = false;
                Master.MostrarToastr("success", "PROCESO COMPLETADO!", "El tipo de cambio ASFI correspondiente al mes en curso ha sido actualizado.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}