﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Web;
using Presentacion.Lib;
using Presentacion.Parametros;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Reportes
{
    public partial class archivo_regulatorio : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodo;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strPeriodo = (string)Session["PERIODO_CONTABLE"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cPersonales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        private void CargaInicial()
        {
            try
            {
                ///se evalua si se muestra el boton de carga de contables
                var objLexico = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PERIODO_CONTABLE" && w.LEPVC_TEMA == "PROCESO").First();
                string strPeriodoActual = objLexico.LEPVC_VALOR;
                string strPeriodoAnterior = DateTime.ParseExact(strPeriodoActual + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(-1).ToString("yyyyMM");
                _strPeriodo = (string)Session["PERIODO_CONTABLE"];
                BtnCargarContables.ClientVisible = false;
                if (_strPeriodo == strPeriodoAnterior || _strPeriodo == strPeriodoActual)
                {
                    BtnCargarContables.ClientVisible = true;
                }
                ///cargamos la tabla de los reportes
                GrvReportes.DataSource = ReportesDisponibles();
                GrvReportes.DataBind();
                ///evaluamos si se muestran los botones de descarga o no
                GrvReportes.Columns[3].Visible = false;
                if (_cPersonales.Contabilidad_ValidarCarga(_strPeriodo))
                {
                    GrvReportes.Columns[3].Visible = true;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        private DataTable ReportesDisponibles()
        {
            try
            {
                var DtblReportes = new DataTable();
                DtblReportes.Clear();
                DtblReportes.Columns.Add("Numero", typeof(int));
                DtblReportes.Columns.Add("IdDocumento", typeof(string));
                DtblReportes.Columns.Add("Descripcion", typeof(string));
                DtblReportes.Columns.Add("Formato", typeof(string));
                DtblReportes.Rows.Add(new object[] { 1, "REP-005", "ANEXO 1", "TXT" });
                DtblReportes.Rows.Add(new object[] { 2, "REP-006", "ANEXO 2", "TXT" });
                DtblReportes.Rows.Add(new object[] { 3, "REP-007", "ANEXO 3", "TXT" });
                DtblReportes.Rows.Add(new object[] { 4, "REP-012", "ANEXO 4", "TXT" });
                DtblReportes.Rows.Add(new object[] { 5, "REP-008", "ANEXO 5", "TXT" });
                DtblReportes.Rows.Add(new object[] { 6, "AREG-009", "PARTES DE PRODUCCION", "TXT" });
                DtblReportes.Rows.Add(new object[] { 7, "AREG-011", "PARTES DE PRODUCCIÓN - CORREDORAS", "TXT" });
                DtblReportes.Rows.Add(new object[] { 8, "AREG-007", "PARTES DE PRODUCCIÓN - TRIMESTRAL", "TXT" });
                DtblReportes.Rows.Add(new object[] { 9, "AREG-010", "PARTES DE SINIESTROS", "TXT" });
                DtblReportes.Rows.Add(new object[] { 10, "AREG-008", "PARTES DE SINIESTROS - TRIMESTRAL", "TXT" });
                DtblReportes.Rows.Add(new object[] { 11, "AREG-001", "PARTES DE PRODUCCIÓN (BOLIVIANOS)", "EXCEL" });
                DtblReportes.Rows.Add(new object[] { 12, "AREG-002", "PARTES DE PRODUCCIÓN (DÓLARES)", "EXCEL" });
                DtblReportes.Rows.Add(new object[] { 13, "AREG-003", "PARTES DE PRODUCCION POR RAMOS", "EXCEL" });
                DtblReportes.Rows.Add(new object[] { 14, "AREG-004", "PARTES DE SINIESTROS (BOLIVIANOS)", "EXCEL" });
                DtblReportes.Rows.Add(new object[] { 15, "AREG-005", "PARTES DE SINIESTROS (DÓLARES)", "EXCEL" });
                DtblReportes.Rows.Add(new object[] { 16, "AREG-006", "PARTES DE SINIESTROS POR RAMOS", "EXCEL" });
                return DtblReportes;
            }
            catch
            {
                throw;
            }
        }
        protected void BtnProcesarSeleccion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidReporte.Contains("IdDocumento"))
                {
                    string strIdDocumento = HidReporte.Get("IdDocumento").ToString();
                    var dtblDatos = ReportesDisponibles();
                    string strFormato = string.Empty;
                    for (int index = 0; index < dtblDatos.Rows.Count; index++)
                    {
                        if (dtblDatos.Rows[index]["IdDocumento"].ToString() == strIdDocumento)
                        {
                            strFormato = dtblDatos.Rows[index]["Formato"].ToString();
                        }
                    }
                    string strNombreArchivo = string.Empty;
                    var dtFechaReporte = DateTime.ParseExact(_strPeriodo + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(2).AddDays(-1);
                    string strMesReporte = dtFechaReporte.ToString("yyyyMM");
                    var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();
                    string strPeriodoProceso = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PERIODO_CONTABLE" && w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                    string strPeriodoProcesoAnterior = DateTime.ParseExact(strPeriodoProceso, "yyyyMM", CultureInfo.InvariantCulture).AddMonths(-1).ToString("yyyyMM");
                    switch (strIdDocumento)
                    {
                        case "REP-005": strNombreArchivo = "M15SA" + _strPeriodo; break;
                        case "REP-006": strNombreArchivo = "M15SB" + _strPeriodo; break;
                        case "REP-007": strNombreArchivo = "M15SC" + _strPeriodo; break;
                        case "REP-012": strNombreArchivo = "M15SD" + _strPeriodo; break;
                        case "REP-008": strNombreArchivo = "M15SE" + _strPeriodo; break;
                        case "AREG-001": strNombreArchivo = "RepPartesProdPersonalesBs"; break;
                        case "AREG-002": strNombreArchivo = "RepPartesProdPersonalesSus"; break;
                        case "AREG-003": strNombreArchivo = "RepPartesProdRamosPersonales"; break;
                        case "AREG-004": strNombreArchivo = "RepPartesSiniestrosPersonalesBs"; break;
                        case "AREG-005": strNombreArchivo = "RepPartesSiniestrosPersonalesSus"; break;
                        case "AREG-006": strNombreArchivo = "RepPartesSiniestrosRamosPersonales"; break; 
                        case "AREG-007": strNombreArchivo = "T01SF" + _strPeriodo; break;
                        case "AREG-008": strNombreArchivo = "T02SG" + _strPeriodo; break;
                        case "AREG-009": strNombreArchivo = "M04SA" + _strPeriodo; break;
                        case "AREG-010": strNombreArchivo = "M04SB" + _strPeriodo; break;
                        case "AREG-011": strNombreArchivo = "M05SE" + _strPeriodo; break;
                    }
                    switch (strIdDocumento)
                    {
                        case "REP-005":
                        case "REP-006":
                        case "REP-007":
                        case "REP-012":
                        case "REP-008":
                            listaParametros.Add(new Agente.ServicioDocumentos.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodo });
                            listaParametros.Add(new Agente.ServicioDocumentos.CParameter() { Key = "@FLAG_REPROCESO", Value = (_strPeriodo == strPeriodoProceso || _strPeriodo == strPeriodoProcesoAnterior) ? true : false });
                            break;
                        case "AREG-001":
                        case "AREG-002":
                        case "AREG-003":
                        case "AREG-004":
                        case "AREG-005":
                        case "AREG-006":
                            listaParametros.Add(new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = dtFechaReporte });
                            break;
                        case "AREG-007":
                        case "AREG-008":
                        case "AREG-009":
                        case "AREG-010":
                        //case "AREG-011":
                            listaParametros.Add(new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_PERIODO", Value = strMesReporte });
                            break;
                    }
                    OC_RESPONSE_FILE objArchivoRespuesta = null;
                    switch (strIdDocumento)
                    {
                        case "REP-005":
                        case "REP-006":
                        case "REP-007":
                        case "REP-012":
                        case "REP-008":
                            objArchivoRespuesta = _cDocumentos.GetReporteRegulatorioTXT(
                                strIdDocumento,
                                listaParametros,
                                new OC_RESPONSE_FILE()
                                {
                                    NombreArchivo = strNombreArchivo,
                                    CarpetaSalida = _strPeriodo,
                                    BoolHistorico = false,
                                    FormatoSalida = strFormato
                                }); 
                            break;
                        case "AREG-011":
                            objArchivoRespuesta = PartesProduccionCorredoras(strNombreArchivo);
                            break;
                        default:
                            objArchivoRespuesta = _cDocumentos.GetReportesArchivosRegulatorios(
                                strIdDocumento,
                                listaParametros,
                                new OC_RESPONSE_FILE()
                                {
                                    NombreArchivo = strNombreArchivo,
                                    CarpetaSalida = _strPeriodo,
                                    BoolHistorico = false,
                                    FormatoSalida = strFormato
                                });
                            break;
                    }
                    if (objArchivoRespuesta != null)
                    {
                        string strRutaArchivoEnc = (!string.IsNullOrEmpty(objArchivoRespuesta.RutaArchivoEnc)) ? System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc)) : string.Empty;
                        Session["DOWNLOAD"] = new OC_ARCHIVO() { 
                            BYTE_ARRAY = (objArchivoRespuesta.ByteArray != null) ? objArchivoRespuesta.ByteArray : File.ReadAllBytes(strRutaArchivoEnc), 
                            CONTENT_TYPE = objArchivoRespuesta.ContentType, 
                            NOMBRE_ARCHIVO = objArchivoRespuesta.NombreArchivo.Replace(".txt", ".209") };
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "toastr.error('Se ha producido un error al obtener la información del reporte seleccionado.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCargarContables_Click(object sender, EventArgs e)
        {
            try 
            {
                Session.Remove("archivo_regulatorio__archivosContables");
                Session.Remove("archivo_regulatorio__datosContables");
                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt", ".209" }; 
                PopCargaContables.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                DataTable DtblDatos = new DataTable();
                DtblDatos.Columns.Add(new DataColumn("Archivo"));
                DtblDatos.Columns.Add(new DataColumn("Contenido"));
                if (Session["archivo_regulatorio__archivosContables"] == null)
                {
                    Session["archivo_regulatorio__archivosContables"] = new List<OC_ARCHIVO>();
                    Session["archivo_regulatorio__datosContables"] = DtblDatos;
                }
                var listaArchivos = (List<OC_ARCHIVO>)Session["archivo_regulatorio__archivosContables"];
                DtblDatos = (DataTable)Session["archivo_regulatorio__datosContables"];
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                listaArchivos.Add(new OC_ARCHIVO
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName.Replace(fileInfo.Extension, string.Empty),
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                });
                using (StreamReader reader = new StreamReader(uploadedFile.FileContent))
                {
                    do
                    {
                        string strTextLine = reader.ReadLine();
                        DataRow dr = DtblDatos.NewRow();
                        dr[0] = uploadedFile.FileName;
                        dr[1] = strTextLine;
                        DtblDatos.Rows.Add(dr);
                    } while (reader.Peek() != -1);
                }
                Session["archivo_regulatorio__archivosContables"] = listaArchivos;
                Session["archivo_regulatorio__datosContables"] = DtblDatos;
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                var listaArchivos = (List<OC_ARCHIVO>)Session["archivo_regulatorio__archivosContables"];
                var DtblDatos = (DataTable)Session["archivo_regulatorio__datosContables"];
                var listaRegistros = new List<CONTABILIDAD>();
                var listaErrores = new List<string>();
                for (int index = 0; index < DtblDatos.Rows.Count; index++)
                {
                    string strNombreArchivo = DtblDatos.Rows[index][0].ToString();
                    string strTextLine = DtblDatos.Rows[index][1].ToString();
                    string[] datos = strTextLine.Split(',');
                    if (!string.IsNullOrEmpty(strTextLine))
                    {
                        var dtFechaArchivo = DateTime.ParseExact(datos[1].Replace("\"", string.Empty).Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        var strPeriodoArchivo = DateTime.ParseExact(dtFechaArchivo.ToString("yyyyMM"), "yyyyMM", CultureInfo.InvariantCulture).AddMonths(-1).ToString("yyyyMM");
                        if (datos.Length != 11)
                        {
                            listaErrores.Add("Error en el archivo '" + strNombreArchivo + "', fila '" + (index + 1) + "': El número de columnas proporcionadas es incorrecto.");
                        }
                        else if (_strPeriodo != strPeriodoArchivo)
                        {
                            listaErrores.Add("Error en el archivo '" + strNombreArchivo + "', fila '" + (index + 1) + "': La fecha del registro no corresponde al mes de producción seleccionado.");
                        }
                        else
                        {
                            listaRegistros.Add(new CONTABILIDAD
                            {
                                COPCH_PERIODO = _strPeriodo,
                                COPCH_COMPANIA = datos[0].Replace("\"", string.Empty).Trim(),
                                COPDT_FECHA = dtFechaArchivo,
                                COPVC_CUENTA = datos[2].Replace("\"", string.Empty).Trim(),
                                COPCH_MONEDA = datos[3].Replace("\"", string.Empty).Trim(),
                                COPVC_SUB_CUENTA = datos[4].Replace("\"", string.Empty).Trim(),
                                COPDC_SALDO_DEBE_ANTERIOR = Convert.ToDecimal(datos[5].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture),
                                COPDC_SALDO_HABER_ANTERIOR = Convert.ToDecimal(datos[6].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture),
                                COPDC_MOVIMIENTO_DEBE = Convert.ToDecimal(datos[7].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture),
                                COPDC_MOVIMIENTO_HABER = Convert.ToDecimal(datos[8].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture),
                                COPDC_SALDO_DEBE_ACTUAL = Convert.ToDecimal(datos[9].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture),
                                COPDC_SALDO_HABER_ACTUAL = Convert.ToDecimal(datos[10].Replace("\"", string.Empty).Trim(), CultureInfo.InvariantCulture)
                            });
                        }
                    }
                }
                if (listaErrores.Count > 0)
                {
                    MostrarLogErrores(listaErrores);
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "toastr.error('Se han encontrado observaciones en el archivo seleccionado, se le ha enviado un correo con un detalle de las observaciones para su revisión.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                {
                    foreach (var objArchivo in listaArchivos)
                    {
                        string strNombreArchivo =
                            objArchivo.NOMBRE_ARCHIVO.StartsWith("M02SC") ? "ArchivoContableC_" :
                            (objArchivo.NOMBRE_ARCHIVO.StartsWith("M02SD") ? "ArchivoContableD_" : "ArchivoContable");
                        File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo + _strPeriodo + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + objArchivo.EXTENSION, objArchivo.BYTE_ARRAY);
                    }
                    bool boolCargaCompleta = _cPersonales.Contabilidad_Registrar(listaRegistros);
                    if (!boolCargaCompleta)
                    {
                        throw new Exception("Se ha presentado un error en la carga de los datos ('BtnProcesarArchivo_Click'). Revise el servicio Crediseguro.Core.");
                    }
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "toastr.success('El proceso de carga de datos ha sido completado exitosamente.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                PopCargaContables.ShowOnPageLoad = false;
                CargaInicial();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void MostrarLogErrores(List<string> listaErrores)
        {
            try
            {
                string strMesProduccion = DateTime.ParseExact(_strPeriodo, "yyyyMM", CultureInfo.InvariantCulture).AddMonths(1).ToString("yyyyMM");
                string strNombreArchivo = "CONTABILIDAD_VALIDACION_" + _strPeriodo + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt";
                StreamWriter writer = new StreamWriter(CParametros.RutaArchivoValidacion + strNombreArchivo, true);
                writer.Write("***** VALIDACIÓN DE DATOS *****");
                writer.Write(Environment.NewLine);
                foreach (string strError in listaErrores)
                    writer.WriteLine(strError);
                writer.Write("***** FIN DE LA VALIDACIÓN *****");
                writer.Flush();
                writer.Close();
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ERROR_CARGA.html"));
                CProduccion _cProduccion = new CProduccion();
                var objCorreo1 = _cProduccion.Correo_Enviar(new Agente.ServicioProduccion.occ_correo
                {
                    Sistema = "CORE PERSONALES",
                    Asunto = "CONTABILIDAD | MES DE PRODUCCIÓN: " + strMesProduccion + " | OBSERVACIÓN EN ARCHIVO SELECCIONADO",
                    Contenido = strHtml,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    FlagHtml = true,
                    ListaCorreoDestinatario = new List<string>() { _objUsuario.Correo },
                    ListaCorreoCopia = new List<string>(),
                    ListaArchivosAdjuntos = new List<Agente.ServicioProduccion.occ_correo__archivo_adjunto>()
                    {
                        new Agente.ServicioProduccion.occ_correo__archivo_adjunto
                        {
                            FlagBytes = true,
                            Bytes = File.ReadAllBytes(CParametros.RutaArchivoValidacion + strNombreArchivo),
                            Nombre = strNombreArchivo
                        }
                    },
                    ListaImagenes = new List<Agente.ServicioProduccion.occ_correo__imagen>()
                    {
                        new Agente.ServicioProduccion.occ_correo__imagen
                        {
                            ContentId = "logo",
                            Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png"))
                        }
                    }
                });                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected OC_RESPONSE_FILE PartesProduccionCorredoras(string strNombreArchivo)
        {
            try
            {
                OC_RESPONSE_FILE objRespuesta = null;
                var DsetDatos = _cPersonales.GetDatasetProcedimiento(
                    "pro.SPR_GETLIST_REPORTE_PARTES_PRODUCCION_CORREDORAS", 
                    new List<Agente.ServicioPersonales.CParameter>() { new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodo } });
                DateTime dtMesProduccion = DateTime.ParseExact(_strPeriodo + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                dtMesProduccion = dtMesProduccion.AddMonths(1);
                string strMesProduccion = dtMesProduccion.ToString("yyyyMM");
                if (DsetDatos.Tables.Count == 1)
                {
                    using (var ms = new MemoryStream())
                    {
                        TextWriter tw = new StreamWriter(ms);
                        foreach (DataRow objDataRow in DsetDatos.Tables[0].Rows)
                        {
                            if (objDataRow[0].ToString().Trim() != string.Empty)
                            {
                                string strRegistro = string.Empty;
                                strRegistro = string.Format("{1},{0},{2},{3},{4},{5},{6},{7}",
                                    objDataRow[0].ToString().Trim(),
                                    objDataRow[1].ToString().Trim(),
                                    objDataRow[2].ToString().Trim(),
                                    objDataRow[3].ToString().Trim(),
                                    objDataRow[4].ToString().Trim(),
                                    objDataRow[5].ToString().Trim(),
                                    objDataRow[6].ToString().Trim(),
                                    objDataRow[7].ToString().Trim());
                                tw.Write(strRegistro);
                                tw.Write(Environment.NewLine);
                            }
                        }
                        tw.Flush();
                        ms.Position = 0;
                        objRespuesta = new OC_RESPONSE_FILE()
                        {
                            ByteArray = ms.ToArray(),
                            NombreArchivo = strNombreArchivo + ".209",
                            ContentType = "text/plain"
                        };
                    }
                }
                return objRespuesta;
            }
            catch
            {
                throw;
            }
        }
    }
}