﻿using Agente.ServicioAzure;
using DevExpress.Web.Bootstrap;
using Microsoft.Reporting.WebForms;
using Presentacion.Sitio.Controladores.Azure;
using Presentacion.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Presentacion.Sitio.Vista.Reportes.Operaciones
{
    public partial class DenunciaSiniestro : System.Web.UI.Page
    {
        private readonly CAzure _cAzure = new CAzure();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                GrvDenuncias.DataBind();
            PopDocumentos.ShowOnPageLoad = false;
        }
        protected void GrvDenuncias_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaDenunciaFormulario = _cAzure.GetListDenunciaFormulario();
                var listLexicosProducto = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "PRODUCTO");
                var listLexicosBroker = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "BROKER");
                var listLexicosCiudad = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "CIUDAD");
                var listaDenuncias = new List<OC_DENUNCIA_SINIESTRO>();
                foreach (DENUNCIA_FORMULARIO objDenunciaFormulario in listaDenunciaFormulario)
                {
                    listaDenuncias.Add(new OC_DENUNCIA_SINIESTRO()
                    {
                        NUMERO_DENUNCIA = objDenunciaFormulario.DEPBI_ID_DENUNCIA_FORMULARIO,
                        ASEGURADO = objDenunciaFormulario.DEPVC_ASEGURADO_NOMBRES + " " + objDenunciaFormulario.DEPVC_ASEGURADO_PATERNO + " " + objDenunciaFormulario.DEPVC_ASEGURADO_MATERNO,
                        PRODUCTO = listLexicosProducto.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.LEPVC_POLIZA_PRODUCTO).FirstOrDefault().LEPVC_DESC,
                        CODIGO_PRODUCTO = objDenunciaFormulario.LEPVC_POLIZA_PRODUCTO,
                        TOMADOR = objDenunciaFormulario.DESVC_POLIZA_TOMADOR,
                        BROKER = (objDenunciaFormulario.DEPVC_BROKER_NOMBRE != string.Empty) ? listLexicosBroker.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.DEPVC_BROKER_NOMBRE).FirstOrDefault().LEPVC_DESC : string.Empty,
                        CODIGO_BROKER = objDenunciaFormulario.DEPVC_BROKER_NOMBRE,
                        CIUDAD_SINIESTRO = listLexicosCiudad.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.LEPVC_SINIESTRO_CIUDAD).FirstOrDefault().LEPVC_DESC,
                        CODIGO_CIUDAD_SINIESTRO = objDenunciaFormulario.LEPVC_SINIESTRO_CIUDAD,
                        FECHA_OCURRENCIA = objDenunciaFormulario.DEPDT_SINIESTRO_FECHA_OCURRENCIA.ToString("dd/MM/yyyy"),
                        DESCRIPCION = objDenunciaFormulario.DEPVC_SINIESTRO_DESCRIPCION
                    });
                }
                GrvDenuncias.DataSource = listaDenuncias;
            }
            catch (Exception ex)
            {

            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                Session.Remove("ADJUNTOS");
                string strRutaArchivo = @"\\bcrcsw00\Comp_Sistemas\DenunciaSiniestro\";
                long longIdDenunciaFormulario = Convert.ToInt64(((BootstrapButton)sender).CommandArgument);
                var objDenunciaFormulario = _cAzure.GetListChildDenunciaFormulario(longIdDenunciaFormulario);
                var listaDenunciaDocumento = objDenunciaFormulario.DENUNCIA_DOCUMENTO;
                var listaDocumentos = new List<OC_DENUNCIA_DOCUMENTO>();
                LblIdDenunciaFormulario.Text = "Número de Denuncia: " + longIdDenunciaFormulario.ToString();
                foreach (DENUNCIA_DOCUMENTO objDenunciaDocumento in listaDenunciaDocumento)
                {
                    if (objDenunciaDocumento.DEPBT_DESCARGADO == false)
                    {
                        if (!Directory.Exists(strRutaArchivo + objDenunciaDocumento.DEPBI_ID_DENUNCIA_FORMULARIO))
                            Directory.CreateDirectory(strRutaArchivo + objDenunciaDocumento.DEPBI_ID_DENUNCIA_FORMULARIO);
                        File.WriteAllBytes(strRutaArchivo + objDenunciaDocumento.DEPBI_ID_DENUNCIA_FORMULARIO + @"\" + objDenunciaDocumento.DEPVC_NOMBRE, objDenunciaDocumento.DEPVB_ARCHIVO);
                        //actualizamos la BD de azure para liberar espacio
                        objDenunciaDocumento.DEPVB_ARCHIVO = null;
                        objDenunciaDocumento.DEPBT_DESCARGADO = true;
                        var ResponseDenunciaDocumento = _cAzure.ModificarDenunciaDocumento(objDenunciaDocumento);
                    }
                    listaDocumentos.Add(new OC_DENUNCIA_DOCUMENTO()
                    {
                        ID_DENUNCIA_FORMULARIO = objDenunciaDocumento.DEPBI_ID_DENUNCIA_FORMULARIO,
                        ID_DENUNCIA_DOCUMENTO = objDenunciaDocumento.DEPBI_ID_DENUNCIA_DOCUMENTO,
                        NOMBRE_ARCHIVO = objDenunciaDocumento.DEPVC_NOMBRE,
                        RUTA_ARCHIVO = strRutaArchivo + objDenunciaDocumento.DEPBI_ID_DENUNCIA_FORMULARIO + @"\" + objDenunciaDocumento.DEPVC_NOMBRE,
                        CONTENT_TYPE = objDenunciaDocumento.DEPVC_CONTENT_TYPE
                    });
                }
                Session["ADJUNTOS"] = listaDocumentos;
                GrvArchivos.DataSource = listaDocumentos;
                GrvArchivos.DataBind();
                PopDocumentos.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {

            }
        }
        protected void BtnDescargar_Click(object sender, EventArgs e)
        {
            try
            {
                var listaDocumentos = (List<OC_DENUNCIA_DOCUMENTO>)Session["ADJUNTOS"];
                long longIdDenunciaDocumento = Convert.ToInt64(((BootstrapButton)sender).CommandArgument);
                var objDenunciaDocumento = listaDocumentos.Where(w => w.ID_DENUNCIA_DOCUMENTO == longIdDenunciaDocumento).FirstOrDefault();
                byte[] bArrayArchivo = File.ReadAllBytes(objDenunciaDocumento.RUTA_ARCHIVO);
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objDenunciaDocumento.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objDenunciaDocumento.NOMBRE_ARCHIVO);
                Response.BinaryWrite(bArrayArchivo);
                Response.Flush();
                Response.End();
            }
            catch (Exception ex)
            {

            }
        }
        protected void ButtonXLSX1_Click(object sender, EventArgs e)
        {
            try
            {
                Warning[] warnings;
                string[] streamids;
                string mimeType;
                string encoding;
                string filenameExtension;
                ReportViewer RptExcel = new ReportViewer();
                RptExcel.ProcessingMode = ProcessingMode.Local;
                RptExcel.LocalReport.ReportPath = Server.MapPath("~/UI/rpt/RptDenunciaFormulario.rdlc");
                ReportDataSource datosExcel = new ReportDataSource("Datos", _cAzure.GetListDenunciaFormularioReporte());
                RptExcel.LocalReport.DataSources.Clear();
                RptExcel.LocalReport.DataSources.Add(datosExcel);
                RptExcel.LocalReport.Refresh();
                byte[] bReporte = RptExcel.LocalReport.Render("Excel", null, out mimeType, out encoding, out filenameExtension, out streamids, out warnings);
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = "application/xls";
                Response.AddHeader("content-disposition", "attachment;filename=ReporteDenunciaSiniestro_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xls");
                Response.BinaryWrite(bReporte);
                Response.Flush();
                Response.End();
            }
            catch (Exception ex)
            {
                //this.Master.RegistrarError(_user.UserId, this.GetType().Name, MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace, "Se ha producido un error inesperado al procesar el requerimiento");
            }
        }
    }
}