﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using Presentacion.Sitio.Controladores.Personales;
using System.IO;
using Agente.ServicioPersonales;
using System.Data;
using DevExpress.Web.Bootstrap;
using PresentacionWeb.Sitio.Entidades;
using DevExpress.Spreadsheet;
using System.Reflection;

namespace Presentacion.Sitio.Vista.Reportes.Tecnica
{
    public partial class ValidacionCierre : System.Web.UI.Page
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        #region Reservas Tecnicas
        protected void BtnValidacionRRC_Click(object sender, EventArgs e)
        {
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_RRC", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                using (var ms = new MemoryStream())
                {
                    TextWriter tw = new StreamWriter(ms);
                    foreach (DataRow objDataRow in DsetDatos.Tables[0].Rows)
                    {
                        if (objDataRow["REPORTE"].ToString().Trim() != string.Empty)
                        {
                            tw.Write(objDataRow["REPORTE"].ToString().Trim());
                            tw.Write(Environment.NewLine);
                        }
                    }
                    tw.Flush();
                    ms.Position = 0;
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = ms.ToArray(), CONTENT_TYPE = "text/plain", NOMBRE_ARCHIVO = "ValidacionRRC_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt" };
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
        #region Desgravamen
        protected void BtnDesgravamen_Click(object sender, EventArgs e)
        {
            string strRutaPlantilla = Server.MapPath("~/UI/templates/BASE_DESGRAVAMEN.xlsx");
            string strIdProducto = ((BootstrapButton)sender).CommandName;
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_VALIDACION_CESION_DESGRAVAMEN", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable }, new CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto } });
                if (DsetDatos.Tables[0].Rows.Count > 0)
                {
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "Reporte")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[0], false, 2, 0);
                            DEWorksheet.Range["A2:L" + (DsetDatos.Tables[0].Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                            DEWorksheet.Columns[2].NumberFormat = "dd/mm/yyyy";
                            DEWorksheet.Columns[3].NumberFormat = "#,##0.00";
                            DEWorksheet.Columns[5].NumberFormat = "#,##0.0000";
                            DEWorksheet.Columns[6].NumberFormat = "#,##0.0000";
                            DEWorksheet.Columns[8].NumberFormat = "#,##0.00";
                            DEWorksheet.Columns[10].NumberFormat = "#,##0.0000";
                            DEWorksheet.Columns[11].NumberFormat = "#,##0.0000";
                        }
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = strIdProducto + "_BaseDesgravamen_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "BtnDesgravamen_Click(ERROR)", "toastr.warning('Todavía no existe información para este mes, por favor intente más tarde.', 'Bases de Desgravamen', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
        #region Sistema de Beneficios
        protected void BtnSiniestrosReaseguro_Click(object sender, EventArgs e)
        {
            string strRutaPlantilla = Server.MapPath("~/UI/templates/SINIESTROS_REASEGURADOS.xlsx");
            try
            {
                var DsetSiniestros = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_SINIESTROS_REASEGURADOS", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (DsetSiniestros.Tables[0].Rows[0][0].ToString() == "TRUE" && DsetSiniestros.Tables[1].Rows.Count > 0)
                {
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "Reporte")
                        {
                            DEWorksheet.Cells["A1"].Value = "SINIESTROS REASEGURADOS - " + ((Label)Master.FindControl("LblMesProduccion")).Text;
                            DEWorksheet.Import(DsetSiniestros.Tables[1], false, 2, 0);
                            DEWorksheet.Range["A2:V" + (DsetSiniestros.Tables[1].Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                            DEWorksheet.Range["N3:P" + (DsetSiniestros.Tables[1].Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                            DEWorksheet.Columns[4].NumberFormat = "dd/mm/yyyy";
                            DEWorksheet.Columns[7].NumberFormat = "dd/mm/yyyy";
                            DEWorksheet.Columns[8].NumberFormat = "dd/mm/yyyy";
                        }
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "SiniestrosReasegurados_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "BtnSiniestrosReaseguro_Click(ERROR)", "toastr.warning('El registro de siniestros para este mes todavía no ha sido cerrado, por favor intente a partir del día " + DsetSiniestros.Tables[0].Rows[0][1].ToString() + ".', 'Sistema de Beneficios', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
    }
}