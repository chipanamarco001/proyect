﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Reportes.Tecnica
{
    public partial class Reaseguradores : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnReaseguroGenerico_Click(object sender, EventArgs e)
        {            
            string strRutaPlantilla = Server.MapPath("~/UI/templates/REASEGURO_GENERICO.xlsx");
            string strIdProducto = ((BootstrapButton)sender).CommandName;
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_REASEGURADORES", new List<CParameter>() {
                    new CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                    new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (DsetDatos.Tables[0] != null && DsetDatos.Tables[0].Rows.Count > 0)
                {
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "Reporte")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[0], false, 2, 0);
                            DEWorksheet.Range["A1:K" + (DsetDatos.Tables[0].Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                            DEWorksheet.Range["G2:k" + (DsetDatos.Tables[0].Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                        }                        
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);                    
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "ReporteReaseguro_" + strIdProducto + "_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Alerta_BtnReaseguroGenerico_Click", "toastr.error('Todavía no existe información para generar el reporte seleccionado, por favor intente de nuevo más tarde.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReaseguroDesgravamen_Click(object sender, EventArgs e)
        {
            string strRutaPlantilla = Server.MapPath("~/UI/templates/REASEGURO_DESGRAVAMEN.xlsx");
            string strIdProducto = ((BootstrapButton)sender).CommandName;
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_REASEGURADORES", new List<CParameter>() {
                    new CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                    new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (DsetDatos.Tables[0] != null && DsetDatos.Tables[0].Rows.Count > 0)
                {
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "Reporte")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[0], false, 2, 0);
                            DEWorksheet.Range["A2:AM" + (DsetDatos.Tables[0].Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                            DEWorksheet.Range["D3:F" + (DsetDatos.Tables[0].Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                        }
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "ReporteReaseguro_" + strIdProducto + "_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Alerta_BtnReaseguroGenerico_Click", "toastr.error('Todavía no existe información para generar el reporte seleccionado, por favor intente de nuevo más tarde.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReaseguroGrupales_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdProducto = ((BootstrapButton)sender).CommandName;
                string strIdReasegurador = ((BootstrapButton)sender).CommandArgument;
                string strRutaTemporal = Server.MapPath("~/UI/tmp/");
                string strRutaPlantilla = Server.MapPath("~/UI/templates/REASEGURO_GRUPALES.xlsx");
                var objFileInfo = new FileInfo(strRutaPlantilla);
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_REASEGURADORES_GRUPALES", new List<CParameter>() {
                    new CParameter() { Key = "@ID_PRODUCTO", Value = strIdProducto },
                    new CParameter() { Key = "@ID_REASEGURO", Value = strIdReasegurador },
                    new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (DsetDatos.Tables.Count >= 2 && DsetDatos.Tables[0].Rows.Count > 0)
                {
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if(DEWorksheet.Name == "Resumen")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                            DEWorksheet.Columns.Remove(7);
                            CellRange objRange = DEWorksheet.Range["A1:G" + (DsetDatos.Tables[0].Rows.Count + 1)];
                            objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                            CellRange objRange2 = DEWorksheet.Range["B2:G" + (DsetDatos.Tables[0].Rows.Count + 1)];
                            objRange2.NumberFormat = "#,##0.00";
                        }
                        if (DEWorksheet.Name == "Detalle")
                        {
                            DEWorksheet.Import(DsetDatos.Tables[1], false, 2, 0);
                            CellRange objRangeBorder = DEWorksheet.Range["A2:Y" + (DsetDatos.Tables[1].Rows.Count + 2)];
                            objRangeBorder.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                            DEWorksheet.Columns[9].NumberFormat = "dd/mm/yyyy";
                            DEWorksheet.Columns[14].NumberFormat = "dd/mm/yyyy";
                            DEWorksheet.Range["P3:U" + (DsetDatos.Tables[1].Rows.Count + 2)].NumberFormat = "#,##0.00";
                            if (strIdProducto != "VGESCO")
                                DEWorksheet.Columns.Remove(10, 5);
                        }
                    }
                    byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    HidDownload.Clear();
                    HidDownload.Add("Download", "true");
                    string strNombreReporte = string.Empty;
                    switch(strIdReasegurador)
                    {
                        case "HANN_2015":
                            strNombreReporte = "ReporteReaseguro (HANNOVER RE)_";
                            break;
                        case "GENRE_2015":
                            strNombreReporte = "ReporteReaseguro (GENERAL RE)_";
                            break;
                        default:
                            strNombreReporte = "ReporteReaseguro_";
                            break;
                    }
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = strNombreReporte + strIdProducto + "_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Alerta_BtnReaseguroGenerico_Click", "toastr.error('Todavía no existe información para generar el reporte seleccionado, por favor intente de nuevo más tarde.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}