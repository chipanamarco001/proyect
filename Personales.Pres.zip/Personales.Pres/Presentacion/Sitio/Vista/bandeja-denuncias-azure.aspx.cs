﻿using Agente.ServicioAzure;
using DevExpress.Web.Bootstrap;
using Microsoft.Reporting.WebForms;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Azure;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class bandeja_denuncias_azure : ControlUsuario
    {
        private readonly CAzure _cAzure = new CAzure();
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
                GrvDenuncias.DataBind();
        }
        protected void GrvDenuncias_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaDenunciaFormulario = _cAzure.GetListDenunciaFormulario();
                var listLexicosProducto = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "PRODUCTO");
                var listLexicosBroker = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "BROKER");
                var listLexicosCiudad = _cAzure.GetListLexicosPorTablaYTema("PARAMETRO", "CIUDAD");
                var listaDenuncias = new List<OC_DENUNCIA_SINIESTRO>();
                foreach (DENUNCIA_FORMULARIO objDenunciaFormulario in listaDenunciaFormulario.Where(w => w.DESDT_FECHA_INSERT >= DateTime.Now.AddMonths(-3) && w.DEPBT_ACTIVO == true))
                {
                    var objProducto = listLexicosProducto.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.LEPVC_POLIZA_PRODUCTO).FirstOrDefault();
                    var objBroker = listLexicosBroker.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.DEPVC_BROKER_NOMBRE).FirstOrDefault();
                    var objCiudadSiniestro = listLexicosCiudad.Where(w => w.LEPVC_VALOR == objDenunciaFormulario.LEPVC_SINIESTRO_CIUDAD).FirstOrDefault();
                    listaDenuncias.Add(new OC_DENUNCIA_SINIESTRO()
                    {
                        NUMERO_DENUNCIA = objDenunciaFormulario.DEPBI_ID_DENUNCIA_FORMULARIO,
                        ASEGURADO = objDenunciaFormulario.DEPVC_ASEGURADO_NOMBRES + " " + objDenunciaFormulario.DEPVC_ASEGURADO_PATERNO + " " + objDenunciaFormulario.DEPVC_ASEGURADO_MATERNO,
                        PRODUCTO = (objProducto != null) ? objProducto.LEPVC_DESC : string.Empty,
                        CODIGO_PRODUCTO = objDenunciaFormulario.LEPVC_POLIZA_PRODUCTO,
                        TOMADOR = objDenunciaFormulario.DESVC_POLIZA_TOMADOR,
                        BROKER = (objDenunciaFormulario.DEPVC_BROKER_NOMBRE != string.Empty) ? ((objBroker != null) ? objBroker.LEPVC_DESC : string.Empty) : string.Empty,
                        CODIGO_BROKER = objDenunciaFormulario.DEPVC_BROKER_NOMBRE,
                        CIUDAD_SINIESTRO = (objCiudadSiniestro != null) ? objCiudadSiniestro.LEPVC_DESC : string.Empty,
                        CODIGO_CIUDAD_SINIESTRO = objDenunciaFormulario.LEPVC_SINIESTRO_CIUDAD,
                        FECHA_OCURRENCIA = objDenunciaFormulario.DEPDT_SINIESTRO_FECHA_OCURRENCIA.ToString("dd/MM/yyyy"),
                        DESCRIPCION = objDenunciaFormulario.DEPVC_SINIESTRO_DESCRIPCION
                    });
                }
                GrvDenuncias.DataSource = listaDenuncias.OrderByDescending(o => o.NUMERO_DENUNCIA).ToList();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                Session.Remove("ADJUNTOS");
                var objLexico = _cPersonales.GetListLexicoPorTablaYTema("RUTA", "BANDEJA_DENUNCIAS_AZURE").FirstOrDefault();
                if (objLexico == null)
                    throw new Exception("La ruta donde se encuentran los archivos no pudo encontrarse.");
                string strRutaArchivo = objLexico.LEPVC_VALOR;
                long longIdDenunciaFormulario = Convert.ToInt64(HidIdDenuncia.Value);
                var listaDocumentos = new List<OC_DENUNCIA_DOCUMENTO>();
                var listaArchivosDenuncia = _cAzure.ListaArchivosDenunciaPorId(longIdDenunciaFormulario);
                LblIdDenunciaFormulario.Text = "Número de Denuncia: " + longIdDenunciaFormulario.ToString();
                foreach (var objArchivoDenuncia in listaArchivosDenuncia)
                {
                    if (!objArchivoDenuncia.DEPBT_DESCARGADO && objArchivoDenuncia.DEPVB_ARCHIVO != null)
                    {
                        if (!Directory.Exists(strRutaArchivo + longIdDenunciaFormulario))
                            Directory.CreateDirectory(strRutaArchivo + longIdDenunciaFormulario);
                        File.WriteAllBytes(strRutaArchivo + longIdDenunciaFormulario + @"\" + objArchivoDenuncia.DEPVC_NOMBRE, objArchivoDenuncia.DEPVB_ARCHIVO);
                        //actualizamos la BD de azure para liberar espacio
                        var ResponseDenunciaDocumento = _cAzure.ModificarDenunciaDocumento(new DENUNCIA_DOCUMENTO()
                        {
                            DEPBI_ID_DENUNCIA_FORMULARIO = longIdDenunciaFormulario,
                            DEPBI_ID_DENUNCIA_DOCUMENTO = objArchivoDenuncia.DEPBI_ID_DENUNCIA_DOCUMENTO,
                            DEPVB_ARCHIVO = null,
                            DEPBT_DESCARGADO = true,
                            DEPBT_ACTIVO = true
                        });
                    }
                    if (!string.IsNullOrEmpty(objArchivoDenuncia.DEPVC_NOMBRE))
                        listaDocumentos.Add(new OC_DENUNCIA_DOCUMENTO()
                        {
                            ID_DENUNCIA_FORMULARIO = longIdDenunciaFormulario,
                            ID_DENUNCIA_DOCUMENTO = objArchivoDenuncia.DEPBI_ID_DENUNCIA_DOCUMENTO,
                            NOMBRE_ARCHIVO = objArchivoDenuncia.DEPVC_NOMBRE,
                            RUTA_ARCHIVO = strRutaArchivo + longIdDenunciaFormulario + @"\" + objArchivoDenuncia.DEPVC_NOMBRE,
                            CONTENT_TYPE = objArchivoDenuncia.DEPVC_CONTENT_TYPE
                        });
                }
                Session["ADJUNTOS"] = listaDocumentos;
                GrvArchivos.DataSource = listaDocumentos;
                GrvArchivos.DataBind();
                PopDocumentos.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "alert('Se ha presentado un error: " + ex.Message + ".');", true);
            }
        }
        protected void BtnDescargar_Click(object sender, EventArgs e)
        {
            try
            {
                var listaDocumentos = (List<OC_DENUNCIA_DOCUMENTO>)Session["ADJUNTOS"];
                long longIdDenunciaDocumento = Convert.ToInt64(((BootstrapButton)sender).CommandArgument);
                var objDenunciaDocumento = listaDocumentos.Where(w => w.ID_DENUNCIA_DOCUMENTO == longIdDenunciaDocumento).FirstOrDefault();
                byte[] objDocumento = File.ReadAllBytes(objDenunciaDocumento.RUTA_ARCHIVO);
                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = objDocumento,
                    CONTENT_TYPE = objDenunciaDocumento.CONTENT_TYPE,
                    NOMBRE_ARCHIVO = objDenunciaDocumento.NOMBRE_ARCHIVO
                };
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void ButtonXLSX1_Click(object sender, EventArgs e)
        {
            try
            {
                ReportViewer RptExcel = new ReportViewer();
                RptExcel.ProcessingMode = ProcessingMode.Local;
                RptExcel.LocalReport.ReportPath = Server.MapPath("~/UI/rpt/RptDenunciaFormulario.rdlc");
                ReportDataSource datosExcel = new ReportDataSource("Datos", _cAzure.GetListDenunciaFormularioReporte());
                RptExcel.LocalReport.DataSources.Clear();
                RptExcel.LocalReport.DataSources.Add(datosExcel);
                RptExcel.LocalReport.Refresh();
                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = RptExcel.LocalReport.Render("Excel"),
                    CONTENT_TYPE = "application/xls",
                    NOMBRE_ARCHIVO = "ReporteDenunciaSiniestro_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xls"
                };
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO.Replace(",", string.Empty));
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
    }
}