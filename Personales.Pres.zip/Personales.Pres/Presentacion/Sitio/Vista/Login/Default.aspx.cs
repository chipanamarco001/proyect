﻿using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Personales;
using System;
using System.IO;
using System.Web;
using System.Web.UI;

namespace PresentacionWeb.Sitio.Vista.Login
{
    public partial class Default : ControlUsuario
    {
        private string _strIdUsuario = string.Empty;
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCore _cCore = new CCore();
        protected void Page_Load(object sender, EventArgs e)
        {
            DatosIniciales();
        }
        protected void BtnIngresar_Click(object sender, EventArgs e)
        {
            try
            {
                var objUsuario = _cPersonales.ValidaAccesoUsuario();             
                if (objUsuario != null && objUsuario.Menu.Count > 0)
                {
                    Session["SessionUsuario"] = objUsuario;
                    Response.Redirect("~/Sitio/Vista/Inicio/Default.aspx", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('El usuario no cuenta con acceso al sistema.', 'ACCESOS', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    Session.Remove("User");
                }
            }
            catch (Exception ex)
            {
                Session.Clear();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('" + ex.Message + ".', 'ERROR!', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
        }
        protected void DatosIniciales()
        {
            Session.Clear();
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (windowsIdentity != null)
                _strIdUsuario = (HttpContext.Current.User.Identity.Name != string.Empty) ? HttpContext.Current.User.Identity.Name : windowsIdentity.Name;
            _strIdUsuario = _strIdUsuario.Split(new[] { "\\" }, StringSplitOptions.None)[1];
            _strIdUsuario = _strIdUsuario.ToUpper();
            Session["IdUsuario"] = _strIdUsuario;
            var objUsuario = _cCore.DatosDirectorioActivo(_strIdUsuario);
            PnlUsuarioDominio.Visible = false;
            if (objUsuario != null)
            {                
                PnlUsuarioDominio.Visible = true;
                LblNombreUsuario.Text = objUsuario.NombreCompleto;
                LblIdUsuario.Text = "(" + objUsuario.Dominio + "\\" + objUsuario.Matricula + ")";
                byte[] bytes;
                if (objUsuario.Foto != null)
                {
                    bytes = objUsuario.Foto;
                }
                else
                {
                    string strRutaImgUsuario = Server.MapPath(@"~/UI/img/users/1.jpg");
                    var objFileInfo = new FileInfo(strRutaImgUsuario);
                    bytes = File.ReadAllBytes(strRutaImgUsuario);
                }
                string strBytesImg = Convert.ToBase64String(bytes);
                Session["ImgUsuario"] = strBytesImg;
                ImgUsuarioDominio.ImageUrl = "Usuario.ashx";
            }
            else
            {
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=No se ha podido obtener la información del usuario que inicio sesión en este equipo (" + _strIdUsuario + "). El acceso al sistema ha sido denegado.", false);
            }
        }
    }
}