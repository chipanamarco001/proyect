﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class consulta_compliance : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
		private readonly CDocumentos _cDocumentos = new CDocumentos();
		protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Limpiar();
            }
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cPersonales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }



        private void Limpiar()
        {
            try
            {
                var listaLexicosDocumento = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "DOCUMENTO_IDENTIDAD").ToList();
                CmbBusquedaDocumentoTipo.Items.Clear();
                CmbBusquedaDocumentoTipo.DataSource = listaLexicosDocumento.Where(w => w.LEPVC_TEMA == "TIPO").ToList().OrderBy(o => o.LEPVC_DESC_CORTA);
                CmbBusquedaDocumentoTipo.TextField = "LEPVC_DESC_CORTA";
                CmbBusquedaDocumentoTipo.ValueField = "LEPVC_VALOR";
                CmbBusquedaDocumentoTipo.DataBind();
                var grpCumplimiento = (BootstrapLayoutGroup)BflResultados.FindItemOrGroupByName("Cumplimiento");
                grpCumplimiento.CssClasses.GroupHeader = "bg-dark font-weight-bold text-white";
                grpCumplimiento.Caption = "CUMPLIMIENTO (CRS)";
                GrvCumplimiento.DataSource = new List<ocp_an_bcp__response__detalle>();
                GrvCumplimiento.DataBind();
                var grpListasInternacionales = (BootstrapLayoutGroup)BflResultados.FindItemOrGroupByName("ListasInternacionales");
                grpListasInternacionales.CssClasses.GroupHeader = "bg-dark font-weight-bold text-white";
                grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC)";
                GrvListasInternacionales.DataSource = new List<occ_amlc__coincidencia>();
                GrvListasInternacionales.DataBind();
                CmbBusquedaDocumentoTipo.Value = null;
                TxtBusquedaDocumentoNumero.Value = null;
                TxtBusquedaDocumentoComplemento.Value = null;
                TxtBusquedaPaterno.Value = null;
                TxtBusquedaMaterno.Value = null;
                TxtBusquedaNombres.Value = null;
                CmbBusquedaDocumentoTipo.ClientEnabled = true;
                TxtBusquedaDocumentoNumero.ClientEnabled = true;
                TxtBusquedaDocumentoComplemento.ClientEnabled = false;
                TxtBusquedaPaterno.ClientEnabled = true;
                TxtBusquedaMaterno.ClientEnabled = true;
                TxtBusquedaNombres.ClientEnabled = true;
                BtnLimpiar.ClientVisible = false;
                BtnConsultar.ClientVisible = true;
                btnConstanciaBusqueda.ClientVisible = false;

			}
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                CmbBusquedaDocumentoTipo.ClientEnabled = false;
                TxtBusquedaDocumentoNumero.ClientEnabled = false;
                TxtBusquedaDocumentoComplemento.ClientEnabled = false;
                TxtBusquedaPaterno.ClientEnabled = false;
                TxtBusquedaMaterno.ClientEnabled = false;
                TxtBusquedaNombres.ClientEnabled = false;
                BtnConsultar.ClientVisible = false;
                BtnLimpiar.ClientVisible = true;
                btnConstanciaBusqueda.ClientVisible = true;
                ///
                var objRequest = new ocp_an_bcp__request
                {
                    idcTipo = (CmbBusquedaDocumentoTipo.SelectedItem.Value.ToString() == "CI") ? "Q" : CmbBusquedaDocumentoTipo.SelectedItem.Value.ToString(),
                    idcNumero = TxtBusquedaDocumentoNumero.Text.Trim(),
                    idcComplemento = string.IsNullOrEmpty(TxtBusquedaDocumentoComplemento.Text) ? "00" : TxtBusquedaDocumentoComplemento.Text.Trim().ToUpper(),
                    idcExtension = "00",
                    matricula = _objUsuario.Matricula
                };
                var grpCumplimiento = (BootstrapLayoutGroup)BflResultados.FindItemOrGroupByName("Cumplimiento");
                grpCumplimiento.CssClasses.GroupHeader = "bg-dark font-weight-bold text-white";
                grpCumplimiento.Caption = "CUMPLIMIENTO (CRS)";
                bool boolCumplimiento = false;
                string strRespuestaCumplimiento = string.Empty;
                var listaCumplimiento = new List<ocp_an_bcp__response__detalle>();

				var objRespaldoCompliance = new RESPALDO_COMPLIANCE();
				objRespaldoCompliance.REPVC_TIPO_DOCUMENTO = Convert.ToString(CmbBusquedaDocumentoTipo.SelectedItem.Value);
				objRespaldoCompliance.REPVC_NUMERO_DOCUMENTO = TxtBusquedaDocumentoNumero.Text;
				objRespaldoCompliance.RESVC_DOCUMENTO_COMPLEMENTO = TxtBusquedaDocumentoComplemento.Text;
                objRespaldoCompliance.RESVC_AP_PATERNO = TxtBusquedaPaterno.Text;
				objRespaldoCompliance.RESVC_AP_MATERNO = TxtBusquedaMaterno.Text;
				objRespaldoCompliance.RESVC_NOMBRE = TxtBusquedaNombres.Text;
				///archivo negativo
				if (Convert.ToString(CmbBusquedaDocumentoTipo.SelectedItem.Value) != "NIT")
                {
                    for (int index = 1; index <= 11; index++)
                    {
                        switch (index)
                        {
                            case 1: objRequest.idcExtension = "XX"; break;
                            case 2: objRequest.idcExtension = "LP"; break;
                            case 3: objRequest.idcExtension = "CB"; break;
                            case 4: objRequest.idcExtension = "SC"; break;
                            case 5: objRequest.idcExtension = "OR"; break;
                            case 6: objRequest.idcExtension = "PO"; break;
                            case 7: objRequest.idcExtension = "TJ"; break;
                            case 8: objRequest.idcExtension = "CH"; break;
                            case 9: objRequest.idcExtension = "PA"; break;
                            case 10: objRequest.idcExtension = "BE"; break;
                            case 11: objRequest.idcExtension = "PE"; break;
                        }
                        var objResponse = ocp_an_bcp.ConsultaArchivoNegativo(objRequest);
                        if (objResponse.data.encontrado)
                        {
                            boolCumplimiento = true;
                            strRespuestaCumplimiento = objResponse.data.detalle.ToUpper();
                            objResponse.detalle.ForEach(s =>
                            {
                                s.causal =
                                    CmbBusquedaDocumentoTipo.SelectedItem.Value.ToString() + "-" +
                                    TxtBusquedaDocumentoNumero.Text.Trim() +
                                    TxtBusquedaDocumentoComplemento.Text.Trim().ToUpper() +
                                    ((objRequest.idcExtension == "XX") ? string.Empty : objRequest.idcExtension);
                            });
                            listaCumplimiento.AddRange(objResponse.detalle);
							//objRespaldoCompliance.RESVC_NOMBRE = objResponse.data.

						}
                    }

                    if (boolCumplimiento)
                    {
                        grpCumplimiento.CssClasses.GroupHeader = "bg-danger font-weight-bold text-white";
                        grpCumplimiento.Caption = "CUMPLIMIENTO (CRS): " + strRespuestaCumplimiento;
                        GrvCumplimiento.DataSource = listaCumplimiento;
						objRespaldoCompliance.RESBT_ESTADO_ARCHIVO_NEGATIVO = true;
						
					}
                    else
                    {
                        grpCumplimiento.CssClasses.GroupHeader = "bg-success font-weight-bold text-white";
                        grpCumplimiento.Caption = "CUMPLIMIENTO (CRS): EL CLIENTE NO SE ENCUENTRA EN ARCHIVO NEGATIVO BOLIVIA";
                        GrvCumplimiento.DataSource = new List<ocp_an_bcp__response__detalle>();
						objRespaldoCompliance.RESBT_ESTADO_ARCHIVO_NEGATIVO = false;
					}
                }
                else
                {
					grpCumplimiento.CssClasses.GroupHeader = "bg-success font-weight-bold text-white";
					grpCumplimiento.Caption = "CUMPLIMIENTO (CRS): NO SE PUEDE REALIZAR LA BUSQUEDA";
					GrvCumplimiento.DataSource = new List<ocp_an_bcp__response__detalle>();
					objRespaldoCompliance.RESBT_ESTADO_ARCHIVO_NEGATIVO = false;
				}
                GrvCumplimiento.DataBind();


                ///listas internacionales
                var grpListasInternacionales = (BootstrapLayoutGroup)BflResultados.FindItemOrGroupByName("ListasInternacionales");
                grpListasInternacionales.CssClasses.GroupHeader = "bg-dark font-weight-bold text-white";
                grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC)";
                                
                if (Convert.ToString(CmbBusquedaDocumentoTipo.SelectedItem.Value) == "NIT")
                {
                    var objConsultaAMLC = _cPersonales.AMLC_ComsultaListasInternacionalesPJ(  
                                        //"1002653024",
                                        TxtBusquedaDocumentoNumero.Text.Trim(),					
                                        TxtBusquedaNombres.Text.Trim().ToUpper());

                    if (objConsultaAMLC.ListaCoincidencias == null || objConsultaAMLC.ListaCoincidencias.Count <= 0)
                    {
                        grpListasInternacionales.CssClasses.GroupHeader = "bg-success font-weight-bold text-white";
                        grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC): " + objConsultaAMLC.Respuesta.ToUpper().Trim();
                        GrvListasInternacionales.DataSource = new List<occ_amlc__coincidencia_pj>();
                        objRespaldoCompliance.RESBT_ESTADO_LISTAS_INTERNACIONALES = false;                        
                    }
                    else
                    {
                        grpListasInternacionales.CssClasses.GroupHeader = "bg-danger font-weight-bold text-white";
                        grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC): " + objConsultaAMLC.Respuesta.ToUpper().Trim();
                        GrvListasInternacionales.DataSource = objConsultaAMLC.ListaCoincidencias;
                        objRespaldoCompliance.RESBT_ESTADO_LISTAS_INTERNACIONALES = true;                        
                    }
				}
                else
                {
                    var objConsultaAMLC = _cPersonales.AMLC_ComsultaListasInternacionales(
                                (CmbBusquedaDocumentoTipo.SelectedItem.Value.ToString() == "CI") ? "Q" : CmbBusquedaDocumentoTipo.SelectedItem.Value.ToString(),
                                TxtBusquedaDocumentoNumero.Text.Trim(),
                                TxtBusquedaDocumentoComplemento.Text.Trim().ToUpper(),
                                TxtBusquedaPaterno.Text.Trim().ToUpper(),
                                TxtBusquedaMaterno.Text.Trim().ToUpper(),
                                TxtBusquedaNombres.Text.Trim().ToUpper());
					if (objConsultaAMLC.ListaCoincidencias.Count > 0)
					{
						grpListasInternacionales.CssClasses.GroupHeader = "bg-danger font-weight-bold text-white";
						grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC): " + objConsultaAMLC.Respuesta.ToUpper().Trim();
						GrvListasInternacionales.DataSource = objConsultaAMLC.ListaCoincidencias;
						objRespaldoCompliance.RESBT_ESTADO_LISTAS_INTERNACIONALES = true;
						
					}
					else
					{
						grpListasInternacionales.CssClasses.GroupHeader = "bg-success font-weight-bold text-white";
						grpListasInternacionales.Caption = "LISTAS INTERNACIONALES (AMLC): " + objConsultaAMLC.Respuesta.ToUpper().Trim();
						GrvListasInternacionales.DataSource = new List<occ_amlc__coincidencia>();
						objRespaldoCompliance.RESBT_ESTADO_LISTAS_INTERNACIONALES = false;						
					}
				}                                             
				
                GrvListasInternacionales.DataBind();

                var response = _cPersonales.RespaldoComplianceRegistrar(objRespaldoCompliance);
                Session["RESPALDO_COMPLIANCE"] = response;
			}
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

		protected void btnConstanciaBusqueda_Click(object sender, EventArgs e)
		{
			try
			{
                var objRespaldoCompliance = (RESPALDO_COMPLIANCE)Session["RESPALDO_COMPLIANCE"];

				var objArchivoRespuesta = _cDocumentos.Documento_Generar(
							"COMP_001",
							new List<occ_response_file__parametro>() {
				new occ_response_file__parametro { Nombre = "longIdRespaldo", Valor = objRespaldoCompliance.REPBI_ID_RESPALDO },
				new occ_response_file__parametro { Nombre = "strFormato", Valor = "PDF" }
				});

				string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));

                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc),
                    CONTENT_TYPE = "application/pdf",
                    NOMBRE_ARCHIVO = objRespaldoCompliance.REPVC_NUMERO_DOCUMENTO + ".pdf"                   
                };

				ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);

			}
			catch (Exception ex)
			{
				Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void BtnDownload_Click(object sender, EventArgs e)
		{
			if (Session["DOWNLOAD"] != null)
			{
				var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
				Session.Remove("DOWNLOAD");
				Response.Buffer = true;
				Response.Clear();
				Response.ContentType = objArchivo.CONTENT_TYPE;
				Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
				Response.BinaryWrite(objArchivo.BYTE_ARRAY);
				Response.Flush();
				Response.End();
			}
		}

		protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            try
            {
                Limpiar();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}