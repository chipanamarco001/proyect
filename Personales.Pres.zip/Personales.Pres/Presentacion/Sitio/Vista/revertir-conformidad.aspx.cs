﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using DocumentFormat.OpenXml.Drawing.Charts;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class revertir_conformidad : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCore _cCore = new CCore();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session["revertir_conformidad__periodoActual"] = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE").First().LEPVC_VALOR;
                Session["revertir_conformidad__listaRevertir"] = _cPersonales.GetListLexicoPorTabla("REVERTIR");
                CargaInicial();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void CargaInicial()
        {
            try
            {
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                var objConformidades = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_CIERRE",
                    new List<CParameter>() { new CParameter() { Key = "PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (objConformidades.Tables.Count >= 3)
                {
                    for (int index = 0; index < objConformidades.Tables[2].Rows.Count; index++)
                    {
                        var objUsuario = _cCore.DatosDirectorioActivo(objConformidades.Tables[2].Rows[index]["USUARIO"].ToString());
                        objConformidades.Tables[2].Rows[index]["USUARIO"] = objConformidades.Tables[2].Rows[index]["USUARIO"].ToString() + " - " + objUsuario.NombreCompleto;
                    }
                }
                Session.Remove("revertir_conformidad__listaConformidades");
                Session["CONFORMIDADES"] = objConformidades;
                GrvConformidades.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CONFORMIDADES"] != null)
                {
                    var objDataSet = (DataSet)Session["CONFORMIDADES"];
                    var listaConformidades = new List<OcpConformidades>();
                    if (Session["revertir_conformidad__listaConformidades"] == null)
                    {
                        for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                        {
                            listaConformidades.Add(new OcpConformidades
                            {
                                DescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString(),
                                DescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString(),
                                Estado = objDataSet.Tables[1].Rows[index]["ESTADO"].ToString(),
                                Usuario = objDataSet.Tables[1].Rows[index]["USUARIO"].ToString(),
                                Fecha = string.IsNullOrEmpty(objDataSet.Tables[1].Rows[index]["FECHA"].ToString()) ? string.Empty : Convert.ToDateTime(objDataSet.Tables[1].Rows[index]["FECHA"]).ToString("dd/MM/yyyy HH:mm"),
                                NumeroNivel = Convert.ToInt32(objDataSet.Tables[1].Rows[index]["NUMERO_NIVEL"]),
                                IdNivel = objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString(),
                                IdGrupo = objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString(),
                                FechaInicio = string.IsNullOrEmpty(objDataSet.Tables[1].Rows[index]["FECHA_INICIO"].ToString()) ? string.Empty : Convert.ToDateTime(objDataSet.Tables[1].Rows[index]["FECHA_INICIO"]).ToString("dd/MM/yyyy HH:mm")
                            });
                        }
                        Session["revertir_conformidad__listaConformidades"] = listaConformidades;
                    }
                    listaConformidades = (List<OcpConformidades>)Session["revertir_conformidad__listaConformidades"];
                    GrvConformidades.DataSource = listaConformidades;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            var objKeyValue = (sender as BootstrapGridView).GetMasterRowKeyValue();
            var objDataSet = (DataSet)Session["CONFORMIDADES"];
            var GrvResponsables = (sender as BootstrapGridView);
            DataView dvResponsable = new DataView(objDataSet.Tables[2]);
            dvResponsable.RowFilter = "ID_GRUPO = '" + objKeyValue.ToString() + "'";
            GrvResponsables.DataSource = dvResponsable;
        }
        protected void BtnAccion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccion.Contains("IdGrupo"))
                {
                    var listaConformidades = (List<OcpConformidades>)Session["revertir_conformidad__listaConformidades"];
                    string strIdGrupo = HidAccion.Get("IdGrupo").ToString();
                    var objConformidad = listaConformidades.FirstOrDefault(f => f.IdGrupo == strIdGrupo);
                    Session["revertir_conformidad__objConformidad"] = objConformidad;
                    var objUsuario = _cCore.DatosDirectorioActivo(objConformidad.Usuario);
                    LblConformidadUsuario.Text = objConformidad.Usuario + " - " + objUsuario.NombreCompleto;
                    LblConformidadFecha.Text = objConformidad.Fecha;
                    LblConformidadProceso.Text = objConformidad.DescripcionNivel + " | " + objConformidad.DescripcionConformidad;
                    LblUsuarioConfirmacion.Text = _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto;
                    TxtComentarioConformidad.Text = null;
                    TxtComentarioConformidad.IsValid = true;
                    TxtPassword.Text = null;
                    TxtPassword.IsValid = true;
                    PopConformidad.ShowOnPageLoad = true;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_CustomButtonInitialize(object sender, BootstrapGridViewCustomButtonEventArgs e)
        {
            try
            {
                e.Visible = DevExpress.Utils.DefaultBoolean.False;
                var listaConformidades = (List<OcpConformidades>)Session["revertir_conformidad__listaConformidades"];
                var strPeriodoActual = Session["revertir_conformidad__periodoActual"].ToString();
                if (listaConformidades.Exists(f => f.Estado == "CONFORME") && _strPeriodoContable == strPeriodoActual)
                {
                    BootstrapGridView iGrvBandeja = (BootstrapGridView)sender;
                    var objConformidad = (OcpConformidades)iGrvBandeja.GetRow(e.VisibleIndex);
                    int intNivelHabilitado = listaConformidades.Where(w => w.Estado == "CONFORME").Max(m => m.NumeroNivel);
                    int intNumeroNivel = objConformidad.NumeroNivel;
                    if (intNivelHabilitado == intNumeroNivel && objConformidad.Estado == "CONFORME")
                    {
                        string strIdGrupo = objConformidad.IdGrupo;
                        var objRevertir = ((List<LEXICO>)Session["revertir_conformidad__listaRevertir"]).FirstOrDefault(w => w.LEPVC_TEMA == strIdGrupo);
                        _objUsuario = (occ_usuario)Session["SessionUsuario"];
                        //usuario principal - gerente de area
                        var listaUsuarioPrincipal = _cPersonales.Usuario_ObtenerListaPorIdRol(Convert.ToInt64(objRevertir.LEPVC_VALOR));
                        if (listaUsuarioPrincipal.Exists(f => f.USPVC_ID_USUARIO == _objUsuario.Matricula))
                        {
                            e.Visible = DevExpress.Utils.DefaultBoolean.True;
                        }
                        else
                        {
                            //usuario backup - gerente general
                            var listaUsuarioBackup = _cPersonales.Usuario_ObtenerListaPorIdRol(Convert.ToInt64(objRevertir.LEPVC_DESC_CORTA));
                            if (listaUsuarioBackup.Exists(f => f.USPVC_ID_USUARIO == _objUsuario.Matricula))
                            {
                                e.Visible = DevExpress.Utils.DefaultBoolean.True;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CbPassword_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            e.Result = "false";
            if (_cCore.ValidarAutenticacion(_objUsuario.Matricula, TxtPassword.Text.Trim()))
            {
                e.Result = "true";
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                var objConformidad = (OcpConformidades)Session["revertir_conformidad__objConformidad"];
                DateTime dtMesProduccion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1);
                string strMesProduccionLiteral = dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString();
                if (_cPersonales.Conformidad_RevertirPorIdGrupo(_strPeriodoContable, objConformidad.IdGrupo, TxtComentarioConformidad.Text.Trim().ToUpper()))
                {
                    CorreoReversionRegistrada(objConformidad);
                    PopConformidad.ShowOnPageLoad = false;
                    Session.Remove("revertir_conformidad__objConformidad");
                    CargaInicial();
                    Master.MostrarToastr("success", "CIERRE MENSUAL - " + strMesProduccionLiteral, "La conformidad seleccionada ha sido revertida exitosamente.");
                }
                else
                {
                    Master.MostrarToastr("error", "CIERRE MENSUAL - " + strMesProduccionLiteral, "No se pudo completar la reversión de la conformidad. Por favor intente más tarde.");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoReversionRegistrada(OcpConformidades objConformidad)
        {
            try
            {
                DateTime dtMesProduccion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1);
                string 
                    strMesProduccion = dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString(),
                    strIdNivel = objConformidad.IdNivel,
                    strDescripcionNivel = objConformidad.DescripcionNivel,
                    strDescripcionConformidad = objConformidad.DescripcionConformidad;
                List<string> listaMailTO = new List<string>();
                List<string> listaMailCC = new List<string>();
                ///destinatarios del correo
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                    {
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                    }
                }
                ///destinatarios en copia
                var objLexicoMailCC = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-INF-CC").First();
                foreach (string strCorreo in objLexicoMailCC.LEPVC_VALOR.Split(';').ToList())
                {
                    listaMailCC.Add(strCorreo.ToLower());
                }
                listaMailCC.Add(_objUsuario.Correo.ToLower());
                ///armamos el contenido del correo
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_REVERTIDA.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", strMesProduccion);
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#COMENTARIO#", TxtComentarioConformidad.Text.Trim().ToUpper());
                var objResponse = new CProduccion().Correo_Enviar(new Agente.ServicioProduccion.occ_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL | " + strMesProduccion + " | CONFORMIDAD REVERTIDA: " + strDescripcionNivel + " (" + strDescripcionConformidad + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true, 
                    Sistema = "CORE PERSONALES",
                    ListaImagenes = new List<Agente.ServicioProduccion.occ_correo__imagen>(), 
                    ListaArchivosAdjuntos = new List<Agente.ServicioProduccion.occ_correo__archivo_adjunto>()
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}