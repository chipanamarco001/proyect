﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Finanzas
{
    public partial class GenerarContabilidad : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private readonly CCore _cCore = new CCore();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();            
            if (!IsPostBack)
            {
                CargaInicial();
            }            
            LblUsuarioConfirmacion.Text = _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto;
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void CargaInicial()
        {
            try
            {
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                Session.Remove("DOWNLOAD");                
                PnlGenerar.ClientVisible = false;
                PnlCuadre.ClientVisible = false;
                if (Session["ASIENTOS_REINTENTAR"] != null)
                {
                    Session.Remove("ASIENTOS_REINTENTAR");
                    PnlGenerar.ClientVisible = true;
                }
                else
                {
                    var objResponse = _cPersonales.GetDatasetProcedimiento("pro.SPR_ASIENTOS_CONTABLES_VALIDAR", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                    if (objResponse.Tables.Count > 0)
                    {
                        Session["CUADRE_CONTABLE"] = objResponse.Tables[0];
                        GrvBolivianos.DataBind();
                        GrvDolares.DataBind();
                        Session["GenerarContabilidad__ValidacionRRC"] = objResponse.Tables[1];
                        GrvValidacionRRC.DataBind();
                        PnlCuadre.ClientVisible = true;
                        PnlNotificacionSuccess.Visible = false;
                        var DtblConformidades = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_CIERRE", new List<CParameter>() { new CParameter() { Key = "PERIODO_CONTABLE", Value = _strPeriodoContable } }).Tables[1];
                        BtnReprocesarAsientos.ClientSideEvents.Click = null;
                        BtnReprocesarAsientos.ClientVisible = true;
                        for (int index = 0; index < DtblConformidades.Rows.Count; index++)
                        {
                            if (DtblConformidades.Rows[index]["NUMERO_NIVEL"].ToString() == "3" && DtblConformidades.Rows[index]["ESTADO"].ToString() == "CONFORME")
                            {
                                BtnReprocesarAsientos.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
                                BtnReprocesarAsientos.ClientVisible = false;
                            }
                        }
                    }
                    else
                        PnlGenerar.ClientVisible = true;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvBolivianos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var objDataTable = (DataTable)Session["CUADRE_CONTABLE"];
                DataView dvBolivianos = new DataView(objDataTable);
                dvBolivianos.RowFilter = "MONEDA = 'BOB'";
                GrvBolivianos.DataSource = dvBolivianos;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvDolares_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var objDataTable = (DataTable)Session["CUADRE_CONTABLE"];
                DataView dvDolares = new DataView(objDataTable);
                dvDolares.RowFilter = "MONEDA = 'USD'";
                GrvDolares.DataSource = dvDolares;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void ASPxCallback1_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            try
            {
                e.Result = e.Parameter + "|" + ((Convert.ToInt32(e.Parameter) != 34) ? (Convert.ToInt32(e.Parameter) + 1).ToString() : "0");
                _cPersonales.GetDatasetProcedimiento("pro.SPR_ASIENTOS_CONTABLES_GENERAR", new List<CParameter>() { new CParameter() { Key = "@NUMERO_PROCESO", Value = Convert.ToInt32(e.Parameter) }, new CParameter() { Key = "@ID_USUARIO", Value = _objUsuario.Matricula } });                
            }
            catch (Exception ex)
            {
                string strProceso = string.Empty;
                switch (Convert.ToInt32(e.Parameter))
                {
                    case 1: strProceso = "01A - POLIZAS NUEVAS - PRIMA NETA"; break;
                    case 2: strProceso = "01B - POLIZAS NUEVAS - PRIMA ADICIONAL"; break;
                    case 3: strProceso = "02A - POLIZAS RENOVADAS - PRIMA NETA"; break;
                    case 4: strProceso = "02B - POLIZAS RENOVADAS - PRIMA ADICIONAL"; break;
                    case 5: strProceso = "03A - CAPITAL ASEGURADO"; break;
                    case 6: strProceso = "06A - LIBERACION CAPITAL ASEGURADO"; break;
                    case 7: strProceso = "07A - PRIMAS CEDIDAS - NETA"; break;
                    case 8: strProceso = "07B - PRIMAS CEDIDAS - COMISION"; break;
                    case 9: strProceso = "08A - CAPITAL ASEGURADO CEDIDO"; break;
                    case 10: strProceso = "10A - LIBERACION CAPITAL ASEGURADO CEDIDO"; break;
                    case 11: strProceso = "11A - CONSTITUCION RESERVA DE RISGOS EN CURSO"; break;
                    case 12: strProceso = "12A - LIBERACION RESERVA DE RISGOS EN CURSO"; break;
                    case 13: strProceso = "13A - CONSTITUCION RESERVA DE SINIESTROS"; break;
                    case 14: strProceso = "14A - LIBERACION RESERVA DE SINIESTROS"; break;
                    case 15: strProceso = "15A - INDEMNIZACION DE SINIESTROS"; break;
                    case 16: strProceso = "16A - REEMBOLSOS DE SINIESTROS"; break;
                    case 17: strProceso = "16B - REEMBOLSOS DE SINIESTROS - ADICIONAL"; break;
                    case 18: strProceso = "17A - IMPUESTO IVA"; break;
                    case 19: strProceso = "17B - IMPUESTO IT"; break;
                    case 20: strProceso = "03B - ANULACIÓN CAPITAL ASEGURADO"; break;
                    case 21: strProceso = "04A - ANULACIÓN POLIZAS NUEVAS"; break;
                    case 22: strProceso = "04B - ANULACIÓN POLIZAS NUEVAS"; break;
                    case 23: strProceso = "05B - ANULACIÓN POLIZAS RENOVADAS"; break;
                    case 24: strProceso = "05A - ANULACIÓN POLIZAS RENOVADAS"; break;
                    case 25: strProceso = "19B - ANULACIÓN PRIMA CEDIDA"; break;
                    case 26: strProceso = "20A - ANULACIÓN CAPITAL CEDIDO"; break;
                    case 27: strProceso = "18A - COMISION BROKER"; break;
                    case 28: strProceso = "21A - ANULACIÓN DE COMISIÓN BROKER"; break;
                    case 29: strProceso = "23 - COBRO PRIMA POLIZAS NUEVAS"; break;
                    case 30: strProceso = "24 - COBRO PRIMA POLIZAS RENOVADAS"; break;
                    case 31: strProceso = "25 - CONSTITUCION DE PRIMAS (VGCECA, VGCECR)"; break;
                    case 32: strProceso = "26 - GASTO - COMISION DE COBRANZA (VGCECA, VGCECR)"; break;
                    case 33: strProceso = "APLICANDO AJUSTES"; break;
                    case 34: strProceso = "GENERANDO ASIENTOS PARA VALIDACIÓN"; break;
                }
                var listaErrores = (List<ListErrors>)HttpContext.Current.Session["ERROR_LIST"];
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ERROR_FINANZAS_1.html"));
                strHtml = strHtml.Replace("#SERVIDOR#", "BCRCSD00");
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#PROCESO#", strProceso);
                strHtml = strHtml.Replace("#DESCRIPCION#", listaErrores.FirstOrDefault().ErrorMessage);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("g", CultureInfo.CreateSpecificCulture("es-ES")));                
                Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = new List<string>() { "WHuanca@crediseguro.com.bo" },
                    ListaCorreoCopia = new List<string>() { _objUsuario.Correo },
                    Asunto = "CIERRE MENSUAL - ERROR EN LA GENERACIÓN DE LOS ASIENTOS CONTABLES",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
                BtnGenerar.ClientEnabled = false;
                e.Result = e.Parameter + "|-1";
            }            
        }
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Session["ASIENTOS_REINTENTAR"] = "true";
            Response.Redirect("GenerarContabilidad.aspx", false);
        }
        protected void BtnFinalizarGeneracion_Click(object sender, EventArgs e)
        {
            try
            {
                CargaInicial();
                PnlGenerar.ClientVisible = false;
                PnlCuadre.ClientVisible = true;
                LblMensajeSuccess.Text = "La generación de asientos contables ha finalizado con éxito!";
                PnlNotificacionSuccess.Visible = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDescargaAsientos_Click(object sender, EventArgs e)
        {
            try
            {
                PnlNotificacionSuccess.Visible = false;
                Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = AsientosContables(), CONTENT_TYPE = "text/plain", NOMBRE_ARCHIVO = "ASIENTO.txt" };
                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReprocesarAsientos_Click(object sender, EventArgs e)
        {
            try
            {
                PnlGenerar.ClientVisible = true;
                PnlCuadre.ClientVisible = false;
                PnlNotificacionSuccess.Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CbPassword_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            if (_objUsuario == null)
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
            string strIdUsuario = _objUsuario.Matricula;
            string strPasswordUsuario = TxtPassword.Text.Trim();
            e.Result = "false";
            if (_cCore.ValidarAutenticacion(strIdUsuario, strPasswordUsuario))
                e.Result = "true";
        }
        protected byte[] AsientosContables()
        {
            try
            {
                var strRutaReporte = _cDocumentos.GetReporteAsientosContables(_strPeriodoContable, Parametros.CParametros.RutaReportes);
                return File.ReadAllBytes(strRutaReporte);
            }
            catch
            {
                throw;
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {            
            try
            {
                string strIdGrupo = Session["ID_GRUPO"].ToString();
                string strIdNivel = Session["ID_NIVEL"].ToString();
                string strNivel = string.Empty;
                string strDescripcion = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcion = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                string strIdResponsable = string.Empty;
                for (int index = 0; index < objDataSet.Tables[2].Rows.Count; index++)
                    if (objDataSet.Tables[2].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo && objDataSet.Tables[2].Rows[index]["USUARIO"].ToString().Contains(_objUsuario.Matricula))
                        strIdResponsable = objDataSet.Tables[2].Rows[index]["ID_RESPONSABLE"].ToString();
                var objLexico2 = _cPersonales.GetListLexicoPorTabla(strIdGrupo);
                CONFORMIDAD objConformidad = new CONFORMIDAD();
                objConformidad.COPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objConformidad.COPVC_USUARIO = _objUsuario.Matricula;
                objConformidad.COPVC_NOMBRE = _objUsuario.NombreCompleto;
                objConformidad.COPVC_AREA = objLexico2.FirstOrDefault().LEPVC_VALOR;
                objConformidad.COPVC_PROCESO = strNivel + ": " + strDescripcion;
                objConformidad.COPVC_ID_RESPONSABLE = strIdResponsable;
                objConformidad.COPVC_ESTADO = "CONFORME";
                objConformidad.COPVC_OBSERVACION = TxtComentarioConformidad.Text.Trim().ToUpper();
                var objResult = _cPersonales.RegistrarConformidad(objConformidad);
                if (objResult != null)
                {                    
                    string strRutaServidor = @"F:\REPOSITORIO_ERP_CONTA\ERP\ARCHIVOS\";
                    if (File.Exists(strRutaServidor + "ASIENTO.txt"))
                        File.Move(strRutaServidor + "ASIENTO.txt", strRutaServidor + "ASIENTO_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt");
                    File.WriteAllBytes(strRutaServidor + "ASIENTO.txt", AsientosContables());
                    CorreoConformidadRegistrada(strIdGrupo);
                    PopConformidad.ShowOnPageLoad = false;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "BtnConfirmacion_Click()", "toastr.success('Se ha completado el proceso y el archivo \"ASIENTO.txt\" ya fue colocado en la ruta del sistema Smart Stream.', 'Generar Contabilidad', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);                
                }
                else
                    throw new Exception("No se pudo registrar la conformidad en la BD.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDetalleConformidades_Click(object sender, EventArgs e)
        {
            try
            {
                var objConformidades = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_CONFORMIDADES_CIERRE", new List<CParameter>() { new CParameter() { Key = "PERIODO_CONTABLE", Value = _strPeriodoContable } });
                if (objConformidades.Tables.Count >= 3)
                {
                    LblInicioProceso.Text = (!string.IsNullOrEmpty(objConformidades.Tables[1].Rows[0]["FECHA_INICIO"].ToString())) ? "El proceso de cierre ha iniciado el " + objConformidades.Tables[1].Rows[0]["FECHA_INICIO"].ToString() : string.Empty;
                    for (int index = 0; index < objConformidades.Tables[2].Rows.Count; index++)
                    {
                        var objUsuario = _cCore.DatosDirectorioActivo(objConformidades.Tables[2].Rows[index]["USUARIO"].ToString());
                        objConformidades.Tables[2].Rows[index]["USUARIO"] = objConformidades.Tables[2].Rows[index]["USUARIO"].ToString() + " - " + objUsuario.NombreCompleto;
                    }
                }
                Session["CONFORMIDADES"] = objConformidades;
                GrvConformidades.DataBind();                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CONFORMIDADES"] != null)
                {
                    var objDataSet = (DataSet)Session["CONFORMIDADES"];
                    GrvConformidades.DataSource = objDataSet.Tables[1];
                    GrvConformidades.Columns[8].Visible = false;
                    GrvConformidades.Columns[9].Visible = false;
                    if (_objUsuario == null)
                        _objUsuario = (occ_usuario)Session["SessionUsuario"];
                    for (int index = 0; index < objDataSet.Tables[0].Rows.Count; index++)
                    {
                        if (objDataSet.Tables[0].Rows[index][0].ToString() == _objUsuario.Matricula)
                        {
                            GrvConformidades.Columns[8].Visible = true;
                            GrvConformidades.Columns[9].Visible = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            var objKeyValue = (sender as BootstrapGridView).GetMasterRowKeyValue();
            var objDataSet = (DataSet)Session["CONFORMIDADES"];
            var GrvResponsables = (sender as BootstrapGridView);
            DataView dvResponsable = new DataView(objDataSet.Tables[2]);
            dvResponsable.RowFilter = "ID_GRUPO = '" + objKeyValue.ToString() + "'";
            GrvResponsables.DataSource = dvResponsable;
        }
        protected void BtnResponsable_Init(object sender, EventArgs e)
        {
            BootstrapButton btn = sender as BootstrapButton;
            GridViewDataItemTemplateContainer container = btn.NamingContainer as GridViewDataItemTemplateContainer;
            string value = DataBinder.Eval(container.DataItem, "ESTADO").ToString();
            if (value == "NO INICIADO" || value == "CONFORME")
            {
                btn.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
                btn.ClientVisible = false;
            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = ((BootstrapButton)sender).CommandArgument;
                string strIdNivel = ((BootstrapButton)sender).CommandName;
                string strIdControl = ((BootstrapButton)sender).ID;
                PopDetalleConformidades.ShowOnPageLoad = false;
                PopConformidad.ShowOnPageLoad = false;
                PopObservacion.ShowOnPageLoad = false;
                switch (strIdControl)
                {
                    case "BtnObservacion":
                        TxtObservacion.Text = null;
                        PopObservacion.ShowOnPageLoad = true;
                        break;
                    case "BtnConformidad":
                        TxtPassword.Text = null;
                        PopConformidad.ShowOnPageLoad = true;
                        break;
                }
                Session["ID_GRUPO"] = strIdGrupo;
                Session["ID_NIVEL"] = strIdNivel;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnObservar_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = Session["ID_GRUPO"].ToString();
                string strDescripcionNivel = string.Empty,
                    strDescripcionConformidad = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                //registrar el estado
                string strIdResponsable = string.Empty;
                for (int index = 0; index < objDataSet.Tables[2].Rows.Count; index++)
                    if (objDataSet.Tables[2].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo && objDataSet.Tables[2].Rows[index]["USUARIO"].ToString().Contains(_objUsuario.Matricula))
                        strIdResponsable = objDataSet.Tables[2].Rows[index]["ID_RESPONSABLE"].ToString();
                var objLexico2 = _cPersonales.GetListLexicoPorTabla(strIdGrupo);
                CONFORMIDAD objConformidad = new CONFORMIDAD();
                objConformidad.COPCH_PERIODO_CONTABLE = _strPeriodoContable;
                objConformidad.COPVC_USUARIO = _objUsuario.Matricula;
                objConformidad.COPVC_NOMBRE = _objUsuario.NombreCompleto;
                objConformidad.COPVC_AREA = objLexico2.FirstOrDefault().LEPVC_VALOR;
                objConformidad.COPVC_PROCESO = strDescripcionNivel + ": " + strDescripcionConformidad;
                objConformidad.COPVC_ID_RESPONSABLE = strIdResponsable;
                objConformidad.COPVC_ESTADO = "OBSERVADO";
                objConformidad.COPVC_OBSERVACION = TxtObservacion.Text.Trim().ToUpper();
                var objResult = _cPersonales.RegistrarConformidad(objConformidad);
                CorreoObservacionRegistrada(strIdGrupo);
                PopObservacion.ShowOnPageLoad = false;
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "toastr.warning", "toastr.warning('Se ha registrado la observación y se ha notificado al área de sistemas para su revisión..', 'CIERRE MENSUAL (" + _strPeriodoContable + ")', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoConformidadRegistrada(string strIdGrupo)
        {
            try
            {
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strMesProduccion = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString(),
                    strIdNivel = string.Empty,
                    strDescripcionNivel = string.Empty,
                    strDescripcionConformidad = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strIdNivel = objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString();
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                List<string> listaMailTO = new List<string>();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                List<string> listaMailCC = new List<string>();
                var listaLexicoMail = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-INF-CC");
                if (listaLexicoMail.Count > 0)
                    listaMailCC = listaLexicoMail.First().LEPVC_VALOR.Split(';').ToList();
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_PROCESO.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", strMesProduccion);
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#COMENTARIO#", TxtComentarioConformidad.Text.Trim().ToUpper());
                var objResponse = Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL DE " + strMesProduccion + " | CONFORMIDAD: " + strDescripcionNivel + " (" + strDescripcionConformidad + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoObservacionRegistrada(string strIdGrupo)
        {
            try
            {
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strMesProduccion = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString(),
                    strIdNivel = string.Empty,
                    strDescripcionNivel = string.Empty,
                    strDescripcionConformidad = string.Empty;
                var objDataSet = (DataSet)Session["CONFORMIDADES"];
                for (int index = 0; index < objDataSet.Tables[1].Rows.Count; index++)
                {
                    if (objDataSet.Tables[1].Rows[index]["ID_GRUPO"].ToString() == strIdGrupo)
                    {
                        strIdNivel = objDataSet.Tables[1].Rows[index]["ID_NIVEL"].ToString();
                        strDescripcionNivel = objDataSet.Tables[1].Rows[index]["DESCRIPCION_NIVEL"].ToString();
                        strDescripcionConformidad = objDataSet.Tables[1].Rows[index]["DESCRIPCION_CONFORMIDAD"].ToString();
                        break;
                    }
                }
                List<string> listaMailTO = new List<string>();
                var listaLexicoMailTO = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-OBS-TO");
                if (listaLexicoMailTO.Count > 0)
                    listaMailTO = listaLexicoMailTO.First().LEPVC_VALOR.Split(';').ToList();
                List<string> listaMailCC = new List<string>();
                var listaLexicoMailCC = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "MAIL-OBS-CC");
                if (listaLexicoMailCC.Count > 0)
                    foreach (string strCorreo in listaLexicoMailCC.First().LEPVC_VALOR.Split(';').ToList())
                        listaMailCC.Add(strCorreo);
                var listaResponsables = _cPersonales.GetListLexicoPorTablaYTema(strIdNivel, "RESPONSABLE");
                var listaUsuarios = _cPersonales.ObtenerListaUsuariosActivos();
                foreach (var objResponsable in listaResponsables)
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objResponsable.LEPVC_DESC_CORTA);
                    if (objUsuario != null)
                        listaMailCC.Add(objUsuario.USPVC_CORREO);
                }
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_CONFORMIDAD_OBSERVACION.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", strMesProduccion);
                strHtml = strHtml.Replace("#PERIODO#", _strPeriodoContable);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#OBSERVACION#", TxtObservacion.Text.Trim());
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                Correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CIERRE MENSUAL DE " + strMesProduccion + " | OBSERVACIÓN: " + strDescripcionNivel + " (" + strDescripcionConformidad + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvValidacionRRC_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["GenerarContabilidad__ValidacionRRC"] != null)
                {
                    var objDataTable = (DataTable)Session["GenerarContabilidad__ValidacionRRC"];
                    objDataTable.DefaultView.Sort = "NUMERO ASC";
                    GrvValidacionRRC.DataSource = objDataTable;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}