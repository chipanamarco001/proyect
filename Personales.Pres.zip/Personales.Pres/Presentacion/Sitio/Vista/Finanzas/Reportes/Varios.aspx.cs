﻿using Agente.ServicioPersonales;
using DevExpress.Compression;
using DevExpress.Spreadsheet;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Finanzas.Reportes
{
    public partial class Varios : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnAnexoK_Click(object sender, EventArgs e)
        {            
            try
            {
                var objOCArchivo = new OC_ARCHIVO();
                var objZipArchive = new ZipArchive();
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_ANEXO_K", new List<CParameter>() { new CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });                
                if (DsetDatos.Tables[0].Rows[0]["MENSAJE"].ToString() == string.Empty)
                {
                    //formato txt
                    using (var ms = new MemoryStream())
                    {
                        TextWriter tw = new StreamWriter(ms);
                        foreach (DataRow objDataRow in DsetDatos.Tables[0].Rows)
                        {
                            if (objDataRow[0].ToString().Trim() != string.Empty)
                            {
                                tw.Write(objDataRow[0].ToString().Trim());
                                tw.Write(Environment.NewLine);
                            }
                        }
                        tw.Flush();
                        ms.Position = 0;                        
                        objZipArchive.AddByteArray("T04SK" + dtPeriodoProceso.AddMonths(1).ToString("yyyyMM") + ".209", ms.ToArray());
                    }
                    //formato excel
                    string strRutaPlantilla = Server.MapPath("~/UI/templates/ANEXO_K.xlsx");
                    Workbook DEWorkbook = new Workbook();
                    DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                    {
                        if (DEWorksheet.Name == "Reporte")
                        {
                            DataTable DtblDatos = DsetDatos.Tables[1];
                            DtblDatos.DefaultView.Sort = "ORDEN ASC";
                            DEWorksheet.Import(DtblDatos, false, 15, 0);
                            DEWorksheet.Range["A16:Q" + (DsetDatos.Tables[1].Rows.Count + 15)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                            DEWorksheet.Range["B16:Q" + (DsetDatos.Tables[1].Rows.Count + 15)].NumberFormat = "#,##0.00"; //formato numerico
                            DEWorksheet.Range["A" + (DsetDatos.Tables[1].Rows.Count + 15) + ":Q" + (DsetDatos.Tables[1].Rows.Count + 15)].Font.Bold = true;
                            DEWorksheet.Cells["A10"].Value = DsetDatos.Tables[2].Rows[0]["FECHA1"].ToString();
                            DEWorksheet.Cells["B13"].Value = DsetDatos.Tables[2].Rows[0]["FECHA2"].ToString();
                            DEWorksheet.Cells["J13"].Value = DsetDatos.Tables[2].Rows[0]["FECHA3"].ToString();
                            DEWorksheet.Cells["B14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA4"].ToString();
                            DEWorksheet.Cells["D14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA5"].ToString();
                            DEWorksheet.Cells["F14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA6"].ToString();
                            DEWorksheet.Cells["J14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA4"].ToString();
                            DEWorksheet.Cells["L14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA5"].ToString();
                            DEWorksheet.Cells["N14"].Value = DsetDatos.Tables[2].Rows[0]["FECHA6"].ToString();
                            DEWorksheet.Columns.Remove(17);
                        }
                    }
                    byte[] bReporteExcel = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    objZipArchive.AddByteArray("AnexoK_" + dtPeriodoProceso.AddMonths(1).ToString("yyyyMM") + ".xlsx", bReporteExcel);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        objZipArchive.Save(stream);
                        objOCArchivo = new OC_ARCHIVO() { BYTE_ARRAY = stream.ToArray(), CONTENT_TYPE = "application/zip", NOMBRE_ARCHIVO = "AnexoK_" + dtPeriodoProceso.AddMonths(1).ToString("yyyyMM") + ".zip" };
                        stream.Close();
                    }             
                    Session["DOWNLOAD"] = objOCArchivo;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Alerta", "toastr.error('" + DsetDatos.Tables[0].Rows[0]["MENSAJE"].ToString() + "', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}