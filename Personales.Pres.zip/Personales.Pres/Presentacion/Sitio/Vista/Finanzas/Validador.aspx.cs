﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DocumentFormat.OpenXml.Packaging;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;

namespace Presentacion.Sitio.Vista.Finanzas
{
    public partial class Validador : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("VALIDADOR_ARCHIVOS");
                Session.Remove("VALIDADOR_MES");
                Session.Remove("VALIDADOR_TIPO");
                PnlNotificacion.Visible = false;
                PopInformacion.ShowOnPageLoad = false;
                PopConfirmacion.ShowOnPageLoad = false;
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                DateTime dtPeriodoProceso = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                Session["PERIODO_CONTABLE"] = dtPeriodoProceso.ToString("yyyyMM");
                TxtMesProduccion.Text = dtPeriodoProceso.ToString("yyyyMM");
            }
            if (Session["VALIDADOR_DESCARGA"] != null)
            {
                if (_objUsuario == null)
                    _objUsuario = (occ_usuario)Session["SessionUsuario"];
                string strIdUsuarrio = _objUsuario.Matricula;
                string strRutaTemporal = Server.MapPath("~/UI/tmp/");
                Session.Remove("VALIDADOR_DESCARGA");
                if (File.Exists(strRutaTemporal + strIdUsuarrio + ".xlsx"))
                {
                    byte[] bReporte = File.ReadAllBytes(strRutaTemporal + strIdUsuarrio + ".xlsx");
                    File.Delete(strRutaTemporal + strIdUsuarrio + ".xlsx");
                    Response.Buffer = true;
                    Response.Clear();
                    Response.ContentType = "application/xls";
                    Response.AddHeader("content-disposition", "attachment;filename=ValidadorContable_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx");
                    Response.BinaryWrite(bReporte);
                    Response.Flush();
                    Response.End();
                }
            }
        }
        protected void UpcArchivos_FilesUploadComplete(object sender, DevExpress.Web.FilesUploadCompleteEventArgs e)
        {
            try
            {                
                List<OC_ARCHIVO> listaAdjuntos = new List<OC_ARCHIVO>();
                if (Session["VALIDADOR_ARCHIVOS"] != null)
                    listaAdjuntos = (List<OC_ARCHIVO>)Session["VALIDADOR_ARCHIVOS"];
                for (int index = 0; index < UpcArchivos.UploadedFiles.Length; index++)
                {
                    UploadedFile uploadedFile = UpcArchivos.UploadedFiles[index];
                    FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                    if (!listaAdjuntos.Exists(w => w.NOMBRE_ARCHIVO == uploadedFile.FileName))
                    {
                        listaAdjuntos.Add(new OC_ARCHIVO()
                        {
                            CONTENT_TYPE = uploadedFile.ContentType,
                            EXTENSION = fileInfo.Extension,
                            NOMBRE_ARCHIVO = uploadedFile.FileName,
                            FILE_STREAM = uploadedFile.FileContent,
                            BYTE_ARRAY = uploadedFile.FileBytes
                        });
                    }
                }
                Session["VALIDADOR_ARCHIVOS"] = listaAdjuntos;
                GrvArchivos.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                PnlNotificacion.Visible = false;
                string strMesProducccion = TxtMesProduccion.Text.Trim().ToUpper();
                string strTipoValidacion = CmbTipoValidacion.SelectedItem.Value.ToString();
                List<string[]> listaArchivos = new List<string[]>();
                listaArchivos.Add(new string[] { "SA" + strMesProducccion + ".209", "false" });
                listaArchivos.Add(new string[] { "SB" + strMesProducccion + ".209", "false" });
                listaArchivos.Add(new string[] { "SC" + strMesProducccion + ".209", "false" });
                listaArchivos.Add(new string[] { "SD" + strMesProducccion + ".209", "false" });
                listaArchivos.Add(new string[] { "SE" + strMesProducccion + ".209", "false" });
                if (strTipoValidacion == "T")
                {
                    listaArchivos.Add(new string[] { "SF" + strMesProducccion + ".209", "false" });
                    listaArchivos.Add(new string[] { "SG" + strMesProducccion + ".209", "false" });
                    listaArchivos.Add(new string[] { "SH" + strMesProducccion + ".209", "false" });
                }
                List<OC_ARCHIVO> listaAdjuntos = new List<OC_ARCHIVO>();
                if (Session["VALIDADOR_ARCHIVOS"] != null)
                    listaAdjuntos = (List<OC_ARCHIVO>)Session["VALIDADOR_ARCHIVOS"];
                foreach (string[] objArchivo in listaArchivos)
                {
                    if (listaAdjuntos.Exists(w => w.NOMBRE_ARCHIVO == objArchivo[0]))
                    {
                        objArchivo[1] = "true";
                    }
                }
                bool boolCargar = true;
                foreach (string[] objArchivo in listaArchivos)
                {
                    if (objArchivo[1] != "true")
                    {
                        boolCargar = false;
                        break;
                    }
                }
                if (boolCargar)
                {
                    Session["VALIDADOR_MES"] = strMesProducccion;
                    Session["VALIDADOR_TIPO"] = strTipoValidacion;
                    PopInformacion.ShowOnPageLoad = false;
                    PopConfirmacion.ShowOnPageLoad = true;
                }
                else
                {
                    Session.Remove("VALIDADOR_ARCHIVOS");
                    GrvArchivos.DataBind();
                    LblMensaje.Text = "Los archivos seleccionados no corresponden al mes de validación, por favor revise y vuelva a intentarlo.";
                    PopConfirmacion.ShowOnPageLoad = false;
                    PopInformacion.ShowOnPageLoad = true;
                }
                if (ChkMesProduccion.Checked)
                    TxtMesProduccion.ClientEnabled = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Session.Remove("VALIDADOR_ARCHIVOS");
            Response.Redirect("Validador.aspx", false);
        }
        protected void GrvArchivos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                List<OC_ARCHIVO> listaArchivos = new List<OC_ARCHIVO>();
                if (Session["VALIDADOR_ARCHIVOS"] != null)
                {
                    listaArchivos = (List<OC_ARCHIVO>)Session["VALIDADOR_ARCHIVOS"];
                    GrvArchivos.DataSource = listaArchivos;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnValidar_Click(object sender, EventArgs e)
        {
            if (_objUsuario == null)
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
            string strIdUsuarrio = _objUsuario.Matricula;
            string strRutaTemporal = Server.MapPath("~/UI/tmp/");
            string strRutaPlantilla = Server.MapPath("~/UI/templates/FIN_VALIDADOR.xlsx");
            var objFileInfo = new FileInfo(strRutaPlantilla);
            string strMesProduccion = (string)Session["VALIDADOR_MES"];
            try
            {                
                string strTipoValidacion = (string)Session["VALIDADOR_TIPO"];
                List<OC_ARCHIVO> listaAdjuntos = new List<OC_ARCHIVO>();
                if (Session["VALIDADOR_ARCHIVOS"] != null)
                    listaAdjuntos = (List<OC_ARCHIVO>)Session["VALIDADOR_ARCHIVOS"];
                foreach (OC_ARCHIVO objAdjunto in listaAdjuntos)
                {
                    if (objAdjunto.NOMBRE_ARCHIVO == "SA" + strMesProduccion + ".209")
                        DatosArchivoA(objAdjunto, strMesProduccion);
                    if (objAdjunto.NOMBRE_ARCHIVO == "SB" + strMesProduccion + ".209")
                        DatosArchivoB(objAdjunto, strMesProduccion);
                    if (objAdjunto.NOMBRE_ARCHIVO == "SC" + strMesProduccion + ".209")
                        DatosArchivoC(objAdjunto, strMesProduccion);
                    if (objAdjunto.NOMBRE_ARCHIVO == "SD" + strMesProduccion + ".209")
                        DatosArchivoD(objAdjunto, strMesProduccion);
                    if (objAdjunto.NOMBRE_ARCHIVO == "SE" + strMesProduccion + ".209")
                        DatosArchivoE(objAdjunto, strMesProduccion);
                    if (strTipoValidacion == "T")
                    {
                        if (objAdjunto.NOMBRE_ARCHIVO == "SF" + strMesProduccion + ".209")
                            DatosArchivoF(objAdjunto, strMesProduccion);
                        if (objAdjunto.NOMBRE_ARCHIVO == "SG" + strMesProduccion + ".209")
                            DatosArchivoG(objAdjunto, strMesProduccion);
                        if (objAdjunto.NOMBRE_ARCHIVO == "SH" + strMesProduccion + ".209")
                            DatosArchivoH(objAdjunto, strMesProduccion);
                    }
                }
                var response = _cPersonales.GetListArchivoValidacion(strMesProduccion, (strTipoValidacion == "T") ? true : false);
                if (response != null)
                {
                    if (File.Exists(strRutaTemporal + strIdUsuarrio + objFileInfo.Extension))
                        File.Delete(strRutaTemporal + strIdUsuarrio + objFileInfo.Extension);
                    File.Copy(strRutaPlantilla, strRutaTemporal + strIdUsuarrio + objFileInfo.Extension);
                    using (var workbook = SpreadsheetDocument.Open(strRutaTemporal + strIdUsuarrio + objFileInfo.Extension, true))
                    {
                        WorksheetPart worksheetPart1 = GetWorksheetPartByName(workbook, "Validador");
                        DocumentFormat.OpenXml.Spreadsheet.Worksheet worksheet1 = worksheetPart1.Worksheet;
                        DocumentFormat.OpenXml.Spreadsheet.SheetData sheetData1 = worksheet1.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.SheetData>();
                        uint rowIndex = 5;
                        foreach (SPR_GETLIST_ARCHIVO_VALIDACION_Result objArchivoValidacion in response)
                        {
                            DocumentFormat.OpenXml.Spreadsheet.Row newRow = new DocumentFormat.OpenXml.Spreadsheet.Row() { RowIndex = rowIndex };
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.FECHA), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.MES_PRODUCCION), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.TIPO_COMPARACION), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.ARCHIVO), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.CAMPO_EVALUADO), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.RAMO_EVALUADO), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.CAMPO_CONTABILIDAD), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.MONTO_EVALUADO.ToString()), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.Number });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.MONTO_CONTABILIDAD.ToString()), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.Number });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.DIFERENCIA.ToString()), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.Number });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.OBSERVACION), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.CONDICION), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });
                            newRow.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.Cell() { CellValue = new DocumentFormat.OpenXml.Spreadsheet.CellValue(objArchivoValidacion.CUENTAS_EVALUADAS), DataType = DocumentFormat.OpenXml.Spreadsheet.CellValues.String });                            
                            sheetData1.AppendChild(newRow);
                            rowIndex++;
                        }
                        worksheetPart1.Worksheet.Save();
                        workbook.WorkbookPart.Workbook.Save();
                    }
                    PopConfirmacion.ShowOnPageLoad = false;
                    PopInformacion.ShowOnPageLoad = false;
                    PnlNotificacion.Visible = true;
                    Session.Remove("VALIDADOR_ARCHIVOS");                    
                    Session.Remove("VALIDADOR_TIPO");
                    Session.Remove("VALIDADOR_MES");
                    Session["VALIDADOR_DESCARGA"] = "TRUE";
                    CmbTipoValidacion.Value = null;
                    ChkMesProduccion.Checked = false;
                    GrvArchivos.DataBind();
                    TxtMesProduccion.Text = ConfigurationManager.AppSettings["MesProduccion"];
                    TxtMesProduccion.ClientEnabled = false;
                }
                else
                {
                    throw new Exception("Error en el proceso de validación.");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        private static WorksheetPart GetWorksheetPartByName(SpreadsheetDocument document, string sheetName)
        {
            IEnumerable<DocumentFormat.OpenXml.Spreadsheet.Sheet> sheets = document.WorkbookPart.Workbook.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.Sheets>().Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == sheetName);
            if (sheets.Count() == 0)
            {
                return null;
            }
            string relationshipId = sheets.First().Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(relationshipId);
            return worksheetPart;
        }
        protected void DatosArchivoA(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_A> listaDatosArchivoA = new List<ARCHIVO_A>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoA.Add(new ARCHIVO_A()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPCH_CPARTE = datos[1],
                            ARPCH_COFICINA = datos[2],
                            ARPCH_CSECTOR = datos[3],
                            ARPCH_CMONEDA = datos[4],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[5], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[6],
                            ARPCH_CRAMO = datos[7],
                            ARPCH_CPOLIZA = datos[8],
                            ARPDC_MCAPITALASEGURADO = Convert.ToDecimal(datos[9]),
                            ARPIN_QPOLIZANEWEMITIDA = Convert.ToInt32(datos[10]),
                            ARPIN_QPOLIZARENOVADA = Convert.ToInt32(datos[11]),
                            ARPDC_MPRIMADIRECTA = Convert.ToDecimal(datos[12]),
                            ARPDC_MPRIMADIRECTABS = Convert.ToDecimal(datos[13]),
                            ARPDC_MCAPITALANULADO = Convert.ToDecimal(datos[14]),
                            ARPIN_QPOLIZAANULADA = Convert.ToInt32(datos[15]),
                            ARPDC_MPRIMAANULADA = Convert.ToDecimal(datos[16]),
                            ARPDC_MPRIMAANULADABS = Convert.ToDecimal(datos[17]),
                            ARPDC_MCAPASEGURADONETO = Convert.ToDecimal(datos[18]),
                            ARPIN_QPOLIZASNETAS = Convert.ToInt32(datos[19]),
                            ARPDC_MPRIMANETA = Convert.ToDecimal(datos[20]),
                            ARPDC_MPRIMANETABS = Convert.ToDecimal(datos[21]),
                            ARPDC_MPRIMAACEPREASEG = Convert.ToDecimal(datos[22]),
                            ARPDC_MPRIMAACEPREASEGBS = Convert.ToDecimal(datos[23]),
                            ARPDC_MPRIMACEDIDAREASEG = Convert.ToDecimal(datos[24]),
                            ARPDC_MPRIMACEDIDAREASEGBS = Convert.ToDecimal(datos[25]),
                            ARPDC_MANULPRIMASCEDRE = Convert.ToDecimal(datos[26]),
                            ARPDC_MANULPRIMASCEDREBS = Convert.ToDecimal(datos[27])
                        });
                    }
                    var response = _cPersonales.RegistrarListaArchivoA(listaDatosArchivoA, strMesProduccion);
                    if (response)
                        CrearArchivo(objAdjunto, strMesProduccion);
                    else
                        throw new Exception("Se ha producido un error al registrar los datos del archivo.");
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoB(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_B> listaDatosArchivoB = new List<ARCHIVO_B>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoB.Add(new ARCHIVO_B()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPCH_CPARTE = datos[1],
                            ARPCH_COFICINA = datos[2],
                            ARPCH_CSECTOR = datos[3],
                            ARPCH_CMONEDA = datos[4],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[5], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[6],
                            ARPCH_CRAMO = datos[7],
                            ARPCH_CPOLIZA = datos[8],
                            ARPIN_NSINIESDENUNCIADOS = Convert.ToInt32(datos[9]),
                            ARPDC_MSINIESDENUNCIADOS = Convert.ToDecimal(datos[10]),
                            ARPIN_NSINIESLIQUIDADOS = Convert.ToInt32(datos[11]),
                            ARPDC_MSINIESLIQUIDADOS = Convert.ToDecimal(datos[12]),
                            ARPDC_MSINIESLIQUIDADOSBS = Convert.ToDecimal(datos[13]),
                            ARPDC_MSINPAGREASEGACEP = Convert.ToDecimal(datos[14]),
                            ARPDC_MSINPAGREASEGACEPBS = Convert.ToDecimal(datos[15]),
                            ARPDC_MSINREEMREASEGCED = Convert.ToDecimal(datos[16]),
                            ARPDC_MSINREEMREASEGCEDBS = Convert.ToDecimal(datos[17])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoB(listaDatosArchivoB, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoC(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_C> listaDatosArchivoC = new List<ARCHIVO_C>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoC.Add(new ARCHIVO_C()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[1], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPVC_CCUENTA = datos[2],
                            ARPCH_CMONEDA = datos[3],
                            ARPVC_CANALITICA = datos[4],
                            ARPDC_MSALDODEBEANTERIOR = Convert.ToDecimal(datos[5]),
                            ARPDC_MSALDOHABERANTERIO = Convert.ToDecimal(datos[6]),
                            ARPDC_MMOVIMIENTODEBE = Convert.ToDecimal(datos[7]),
                            ARPDC_MMOVIMIENTOHABER = Convert.ToDecimal(datos[8]),
                            ARPDC_MSALDODEBEACTUAL = Convert.ToDecimal(datos[9]),
                            ARPDC_MSALDOHABERACTUAL = Convert.ToDecimal(datos[10])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoC(listaDatosArchivoC, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoD(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_D> listaDatosArchivoD = new List<ARCHIVO_D>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoD.Add(new ARCHIVO_D()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[1], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPVC_CCUENTA = datos[2],
                            ARPCH_CMONEDA = datos[3],
                            ARPVC_CANALITICA = datos[4],
                            ARPDC_MSALDODEBEANTERIOR = Convert.ToDecimal(datos[5]),
                            ARPDC_MSALDOHABERANTERIO = Convert.ToDecimal(datos[6]),
                            ARPDC_MMOVIMIENTODEBE = Convert.ToDecimal(datos[7]),
                            ARPDC_MMOVIMIENTOHABER = Convert.ToDecimal(datos[8]),
                            ARPDC_MSALDODEBEACTUAL = Convert.ToDecimal(datos[9]),
                            ARPDC_MSALDOHABERACTUAL = Convert.ToDecimal(datos[10])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoD(listaDatosArchivoD, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoE(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_E> listaDatosArchivoE = new List<ARCHIVO_E>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoE.Add(new ARCHIVO_E()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPCH_CCORREDORA = datos[1],
                            ARPCH_CMONEDA = datos[2],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[3], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[4],
                            ARPCH_CRAMO = datos[5],
                            ARPCH_CPOLIZA = datos[6],
                            ARPDC_MPRODUCCION = Convert.ToDecimal(datos[7])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoE(listaDatosArchivoE, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoF(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_F> listaDatosArchivoF = new List<ARCHIVO_F>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoF.Add(new ARCHIVO_F()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[1], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[2],
                            ARPCH_CRAMO = datos[3],
                            ARPDC_MPRIMASDIRECTAS = Convert.ToDecimal(datos[4]),
                            ARPDC_MANULPRIMASDIRECTAS = Convert.ToDecimal(datos[5]),
                            ARPDC_MPRIMASNETASANUL = Convert.ToDecimal(datos[6]),
                            ARPDC_MPRIMASACEPREASNAL = Convert.ToDecimal(datos[7]),
                            ARPDC_MPRIMASACEPREASEXT = Convert.ToDecimal(datos[8]),
                            ARPDC_MTOTPRIMASACEPREAS = Convert.ToDecimal(datos[9]),
                            ARPDC_MPRIMASTOTNETAS = Convert.ToDecimal(datos[10]),
                            ARPDC_MPRIMASCEDREASNAL = Convert.ToDecimal(datos[11]),
                            ARPDC_MPRIMASCEDREASEXT = Convert.ToDecimal(datos[12]),
                            ARPDC_MTOTPRIMASCEDIDAS = Convert.ToDecimal(datos[13]),
                            ARPDC_MPRIMASNETASRET = Convert.ToDecimal(datos[14])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoF(listaDatosArchivoF, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoG(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_G> listaDatosArchivoG = new List<ARCHIVO_G>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoG.Add(new ARCHIVO_G()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[1], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[2],
                            ARPCH_CRAMO = datos[3],
                            ARPDC_MSINIESDIRECTOS = Convert.ToDecimal(datos[4]),
                            ARPDC_MSINIESREASACEPNAL = Convert.ToDecimal(datos[5]),
                            ARPDC_MSINREASACEPEXT = Convert.ToDecimal(datos[6]),
                            ARPDC_MTOTSINREASACEP = Convert.ToDecimal(datos[7]),
                            ARPDC_MSINIESTROSTOTALES = Convert.ToDecimal(datos[8]),
                            ARPDC_MSINREEMREASNAL = Convert.ToDecimal(datos[9]),
                            ARPDC_MSINREEMREASEXT = Convert.ToDecimal(datos[10]),
                            ARPDC_MTOTSINIESREEMB = Convert.ToDecimal(datos[11]),
                            ARPDC_MSINIESTROSRET = Convert.ToDecimal(datos[12])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoG(listaDatosArchivoG, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosArchivoH(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                List<ARCHIVO_H> listaDatosArchivoH = new List<ARCHIVO_H>();
                using (StreamReader objStreamReader = new StreamReader(objAdjunto.FILE_STREAM))
                {
                    string strFila;
                    while ((strFila = objStreamReader.ReadLine()) != null)
                    {
                        string[] datos = (strFila.Replace("\"", string.Empty)).Split(',');
                        listaDatosArchivoH.Add(new ARCHIVO_H()
                        {
                            ARPCH_MES_PRODUCCION = strMesProduccion,
                            ARPCH_CCOMPANIA = datos[0],
                            ARPDT_FINFORMACION = DateTime.ParseExact(datos[1], "yyyy-MM-dd", CultureInfo.InvariantCulture),
                            ARPCH_CMODALIDAD = datos[2],
                            ARPCH_CRAMO = datos[3],
                            ARPDC_MTOTCAPASEGURADO = Convert.ToDecimal(datos[4]),
                            ARPDC_MCAPASEGCEDIDO = Convert.ToDecimal(datos[5]),
                            ARPDC_MCAPASEGRETENIDO = Convert.ToDecimal(datos[6]),
                            ARPDC_MTOTRESERVMATE = Convert.ToDecimal(datos[7]),
                            ARPDC_MRESMATCTAREASEG = Convert.ToDecimal(datos[8]),
                            ARPDC_MRESERVMATRETENIDA = Convert.ToDecimal(datos[9])
                        });
                    }
                }
                var response = _cPersonales.RegistrarListaArchivoH(listaDatosArchivoH, strMesProduccion);
                if (response)
                    CrearArchivo(objAdjunto, strMesProduccion);
                else
                    throw new Exception("Se ha producido un error al registrar los datos del archivo.");
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CrearArchivo(OC_ARCHIVO objAdjunto, string strMesProduccion)
        {
            try
            {
                string strRutaArchivo = @"\\bcrcsw00\ProduccionPersonales\Conversor\ValidadorContable\Archivos\";
                if (!Directory.Exists(strRutaArchivo + strMesProduccion))
                    Directory.CreateDirectory(strRutaArchivo + strMesProduccion);
                if (File.Exists(strRutaArchivo + strMesProduccion + @"\" + objAdjunto.NOMBRE_ARCHIVO))
                    File.Delete(strRutaArchivo + strMesProduccion + @"\" + objAdjunto.NOMBRE_ARCHIVO);
                File.WriteAllBytes(strRutaArchivo + strMesProduccion + @"\" + objAdjunto.NOMBRE_ARCHIVO, objAdjunto.BYTE_ARRAY);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}