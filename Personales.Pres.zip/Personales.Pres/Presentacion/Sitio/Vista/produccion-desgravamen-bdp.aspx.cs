﻿using Agente.ServicioDocumentos;
using Agente.ServicioProduccion;
using DevExpress.Compression;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.Lib;
using Presentacion.Parametros;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class produccion_desgravamen_bdp : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        private readonly CProduccion _cProduccion = new CProduccion();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodo;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
                Session.Remove("ARCHIVOS_BDP");
            }
            _strPeriodo = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                GrvSeguimiento.DataBind();
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProcesoActual = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                _strPeriodo = (string)Session["PERIODO_CONTABLE"];
                BtnCargarArchivo.ClientVisible = false;
                if (strPeriodoProcesoActual == _strPeriodo)
                {
                    BtnCargarArchivo.ClientVisible = true;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvSeguimiento_DataBinding(object sender, EventArgs e)
        {
            try
            {
                _strPeriodo = (string)Session["PERIODO_CONTABLE"];
                var dSetSeguimiento = _cCrediseguro.DESBDP_BaseSeguimiento(_strPeriodo);
                var objControlBDP = new ocp_control_bdp().CargarListas(dSetSeguimiento);
                Session["produccion_desgravamen_bdp__control"] = objControlBDP;
                GrvSeguimiento.DataSource = objControlBDP.ListaProduccion;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvSeguimiento_CustomButtonInitialize(object sender, BootstrapGridViewCustomButtonEventArgs e)
        {
            try
            {
                BootstrapGridView iGrvBandeja = (BootstrapGridView)sender;
                var objBandejaProduccion = (ocp_control_bdp__bandeja)iGrvBandeja.GetRow(e.VisibleIndex);
                var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
                string strPeriodoProcesoActual = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                switch (e.ButtonID)
                {
                    case "Documentos":
                        e.Visible = (objBandejaProduccion.PRIMA_PRODUCIDA > 0) ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "Produccion":
                        e.Visible = (strPeriodoProcesoActual == objBandejaProduccion.PERIODO) ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccionBandeja_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccionBandeja.Contains("Periodo") && HidAccionBandeja.Contains("Accion"))
                {
                    string strPeriodoSeleccionado = HidAccionBandeja.Get("Periodo").ToString();
                    var objControlBDP = (ocp_control_bdp)Session["produccion_desgravamen_bdp__control"];
                    var listaBandeja = objControlBDP.ListaProduccion;
                    var objBandeja = listaBandeja.Where(w => w.PERIODO == strPeriodoSeleccionado).First();
                    switch (HidAccionBandeja.Get("Accion"))
                    {
                        case "Documentos":
                            GrvDocumentos.DataBind();
                            PopDocumentos.ShowOnPageLoad = true;
                            Session["produccion_desgravamen_bdp__periodo"] = strPeriodoSeleccionado;
                            break;
                        case "Produccion":
                            PopProduccion.ShowOnPageLoad = true;
                            break;

                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvDocumentos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var objControlBDP = (ocp_control_bdp)Session["produccion_desgravamen_bdp__control"];
                GrvDocumentos.DataSource = objControlBDP.ListaDocumentos;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCargarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                string strNombreProducto = "9349 - DESGRAVAMEN BDP";
                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt" };
                PopCargarArchivo.HeaderText = strNombreProducto;
                PopCargarArchivo.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                DataTable DtblDatos = new DataTable();
                DtblDatos.Columns.Add(new DataColumn("Column1"));
                using (StreamReader reader = new StreamReader(uploadedFile.FileContent))
                {
                    do
                    {
                        string strTextLine = reader.ReadLine();
                        DataRow dr = DtblDatos.NewRow();
                        dr[0] = strTextLine;
                        DtblDatos.Rows.Add(dr);
                    } while (reader.Peek() != -1);
                }
                Session["DATOS_ARCHIVO_CARGADO"] = DtblDatos;
                Session["ARCHIVO_CARGADO"] = new OC_ARCHIVO()
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                if (Session["DATOS_ARCHIVO_CARGADO"] == null || Session["ARCHIVO_CARGADO"] == null)
                {
                    throw new Exception("Se ha encontrado un problema con el archivo seleccionado ('BtnProcesarArchivo_Click').");
                }
                DataTable DtblDatos = (DataTable)Session["DATOS_ARCHIVO_CARGADO"];
                var registros = new Dictionary<string, (string CarnetAsegurado, string CarnetCoAsegurado, int Indice)>();
                var listaErrores = new List<string>();
                var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
                int intNumeroColumnas = 60;
                DataTable DtblDatosAuxiliar = new DataTable();
                for (int index = 0; index < intNumeroColumnas; index++)
                {
                    DtblDatosAuxiliar.Columns.Add(new DataColumn("Column" + (index + 1)));
                }
                for (int index = 0; index < DtblDatos.Rows.Count; index++)
                {
                    string strTextLine = DtblDatos.Rows[index][0].ToString();
                    string[] datos = strTextLine.Split('|');
                    if (datos.Length != intNumeroColumnas)
                        listaErrores.Add("Error en la fila '" + (index + 1) + "': El número de columnas proporcionadas es incorrecto.");
                    else
                    {
                        registros.Add(datos[1], (CarnetAsegurado: datos[10], CarnetCoAsegurado: datos[19], Indice: index));
                        DataRow dr = DtblDatosAuxiliar.NewRow();
                        for (int intColumna = 0; intColumna < intNumeroColumnas; intColumna++)
                            dr[intColumna] = datos[intColumna];
                        DtblDatosAuxiliar.Rows.Add(dr);
                    }
                }
                var listaValidaciones = new List<string>();
                if (listaValidaciones.Count > 0)
                {
                    foreach (var strError in listaValidaciones)
                    {
                        listaErrores.Add(strError);
                    }
                }
                if (listaErrores.Count > 0)
                {
                    MostrarLogErrores(listaErrores, "DESBDP");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                        "$('.preloader').fadeOut();" +
                        "toastr.error('Se han encontrado observaciones en el archivo seleccionado, se le ha enviado un correo con un detalle de las observaciones para su revisión.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                {
                    string strNombreArchivo = "DESBDP_Afiliaciones_" + _strPeriodo + objArchivo.EXTENSION;
                    if (File.Exists(CParametros.RutaArchivoDatos + "DESBDP_Afiliaciones_" + _strPeriodo + objArchivo.EXTENSION))
                    {
                        File.Delete(CParametros.RutaArchivoDatos + "DESBDP_Afiliaciones_" + _strPeriodo + objArchivo.EXTENSION);
                    }
                    File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo, objArchivo.BYTE_ARRAY);
                    bool boolCargaCompleta = _cCrediseguro.DESBDP_RegistrarDatos(_strPeriodo);
                    if (boolCargaCompleta)
                    {
                        var dSetValidacion = _cCrediseguro.DESBDP_Validacion(_strPeriodo);
                        if (dSetValidacion.Tables[0].Rows.Count > 0)
                        {
                            for (int index = 0; index < dSetValidacion.Tables[0].Rows.Count; index++)
                            {
                                listaErrores.Add(dSetValidacion.Tables[0].Rows[index][1].ToString());
                            }
                            FormatearErrores(listaErrores, "DESBDP", registros, DtblDatos);
                            MostrarLogErrores(listaErrores, "DESBDP");
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                            "$('.preloader').fadeOut();" +
                            "toastr.info('El proceso de carga de datos ha sido completado exitosamente, pero el archivo presenta algunas observaciones. Se ha enviado un correo con el detalle de las mismas', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                            "$('.preloader').fadeOut();" +
                            "toastr.success('El proceso de carga de datos ha sido completado exitosamente.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        }
                    }
                    else
                    {
                        throw new Exception("Se ha presentado un error en la carga de los datos a la base de datos ('BtnProcesarArchivo_Click'). Revise el servicio Crediseguro.Core.");
                    }
                }
                PopCargarArchivo.ShowOnPageLoad = false;
                CargaInicial();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void FormatearErrores(List<string> errores, string idProducto, Dictionary<string, (string CarnetAsegurado, string CarnetCoAsegurado, int Indice)> registros, DataTable datosCargados)
        {
            string texto = String.Join("\n", errores);
            var observaciones = new List<(string Identificador, string Observacion)>();

            string pattern = @"documento: (\d+) y fecha de nacimiento: \d+/\d+/\d+, superan los 76|La operación número '(\d+)' puede ser reactivada.|operacion '(\d+)' puede ser anulada por dias de mora, Prima pendiente: (\d+.\d+), Frecuencia: (.+)|operación: (\d+).+?lista negra \(motivo: '(.+)'|documento: (\d+).+las siguientes coberturas: (.+).|número '(\d+)' no tiene titular 1";
            MatchCollection matches = Regex.Matches(texto, pattern);
            if (matches.Count > 0)
            {
                string categoria = "";
                foreach (Match match in matches)
                {
                    var groups = match.Groups.Cast<Group>().Skip(1).Where(g => g.Success).ToList();
                    if (match.Value.Contains("superan los 76"))
                    {
                        categoria = "Edad";
                    }
                    else if (match.Value.Contains("ser reactivada"))
                    {
                        categoria = "Reactivacion";
                    }
                    else if (match.Value.Contains("mora, Prima pendiente"))
                    {
                        categoria = "Mora";
                    }
                    else if (match.Value.Contains("lista negra"))
                    {
                        categoria = "Lista Negra";
                    }
                    else if (match.Value.Contains("coberturas:"))
                    {
                        categoria = "Siniestros Pagados";
                    }
                    else if (match.Value.Contains("no tiene titular 1"))
                    {
                        categoria = "Sin Titular 1";
                    }
                    else if (match.Value.Contains("no pudo ser asignada"))
                    {
                        categoria = "No asignado";
                    }
                    switch (categoria)
                    {
                        case "Edad":
                            observaciones.Add((Identificador: $"CI-{groups[0].Value}", Observacion: $"{categoria}|Mayor a 76 años"));
                            break;
                        case "Reactivacion":
                            observaciones.Add((Identificador: $"OP-{groups[0].Value}", Observacion: $"{categoria}"));
                            break;
                        case "Mora":
                            observaciones.Add((Identificador: $"OP-{groups[0].Value}", Observacion: $"{categoria}|Prima pendiente: {groups[1].Value}, Frecuencia: {groups[2].Value}"));
                            break;
                        case "Lista Negra":
                            observaciones.Add((Identificador: $"OP-{groups[0].Value}", Observacion: $"{categoria}|{groups[1].Value.Replace('|', ';')}"));
                            break;
                        case "Siniestros Pagados":
                            observaciones.Add((Identificador: $"CI-{groups[0].Value}", Observacion: $"{categoria}|{groups[1].Value}"));
                            break;
                        case "Sin Titular 1":
                            observaciones.Add((Identificador: $"CI-{groups[0].Value}", Observacion: $"{categoria}"));
                            break;
                        case "No asignado":
                            observaciones.Add((Identificador: $"OP-{groups[0].Value}", Observacion: $"{categoria}"));
                            break;
                        default:
                            break;
                    }
                }
            }
            int contadorFaltantes = 0;
            foreach (var observacion in observaciones)
            {
                string valorIdentificador = observacion.Identificador.Split('-')[1];
                if (observacion.Identificador.StartsWith("CI-"))
                {
                    int[] indices = registros.Where(r => r.Value.CarnetAsegurado == valorIdentificador || r.Value.CarnetCoAsegurado == valorIdentificador).Select(v => v.Value.Indice).ToArray();
                    foreach (var indice in indices)
                    {
                        datosCargados.Rows[indice][0] = datosCargados.Rows[indice][0] + "|" + observacion.Observacion;
                    }                    
                }
                else if (observacion.Identificador.StartsWith("OP-"))
                {
                    if (registros.ContainsKey(valorIdentificador))
                    {
                        int indice = registros[valorIdentificador].Indice;
                        datosCargados.Rows[indice][0] = datosCargados.Rows[indice][0] + "|" + observacion.Observacion;
                    }
                    else
                    {
                        contadorFaltantes++;
                    }
                }
            }
            string strNombreArchivo = idProducto + "_VALIDACION_" + _strPeriodo + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt";
            StreamWriter writer = new StreamWriter(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo, true);
            writer.Write(Environment.NewLine);
            for (int index = 0; index < datosCargados.Rows.Count; index++)
            {
                writer.WriteLine(datosCargados.Rows[index][0].ToString());
            }
            writer.Flush();
            writer.Close();

            byte[] objDocumento = File.ReadAllBytes(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo);
            Session["DOWNLOAD"] = new OC_ARCHIVO()
            {
                BYTE_ARRAY = objDocumento,
                CONTENT_TYPE = "text",
                NOMBRE_ARCHIVO = strNombreArchivo
            };
            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
        }

        protected void MostrarLogErrores(List<string> listaErrores, string strIdProducto)
        {
            try
            {
                string strNombreArchivo = strIdProducto + "_VALIDACION_" + _strPeriodo + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt";
                StreamWriter writer = new StreamWriter(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo, true);
                writer.Write("***** VALIDACIÓN DE DATOS: " + strIdProducto + " *****");
                writer.Write(Environment.NewLine);
                foreach (string strError in listaErrores)
                    writer.WriteLine(strError);
                writer.Write("***** FIN DE LA VALIDACIÓN *****");
                writer.Flush();
                writer.Close();
                string strHtml = File.ReadAllText(Server.MapPath("~/UI/templates/EMAIL_ERROR_CARGA.html"));
                var objCorreo1 = _cProduccion.Correo_Enviar(new occ_correo
                {
                    ListaCorreoDestinatario = new List<string>() { _objUsuario.Correo },
                    ListaCorreoCopia = Parametros.CParametros.ListaCorreoCopiaSistemas,
                    Sistema = "CORE PERSONALES",
                    Asunto = "ERROR EN ARCHIVO SELECCIONADO (" + strIdProducto + ")",
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<occ_correo__imagen>() { new occ_correo__imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/UI/img/logo-text.png")) } },
                    ListaArchivosAdjuntos = new List<occ_correo__archivo_adjunto>() {
                        new occ_correo__archivo_adjunto {
                            FlagBytes = true,
                            Bytes = File.ReadAllBytes(Parametros.CParametros.RutaArchivoValidacion + strNombreArchivo),
                            Nombre = strNombreArchivo } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProduccion_Click(object sender, EventArgs e)
        {
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pol.SPR_PRODUCCION_DESBDP",
                    new List<Agente.ServicioPersonales.CParameter>() {
                        new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodo },
                        new Agente.ServicioPersonales.CParameter() { Key = "@USUARIO", Value = _objUsuario.Matricula } });
                PopProduccion.ShowOnPageLoad = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "toastr.success('El proceso de producción ha sido ejecutado con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccionDocumento_Click(object sender, EventArgs e)
        {
            try
            {
                string strPeriodoSeleccionado = Session["produccion_desgravamen_bdp__periodo"].ToString();
                var objControlBDP = (ocp_control_bdp)Session["produccion_desgravamen_bdp__control"];
                string strIdDocumento = HidAccionDocumento.Get("IdDocumento").ToString();
                var listaDocumentos = objControlBDP.ListaDocumentos;
                var objDocumentoProducto = listaDocumentos.Where(w => w.ID_DOCUMENTO == strIdDocumento).First();
                switch (objDocumentoProducto.NOMBRE)
                {
                    case "REPORTE":
                        var objReporte = _cDocumentos.GetReporteProducto(
                            "DESBDP",
                            strIdDocumento,
                            new List<CParameter>() {
                                new CParameter() { Key = "@PERIODO_CONTABLE", Value = strPeriodoSeleccionado },
                                new CParameter() { Key = "@ID_PRODUCTO", Value = "DESBDP" }
                            },
                            new OC_RESPONSE_FILE() { NombreArchivo = "DESBDP_Reporte_" + strPeriodoSeleccionado, CarpetaSalida = strPeriodoSeleccionado, BoolHistorico = false, FormatoSalida = objDocumentoProducto.FORMATO });
                        Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = objReporte.ByteArray, CONTENT_TYPE = objReporte.ContentType, NOMBRE_ARCHIVO = objReporte.NombreArchivo };
                        break;
                    case "LIQUIDACION":
                        var objZipArchive = new ZipArchive();
                        var objOCArchivo = new OC_ARCHIVO();
                        var listaLiquidaciones = _cDocumentos.GetLiquidacionDESBDP(strIdDocumento, strPeriodoSeleccionado);
                        foreach (var objLiquidacion in listaLiquidaciones)
                        {
                            string strRutaArchivoEnc = Encoding.UTF8.GetString(System.Convert.FromBase64String(objLiquidacion.RutaArchivoEnc));
                            objZipArchive.AddByteArray(objLiquidacion.NombreArchivo, File.ReadAllBytes(strRutaArchivoEnc));
                        }
                        using (MemoryStream stream = new MemoryStream())
                        {
                            objZipArchive.Save(stream);
                            objOCArchivo = new OC_ARCHIVO() { BYTE_ARRAY = stream.ToArray(), CONTENT_TYPE = "application/zip", NOMBRE_ARCHIVO = "DESBDP_Liquidacion_" + strPeriodoSeleccionado + ".zip" };
                            stream.Close();
                        }
                        Session["DOWNLOAD"] = objOCArchivo;
                        break;
                    default:
                        var objOtroDocumento = _cDocumentos.Documento_Generar(
                           strIdDocumento,
                           new List<occ_response_file__parametro>() {
                                new occ_response_file__parametro { Nombre = "strPeriodoContable", Valor = strPeriodoSeleccionado },
                                new occ_response_file__parametro { Nombre = "strIdProducto", Valor = "DESBDP" }
                           });
                        Session["DOWNLOAD"] = new OC_ARCHIVO
                        {
                            BYTE_ARRAY = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objOtroDocumento.RutaArchivoEnc))),
                            CONTENT_TYPE = objOtroDocumento.ContentType,
                            NOMBRE_ARCHIVO = objOtroDocumento.NombreArchivo
                        };
                        break;
                }
                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcListaNegra_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["produccion_desgravamen_bdp__listaNegra"] = new OC_ARCHIVO()
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarListaNegra_Click(object sender, EventArgs e)
        {
            try
            {
                ValidacionCarga _validacionCarga = new ValidacionCarga();
                if (Session["produccion_desgravamen_bdp__listaNegra"] == null)
                {
                    throw new Exception("Se ha encontrado un problema con el archivo seleccionado ('BtnProcesarListaNegra_Click').");
                }
                var listaErrores = new List<string>();
                var objArchivo = (OC_ARCHIVO)Session["produccion_desgravamen_bdp__listaNegra"];                
                string strNombreArchivo = "DESBDP_ListaNegra_" + DateTime.Now.ToString("yyyyMMddhhmmss") + objArchivo.EXTENSION;
                File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo, objArchivo.BYTE_ARRAY);
                bool boolCargaCompleta = _cCrediseguro.DESBDP_RegistrarListaNegra(strNombreArchivo);
                if (boolCargaCompleta)
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks,
                    "$('.preloader').fadeOut();" +
                    "toastr.success('La lista negra del produco ha sido actualizada con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                {
                    throw new Exception("Se ha presentado un error en la carga de los datos a la base de datos ('BtnProcesarListaNegra_Click'). Revise el servicio Crediseguro.Core.");
                }
                PopListaNegra.ShowOnPageLoad = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            if (e.CellValue.IsEmpty && e.DataColumn.DataType == typeof(DateTime))
            {
                e.DataTableValue = DBNull.Value;
                e.Action = DataTableExporterAction.Continue;
            }
        }
        protected void BtnDescargarListaNegra_Click(object sender, EventArgs e)
        {
            try
            {
                var objLexico = _cPersonales.GetListLexicoPorTablaYTema("DESBDP", "LISTA_NEGRA").First();
                var listaNegra = new List<ocp_bdp__listaNegra>();
                listaNegra = JsonConvert.DeserializeObject<List<ocp_bdp__listaNegra>>(objLexico.LEPVC_VALOR);
                DataTable DtblDatos = _cCrediseguro.DESBDP_ObtenerListaNegra().Tables[0];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(Server.MapPath("~/UI/templates/ListaNegra.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "ListaNegra")
                    {
                        DEWorksheet.Import(DtblDatos, false, 1, 0);
                        DEWorksheet.Range["A1:C" + (DtblDatos.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                    }
                }
                OC_ARCHIVO objReporte = new OC_ARCHIVO();
                using (MemoryStream stream = new MemoryStream())
                {
                    DEWorkbook.SaveDocument(stream, DevExpress.Spreadsheet.DocumentFormat.OpenXml);
                    objReporte.BYTE_ARRAY = stream.ToArray();
                    objReporte.CONTENT_TYPE = "application/vnd.ms-excel";
                    objReporte.NOMBRE_ARCHIVO = "DESBDP_ListaNegra_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx";
                    stream.Close();
                }
                Session["DOWNLOAD"] = objReporte;
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}