﻿using Agente.ServicioCrediseguro;
using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Web;
using DocumentFormat.OpenXml.Drawing.Charts;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class registrar_anulacion : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        private string _strPeriodoContable;
        private bool _boolBroker;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
            _boolBroker = (_objUsuario.Area == "BROKER") ? true : false;
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cPersonales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                _boolBroker = (_objUsuario.Area == "BROKER") ? true : false;
                Session["registrar_anulacion__bandeja"] = _cPersonales.Anulacion_Bandeja(_strPeriodoContable, _boolBroker);
                GrvAnulaciones.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAnulaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["registrar_anulacion__bandeja"] != null)
                {
                    DataView dvAnulaciones = new DataView(((DataSet)Session["registrar_anulacion__bandeja"]).Tables[0]);
                    dvAnulaciones.Sort = "NUMERO";
                    GrvAnulaciones.DataSource = dvAnulaciones.ToTable();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAnulaciones_PreRender(object sender, EventArgs e)
        {
            try
            {
                var objLexico = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PERIODO_CONTABLE" && w.LEPVC_TEMA == "PROCESO").First();
                string strPeriodoContableCore = objLexico.LEPVC_VALOR;
                DateTime dtFechaCorte = DateTime.ParseExact(objLexico.LEPVC_DESC_CORTA, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                BtnCargaIndividual.ClientVisible = false;
                BtnCargaMasiva.ClientVisible = false;
                GrvAnulaciones.Columns[13].Visible = false;
                GrvAnulaciones.Columns[14].Visible = false;
                if (_strPeriodoContable == strPeriodoContableCore)
                {
                    if (DateTime.Today < dtFechaCorte)
                    {
                        BtnCargaIndividual.ClientVisible = true;
                        BtnCargaMasiva.ClientVisible = true;
                        GrvAnulaciones.Columns[13].Visible = true;
                        GrvAnulaciones.Columns[14].Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCargaIndividual_Click(object sender, EventArgs e)
        {
            try
            {
                PopCargaIndividual.ShowOnPageLoad = true;
                PnlBusqueda.Visible = true;
                CmbProducto.Value = null;
                TxtNumeroDocumento.Text = null;
                TxtNombre.Text = null;
                GrvAfiliaciones.Visible = false;
                DataView dvProductos = new DataView(((DataSet)Session["registrar_anulacion__bandeja"]).Tables[1]);
                dvProductos.Sort = "NOMBRE_COMERCIAL";
                CmbProducto.Items.Clear();
                CmbProducto.DataSource = dvProductos.ToTable();
                CmbProducto.ValueField = "ID_PRODUCTO";
                CmbProducto.TextField = "NOMBRE_COMERCIAL";
                CmbProducto.DataBind();
                PnlRegistro.Visible = false;
                PopCargaIndividual.FindControl("BtnRegistrar").Visible = false;
                PopCargaIndividual.FindControl("BtnActualizar").Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Session["registrar_anulacion__afiliaciones"] = _cPersonales.Anulacion_Buscar(
                    "INDIVIDUAL",
                    CmbProducto.SelectedItem.Value.ToString(),
                    string.Empty,
                    string.Empty,
                    DateTime.Today,
                    string.IsNullOrEmpty(TxtNumeroDocumento.Text) ? string.Empty : TxtNumeroDocumento.Text.Trim().ToUpper(),
                    string.IsNullOrEmpty(TxtNombre.Text) ? string.Empty : TxtNombre.Text.Trim().ToUpper(),
                    string.Empty,
                    _boolBroker);
                GrvAfiliaciones.Visible = true;
                GrvAfiliaciones.DataBind();
                PnlRegistro.Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAfiliaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["registrar_anulacion__afiliaciones"] != null)
                    GrvAfiliaciones.DataSource = ((DataSet)Session["registrar_anulacion__afiliaciones"]).Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnSeleccionarAfiliacion_Click(object sender, EventArgs e)
        {
            try
            {
                var strIdAfiliacion = HidIdAfiliacion.Value;
                var DtblAfiliaciones = ((DataSet)Session["registrar_anulacion__afiliaciones"]).Tables[0];
                TxtFechaAnulacion.Text = null;
                TxtPrima.Text = null;
                TxtComisionBroker.Text = null;
                TxtPrimaCedida.Text = null;
                PopCargaIndividual.FindControl("BtnRegistrar").Visible = true;
                PopCargaIndividual.FindControl("BtnActualizar").Visible = false;
                for (int index = 0; index < DtblAfiliaciones.Rows.Count; index++)
                {
                    if (DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString() == strIdAfiliacion)
                    {
                        var objAnulacion = new ocp_anulacion
                        {
                            TipoAnulacion = DtblAfiliaciones.Rows[index]["TIPO_ANULACION"].ToString(),
                            Certificado = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString(),
                            IdProducto = DtblAfiliaciones.Rows[index]["ID_PRODUCTO"].ToString(),
                            Ramo = DtblAfiliaciones.Rows[index]["RAMO"].ToString(),
                            IdAfiliacion = DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString(),
                            IdTomador = DtblAfiliaciones.Rows[index]["ID_TOMADOR"].ToString(),
                            IdAsegurado = DtblAfiliaciones.Rows[index]["ID_ASEGURADO"].ToString(),
                            PeriodoCorresponde = DtblAfiliaciones.Rows[index]["PERIODO_CORRESPONDE"].ToString(),
                            Moneda = DtblAfiliaciones.Rows[index]["MONEDA"].ToString(),
                            CodigoAPSBroker = DtblAfiliaciones.Rows[index]["ID_BROKER"].ToString(),
                            NumeroPoliza = DtblAfiliaciones.Rows[index]["POLIZA"].ToString(),
                            IdReaseguro = DtblAfiliaciones.Rows[index]["ID_REASEGURO"].ToString(),
                            FechaAfiliacion = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]),
                            DiasVigenciaAfiliacion = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIAS_VIGENCIA"]),
                            ProduccionPrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_NETA"]),
                            ProduccionComisionBroker = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["COMISION_BROKER"]),
                            ProduccionPrimaCedida = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_CEDIDA"]),
                        };
                        Session["registrar_anulacion__anulacion"] = objAnulacion;
                        PnlBusqueda.Visible = false;
                        PnlRegistro.Visible = true;
                        LblAfiliacionProducto.Text = DtblAfiliaciones.Rows[index]["PRODUCTO"].ToString();
                        LblAfiliacionAsegurado.Text = DtblAfiliaciones.Rows[index]["ASEGURADO"].ToString();
                        LblAfiliacionIdAfiliacion.Text = objAnulacion.IdAfiliacion;
                        LblAfiliacionPoliza.Text = objAnulacion.NumeroPoliza;
                        LblAfiliacionCertificado.Text = objAnulacion.Certificado;
                        LblAfiliacionInicioVigencia.Text = objAnulacion.FechaAfiliacion.ToString("dd/MM/yyyy");
                        LblAfiliacionFinVigencia.Text = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_FIN_VIGENCIA"]).ToString("dd/MM/yyyy");
                        LblAfiliacionDiasVigencia.Text = objAnulacion.DiasVigenciaAfiliacion.ToString();
                        LblProduccionTipoAnulacion.Text = objAnulacion.TipoAnulacion;
                        LblProduccionMoneda.Text = objAnulacion.Moneda;
                        LblProduccionFactorPrimaAdicional.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["FACTOR_PRIMA_ADICIONAL"]).ToString("p2");
                        LblProduccionPrimaComercial.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_COMERCIAL"]).ToString("n2");
                        LblProduccionPrimaAdicional.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_ADICIONAL"]).ToString("n2");
                        LblProduccionPrimaNeta.Text = objAnulacion.ProduccionPrimaNeta.ToString("n2");
                        LblProduccionComisionBroker.Text = objAnulacion.ProduccionComisionBroker.ToString("n2");
                        LblProduccionPrimaCedida.Text = objAnulacion.ProduccionPrimaCedida.ToString("n2");
                        LblProduccionReasegurador.Text = DtblAfiliaciones.Rows[index]["REASEGURADOR"].ToString();
                        BtnCalcular.ClientVisible = false;
                        TxtFechaAnulacion.MinDate = objAnulacion.FechaAfiliacion;
                        TxtFechaAnulacion.MaxDate = DateTime.Today;
                        TxtDiasCobertura.Caption = "Días con Cobertura";
                        if (objAnulacion.TipoAnulacion == "PRORRATA" || objAnulacion.TipoAnulacion == "PLAZOS CORTOS")
                        {
                            BtnCalcular.ClientVisible = true;
                        }
                        if (objAnulacion.TipoAnulacion == "PLAZOS CORTOS")
                        {
                            TxtDiasCobertura.Caption = "Meses Corridos";
                        }
                        HidAccionConfirmacion.Value = "CARGA_INDIVIDUAL";
                        LblMensajeConfirmacion.Text = "Se registrará la anulación con los datos ingresados en el formulario. ¿Está seguro(a) que desea continuar?";
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                var objAnulacion = (ocp_anulacion)Session["registrar_anulacion__anulacion"];
                DateTime DtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                int intDiasCoberturaAfiliacion = (DtFechaAnulacion - objAnulacion.FechaAfiliacion).Days + 1;
                decimal decPrima = 0, decPrimaCedida = 0, decComisionBroker = 0;
                switch (objAnulacion.TipoAnulacion)
                {
                    case "PRORRATA":
                        TxtDiasCobertura.Text = intDiasCoberturaAfiliacion.ToString();
                        decPrima = ocp_anulacion.Prorrateo(objAnulacion.ProduccionPrimaNeta, objAnulacion.DiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                        decPrimaCedida = ocp_anulacion.Prorrateo(objAnulacion.ProduccionPrimaCedida, objAnulacion.DiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                        decComisionBroker = ocp_anulacion.Prorrateo(objAnulacion.ProduccionComisionBroker, objAnulacion.DiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                        break;
                    case "PLAZOS CORTOS":
                        int intMesesCorridos = ocp_anulacion.MesesCorridos(objAnulacion.IdProducto, intDiasCoberturaAfiliacion);
                        decimal decPlazosCortos = ocp_anulacion.FactorPlazosCortos(intMesesCorridos);
                        TxtDiasCobertura.Text = intMesesCorridos.ToString() + " (a devolver el " + ((1 - decPlazosCortos) * 100).ToString("n2") + "% de la prima neta)";
                        decPrima = ocp_anulacion.PlazosCortos(objAnulacion.ProduccionPrimaNeta, decPlazosCortos);
                        decPrimaCedida = ocp_anulacion.PlazosCortos(objAnulacion.ProduccionPrimaCedida, decPlazosCortos);
                        decComisionBroker = ocp_anulacion.PlazosCortos(objAnulacion.ProduccionComisionBroker, decPlazosCortos);
                        break;
                }
                TxtPrima.Value = decPrima;
                TxtComisionBroker.Value = decComisionBroker;
                TxtPrimaCedida.Value = decPrimaCedida;
                TxtPrima.IsValid = true;
                TxtComisionBroker.IsValid = true;
                TxtPrimaCedida.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCargaMasiva_Click(object sender, EventArgs e)
        {
            try
            {
                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
                PopCargaMasiva.ShowOnPageLoad = true;
                PnlMasivoPaso1.Visible = true;
                PnlMasivoPaso2.Visible = false;
                PopCargaMasiva.FindControl("BtnMasivoContinuar").Visible = true;
                PopCargaMasiva.FindControl("BtnMasivoProcesar").Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["registrar_anulacion__archivo"] = new OC_ARCHIVO
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                var objArchivo = (OC_ARCHIVO)Session["registrar_anulacion__archivo"];
                CmbWorksheet.Items.Clear();
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(objArchivo.BYTE_ARRAY, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    CmbWorksheet.Items.Add(new DevExpress.Web.Bootstrap.BootstrapListEditItem(DEWorksheet.Name, DEWorksheet.Name));
                }
                CmbWorksheet.Value = null;
                PnlMasivoPaso1.Visible = false;
                PnlMasivoPaso2.Visible = true;
                PopCargaMasiva.FindControl("BtnMasivoContinuar").Visible = false;
                PopCargaMasiva.FindControl("BtnMasivoProcesar").Visible = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnMasivoProcesar_Click(object sender, EventArgs e)
        {
            try
            {
                var objArchivo = (OC_ARCHIVO)Session["registrar_anulacion__archivo"];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(objArchivo.BYTE_ARRAY, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                var listaAnulaciones = new List<POLIZAS_ANULADAS>();
                var listaErrores = new List<ERROR_SISTEMA>();
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == (string)CmbWorksheet.SelectedItem.Value)
                    {
                        CellRange range = DEWorksheet.Range["A2:F1011"];
                        System.Data.DataTable dataTable = DEWorksheet.CreateDataTable(range, false, true);
                        DataTableExporter exporter = DEWorksheet.CreateDataTableExporter(range, dataTable, false);
                        exporter.CellValueConversionError += exporter_CellValueConversionError;
                        exporter.Options.DefaultCellValueToColumnTypeConverter.ConvertStringValues = false;
                        exporter.Export();
                        for (int index = 0; index < dataTable.Rows.Count; index++)
                        {
                            if (!string.IsNullOrEmpty(dataTable.Rows[index][0].ToString().Trim()))
                            {
                                if (string.IsNullOrEmpty(dataTable.Rows[index][1].ToString().Trim()))
                                    listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número de póliza\" no ha sido proporcionado (" + dataTable.Rows[index][1].ToString().Trim() + ")." });
                                if (string.IsNullOrEmpty(dataTable.Rows[index][3].ToString().Trim()))
                                {
                                    listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número del documento de identidad\" no ha sido proporcionado." });
                                }
                                else
                                {
                                    int intNumeroDocumento = 0;
                                    if (!int.TryParse(dataTable.Rows[index][3].ToString().Trim(), out intNumeroDocumento))
                                    {
                                        listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número del documento de identidad\" debe ser un valor numérico (" + dataTable.Rows[index][3].ToString().Trim() + ")." });
                                    }
                                }
                                var dtFechaInicioVigencia = funciones.GetDateTime(dataTable.Rows[index][4].ToString().Trim(), "dd/MM/yyyy");
                                if (dtFechaInicioVigencia == null)
                                    listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': La \"fecha de inicio de vigencia\" no ha sido proporcionada o no es un valor valido (" + dataTable.Rows[index][4].ToString().Trim() + ")." });
                                var dtFechaAnulacion = funciones.GetDateTime(dataTable.Rows[index][5].ToString().Trim(), "dd/MM/yyyy");
                                if (dtFechaAnulacion == null)
                                    listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': La \"fecha de anulación\" no ha sido proporcionada o no es un valor valido (" + dataTable.Rows[index][5].ToString().Trim() + ")." });
                                else if (dtFechaAnulacion > DateTime.Today)
                                {
                                    listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': La \"fecha de anulación\" no puede ser mayor que la fecha actual (" + dataTable.Rows[index][5].ToString().Trim() + ")." });
                                }
                                listaAnulaciones.Add(new POLIZAS_ANULADAS
                                {
                                    POPBI_ID_POLIZAS_ANULADAS = index + 1,
                                    PA_IDPRODUCTO = dataTable.Rows[index][0].ToString().Trim().ToUpper(),
                                    PA_POLIZA = dataTable.Rows[index][1].ToString().Trim().ToUpper(),
                                    PA_IDCERTIFICADO = dataTable.Rows[index][2].ToString().Trim().ToUpper(),                                    
                                    PA_IDCLIENTE = dataTable.Rows[index][3].ToString().Trim().ToUpper(),
                                    PA_FECHA_INGRESO = dtFechaInicioVigencia ?? DateTime.Today,
                                    PA_FECHA_ANULACION = dtFechaAnulacion ?? DateTime.Today
                                });
                            }
                        }
                        break;
                    }
                }
                bool boolMostrarErrores = true;
                if (listaErrores.Count == 0)
                {
                    CCore _cCore = new CCore();
                    boolMostrarErrores = false;
                    foreach (var objAnulacion in listaAnulaciones)
                    {
                        DataSet dsetBusqueda = _cPersonales.Anulacion_Buscar(
                            "MASIVO",
                            objAnulacion.PA_IDPRODUCTO.Trim(),
                            objAnulacion.PA_POLIZA.Trim(),
                            objAnulacion.PA_IDCERTIFICADO.Trim(),
                            objAnulacion.PA_FECHA_INGRESO,
                            objAnulacion.PA_IDCLIENTE.Trim(),
                            string.Empty,
                            string.Empty,
                            _boolBroker);
                        if (dsetBusqueda.Tables[0].Columns.Count == 1)
                        {
                            listaErrores.Add(new ERROR_SISTEMA { ERPVC_MENSAJE = "Error en la registro '" + (objAnulacion.POPBI_ID_POLIZAS_ANULADAS) + "': " + dsetBusqueda.Tables[0].Rows[0][0].ToString() });
                        }
                        else
                        {
                            var dtblAfiliacion = dsetBusqueda.Tables[0];
                            int intDiasCoberturaAfiliacion = ((objAnulacion.PA_FECHA_ANULACION ?? DateTime.Today) - objAnulacion.PA_FECHA_INGRESO).Days + 1;
                            decimal decPrimaAnulada = 0, decPrimaCedida = 0, decComisionBroker = 0;
                            decimal decTipoCambio = _cCore.ObtenerTipoCambioERP();
                            decimal
                                decProduccionPrimaNeta = funciones.GetDecimal(dtblAfiliacion.Rows[0]["PRIMA_NETA"].ToString()),
                                decProduccionPrimaCedida = funciones.GetDecimal(dtblAfiliacion.Rows[0]["PRIMA_CEDIDA"].ToString()),
                                decProduccionComisionBroker = funciones.GetDecimal(dtblAfiliacion.Rows[0]["COMISION_BROKER"].ToString());
                            int intDiasVigenciaAfiliacion = Convert.ToInt32(dtblAfiliacion.Rows[0]["DIAS_VIGENCIA"].ToString());
                            switch (dtblAfiliacion.Rows[0]["TIPO_ANULACION"].ToString())
                            {
                                case "PRORRATA":
                                    TxtDiasCobertura.Text = intDiasCoberturaAfiliacion.ToString();
                                    decPrimaAnulada = ocp_anulacion.Prorrateo(decProduccionPrimaNeta, intDiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                                    decPrimaCedida = ocp_anulacion.Prorrateo(decProduccionPrimaCedida, intDiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                                    decComisionBroker = ocp_anulacion.Prorrateo(decProduccionComisionBroker, intDiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                                    break;
                                case "PLAZOS CORTOS":
                                    int intMesesCorridos = ocp_anulacion.MesesCorridos(objAnulacion.PA_IDPRODUCTO.Trim(), intDiasCoberturaAfiliacion);
                                    decimal decPlazosCortos = ocp_anulacion.FactorPlazosCortos(intMesesCorridos);
                                    decPrimaAnulada = ocp_anulacion.PlazosCortos(decProduccionPrimaNeta, decPlazosCortos);
                                    decPrimaCedida = ocp_anulacion.PlazosCortos(decProduccionPrimaCedida, decPlazosCortos);
                                    decComisionBroker = ocp_anulacion.PlazosCortos(decProduccionComisionBroker, decPlazosCortos);
                                    break;
                            }
                            objAnulacion.PA_IDCERTIFICADO = dtblAfiliacion.Rows[0]["CERTIFICADO"].ToString();
                            objAnulacion.PA_IDPRODUCTO = dtblAfiliacion.Rows[0]["ID_PRODUCTO"].ToString();
                            objAnulacion.PA_RAMO = dtblAfiliacion.Rows[0]["RAMO"].ToString();
                            objAnulacion.PA_NROOPERACION = dtblAfiliacion.Rows[0]["ID_AFILIACION"].ToString();
                            objAnulacion.PA_IDTOMADOR = dtblAfiliacion.Rows[0]["ID_TOMADOR"].ToString();
                            objAnulacion.PA_IDCLIENTE = dtblAfiliacion.Rows[0]["ID_ASEGURADO"].ToString();
                            objAnulacion.PA_PERIODO_CORRESPONDE = dtblAfiliacion.Rows[0]["PERIODO_CORRESPONDE"].ToString();
                            objAnulacion.PA_PERIODO_AFECTADO = _strPeriodoContable;
                            objAnulacion.PA_MONEDA = dtblAfiliacion.Rows[0]["MONEDA"].ToString();
                            objAnulacion.PA_PRIMA_COMERCIAL = 0;
                            objAnulacion.PA_PRIMA_COMERCIAL_USD = 0;
                            objAnulacion.PA_PRIMA_NETA = decPrimaAnulada;
                            objAnulacion.PA_PRIMA_NETA_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decPrimaAnulada / decTipoCambio, 2) : decPrimaAnulada;
                            objAnulacion.PA_PRIMA_ADICIONAL = 0;
                            objAnulacion.PA_PRIMA_ADICIONAL_USD = 0;
                            objAnulacion.PA_PRIMA_CEDIDA = decPrimaCedida;
                            objAnulacion.PA_PRIMA_CEDIDA_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decPrimaCedida / decTipoCambio, 2) : decPrimaCedida;
                            objAnulacion.PA_CAPITAL_ASEGURADO = 0;
                            objAnulacion.PA_CAPITAL_ASEGURADO_USD = 0;
                            objAnulacion.PA_CAPITAL_CEDIDO = 0;
                            objAnulacion.PA_CAPITAL_CEDIDO_USD = 0;
                            objAnulacion.PA_FECHA_INGRESO = DateTime.Now;
                            objAnulacion.PA_USUARIO_INGRESO = _objUsuario.Matricula;
                            objAnulacion.PA_USUARIO_AUTORIZADOR = _objUsuario.Matricula;
                            objAnulacion.PA_COMISION_BROKER = decComisionBroker;
                            objAnulacion.PA_COMISION_BROKER_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decComisionBroker / decTipoCambio, 2) : decComisionBroker;
                            objAnulacion.PA_CODIGO_APS_BROKER = dtblAfiliacion.Rows[0]["CODIGO_BROKER"].ToString();
                            objAnulacion.PA_POLIZA = dtblAfiliacion.Rows[0]["POLIZA"].ToString();
                            objAnulacion.PA_ID_REASEGURO = dtblAfiliacion.Rows[0]["ID_REASEGURADOR"].ToString();
                        }
                    }
                    if (listaErrores.Count == 0)
                    {
                        Session["registrar_anulacion__listaAnulaciones"] = listaAnulaciones;
                        HidAccionConfirmacion.Value = "CARGA_MASIVA";
                        LblMensajeConfirmacion.Text = "¿Está seguro que desea registrar las anulaciones del archivo seleccionado?";
                        PopCargaMasiva.ShowOnPageLoad = false;
                        PopConfirmacion.ShowOnPageLoad = true;
                    }
                    else
                    {
                        boolMostrarErrores = true;
                    }
                }
                if (boolMostrarErrores)
                {
                    PopCargaMasiva.ShowOnPageLoad = false;
                    PopValidacion.ShowOnPageLoad = true;
                    GrvErrores.DataSource = listaErrores;
                    GrvErrores.DataBind();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.danger('Se han encontrado observaciones en el archivo seleccionado, por favor revise el detalle desplegado.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            if (e.CellValue.IsEmpty && e.DataColumn.DataType == typeof(DateTime))
            {
                e.DataTableValue = DBNull.Value;
                e.Action = DataTableExporterAction.Continue;
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strAccion = HidAccionConfirmacion.Value;
                CCore _cCore = new CCore();
                if (strAccion == "CARGA_MASIVA")
                {
                    var objArchivo = (OC_ARCHIVO)Session["registrar_anulacion__archivo"];
                    var listaAnulaciones = (List<POLIZAS_ANULADAS>)Session["registrar_anulacion__listaAnulaciones"];
                    string strRutaArchivos = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ARCHIVOS").First().LEPVC_VALOR;
                    string strNombreArchivo = "AnulacionMasiva_" + DateTime.Now.ToString("yyyyMMddHHmmss") + objArchivo.EXTENSION;
                    if (File.Exists(strRutaArchivos + strNombreArchivo))
                        File.Delete(strRutaArchivos + strNombreArchivo);
                    File.WriteAllBytes(strRutaArchivos + strNombreArchivo, objArchivo.BYTE_ARRAY);
                    _cCrediseguro.Anulacion_RegistrarLista(listaAnulaciones);
                    Session.Remove("registrar_anulacion__archivo");
                    Session.Remove("registrar_anulacion__listaAnulaciones");
                    PopConfirmacion.ShowOnPageLoad = false;
                    PopCargaMasiva.ShowOnPageLoad = false;
                    CargaInicial();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "002", "toastr.success('La carga masiva de anulaciones ha finalizado con éxito " + listaAnulaciones.Count.ToString() + " anulaciones han sido registradas en el sistema de producción.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                if (strAccion == "CARGA_INDIVIDUAL")
                {
                    var objAnulacion = (ocp_anulacion)Session["registrar_anulacion__anulacion"];
                    DateTime dtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    decimal decTipoCambio = _cCore.ObtenerTipoCambioERP();
                    decimal decPrimaAnulada = funciones.GetDecimal(TxtPrima.Text.ToString().Trim());
                    decimal decComisionBroker = funciones.GetDecimal(TxtComisionBroker.Text.ToString().Trim());
                    decimal decPrimaCedida = funciones.GetDecimal(TxtPrimaCedida.Text.ToString().Trim());
                    var objAnulacionResult = _cCrediseguro.Anulacion_Registrar(new POLIZAS_ANULADAS
                    {
                        PA_IDCERTIFICADO = objAnulacion.Certificado,
                        PA_IDPRODUCTO = objAnulacion.IdProducto,
                        PA_RAMO = objAnulacion.Ramo,
                        PA_NROOPERACION = objAnulacion.IdAfiliacion,
                        PA_IDTOMADOR = objAnulacion.IdTomador,
                        PA_IDCLIENTE = objAnulacion.IdAsegurado,
                        PA_PERIODO_CORRESPONDE = objAnulacion.PeriodoCorresponde,
                        PA_PERIODO_AFECTADO = _strPeriodoContable,
                        PA_MONEDA = objAnulacion.Moneda,
                        PA_PRIMA_COMERCIAL = 0,
                        PA_PRIMA_COMERCIAL_USD = 0,
                        PA_PRIMA_NETA = decPrimaAnulada,
                        PA_PRIMA_NETA_USD = (objAnulacion.Moneda == "BOB") ? Math.Round(decPrimaAnulada / decTipoCambio, 2) : decPrimaAnulada,
                        PA_PRIMA_ADICIONAL = 0,
                        PA_PRIMA_ADICIONAL_USD = 0,
                        PA_PRIMA_CEDIDA = decPrimaCedida,
                        PA_PRIMA_CEDIDA_USD = (objAnulacion.Moneda == "BOB") ? Math.Round(decPrimaCedida / decTipoCambio, 2) : decPrimaCedida,
                        PA_CAPITAL_ASEGURADO = 0,
                        PA_CAPITAL_ASEGURADO_USD = 0,
                        PA_CAPITAL_CEDIDO = 0,
                        PA_CAPITAL_CEDIDO_USD = 0,
                        PA_FECHA_INGRESO = DateTime.Now,
                        PA_USUARIO_INGRESO = _objUsuario.Matricula,
                        PA_USUARIO_AUTORIZADOR = _objUsuario.Matricula,
                        PA_COMISION_BROKER = decComisionBroker,
                        PA_COMISION_BROKER_USD = (objAnulacion.Moneda == "BOB") ? Math.Round(decComisionBroker / decTipoCambio, 2) : decComisionBroker,
                        PA_CODIGO_APS_BROKER = objAnulacion.CodigoAPSBroker,
                        PA_POLIZA = objAnulacion.NumeroPoliza,
                        PA_ID_REASEGURO = objAnulacion.IdReaseguro,
                        PA_FECHA_ANULACION = dtFechaAnulacion
                    });
                    CargaInicial();
                    PopCargaIndividual.ShowOnPageLoad = false;
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__anulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "003", "toastr.success('El registro de la anulación en el sistema de producción ha sido completado con éxito.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                if (strAccion == "ELIMINAR")
                {
                    var longIdAnulacion = (long)Session["registrar_anulacion__idAnulacion"];
                    _cCrediseguro.Anulacion_Eliminar(longIdAnulacion);
                    CargaInicial();
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__idAnulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "004", "toastr.success('El registro de anulación ha sido eliminado de la base de producción con éxito.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                if (strAccion == "ACTUALIZAR")
                {
                    var objAnulacion = (POLIZAS_ANULADAS)Session["registrar_anulacion__objAnulacion"];
                    DateTime dtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    decimal decTipoCambio = _cCore.ObtenerTipoCambioERP();
                    decimal decPrimaAnulada = funciones.GetDecimal(TxtPrima.Text.ToString().Trim());
                    decimal decComisionBroker = funciones.GetDecimal(TxtComisionBroker.Text.ToString().Trim());
                    decimal decPrimaCedida = funciones.GetDecimal(TxtPrimaCedida.Text.ToString().Trim());
                    objAnulacion.PA_PRIMA_NETA = decPrimaAnulada;
                    objAnulacion.PA_PRIMA_NETA_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decPrimaAnulada / decTipoCambio, 2) : decPrimaAnulada;
                    objAnulacion.PA_PRIMA_CEDIDA = decPrimaCedida;
                    objAnulacion.PA_PRIMA_CEDIDA_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decPrimaCedida / decTipoCambio, 2) : decPrimaCedida;
                    objAnulacion.PA_COMISION_BROKER = decComisionBroker;
                    objAnulacion.PA_COMISION_BROKER_USD = (objAnulacion.PA_MONEDA == "BOB") ? Math.Round(decComisionBroker / decTipoCambio, 2) : decComisionBroker;
                    objAnulacion.PA_FECHA_ANULACION = dtFechaAnulacion;
                    _cCrediseguro.Anulacion_Modificar(objAnulacion);
                    CargaInicial();
                    PopCargaIndividual.ShowOnPageLoad = false;
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__objAnulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "005", "toastr.success('La actualización de la anulación en el sistema de producción ha sido completado con éxito.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnSeleccionarAnulacion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAnulacion.Contains("IdAnulacion") && HidAnulacion.Contains("Accion"))
                {
                    var longIdAnulacion = Convert.ToInt64(HidAnulacion.Get("IdAnulacion"));
                    switch (HidAnulacion.Get("Accion").ToString())
                    {
                        case "Editar":
                            var objAnulacion = _cCrediseguro.Anulacion_ObtenerObjetoPorId(longIdAnulacion);
                            var dsetAfiliaciones = _cPersonales.Anulacion_Buscar(
                                "INDIVIDUAL",
                                objAnulacion.PA_IDPRODUCTO.Trim(),
                                string.Empty,
                                string.Empty,
                                DateTime.Today,
                                string.Empty,
                                string.Empty,
                                objAnulacion.PA_NROOPERACION.Trim(),
                                _boolBroker);                            
                            var DtblAfiliaciones = dsetAfiliaciones.Tables[0];                            
                            TxtFechaAnulacion.Value = objAnulacion.PA_FECHA_ANULACION;
                            DateTime DtFechaAfiliacion = Convert.ToDateTime(DtblAfiliaciones.Rows[0]["FECHA_INICIO_VIGENCIA"]);
                            DateTime DtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                            int intDiasCoberturaAfiliacion = (DtFechaAnulacion - DtFechaAfiliacion).Days + 1;
                            TxtDiasCobertura.Caption = "Días con Cobertura";
                            if (DtblAfiliaciones.Rows[0]["TIPO_ANULACION"].ToString() == "PLAZOS CORTOS")
                            {
                                int intMesesCorridos = ocp_anulacion.MesesCorridos(objAnulacion.PA_IDPRODUCTO.Trim(), intDiasCoberturaAfiliacion);
                                decimal decPlazosCortos = ocp_anulacion.FactorPlazosCortos(intMesesCorridos);
                                TxtDiasCobertura.Text = intMesesCorridos.ToString() + " (a devolver el " + ((1 - decPlazosCortos) * 100).ToString("n2") + "% de la prima neta)";
                                TxtDiasCobertura.Caption = "Meses Corridos";
                            }
                            else
                            {
                                TxtDiasCobertura.Text = intDiasCoberturaAfiliacion.ToString();
                            }
                            TxtPrima.Value = objAnulacion.PA_PRIMA_NETA;
                            TxtComisionBroker.Value = objAnulacion.PA_COMISION_BROKER;
                            TxtPrimaCedida.Value = objAnulacion.PA_PRIMA_CEDIDA;
                            PopCargaIndividual.FindControl("BtnRegistrar").Visible = false;
                            PopCargaIndividual.FindControl("BtnActualizar").Visible = true;                            
                            for (int index = 0; index < DtblAfiliaciones.Rows.Count; index++)
                            {
                                if (DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString() == objAnulacion.PA_NROOPERACION.Trim())
                                {
                                    var objAnulacionEdicion = new ocp_anulacion
                                    {
                                        TipoAnulacion = DtblAfiliaciones.Rows[index]["TIPO_ANULACION"].ToString(),
                                        Certificado = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString(),
                                        IdProducto = DtblAfiliaciones.Rows[index]["ID_PRODUCTO"].ToString(),
                                        Ramo = DtblAfiliaciones.Rows[index]["RAMO"].ToString(),
                                        IdAfiliacion = DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString(),
                                        IdTomador = DtblAfiliaciones.Rows[index]["ID_TOMADOR"].ToString(),
                                        IdAsegurado = DtblAfiliaciones.Rows[index]["ID_ASEGURADO"].ToString(),
                                        PeriodoCorresponde = DtblAfiliaciones.Rows[index]["PERIODO_CORRESPONDE"].ToString(),
                                        Moneda = DtblAfiliaciones.Rows[index]["MONEDA"].ToString(),
                                        CodigoAPSBroker = DtblAfiliaciones.Rows[index]["ID_BROKER"].ToString(),
                                        NumeroPoliza = DtblAfiliaciones.Rows[index]["POLIZA"].ToString(),
                                        IdReaseguro = DtblAfiliaciones.Rows[index]["ID_REASEGURO"].ToString(),
                                        FechaAfiliacion = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]),
                                        DiasVigenciaAfiliacion = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIAS_VIGENCIA"]),
                                        ProduccionPrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_NETA"]),
                                        ProduccionComisionBroker = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["COMISION_BROKER"]),
                                        ProduccionPrimaCedida = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_CEDIDA"]),
                                    };
                                    Session["registrar_anulacion__objAnulacion"] = objAnulacion;
                                    Session["registrar_anulacion__anulacion"] = objAnulacionEdicion;
                                    PnlBusqueda.Visible = false;
                                    PnlRegistro.Visible = true;
                                    LblAfiliacionProducto.Text = DtblAfiliaciones.Rows[index]["PRODUCTO"].ToString();
                                    LblAfiliacionAsegurado.Text = DtblAfiliaciones.Rows[index]["ASEGURADO"].ToString();
                                    LblAfiliacionIdAfiliacion.Text = objAnulacionEdicion.IdAfiliacion;
                                    LblAfiliacionPoliza.Text = objAnulacionEdicion.NumeroPoliza;
                                    LblAfiliacionCertificado.Text = objAnulacionEdicion.Certificado;
                                    LblAfiliacionInicioVigencia.Text = objAnulacionEdicion.FechaAfiliacion.ToString("dd/MM/yyyy");
                                    LblAfiliacionFinVigencia.Text = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_FIN_VIGENCIA"]).ToString("dd/MM/yyyy");
                                    LblAfiliacionDiasVigencia.Text = objAnulacionEdicion.DiasVigenciaAfiliacion.ToString();
                                    LblProduccionTipoAnulacion.Text = objAnulacionEdicion.TipoAnulacion;
                                    LblProduccionMoneda.Text = objAnulacionEdicion.Moneda;
                                    LblProduccionFactorPrimaAdicional.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["FACTOR_PRIMA_ADICIONAL"]).ToString("p2");
                                    LblProduccionPrimaComercial.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_COMERCIAL"]).ToString("n2");
                                    LblProduccionPrimaAdicional.Text = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_ADICIONAL"]).ToString("n2");
                                    LblProduccionPrimaNeta.Text = objAnulacionEdicion.ProduccionPrimaNeta.ToString("n2");
                                    LblProduccionComisionBroker.Text = objAnulacionEdicion.ProduccionComisionBroker.ToString("n2");
                                    LblProduccionPrimaCedida.Text = objAnulacionEdicion.ProduccionPrimaCedida.ToString("n2");
                                    LblProduccionReasegurador.Text = DtblAfiliaciones.Rows[index]["REASEGURADOR"].ToString();
                                    BtnCalcular.ClientVisible = false;
                                    TxtFechaAnulacion.MinDate = objAnulacionEdicion.FechaAfiliacion;
                                    TxtFechaAnulacion.MaxDate = DateTime.Today;
                                    if (objAnulacionEdicion.TipoAnulacion == "PRORRATA" || objAnulacionEdicion.TipoAnulacion == "PLAZOS CORTOS")
                                    {
                                        BtnCalcular.ClientVisible = true;
                                    }
                                    HidAccionConfirmacion.Value = "ACTUALIZAR";
                                    LblMensajeConfirmacion.Text = "Se actualizará la anulación con los datos ingresados en el formulario. ¿Está seguro(a) que desea continuar?";
                                    PopCargaIndividual.ShowOnPageLoad = true;
                                }
                            }
                            break;
                        case "Eliminar":
                            Session["registrar_anulacion__idAnulacion"] = longIdAnulacion;
                            HidAccionConfirmacion.Value = "ELIMINAR";
                            LblMensajeConfirmacion.Text = "Esta acción eliminara la anulación de la base de producción. ¿Está seguro(a) que desea continuar?";
                            PopConfirmacion.ShowOnPageLoad = true;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReporte_Click(object sender, EventArgs e)
        {
            try
            {
                var DtblDatos = ((DataSet)Session["registrar_anulacion__bandeja"]).Tables[0];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(Server.MapPath("~/UI/templates/reporte-anulaciones.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Reporte")
                    {
                        DEWorksheet.Import(DtblDatos, false, 1, 0);
                        DEWorksheet.Range["A1:M" + (DtblDatos.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        DEWorksheet.Columns[5].NumberFormat = "dd/mm/yyyy";
                        DEWorksheet.Columns[6].NumberFormat = "dd/mm/yyyy";
                        DEWorksheet.Columns[7].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[8].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[10].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[2].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[3].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[4].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[5].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[6].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[7].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.DeleteCells(DEWorksheet.Range["N1:Z" + (DtblDatos.Rows.Count + 1)], DeleteMode.EntireColumn);
                        Session["DOWNLOAD"] = new OC_ARCHIVO()
                        {
                            BYTE_ARRAY = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                            CONTENT_TYPE = "application/vnd.ms-excel",
                            NOMBRE_ARCHIVO = "Anulaciones_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + "_CRSP.xlsx"
                        };
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}