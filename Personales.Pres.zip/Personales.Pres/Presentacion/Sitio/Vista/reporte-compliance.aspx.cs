﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class reporte_compliance : ControlUsuario
    {
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Limpiar();
            }
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        private void Limpiar()
        {
            try
            {
                BtsFechaHasta.Text = BtsFechaDesde.Text = string.Empty;
                BtnConsultar.ClientVisible = BtsFechaDesde.ClientEnabled = BtsFechaHasta.ClientEnabled = true;
                BtnLimpiar.ClientVisible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }
        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                var strFechaDesde = BtsFechaDesde.Text;
                var strFechaHasta = BtsFechaHasta.Text;
                
                if(!string.IsNullOrEmpty(strFechaDesde) && !string.IsNullOrEmpty(strFechaHasta))
                {
                    var dateFechaDesde = Convert.ToDateTime(strFechaDesde);
                    var dateFechaHasta = Convert.ToDateTime(strFechaHasta).AddDays(1).AddTicks(-1);
                    if (dateFechaHasta >= dateFechaDesde) 
                    {
                        var auxPeriodo = dateFechaDesde.ToString("dd-MM-yyyy") + (dateFechaHasta == dateFechaDesde ? string.Empty : "_" + dateFechaHasta.ToString("dd-MM-yyyy"));
                        var objDocumento = _cDocumentos.GetReporteCompliance(
                            "REP-022",
                            new List<Agente.ServicioDocumentos.CParameter>() {
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_DESDE", Value = dateFechaDesde },
                                new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_HASTA", Value = dateFechaHasta }
                            },
                            new OC_RESPONSE_FILE() { NombreArchivo = "Reporte_" + auxPeriodo, CarpetaSalida = _strPeriodoContable, BoolHistorico = false, FormatoSalida = "EXCEL" 
                            });
                        if(objDocumento.ByteArray != null)
                        {
                            var objArchivo = new OC_ARCHIVO() { BYTE_ARRAY = objDocumento.ByteArray, CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
                            Session["DOWNLOAD"] = objArchivo;
                            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                            BtnConsultar.ClientVisible = false;
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('"+ objDocumento.Mensaje +"', 'CONSULTA', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                        }
                    } 
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('El rango de fechas no es válido.', 'CONSULTA', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se deben elegir 2 fechas para realizar la consulta.', 'CONSULTA', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                BtnLimpiar.ClientVisible = true;
            } 
            catch(Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('" + ex.Message + ".', 'ERROR!', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
        }
    }
}