﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.Lib;
using Presentacion.Parametros;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;

namespace Presentacion.Sitio.Vista.Herramienta
{
    public partial class Alertas : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                Session["BASE_ALERTAS"] = ObtenerListaAlertasActivas();
                Session["ALERTA_USUARIOS"] = _cPersonales.ObtenerListaUsuariosActivos();
                GrvAlertas.DataBind();                
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected List<ALERTA> ObtenerListaAlertasActivas()
        {
            try
            {
                var listaAlertas = _cPersonales.ObtenerListaAlertas().Where(w => w.ALPBT_ACTIVO == true).ToList();
                foreach (var objAlerta in listaAlertas)
                {
                    if (!string.IsNullOrEmpty(objAlerta.ALPVC_ADJUNTOS))
                    {
                        string strArchivosAlerta = string.Empty;
                        var listaArchivosAlerta = JsonConvert.DeserializeObject<List<occ_correo_archivo_adjunto>>(objAlerta.ALPVC_ADJUNTOS);
                        foreach (var objArchivoAlerta in listaArchivosAlerta)
                        {
                            strArchivosAlerta += "[" + objArchivoAlerta.Nombre + "]";
                        }
                        objAlerta.ALPVC_ADJUNTOS = strArchivosAlerta;
                    }
                }
                return listaAlertas;
            }
            catch
            {
                throw;
            }
        }
        protected void GrvAlertas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["BASE_ALERTAS"] != null)
                    GrvAlertas.DataSource = (List<ALERTA>)Session["BASE_ALERTAS"];
                else
                    GrvAlertas.DataSource = null;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAlertas_HtmlEditFormCreated(object sender, DevExpress.Web.ASPxGridViewEditFormEventArgs e)
        {
            BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
            //BootstrapButton BtnGuardar = CurrentGrid.FindEditFormTemplateControl("BtnGuardar") as BootstrapButton;
            if (CurrentGrid.EditingRowVisibleIndex >= 0)
            {
                BootstrapTextBox TxtDestinatarios = CurrentGrid.FindEditFormTemplateControl("TxtDestinatarios") as BootstrapTextBox;
                TxtDestinatarios.Text = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "ALPVC_DESTINATARIOS")?.ToString();
                BootstrapTextBox TxtAsunto = CurrentGrid.FindEditFormTemplateControl("TxtAsunto") as BootstrapTextBox;
                TxtAsunto.Text = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "ALPVC_ASUNTO")?.ToString();
                BootstrapMemo TxtMensaje = CurrentGrid.FindEditFormTemplateControl("TxtMensaje") as BootstrapMemo;
                TxtMensaje.Text = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "ALPVC_MENSAJE")?.ToString();
                BootstrapDateEdit TxtFecha = CurrentGrid.FindEditFormTemplateControl("TxtFecha") as BootstrapDateEdit;
                TxtFecha.Text = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "ALPDT_FECHA")?.ToString();
            }
        }
        protected void GrvAlertas_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            try
            {
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                long longIdAlerta = Convert.ToInt64(e.Keys[GrvAlertas.KeyFieldName].ToString());
                string strEstado = ((List<ALERTA>)Session["BASE_ALERTAS"]).Where(w => w.ALPBI_ID_ALERTA == longIdAlerta).FirstOrDefault().ALPVC_ESTADO;
                if ((strEstado ?? string.Empty) != "ENVIADO")
                {
                    var objDireccionResult = _cPersonales.DesactivarAlerta(new ALERTA() { ALPBI_ID_ALERTA = longIdAlerta });
                    Session["BASE_ALERTAS"] = ObtenerListaAlertasActivas();
                    GrvAlertas.DataBind();
                }
                CurrentGrid.CancelEdit();
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                var listaAdjuntos = (List<OC_ARCHIVO>)Session["ALERTA_ADJUNTOS"];
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);                
                var objArchivo = new OC_ARCHIVO()
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
                listaAdjuntos.Add(objArchivo);
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                var listaUsuarios = (List<USUARIO>)Session["ALERTA_USUARIOS"];
                var listaDestinatarios = TxtDestinatarios.Text.Split(';').ToList();
                string strDestinatarios = string.Empty;
                foreach (string strUsuario in listaDestinatarios)
                {
                    var objUsuario = listaUsuarios.Where(w => w.USSVC_PATERNO + " " + w.USSVC_MATERNO + " " + w.USPVC_NOMBRES == strUsuario).FirstOrDefault();
                    if (objUsuario != null)
                        strDestinatarios += ((strDestinatarios != string.Empty) ? ";" : string.Empty) + objUsuario.USPVC_CORREO;
                }
                var objAlerta = new ALERTA()
                {
                    ALPVC_DESTINATARIOS = strDestinatarios,
                    ALPVC_ASUNTO = Regex.Replace(TxtAsunto.Text.Trim().ToUpper(), @"\r\n?|\n", string.Empty),
                    ALPVC_MENSAJE = Regex.Replace(TxtMensaje.Text.Trim().ToUpper(), @"\r\n?|\n", string.Empty),
                    ALPDT_FECHA = DateTime.ParseExact(TxtFecha.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    ALPVC_ESTADO = "PENDIENTE",
                    ALPVC_ADJUNTOS = string.Empty
                };
                var objAlertaResult = _cPersonales.AgregarAlerta(objAlerta);
                var listaAdjuntoAlerta = new List<occ_correo_archivo_adjunto>();
                var listaAdjuntos = (List<OC_ARCHIVO>)Session["ALERTA_ADJUNTOS"];
                int intIndice = 1;
                foreach (var objArchivo in listaAdjuntos)
                {
                    string strRutaAdjunto = CParametros.RutaAdjuntos + "ALERTA-" + objAlertaResult.ALPBI_ID_ALERTA + "-" + intIndice + objArchivo.EXTENSION;
                    File.WriteAllBytes(strRutaAdjunto, objArchivo.BYTE_ARRAY);
                    listaAdjuntoAlerta.Add(new occ_correo_archivo_adjunto() {
                        FlagBytes = false,
                        Ruta = strRutaAdjunto,
                        Nombre = objArchivo.NOMBRE_ARCHIVO
                    });
                    intIndice++;
                }
                var objAdjuntosAlertaResult = _cPersonales.ActualizarAdjuntoAlerta(objAlertaResult.ALPBI_ID_ALERTA, listaAdjuntoAlerta);
                Session["BASE_ALERTAS"] = ObtenerListaAlertasActivas();
                GrvAlertas.DataBind();
                PopNuevaAlerta.ShowOnPageLoad = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnNuevaAlerta_Click(object sender, EventArgs e)
        {
            try
            {
                Session["ALERTA_ADJUNTOS"] = new List<OC_ARCHIVO>();
                var listaUsuarios = (List<USUARIO>)Session["ALERTA_USUARIOS"];
                BootstrapListBox LstDestinatarios = (BootstrapListBox)TxtDestinatarios.FindControl("LstDestinatarios");
                LstDestinatarios.Items.Clear();
                LstDestinatarios.Items.Add(new BootstrapListEditItem() { Text = "(Seleccionar todo)" });
                foreach (var objUsuario in listaUsuarios.OrderBy(o => o.USSVC_PATERNO))
                {
                    LstDestinatarios.Items.Add(new BootstrapListEditItem()
                    {
                        Value = objUsuario.USPVC_CORREO,
                        Text = objUsuario.USSVC_PATERNO + " " + objUsuario.USSVC_MATERNO + " " + objUsuario.USPVC_NOMBRES
                    });
                }
                TxtDestinatarios.Text = TxtAsunto.Text = TxtMensaje.Text = TxtFecha.Text = null;
                PopNuevaAlerta.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}