﻿using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Lib;
using DevExpress.Web.Bootstrap;
using System.Globalization;

namespace Presentacion.Sitio.Vista
{
    public partial class poliza_renovacion_ampliacion : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        private string _strPeriodoContable;
        protected user_control.nivel_cobertura ctrlNivelCobertura;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                BtnCancelarPoliza_Click(null, null);
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
            if (Session["nivel_cobertura__poliza"] != null)
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                CargarNiveles(objPoliza);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
        }
        protected void BtnContinuar1_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvPolizas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["poliza_renovacion_ampliacion__bandeja"] == null)
                    Session["poliza_renovacion_ampliacion__bandeja"] = new List<OCC_Bandeja_Renovacion_Ampliacion>();
                GrvPolizas.DataSource = ((List<OCC_Bandeja_Renovacion_Ampliacion>)Session["poliza_renovacion_ampliacion__bandeja"]).OrderBy(o => o.FinVigencia);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected List<OCC_Broker> ListaBrokers()
        {
            try
            {
                var listaBrokers = _cPersonales.ListaBroker();
                listaBrokers.Add(new OCC_Broker() { IdBroker = 0, RazonSocial = "NO APLICA", CodigoAPS = string.Empty, Nit = string.Empty });
                return listaBrokers.OrderBy(o => o.CodigoAPS).ToList();
            }
            catch
            {
                throw;
            }
        }
        protected void BtnVerPoliza_Click(object sender, EventArgs e)
        {
            try
            {
                string strTipo = HidParametro.Get("Tipo").ToString();
                string strIdPoliza = HidParametro.Get("IdPoliza").ToString();                
                PnlBandeja.Visible = false;
                PnlPoliza.Visible = true;
                var listaPolizas = (List<OCC_Bandeja_Renovacion_Ampliacion>)Session["poliza_renovacion_ampliacion__bandeja"];
                long longIdTomador = listaPolizas.Where(w => w.IdPoliza == strIdPoliza).First().IdTomador;
                var objPoliza = _cPersonales.ObtenerPolizaPorId(longIdTomador, strIdPoliza);
                objPoliza.IdPoliza = objPoliza.NumeroPoliza + "-" + NuevaVersion(objPoliza.IdPoliza.Substring(objPoliza.IdPoliza.Length - 2, 2));
                CmbBroker.DataSource = ListaBrokers();
                CmbBroker.ValueField = "IdBroker";
                CmbBroker.TextField = "RazonSocial";
                CmbBroker.DataBind();
                CmbDepartamento.DataSource = _cPersonales.GetListLexicoPorTablaYTema("PARAMETRO", "DEPARTAMENTO").OrderBy(o => o.LEPVC_VALOR);
                CmbDepartamento.ValueField = "LEPVC_VALOR";
                CmbDepartamento.TextField = "LEPVC_DESC_LARGA";
                CmbDepartamento.DataBind();                
                TxtProducto.Text = objPoliza.IdProducto + " - " + objPoliza.NombreProducto;
                TxtIdPoliza.Text = objPoliza.IdPoliza;
                TxtNumeroPoliza.Text = objPoliza.NumeroPoliza;
                TxtNombreTomador.Text = objPoliza.NombreTomador;
                if (objPoliza.IdBroker == null)
                    CmbBroker.Items.FindByValue("0").Selected = true;
                else if (CmbBroker.Items.FindByValue(objPoliza.IdBroker.ToString()) != null)
                    CmbBroker.Items.FindByValue(objPoliza.IdBroker.ToString()).Selected = true;
                DateTime dtNuevoInicioVigencia = objPoliza.FinVigencia.AddDays((objPoliza.InicioVigencia.ToString("HH:mm") == "00:00") ? 1 : 0);
                string strFechaInicioVigencia = dtNuevoInicioVigencia.ToString("dd/MM/yyyy") + " " + objPoliza.InicioVigencia.ToString("HH:mm:ss");
                string strHoraInicio = objPoliza.InicioVigencia.ToString("HH:mm");
                objPoliza.InicioVigencia = DateTime.ParseExact(strFechaInicioVigencia, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                TxtInicioVigencia.Value = dtNuevoInicioVigencia;
                TxtHoraInicio.Value = objPoliza.InicioVigencia;
                TxtFinVigencia.Value = null;
                TxtFinVigencia.MinDate = dtNuevoInicioVigencia;                
                TxtHoraFin.Value = objPoliza.FinVigencia;
                if (CmbMoneda.Items.FindByValue(objPoliza.Moneda) != null)
                    CmbMoneda.Items.FindByValue(objPoliza.Moneda).Selected = true;
                if (CmbTipoConciliacion.Items.FindByValue(objPoliza.TipoConciliacion) != null)
                    CmbTipoConciliacion.Items.FindByValue(objPoliza.TipoConciliacion).Selected = true;
                CmbProduccionMesVencido.Value = (objPoliza.FlagProduccionMesVencido) ? "SI" : "NO";
                TxtModalidadPago.Text = objPoliza.ModalidadPago;
                TxtTipoPago.Text = objPoliza.TipoPago;
                if (objPoliza.DiasAvisoSiniestro > 0)
                    TxtDiasAvisoSiniestro.Value = objPoliza.DiasAvisoSiniestro;
                if (CmbDepartamento.Items.FindByValue(objPoliza.IdDepartamento) != null)
                    CmbDepartamento.Items.FindByValue(objPoliza.IdDepartamento).Selected = true;
                CmbExtraVigencia.Value = (objPoliza.FlagExtraVigencia) ? "SI" : "NO";
                TxtInicioVigencia.ClientEnabled = false;
                TxtHoraInicio.ClientEnabled = false;
                TxtHoraFin.ClientEnabled = false;
                CmbTipoConciliacion.ClientEnabled = false;
                CmbProduccionMesVencido.ClientEnabled = false;
                CmbExtraVigencia.ClientEnabled = false;
                CmbBroker.ClientEnabled = 
                CmbMoneda.ClientEnabled = 
                TxtModalidadPago.ClientEnabled = 
                TxtTipoPago.ClientEnabled = 
                TxtDiasAvisoSiniestro.ClientEnabled = 
                CmbDepartamento.ClientEnabled = true;
                if (strTipo == "Ampliar")
                {
                    LblTipoRegistro.Text = "AMPLIACIÓN";
                    objPoliza.TipoEmision = "AMPLIACIÓN";
                    CmbBroker.ClientEnabled = false;                    
                    CmbMoneda.ClientEnabled = false;                                        
                    if (!string.IsNullOrEmpty(TxtModalidadPago.Text))
                        TxtModalidadPago.ClientEnabled = false;
                    if (!string.IsNullOrEmpty(TxtTipoPago.Text))
                        TxtTipoPago.ClientEnabled = false;
                    if (!string.IsNullOrEmpty(TxtDiasAvisoSiniestro.Text))
                        TxtDiasAvisoSiniestro.ClientEnabled = false;
                    CmbDepartamento.ClientEnabled = false;                    
                    BtnAgregarNivelBlanco.ClientVisible = false;
                    BtnAgregarNivelCopia.ClientVisible = false;
                    BtnEliminarNivel.ClientVisible = false;
                    TxtFinVigencia.MaxDate = dtNuevoInicioVigencia.AddMonths(6).AddDays((strHoraInicio == "00:00") ? -1 : 0);
                }
                if (strTipo == "Renovar")
                {
                    LblTipoRegistro.Text = "RENOVACIÓN";
                    objPoliza.TipoEmision = "RENOVACIÓN";

                    BtnAgregarNivelBlanco.ClientVisible = true;
                    BtnAgregarNivelCopia.ClientVisible = (objPoliza.ListaNiveles.Count > 0) ? true : false;
                    BtnEliminarNivel.ClientVisible = true;
                    TxtFinVigencia.MaxDate = dtNuevoInicioVigencia.AddMonths(12).AddDays((strHoraInicio == "00:00") ? -1 : 0);
                    TxtFinVigencia.Value = TxtFinVigencia.MaxDate;
                }
                Session["nivel_cobertura__poliza"] = objPoliza;
                CargarNiveles(objPoliza);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CargarNiveles(OCC_Poliza objPoliza)
        {
            try
            {
                foreach (var objNivel in objPoliza.ListaNiveles.OrderBy(o => o.NumeroNivel))
                {
                    var BflNivel = (user_control.nivel_cobertura)PnlNiveles.FindControl("Nivel" + objNivel.NumeroNivel);
                    if (BflNivel == null)
                    {
                        ctrlNivelCobertura = (user_control.nivel_cobertura)LoadControl("~/Sitio/Vista/user-control/nivel-cobertura.ascx");
                        ctrlNivelCobertura.ID = "Nivel" + objNivel.NumeroNivel;
                        ctrlNivelCobertura.IniciarControl(objPoliza, objNivel.NumeroNivel);
                        PnlNiveles.Controls.Add(ctrlNivelCobertura);
                    }
                    else
                        BflNivel.IniciarControl(objPoliza, objNivel.NumeroNivel);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAgregarNivel_Click(object sender, EventArgs e)
        {
            try
            {
                string strTipo = ((BootstrapButton)sender).CommandName;
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                int intNumeroNivel = (objPoliza.ListaNiveles.Count > 0) ? objPoliza.ListaNiveles.Max(m => m.NumeroNivel) : 0;
                var listaNiveles = objPoliza.ListaNiveles;
                if (strTipo == "BLANCO")
                    listaNiveles.Add(new OCC_Nivel() {
                        NumeroNivel = intNumeroNivel + 1,
                        EdadMinimaIngreso = 0,
                        EdadMaximaIngreso = 0,
                        EdadMaximaPermanencia = 0,
                        ListaCoberturas = new List<OCC_Cobertura>(),
                        ListaParametros = new List<OCC_Parametro>()
                    });
                if (strTipo == "COPIA")
                {
                    var objNivelCopia = objPoliza.ListaNiveles.Where(w => w.NumeroNivel == intNumeroNivel).First();
                    listaNiveles.Add(new OCC_Nivel()
                    {
                        NumeroNivel = intNumeroNivel + 1,
                        EdadMinimaIngreso = objNivelCopia.EdadMinimaIngreso,
                        EdadMaximaIngreso = objNivelCopia.EdadMaximaIngreso,
                        EdadMaximaPermanencia = objNivelCopia.EdadMaximaPermanencia,
                        ListaCoberturas = objNivelCopia.ListaCoberturas,
                        ListaParametros = objNivelCopia.ListaParametros
                    });
                }
                objPoliza.ListaNiveles = listaNiveles;
                ctrlNivelCobertura = (user_control.nivel_cobertura)LoadControl("~/Sitio/Vista/user-control/nivel-cobertura.ascx");
                ctrlNivelCobertura.ID = "Nivel" + (intNumeroNivel + 1);                
                ctrlNivelCobertura.IniciarControl(objPoliza, intNumeroNivel + 1);
                PnlNiveles.Controls.Add(ctrlNivelCobertura);
                Session["nivel_cobertura__poliza"] = objPoliza;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnEliminarNivel_Click(object sender, EventArgs e)
        {
            try
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                int intNumeroNivel = (objPoliza.ListaNiveles.Count > 0) ? objPoliza.ListaNiveles.Max(m => m.NumeroNivel) : 0;
                var objNivelEliminar = objPoliza.ListaNiveles.Find(f => f.NumeroNivel == intNumeroNivel);
                if (objNivelEliminar != null)
                    objPoliza.ListaNiveles.Remove(objNivelEliminar);                
                ctrlNivelCobertura = (user_control.nivel_cobertura)PnlNiveles.FindControl("Nivel" + intNumeroNivel);
                PnlNiveles.Controls.Remove(ctrlNivelCobertura);
                BtnAgregarNivelCopia.ClientVisible = (objPoliza.ListaNiveles.Count > 0) ? true : false;
                Session["nivel_cobertura__poliza"] = objPoliza;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void ModificarCoberturas(int intNumeroNivel)
        {
            try
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                var objNivel = objPoliza.ListaNiveles.Find(f => f.NumeroNivel == intNumeroNivel);
                GrvEditarCoberturas.DataSource = objNivel.ListaCoberturas;
                GrvEditarCoberturas.DataBind();
                Session["nivel_cobertura__nivel"] = objNivel;
                PopModificarCoberturas.HeaderText = "NIVEL " + intNumeroNivel.ToString() + " - COBERTURAS REGISTRADAS";
                PopModificarCoberturas.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvEditarCoberturas_HtmlEditFormCreated(object sender, ASPxGridViewEditFormEventArgs e)
        {
            try
            {
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                BootstrapButton BtnCoberturaGuardar = CurrentGrid.FindEditFormTemplateControl("BtnCoberturaGuardar") as BootstrapButton;
                BtnCoberturaGuardar.Text = (CurrentGrid.IsNewRowEditing) ? "Agregar" : "Actualizar";
                var objNivel = (OCC_Nivel)Session["nivel_cobertura__nivel"];
                string strCodigo = (CurrentGrid.EditingRowVisibleIndex >= 0) ? CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "Codigo")?.ToString() : string.Empty;
                var listaCoberturas = _cPersonales.GetListLexicoPorTablaYTema("PARAMETRO", "COBERTURA");
                var objCoberturaEdicion = listaCoberturas.Find(f => f.LEPVC_VALOR == strCodigo);
                foreach (var objCobertura in objNivel.ListaCoberturas)
                    if (listaCoberturas.Exists(s => s.LEPVC_VALOR == objCobertura.Codigo))
                        listaCoberturas.Remove(listaCoberturas.Find(f => f.LEPVC_VALOR == objCobertura.Codigo));
                if (objCoberturaEdicion != null)
                    listaCoberturas.Add(objCoberturaEdicion);
                BootstrapComboBox CmbCoberuraNombre = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraNombre") as BootstrapComboBox;
                CmbCoberuraNombre.DataSource = listaCoberturas.OrderBy(o => o.LEPVC_DESC_LARGA).ToList();
                CmbCoberuraNombre.ValueField = "LEPVC_VALOR";
                CmbCoberuraNombre.TextField = "LEPVC_DESC_LARGA";
                CmbCoberuraNombre.DataBind();
                //edicion
                if (CurrentGrid.EditingRowVisibleIndex >= 0)
                {                    
                    if (CmbCoberuraNombre.Items.FindByValue(strCodigo) != null)
                        CmbCoberuraNombre.Items.FindByValue(strCodigo).Selected = true;
                    BootstrapComboBox CmbCoberuraTipo = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraTipo") as BootstrapComboBox;
                    CmbCoberuraTipo.SelectedItem = CmbCoberuraTipo.Items.FindByValue(CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "Tipo")?.ToString());
                    BootstrapComboBox CmbCoberturaMoneda = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaMoneda") as BootstrapComboBox;
                    CmbCoberturaMoneda.SelectedItem = CmbCoberturaMoneda.Items.FindByValue(CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "Moneda")?.ToString());
                    BootstrapSpinEdit TxtCoberturaSumaAsegurada = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaSumaAsegurada") as BootstrapSpinEdit;
                    TxtCoberturaSumaAsegurada.Value = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "SumaAsegurada")?.ToString();
                    BootstrapSpinEdit TxtCoberturaTasaComercial = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaTasaComercial") as BootstrapSpinEdit;
                    TxtCoberturaTasaComercial.Value = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "TasaComercial")?.ToString();
                    bool FlagCoberturaPrincipal = Convert.ToBoolean(CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "FlagCoberturaPrincipal")?.ToString());
                    BootstrapComboBox CmbCoberturaPrincipal = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaPrincipal") as BootstrapComboBox;
                    CmbCoberturaPrincipal.SelectedItem = CmbCoberturaPrincipal.Items.FindByValue((FlagCoberturaPrincipal) ? "SI" : "NO");
                    BootstrapSpinEdit TxtCoberturaDiasCarencia = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaDiasCarencia") as BootstrapSpinEdit;
                    TxtCoberturaDiasCarencia.Value = CurrentGrid.GetRowValues(CurrentGrid.EditingRowVisibleIndex, "DiasCarencia")?.ToString();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvEditarCoberturas_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            try
            {
                var objNivel = (OCC_Nivel)Session["nivel_cobertura__nivel"];                
                int intNumeroCobertura = Convert.ToInt32(e.Keys[GrvEditarCoberturas.KeyFieldName].ToString());
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                BootstrapComboBox CmbCoberuraNombre = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraNombre") as BootstrapComboBox;
                BootstrapComboBox CmbCoberuraTipo = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraTipo") as BootstrapComboBox;
                BootstrapComboBox CmbCoberturaMoneda = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaMoneda") as BootstrapComboBox;
                BootstrapSpinEdit TxtCoberturaSumaAsegurada = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaSumaAsegurada") as BootstrapSpinEdit;
                BootstrapSpinEdit TxtCoberturaTasaComercial = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaTasaComercial") as BootstrapSpinEdit;
                BootstrapComboBox CmbCoberturaPrincipal = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaPrincipal") as BootstrapComboBox;
                BootstrapSpinEdit TxtCoberturaDiasCarencia = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaDiasCarencia") as BootstrapSpinEdit;
                var objCoberturaActualizada = new OCC_Cobertura()
                {
                    NumeroCobertura = intNumeroCobertura + 1,
                    Codigo = CmbCoberuraNombre.SelectedItem.Value.ToString(),
                    Nombre = CmbCoberuraNombre.SelectedItem.Text.Trim(),
                    Tipo = CmbCoberuraTipo.SelectedItem.Value.ToString(),
                    Moneda = CmbCoberturaMoneda.SelectedItem.Value.ToString(),
                    SumaAsegurada = Convert.ToDecimal(TxtCoberturaSumaAsegurada.Text.Trim()),
                    FlagCoberturaPrincipal = (CmbCoberturaPrincipal.SelectedItem.Value.ToString() == "SI") ? true : false,
                    DiasCarencia = Convert.ToInt32(TxtCoberturaDiasCarencia.Value ?? 0),
                    TasaComercial = Convert.ToDecimal(TxtCoberturaTasaComercial.Text.Trim()),
                    TasaReaseguro = 0,
                    IdCoberturaReaseguro = null
                };
                var listaCoberturas = new List<OCC_Cobertura>();
                foreach (var objCobertura in objNivel.ListaCoberturas.OrderBy(o => o.NumeroCobertura))
                {
                    if (objCobertura.NumeroCobertura == intNumeroCobertura)
                        listaCoberturas.Add(objCoberturaActualizada);
                    else
                        listaCoberturas.Add(objCobertura);
                }
                objNivel.ListaCoberturas = listaCoberturas;
                Session["nivel_cobertura__nivel"] = objNivel;
                GrvEditarCoberturas.DataSource = objNivel.ListaCoberturas;
                GrvEditarCoberturas.DataBind();
                CurrentGrid.CancelEdit();
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvEditarCoberturas_RowInserting(object sender, DevExpress.Web.Data.ASPxDataInsertingEventArgs e)
        {
            try
            {
                var objNivel = (OCC_Nivel)Session["nivel_cobertura__nivel"];
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                BootstrapComboBox CmbCoberuraNombre = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraNombre") as BootstrapComboBox;                
                BootstrapComboBox CmbCoberuraTipo = CurrentGrid.FindEditFormTemplateControl("CmbCoberuraTipo") as BootstrapComboBox;
                BootstrapComboBox CmbCoberturaMoneda = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaMoneda") as BootstrapComboBox;
                BootstrapSpinEdit TxtCoberturaSumaAsegurada = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaSumaAsegurada") as BootstrapSpinEdit;
                BootstrapSpinEdit TxtCoberturaTasaComercial = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaTasaComercial") as BootstrapSpinEdit;
                BootstrapComboBox CmbCoberturaPrincipal = CurrentGrid.FindEditFormTemplateControl("CmbCoberturaPrincipal") as BootstrapComboBox;
                BootstrapSpinEdit TxtCoberturaDiasCarencia = CurrentGrid.FindEditFormTemplateControl("TxtCoberturaDiasCarencia") as BootstrapSpinEdit;
                var listaCoberturas = objNivel.ListaCoberturas;
                int intNumeroCobertura = (listaCoberturas.Count > 0) ? listaCoberturas.Max(m => m.NumeroCobertura) : 0;
                listaCoberturas.Add(new OCC_Cobertura()
                {
                    NumeroCobertura = intNumeroCobertura + 1,
                    Codigo = CmbCoberuraNombre.SelectedItem.Value.ToString(),
                    Nombre = CmbCoberuraNombre.SelectedItem.Text.Trim(),
                    Tipo = CmbCoberuraTipo.SelectedItem.Value.ToString(),
                    Moneda = CmbCoberturaMoneda.SelectedItem.Value.ToString(),
                    SumaAsegurada = Convert.ToDecimal(TxtCoberturaSumaAsegurada.Text.Trim()),
                    FlagCoberturaPrincipal = (CmbCoberturaPrincipal.SelectedItem.Value.ToString() == "SI") ? true : false,
                    DiasCarencia = Convert.ToInt32(TxtCoberturaDiasCarencia.Value ?? 0),
                    TasaComercial = Convert.ToDecimal(TxtCoberturaTasaComercial.Text.Trim()),
                    TasaReaseguro = 0,
                    IdCoberturaReaseguro = null
                });
                objNivel.ListaCoberturas = listaCoberturas;
                Session["nivel_cobertura__nivel"] = objNivel;
                GrvEditarCoberturas.DataSource = objNivel.ListaCoberturas;
                GrvEditarCoberturas.DataBind();
                CurrentGrid.CancelEdit();
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvEditarCoberturas_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            try
            {
                BootstrapGridView CurrentGrid = (BootstrapGridView)sender;
                var objNivel = (OCC_Nivel)Session["nivel_cobertura__nivel"];
                int intNumeroCobertura = Convert.ToInt32(e.Keys[GrvEditarCoberturas.KeyFieldName].ToString());
                var listaCoberturas = objNivel.ListaCoberturas;
                var objCobertura = listaCoberturas.Find(f => f.NumeroCobertura == intNumeroCobertura);
                if (objCobertura != null)
                    listaCoberturas.Remove(objCobertura);
                objNivel.ListaCoberturas = listaCoberturas;
                Session["nivel_cobertura__nivel"] = objNivel;
                GrvEditarCoberturas.DataSource = objNivel.ListaCoberturas;
                GrvEditarCoberturas.DataBind();
                CurrentGrid.CancelEdit();
                e.Cancel = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCerrarModificarCoberturas_Click(object sender, EventArgs e)
        {
            try
            {
                GrvEditarCoberturas.CancelEdit();
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                var objNivel = (OCC_Nivel)Session["nivel_cobertura__nivel"];
                var objNivelEliminar = objPoliza.ListaNiveles.Find(f => f.NumeroNivel == objNivel.NumeroNivel);
                objPoliza.ListaNiveles.Remove(objNivelEliminar);
                objPoliza.ListaNiveles.Add(objNivel);
                Session["nivel_cobertura__poliza"] = objPoliza;
                Session.Remove("nivel_cobertura__nivel");
                PopModificarCoberturas.ShowOnPageLoad = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCancelarPoliza_Click(object sender, EventArgs e)
        {
            try
            {
                PnlNiveles.Controls.Clear();
                Session.Remove("nivel_cobertura__poliza");
                Session["poliza_renovacion_ampliacion__bandeja"] = _cPersonales.ListaPolizasRenovacionAmpliacion();
                GrvPolizas.DataBind();
                PnlBandeja.Visible = true;
                PnlPoliza.Visible = false;                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistrarPoliza_Click(object sender, EventArgs e)
        {
            try
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                bool boolValidacionCoberturas = false;
                foreach (var objNivel in objPoliza.ListaNiveles)
                {
                    if (objNivel.ListaCoberturas.Count == 0) { 
                        boolValidacionCoberturas = true;
                        break;
                    }
                }
                if (boolValidacionCoberturas)
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Existen niveles donde no se registraron coberturas, por favor verifique que exista al menos una cobertura por nivel.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                else
                    PopConfirmarcion.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                string strFechaFinVigencia = TxtFinVigencia.Text + " " + objPoliza.FinVigencia.ToString("HH:mm:ss");
                objPoliza.FinVigencia = DateTime.ParseExact(strFechaFinVigencia, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                objPoliza.ModalidadPago = TxtModalidadPago.Text.Trim().ToUpper();
                objPoliza.TipoPago = TxtTipoPago.Text.Trim().ToUpper();
                objPoliza.DiasAvisoSiniestro = Convert.ToInt32(TxtDiasAvisoSiniestro.Value);
                var listaNiveles = new List<OCC_Nivel>();
                foreach (var objNivel in objPoliza.ListaNiveles.OrderBy(o => o.NumeroNivel))
                {
                    var BflNivel = (user_control.nivel_cobertura)PnlNiveles.FindControl("Nivel" + objNivel.NumeroNivel);
                    listaNiveles.Add(BflNivel.ActualizarDatos(objNivel, objNivel.NumeroNivel));
                }
                objPoliza.ListaNiveles = listaNiveles;
                var result = _cPersonales.RegistrarRenovacionOAmpliacion(objPoliza);
                if (result != null)
                {
                    BtnCancelarPoliza_Click(null, null);
                    PopConfirmarcion.ShowOnPageLoad = false;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El registro de la póliza ha sido completado con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se ha presentado un error al momento de registrar la póliza.', 'ERROR', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CmbBroker_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                foreach (var objNivel in objPoliza.ListaNiveles)
                {
                    if (CmbBroker.SelectedItem.Text == "NO APLICA")
                    {
                        objNivel.ListaParametros.Where(w => w.Tipo == "CB").First().Aplicacion = "NA";
                        objNivel.ListaParametros.Where(w => w.Tipo == "CB").First().Factor = 0;
                    }
                    else
                    {
                        objNivel.ListaParametros.Where(w => w.Tipo == "CB").First().Aplicacion = string.Empty;
                        objNivel.ListaParametros.Where(w => w.Tipo == "CB").First().Factor = 0;
                    }
                }              
                Session["nivel_cobertura__poliza"] = objPoliza;
                CargarNiveles(objPoliza);                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        private string NuevaVersion(string strVersionActual)
        {
            try
            {
                string strVersionNueva = string.Empty;
                int intVersionActual = 0;
                if (int.TryParse(strVersionActual, out intVersionActual))
                {
                    strVersionNueva = "00" + (intVersionActual + 1).ToString();
                    strVersionNueva = strVersionNueva.Substring(strVersionNueva.Length - 2, 2);
                }
                else
                {
                    if (strVersionActual.Substring(1, 1) == "9")
                    {
                        switch (strVersionActual.Substring(0, 1))
                        {
                            case "A": strVersionNueva = "B"; break;
                            case "B": strVersionNueva = "C"; break;
                            case "C": strVersionNueva = "D"; break;
                            case "D": strVersionNueva = "E"; break;
                            case "E": strVersionNueva = "F"; break;
                            case "F": strVersionNueva = "G"; break;
                            case "G": strVersionNueva = "H"; break;
                            case "H": strVersionNueva = "I"; break;
                            case "I": strVersionNueva = "J"; break;
                            case "J": strVersionNueva = "K"; break;
                            case "K": strVersionNueva = "L"; break;
                            case "L": strVersionNueva = "M"; break;
                            case "M": strVersionNueva = "N"; break;
                            case "N": strVersionNueva = "O"; break;
                            case "O": strVersionNueva = "P"; break;
                            case "P": strVersionNueva = "Q"; break;
                            case "Q": strVersionNueva = "R"; break;
                            case "R": strVersionNueva = "S"; break;
                            case "S": strVersionNueva = "T"; break;
                            case "T": strVersionNueva = "U"; break;
                            case "U": strVersionNueva = "V"; break;
                            case "V": strVersionNueva = "W"; break;
                            case "W": strVersionNueva = "X"; break;
                            case "X": strVersionNueva = "Y"; break;
                            case "Y": strVersionNueva = "Z"; break;
                        }
                        if (string.IsNullOrEmpty(strVersionNueva))
                        {
                            throw new Exception("Se ha alcanzado el limite de versiones para este tipo de pólizas.");
                        }
                        strVersionNueva += "0";
                    }
                    else
                    {
                        strVersionNueva = strVersionActual.Substring(0, 1) + (Convert.ToInt32(strVersionActual.Substring(1, 1)) + 1).ToString();
                    }
                }
                return strVersionNueva;
            }
            catch
            {
                throw;
            }
        }
    }
}
