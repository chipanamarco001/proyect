﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using System;
using System.Linq;

namespace Presentacion.Sitio.Vista.user_control
{
    public partial class nivel_cobertura : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        public void IniciarControl(OCC_Poliza objPoliza, int intNumeroNivel)
        {
            try
            {
                BflNivel.FindItemOrGroupByName("BfgContenido").Caption = "NIVEL " + intNumeroNivel.ToString();
                TxtEdadMinIngreso.ClientEnabled =
                TxtEdadMaxIngreso.ClientEnabled =
                TxtEdadMaxPermanencia.ClientEnabled =
                TxtFactorPrimaAdicional.ClientEnabled =
                TxtFactorComisionCobranza.ClientEnabled =
                CmbAplicacionComisionCobranza.ClientEnabled =
                TxtFactorComisionBroker.ClientEnabled =
                CmbAplicacionComisionBroker.ClientEnabled =
                BtnModificarCoberturas.ClientVisible = true;
                var objNivel = objPoliza.ListaNiveles.Where(w => w.NumeroNivel == intNumeroNivel). First();
                HidNumeroNivel.Value = objNivel.NumeroNivel.ToString();
                if (objNivel.EdadMinimaIngreso > 0 || (objNivel.EdadMinimaIngreso == 0 && objNivel.EdadMaximaIngreso > 0))
                    TxtEdadMinIngreso.Value = objNivel.EdadMinimaIngreso;
                if (objNivel.EdadMaximaIngreso > 0)
                    TxtEdadMaxIngreso.Value = objNivel.EdadMaximaIngreso;
                if (objNivel.EdadMaximaPermanencia > 0)
                    TxtEdadMaxPermanencia.Value = objNivel.EdadMaximaPermanencia;
                var listaParametros = objNivel.ListaParametros;
                var objParametroPA = listaParametros.Where(w => w.Tipo == "PA").FirstOrDefault();                
                TxtFactorPrimaAdicional.Value = (objParametroPA == null) ? 0 : objParametroPA.Factor;
                var objParametroCC = listaParametros.Where(w => w.Tipo == "CC").FirstOrDefault();
                TxtFactorComisionCobranza.ClientInstanceName = TxtFactorComisionCobranza.ID + objNivel.NumeroNivel.ToString();
                CmbAplicacionComisionCobranza.ClientSideEvents.SelectedIndexChanged = "function(s, e) { if (s.GetValue() == 'NA') { " + TxtFactorComisionCobranza.ClientInstanceName + ".SetEnabled(false); " + TxtFactorComisionCobranza.ClientInstanceName + ".SetValue(0.00); } else { " + TxtFactorComisionCobranza.ClientInstanceName + ".SetEnabled(true); " + TxtFactorComisionCobranza.ClientInstanceName + ".SetValue(null); } }";
                if (objParametroCC != null)
                {                                        
                    CmbAplicacionComisionCobranza.Value = objParametroCC.Aplicacion;
                    TxtFactorComisionCobranza.Value = (objParametroCC.Aplicacion == "NA") ? 0 : objParametroCC.Factor;
                    TxtFactorComisionCobranza.ClientEnabled = (objParametroCC.Aplicacion == "NA") ? false : true;
                }
                var objParametroCB = listaParametros.Where(w => w.Tipo == "CB").FirstOrDefault();
                TxtFactorComisionBroker.ClientInstanceName = TxtFactorComisionBroker.ID + objNivel.NumeroNivel.ToString();
                CmbAplicacionComisionBroker.ClientSideEvents.SelectedIndexChanged = "function(s, e) { if (s.GetValue() == 'NA') { " + TxtFactorComisionBroker.ClientInstanceName + ".SetEnabled(false); " + TxtFactorComisionBroker.ClientInstanceName + ".SetValue(0.00); } else { " + TxtFactorComisionBroker.ClientInstanceName + ".SetEnabled(true); " + TxtFactorComisionBroker.ClientInstanceName + ".SetValue(null); } }";
                if (objParametroCB != null)
                {                    
                    CmbAplicacionComisionBroker.Value = objParametroCB.Aplicacion;
                    TxtFactorComisionBroker.Value = (objParametroCB.Aplicacion == "NA") ? 0 : objParametroCB.Factor;
                    TxtFactorComisionBroker.ClientEnabled = (objParametroCB.Aplicacion == "NA") ? false : true;
                }
                GrvCoberturas.ClientInstanceName = GrvCoberturas.ID + intNumeroNivel;
                GrvCoberturas.DataBind();
                ///bloquedo de campos si corresponde
                if (objPoliza.TipoEmision == "AMPLIACIÓN")
                {
                    if (!string.IsNullOrEmpty(TxtEdadMinIngreso.Text))
                        TxtEdadMinIngreso.ClientEnabled = false;
                    if (!string.IsNullOrEmpty(TxtEdadMaxIngreso.Text))
                        TxtEdadMaxIngreso.ClientEnabled = false;
                    if (!string.IsNullOrEmpty(TxtEdadMaxPermanencia.Text))
                        TxtEdadMaxPermanencia.ClientEnabled = false;
                    TxtFactorPrimaAdicional.ClientEnabled = false;
                    TxtFactorComisionCobranza.ClientEnabled = false;
                    CmbAplicacionComisionCobranza.ClientEnabled = false;
                    TxtFactorComisionBroker.ClientEnabled = false;
                    CmbAplicacionComisionBroker.ClientEnabled = false;
                    if (objPoliza.IdBroker == null)
                    {
                        BflNivel.FindItemOrGroupByName("BliCBFactor").ClientVisible = false;
                        BflNivel.FindItemOrGroupByName("BliCBTipo").ClientVisible = false;
                    }
                    if (objPoliza.TipoEmision == "AMPLIACIÓN" && objPoliza.ListaNiveles.Find(f => f.NumeroNivel == intNumeroNivel).NumeroCoberturas > 0)
                        BtnModificarCoberturas.ClientVisible = false;
                }                
            }
            catch (Exception ex)
            {
                throw new Exception("UserControl__nivel_cobertura", ex);
            }
        }
        public OCC_Nivel ActualizarDatos(OCC_Nivel objNivel, int intNumeroNivel)
        {
            try
            {
                objNivel.EdadMinimaIngreso = Convert.ToInt32(TxtEdadMinIngreso.Value);
                objNivel.EdadMaximaIngreso = Convert.ToInt32(TxtEdadMaxIngreso.Value);
                objNivel.EdadMaximaPermanencia = Convert.ToInt32(TxtEdadMaxPermanencia.Value);
                foreach (var objParametro in objNivel.ListaParametros)
                {
                    switch (objParametro.Tipo)
                    {
                        case "PA":
                            objParametro.Factor = (decimal)TxtFactorPrimaAdicional.Value;
                            break;
                        case "CC":
                            objParametro.Factor = (decimal)TxtFactorComisionCobranza.Value;
                            objParametro.Aplicacion = CmbAplicacionComisionCobranza.SelectedItem.Value.ToString();
                            break;
                        case "CB":
                            objParametro.Factor = (decimal)TxtFactorComisionBroker.Value;
                            objParametro.Aplicacion = CmbAplicacionComisionBroker.SelectedItem.Value.ToString();
                            break;
                    }
                }
                return objNivel;
            }
            catch 
            {
                throw;
            }
        }
        protected void GrvCoberturas_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["nivel_cobertura__poliza"] != null)
                {
                    var objPoliza = (OCC_Poliza)Session["nivel_cobertura__poliza"];
                    int intNumeroNivel = Convert.ToInt32(HidNumeroNivel.Value);
                    GrvCoberturas.DataSource = objPoliza.ListaNiveles.Find(f => f.NumeroNivel == intNumeroNivel).ListaCoberturas;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("UserControl__nivel_cobertura", ex);
            }
        }
        protected void BtnModificarCoberturas_Click(object sender, EventArgs e)
        {
            try
            {
                int intNumeroNivel = Convert.ToInt32(HidNumeroNivel.Value);
                ((poliza_renovacion_ampliacion)this.Page).ModificarCoberturas(intNumeroNivel);
            }
            catch (Exception ex)
            {
                throw new Exception("UserControl__nivel_cobertura", ex);
            }
        }
    }
}