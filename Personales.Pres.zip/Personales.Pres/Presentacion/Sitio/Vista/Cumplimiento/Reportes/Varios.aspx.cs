﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Spreadsheet;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Cumplimiento.Reportes
{
    public partial class Varios : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void BtnCumplimiento_Click(object sender, EventArgs e)
        {
            try
            {
                string strReporte = ((BootstrapButton)sender).CommandName;
                string strRutaPlantilla = string.Empty;
                string strNombreReporte = string.Empty;
                switch (strReporte)
                {
                    case "BENEFICIARIOS": strRutaPlantilla = Server.MapPath("~/UI/templates/CUMPLIMIENTO_BENEFICIARIOS.xlsx"); strNombreReporte = "ReporteBeneficiarios_"; break;
                    case "ASEGURADOS": strRutaPlantilla = Server.MapPath("~/UI/templates/CUMPLIMIENTO_NUEVOS_ASEGURADOS.xlsx"); strNombreReporte = "ReporteNuevosAsegurados_"; break;
                    case "PCCSINIESTROS": strRutaPlantilla = Server.MapPath("~/UI/templates/CUMPLIMIENTO_PCCSINIESTROS.xlsx"); strNombreReporte = "ReportePCC04Siniestros_"; break;
                    case "PCCPRODUCCION": strRutaPlantilla = Server.MapPath("~/UI/templates/CUMPLIMIENTO_PCCPRODUCCION.xlsx"); strNombreReporte = "ReportePCC04Produccion_"; break;
                }
                var objFileInfo = new FileInfo(strRutaPlantilla);
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_CUMPLIMIENTO_CIERRE", new List<Agente.ServicioPersonales.CParameter>() { 
                    new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable }, 
                    new Agente.ServicioPersonales.CParameter() { Key = "@REPORTE", Value = strReporte } });
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Reporte" && strReporte == "BENEFICIARIOS")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:F" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Reporte" && strReporte == "ASEGURADOS")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:H" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Resumen" && strReporte == "PCCSINIESTROS")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:H" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                        DEWorksheet.Range["H2:H" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
                    }
                    if (DEWorksheet.Name == "Detalle" && strReporte == "PCCSINIESTROS")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[1], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:N" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                        DEWorksheet.Range["I2:I" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[13].NumberFormat = "dd/mm/yyyy";
                    }
                    if (DEWorksheet.Name == "Resumen" && strReporte == "PCCPRODUCCION")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:F" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                        DEWorksheet.Range["F2:F" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
                    }
                    if (DEWorksheet.Name == "Detalle" && strReporte == "PCCPRODUCCION")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[1], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:M" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                        DEWorksheet.Range["C2:C" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[6].NumberFormat = "dd/mm/yyyy";
                        DEWorksheet.Columns[7].NumberFormat = "dd/mm/yyyy";
                    }                    
                }
                byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnFormularioPCC04_Click(object sender, EventArgs e)
        {
            try
            {
                var DtblFormularios = _cPersonales.GetTableFormularioPCC04PorPeriodo(_strPeriodoContable);
                string strNombreReporte = "ReportePCC04Normativo_";
                using (var ms = new MemoryStream())
                {
                    TextWriter tw = new StreamWriter(ms);
                    //tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}", "ldr_entity_id", "eff_date", "jrnl_id", "jrnl_seq_nbr", "jrnl_line_nbr", "line_ldr_entity_id", "sucursal", "cuenta", "agencia", "centro", "negocio", "producto", "trans_curr_code", "prim_dr_cr_code", "trans_amt", "descp", "jrnl_user_alpha_fld_1", "jrnl_user_alpha_fld_2"));
                    //tw.Write(Environment.NewLine);
                    for (int index = 0; index < DtblFormularios.Rows.Count; index++)
                    {
                        tw.Write(string.Format(
                            "{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|" +
                            "{10}|{11}|{12}|{13}|{14}|{15}|{16}|{17}|{18}|{19}|" +
                            "{20}|{21}|{22}|{23}|{24}|{25}|{26}|{27}|{28}|{29}|" +
                            "{30}|{31}|{32}|{33}|{34}|{35}|{36}|{37}|{38}|{39}|" +
                            "{40}|{41}|{42}|{43}|{44}|{45}|{46}|{47}|{48}",
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][0].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][0].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][1].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][1].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][2].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][2].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][3].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][3].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][4].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][4].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][5].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][5].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][6].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][6].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][7].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][7].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][8].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][8].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][9].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][9].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

                            string.IsNullOrEmpty(DtblFormularios.Rows[index][10].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][10].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][11].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][11].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][12].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][12].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][13].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][13].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][14].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][14].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][15].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][15].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][16].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][16].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][17].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][17].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][18].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][18].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][19].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][19].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

                            string.IsNullOrEmpty(DtblFormularios.Rows[index][20].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][20].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][21].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][21].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][22].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][22].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][23].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][23].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][24].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][24].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][25].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][25].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][26].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][26].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][27].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][27].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][28].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][28].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][29].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][29].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

                            string.IsNullOrEmpty(DtblFormularios.Rows[index][30].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][30].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][31].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][31].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][32].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][32].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][33].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][33].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][34].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][34].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][35].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][35].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][36].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][36].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][37].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][37].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][38].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][38].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][39].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][39].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

                            string.IsNullOrEmpty(DtblFormularios.Rows[index][40].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][40].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][41].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][41].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][42].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][42].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][43].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][43].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][44].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][44].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][45].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][45].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][46].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][46].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][47].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][47].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
                            string.IsNullOrEmpty(DtblFormularios.Rows[index][48].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][48].ToString(), @"\r\n?|\n", string.Empty), @"\t", " ")));
                        tw.Write(Environment.NewLine);
                    }
                    tw.Flush();
                    ms.Position = 0;
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = ms.ToArray(), CONTENT_TYPE = "application/csv", NOMBRE_ARCHIVO = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".csv" };
                    ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                //Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.danger('" + ex.Message + "', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
        }
        protected void BtnMatrizRiesgo_Click(object sender, EventArgs e)
        {
            try
            {
                int intGestion = Convert.ToInt32(TxtGestion.Text.ToString());
                int intTrimestre = Convert.ToInt32(TxtNumeroTrimestre.Text.ToString());
                string strRutaPlantilla = Server.MapPath("~/UI/templates/MATRIZ_RIESGO.xlsx");
                string strNombreReporte = "MatrizRiesgoCRSP_" + intGestion.ToString() + "_" + intTrimestre.ToString() + "T_";
                var objFileInfo = new FileInfo(strRutaPlantilla);
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_MATRIZ_RIESGO", 
                    new List<Agente.ServicioPersonales.CParameter>() {
                        new Agente.ServicioPersonales.CParameter() { Key = "@GESTION", Value = intGestion },
                        new Agente.ServicioPersonales.CParameter() { Key = "@NUMERO_TRIMESTRE", Value = intTrimestre } });
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Reporte")
                    {
                        DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
                        CellRange objRange = DEWorksheet.Range["A1:S" + (DsetDatos.Tables[0].Rows.Count + 1)];
                        objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }                    
                }
                byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                TxtGestion.Text = TxtNumeroTrimestre.Text = null;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnMatrizRiesgoInstitucional_Click(object sender, EventArgs e)
        {
            try
            {
                int intGestion = Convert.ToInt32(TxtGestionMatrizRiesgoInstitucional.Text.ToString());
                var objArchivoRespuesta = _cDocumentos.Documento_Generar(
                    "REP-017",
                    new List<occ_response_file__parametro>() {
                        new occ_response_file__parametro { Nombre = "intGestion", Valor = intGestion }
                    });
                Session["DOWNLOAD"] = new OC_ARCHIVO
                {
                    BYTE_ARRAY = objArchivoRespuesta.ByteArray,
                    CONTENT_TYPE = objArchivoRespuesta.ContentType,
                    NOMBRE_ARCHIVO = objArchivoRespuesta.NombreArchivo
                };
                ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
                TxtGestionMatrizRiesgoInstitucional.Text = null;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}