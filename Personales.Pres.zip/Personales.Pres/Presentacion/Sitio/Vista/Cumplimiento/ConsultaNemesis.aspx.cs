﻿using Agente.ServicioDocumentos;
using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista.Cumplimiento
{
    public partial class ConsultaNemesis : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
		//protected void Page_Init(object sender, EventArgs e)
		//{
		//	//ScriptManager.GetCurrent(this.Page).RegisterPostBackControl(btnMyExport);
		//	ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
		//	scriptManager.RegisterPostBackControl(this.btnDescargarCarta);
		//	scriptManager.RegisterPostBackControl(this.btnDescargarCartaPJ);
		//}
		protected void Page_Load(object sender, EventArgs e)
        {           
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                Session["NEMESIS_COINCIDENCIAS_PN"] = null;
                Session["NEMESIS_COINCIDENCIAS_PJ"] = null;
                Session["LISTA_AFILIACIONES_PN"] = null;
                Session["LISTA_AFILIACIONES_PJ"] = null;
                Session["CARRITO_PN"] = null;
                Session["CARRITO_PJ"] = null;
            }

            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnBuscarPN_Click(object sender, EventArgs e)
        {
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_NEMESIS_BUSQUEDA",
                    new List<Agente.ServicioPersonales.CParameter>() {
                        new Agente.ServicioPersonales.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(TxtPNFechaDesde.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioPersonales.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(TxtPNFechaHasta.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioPersonales.CParameter() { Key = "@TIPO_PERSONA", Value = "PN" },
                        new Agente.ServicioPersonales.CParameter() { Key = "@NIT", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@RAZON_SOCIAL", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@CI", Value = TxtPNDocumentoNumero.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@COMPLEMENTO", Value = TxtPNDocumentoComplemento.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@EXTENSION", Value = TxtPNDocumentoExtension.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@PATERNO", Value = TxtPNApellidoPaterno.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@MATERNO", Value = TxtPNApellidoMaterno.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@NOMBRES", Value = TxtPNNombres.Text.Trim().ToUpper() }
                    });
                Session["NEMESIS_COINCIDENCIAS_PN"] = DsetDatos.Tables[0];
                GrvPersonaNatural.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvPersonaNatural_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["NEMESIS_COINCIDENCIAS_PN"] != null)
                {
                    GrvPersonaNatural.DataSource = (DataTable)Session["NEMESIS_COINCIDENCIAS_PN"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnBuscarPJ_Click(object sender, EventArgs e)
        {
            try
            {
                var DsetDatos = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_NEMESIS_BUSQUEDA",
                    new List<Agente.ServicioPersonales.CParameter>() {
                        new Agente.ServicioPersonales.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(TxtPJFechaDesde.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioPersonales.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(TxtPJFechaHasta.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioPersonales.CParameter() { Key = "@TIPO_PERSONA", Value = "PJ" },
                        new Agente.ServicioPersonales.CParameter() { Key = "@NIT", Value = TxtPJNit.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@RAZON_SOCIAL", Value = TxtPJRazonSocial.Text.Trim().ToUpper() },
                        new Agente.ServicioPersonales.CParameter() { Key = "@CI", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@COMPLEMENTO", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@EXTENSION", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@PATERNO", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@MATERNO", Value = string.Empty },
                        new Agente.ServicioPersonales.CParameter() { Key = "@NOMBRES", Value = string.Empty }
                    });
                Session["NEMESIS_COINCIDENCIAS_PJ"] = DsetDatos.Tables[0];
                GrvPersonaJuridica.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvPersonaJuridica_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["NEMESIS_COINCIDENCIAS_PJ"] != null)
                {
                    GrvPersonaJuridica.DataSource = (DataTable)Session["NEMESIS_COINCIDENCIAS_PJ"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                int intNumero = Convert.ToInt32(((BootstrapButton)sender).CommandArgument);
                string strTipo = ((BootstrapButton)sender).CommandName;
                var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();
                if (strTipo == "PN")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PN"];

                    var rowSelected = from row in DtblDatos.AsEnumerable()
                                      where row.Field<Int64>("NUMERO") == intNumero
                                      select new
                                      {
                                          DESDE = row.Field<string>("DESDE"),
                                          HASTA = row.Field<string>("HASTA"),
                                          CI = row.Field<string>("CI"),
                                          COMPLEMENTO = row.Field<string>("COMPLEMENTO"),
                                          EXTENSION = row.Field<string>("EXTENSION"),
                                      };
                    listaParametros = new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(rowSelected.Select(c=>c.DESDE).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(rowSelected.Select(c=>c.HASTA).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@TIPO_PERSONA", Value = "PN" },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NIT", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@CI", Value = rowSelected.Select(c=>c.CI).FirstOrDefault().ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@COMPLEMENTO", Value = rowSelected.Select(c=>c.COMPLEMENTO).FirstOrDefault().ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@EXTENSION", Value = rowSelected.Select(c=>c.EXTENSION).FirstOrDefault().ToString().Trim().ToUpper() }
                    };
                }
                if (strTipo == "PJ")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PJ"];
                    var rowSelected = from row in DtblDatos.AsEnumerable()
                                      where row.Field<Int64>("NUMERO") == intNumero
                                      select new
                                      {
                                          DESDE = row.Field<string>("DESDE"),
                                          HASTA = row.Field<string>("HASTA"),
                                          NIT = row.Field<string>("NIT"),
                                      };

                    listaParametros = new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(rowSelected.Select(c=>c.DESDE).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(rowSelected.Select(c=>c.HASTA).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@TIPO_PERSONA", Value = "PJ" },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NIT", Value = rowSelected.Select(c=>c.NIT).FirstOrDefault().ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@CI", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@COMPLEMENTO", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@EXTENSION", Value = string.Empty }
                    };
                }
                var objDocumento = _cDocumentos.GetReporteNemesisCSV(
                    "REP-013",
                    listaParametros,
                    new OC_RESPONSE_FILE() { NombreArchivo = "ConsultaNemesis_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss"), CarpetaSalida = string.Empty, BoolHistorico = false, FormatoSalida = "CSV" });
                if (objDocumento.RutaArchivoEnc != null)
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.warning('No existe información según los parametros indicados para generar el reporte.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnVerAfiliaciones_Click(object sender, EventArgs e)
        {
            try
            {
                int intNumero = Convert.ToInt32(((BootstrapButton)sender).CommandArgument);
                string strTipo = ((BootstrapButton)sender).CommandName;
                var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();

                if (strTipo == "PN")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PN"];
                    var rowSelected = from row in DtblDatos.AsEnumerable()
                                      where row.Field<Int64>("NUMERO") == intNumero
                                      select new
                                      {
                                          DESDE = row.Field<string>("DESDE"),
                                          HASTA = row.Field<string>("HASTA"),
                                          IDCLIENTE = row.Field<string>("IDCLIENTE"),
                                          CI = row.Field<string>("CI"),
                                          COMPLEMENTO = row.Field<string>("COMPLEMENTO"),
                                          EXTENSION = row.Field<string>("EXTENSION"),
                                          PATERNO = row.Field<string>("PATERNO"),
                                          MATERNO = row.Field<string>("MATERNO"),
                                          NOMBRES = row.Field<string>("NOMBRES"),
                                      };

                    var objNemesisCoincidencias = new ocp_nemesis_coincidencias();
                    objNemesisCoincidencias.DESDE = DateTime.ParseExact(rowSelected.Select(c => c.DESDE).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    objNemesisCoincidencias.HASTA = DateTime.ParseExact(rowSelected.Select(c => c.HASTA).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    objNemesisCoincidencias.IDCLIENTE = rowSelected.Select(c => c.IDCLIENTE).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.CI = rowSelected.Select(c => c.CI).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.COMPLEMENTO = rowSelected.Select(c => c.COMPLEMENTO).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.EXTENSION = rowSelected.Select(c => c.EXTENSION).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.PATERNO = rowSelected.Select(c => c.PATERNO).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.MATERNO = rowSelected.Select(c => c.MATERNO).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.NOMBRES = rowSelected.Select(c => c.NOMBRES).FirstOrDefault().ToString().Trim().ToUpper();

                    var dtFechaDesde = objNemesisCoincidencias.DESDE;
                    var dtFechaHasta = objNemesisCoincidencias.HASTA;
                    var strIdCliente = objNemesisCoincidencias.IDCLIENTE;                    
                    var response = _cPersonales.GetListaAfilacionesReporte13PN(dtFechaDesde, dtFechaHasta, strIdCliente);
                    
                    var lstPersonasNemesisPN = Session["LST_PERSONAS_NEMESIS_PN"] != null ? (List<ocp_nemesis_coincidencias>)Session["LST_PERSONAS_NEMESIS_PN"] : new List<ocp_nemesis_coincidencias>();
                    lstPersonasNemesisPN.Add(objNemesisCoincidencias);
                    Session["LST_PERSONAS_NEMESIS_PN"] = lstPersonasNemesisPN;
                                        
                     Session["LISTA_AFILIACIONES_PN"] = response;
                    grdAfiliaciones.DataBind();
                }
                if (strTipo == "PJ")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PJ"];
                    var rowSelected = from row in DtblDatos.AsEnumerable()
                                      where row.Field<Int64>("NUMERO") == intNumero
                                      select new
                                      {
                                          DESDE = row.Field<string>("DESDE"),
                                          HASTA = row.Field<string>("HASTA"),
                                          NIT = row.Field<string>("NIT"),
                                          RAZON_SOCIAL = row.Field<string>("RAZON_SOCIAL")
                                      };

                    var objNemesisCoincidencias = new ocp_nemesis_coincidencias();
                    objNemesisCoincidencias.DESDE = DateTime.ParseExact(rowSelected.Select(c => c.DESDE).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    objNemesisCoincidencias.HASTA = DateTime.ParseExact(rowSelected.Select(c => c.HASTA).FirstOrDefault().ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    objNemesisCoincidencias.NIT = rowSelected.Select(c => c.NIT).FirstOrDefault().ToString().Trim().ToUpper();
                    objNemesisCoincidencias.RAZON_SOCIAL = rowSelected.Select(c => c.RAZON_SOCIAL).FirstOrDefault().ToString().Trim().ToUpper();

                    var dtFechaDesde = objNemesisCoincidencias.DESDE;
                    var dtFechaHasta = objNemesisCoincidencias.HASTA;
                    var strNit = objNemesisCoincidencias.NIT;

                    var response = _cPersonales.GetListaAfilacionesReporte13PJ(dtFechaDesde, dtFechaHasta, strNit);

                    var lstPersonasNemesisPJ = Session["LST_PERSONAS_NEMESIS_PJ"] != null ? (List<ocp_nemesis_coincidencias>)Session["LST_PERSONAS_NEMESIS_PJ"] : new List<ocp_nemesis_coincidencias>();
                    lstPersonasNemesisPJ.Add(objNemesisCoincidencias);
                    Session["LST_PERSONAS_NEMESIS_PJ"] = lstPersonasNemesisPJ;

                    Session["LISTA_AFILIACIONES_PJ"] = response;
                    grdAfiliacionesPJ.DataBind();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void grdAfiliaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["LISTA_AFILIACIONES_PN"] != null)
                {
                    grdAfiliaciones.DataSource = (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["LISTA_AFILIACIONES_PN"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void grdAfiliacionesPJ_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["LISTA_AFILIACIONES_PJ"] != null)
                {
                    grdAfiliacionesPJ.DataSource = (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["LISTA_AFILIACIONES_PJ"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnAgregarCartaUif_Click(object sender, EventArgs e)
        {
            try
            {
				string[] arg = ((BootstrapButton)sender).CommandArgument.ToString().Split(',');

                string strIdCertificado = arg[0];// Convert.ToString(((BootstrapButton)sender).CommandArgument);
				string strIdPago = arg[1];

				var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();

                List<SPR_GETLIST_NEMESIS_PN_Result> lstAfiliaciones = (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["LISTA_AFILIACIONES_PN"];
                var objCartaUif = lstAfiliaciones.Where(w => w.CR_IDCERTIFICADO == strIdCertificado && w.PG_IDPAGO == Convert.ToInt64(strIdPago)).FirstOrDefault();

                List<SPR_GETLIST_NEMESIS_PN_Result> carrito = Session["CARRITO_PN"] != null ? (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["CARRITO_PN"] : new List<SPR_GETLIST_NEMESIS_PN_Result>();

                carrito.Add(objCartaUif);

                Session["CARRITO_PN"] = carrito;
                grdListaUif.DataBind();

            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnAgregarCartaUifPj_Click(object sender, EventArgs e)
        {
            try
            {
				string[] arg = ((BootstrapButton)sender).CommandArgument.ToString().Split(',');

				string strIdPoliza = arg[0];// Convert.ToString(((BootstrapButton)sender).CommandArgument);
				string strIdNit = arg[1];
				string strIdPeriodo = arg[2];

				//string intIdPoliza = Convert.ToString(((BootstrapButton)sender).CommandArgument);
				var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();

                List<SPR_GETLIST_NEMESIS_PJ_Result> lstAfiliaciones = (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["LISTA_AFILIACIONES_PJ"];
                var objCartaUifPJ = lstAfiliaciones.Where(w => w.PAPVC_POLIZA.TrimEnd() == strIdPoliza.TrimEnd() && w.NIT == strIdNit && w.PG_PERIODO == strIdPeriodo).FirstOrDefault();

                List<SPR_GETLIST_NEMESIS_PJ_Result> carrito = Session["CARRITO_PJ"] != null ? (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["CARRITO_PJ"] : new List<SPR_GETLIST_NEMESIS_PJ_Result>();

                carrito.Add(objCartaUifPJ);

                Session["CARRITO_PJ"] = carrito;
                grdListaUifPJ.DataBind();

            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnEliminarCartaUif_Click(object sender, EventArgs e)
        {
            try
            {
				string[] arg = ((BootstrapButton)sender).CommandArgument.ToString().Split(',');

				string strIdCertificado = arg[0];// Convert.ToString(((BootstrapButton)sender).CommandArgument);
				string strIdPago = arg[1];

				var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();

                List<SPR_GETLIST_NEMESIS_PN_Result> carrito = (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["CARRITO_PN"];
                var index = carrito.FindIndex(x => x.CR_IDCERTIFICADO == strIdCertificado && x.PG_IDPAGO == Convert.ToInt64(strIdPago));
                if (index >= 0) carrito.RemoveAt(index);

                Session["CARRITO_PN"] = carrito;
                grdListaUif.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void btnEliminarCartaUifPj_Click(object sender, EventArgs e)
        {
            try
            {
				string[] arg = ((BootstrapButton)sender).CommandArgument.ToString().Split(',');

				string strIdPoliza = arg[0];// Convert.ToString(((BootstrapButton)sender).CommandArgument);
				string strIdNit = arg[1];
				string strIdPeriodo = arg[2];

				var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();

                List<SPR_GETLIST_NEMESIS_PJ_Result> carrito = (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["CARRITO_PJ"];
                var index = carrito.FindIndex(x => x.PAPVC_POLIZA == strIdPoliza && x.NIT == strIdNit && x.PG_PERIODO == strIdPeriodo);
                if (index >= 0) carrito.RemoveAt(index);

                Session["CARRITO_PJ"] = carrito;
                grdListaUifPJ.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void grdListaUif_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CARRITO_PN"] != null)
                {
                    grdListaUif.DataSource = (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["CARRITO_PN"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void grdListaUifPJ_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["CARRITO_PJ"] != null)
                {
                    grdListaUifPJ.DataSource = (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["CARRITO_PJ"];
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            try
            {
                string strTipo = ((BootstrapButton)sender).CommandName;
                if (strTipo == "PN")
                {
                    Session.Remove("NEMESIS_COINCIDENCIAS_PN");
                    GrvPersonaNatural.DataSource = null;
                    GrvPersonaNatural.DataBind();
                    TxtPNFechaDesde.Text = null;
                    TxtPNFechaHasta.Text = null;
                    TxtPNDocumentoNumero.Text = null;
                    TxtPNDocumentoComplemento.Text = null;
                    TxtPNDocumentoExtension.Text = null;
                    TxtPNApellidoPaterno.Text = null;
                    TxtPNApellidoMaterno.Text = null;
                    TxtPNNombres.Text = null;
                    TxtPNFechaDesde.Focus();
                }
                if (strTipo == "PJ")
                {
                    Session.Remove("NEMESIS_COINCIDENCIAS_PJ");
                    GrvPersonaJuridica.DataSource = null;
                    GrvPersonaJuridica.DataBind();
                    TxtPJFechaDesde.Text = null;
                    TxtPJFechaHasta.Text = null;
                    TxtPJNit.Text = null;
                    TxtPJRazonSocial.Text = null;
                    TxtPJFechaDesde.Focus();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {            
				if (Session["DOWNLOAD"] != null)
				{
					var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
					Session.Remove("DOWNLOAD");
					Response.Buffer = true;
					Response.Clear();
					Response.ContentType = objArchivo.CONTENT_TYPE;
					Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
					Response.BinaryWrite(objArchivo.BYTE_ARRAY);
					Response.Flush();                    
					Response.End();
				}			
		}
        protected void btnDescargarCarta_Click(object sender, EventArgs e)
        {
            try
            {
                var carrito = (List<SPR_GETLIST_NEMESIS_PN_Result>)Session["CARRITO_PN"];
                if (carrito == null)
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'No existe informacion para generar la carta.');", true);
                    return;
                }
                var lstPersonas = carrito.GroupBy(x => x.CL_IDCLIENTE).Select(s => s.Key).ToList();

                var lstPersonasCartaNemesis = new List<persona_carta_nemesis>();

                var lstBuscaPersonasNemesis = (List<ocp_nemesis_coincidencias>)Session["LST_PERSONAS_NEMESIS_PN"];

                StringBuilder sb = new StringBuilder();
                sb.Append(@"<html>");
                sb.AppendLine("<head>");
                sb.AppendLine("<title></title>");
                sb.AppendLine("<style>");
                sb.AppendLine(".center {width:10%; margin: auto;}");
                sb.AppendLine(".divNombre {text-align:center;font-weight:bold;font-family:Arial; font-size:12px;}");
                sb.AppendLine("table, th, td { text-align: center; border:1px solid black; border-collapse: collapse; font-family:Arial;font-size:10px;}");
                sb.AppendLine(".titulo {font-family:Arial;font-size:11px;font-weight:bold;background-color:#CCCCCC}");
                sb.AppendLine("</style>");
                sb.AppendLine("</head>");
                sb.AppendLine("<body class=\"center\">");

                foreach (var itemPersona in lstPersonas)
                {
                    var objPersonaCartaNemesis = new persona_carta_nemesis();
                    var objPersona = lstBuscaPersonasNemesis.Where(w => w.IDCLIENTE == itemPersona.TrimEnd()).FirstOrDefault();

                    var nombrePersona = objPersona.PATERNO + " " + objPersona.MATERNO + " " + objPersona.NOMBRES;
                    //var documento = objPersona.CARNET;// (objPersona.CARNET + " " + objPersona.EXT + " " + objPersona.COMPLEMENTO).TrimStart().TrimEnd();

                    objPersonaCartaNemesis.PATERNO = objPersona.PATERNO;
                    objPersonaCartaNemesis.MATERNO = objPersona.MATERNO;
                    objPersonaCartaNemesis.NOMBRE = objPersona.NOMBRES;
                    objPersonaCartaNemesis.NOMBRE_PERSONA = nombrePersona;
                    objPersonaCartaNemesis.ID_PERSONA = itemPersona;
                    objPersonaCartaNemesis.NUMERO_DOCUMENTO = objPersona.CI.TrimStart().TrimEnd();
                    objPersonaCartaNemesis.EXTENSION = objPersona.EXTENSION;
                    objPersonaCartaNemesis.COMPLEMENTO = objPersona.COMPLEMENTO;

                    objPersonaCartaNemesis.DOCUMENTO = objPersona.CI;

                    sb.AppendLine("<div class=\"divNombre\">");
                    sb.AppendLine("<br />");
                    sb.AppendLine(nombrePersona);
                    sb.AppendLine("<br />");
                    sb.AppendLine("DOCUMENTO DE IDENTIDAD: " + objPersona.CI);
                    sb.AppendLine("<br />");

                    sb.AppendLine("<table style=\"width:100%;\">");
                    sb.AppendLine("<tr>");
                    sb.AppendLine("<td class=\"titulo\">Tipo de Producto</td>");
                    sb.AppendLine("<td class=\"titulo\">N° de <br /> Afiliación</td>");
                    sb.AppendLine("<td class=\"titulo\">Fecha Inicio <br /> de Afiliación</td>");
                    sb.AppendLine("<td class=\"titulo\">Fecha de Cierre <br /> de Afiliación</td>");
                    sb.AppendLine("<td class=\"titulo\">Periodo de <br /> Alcance</td>");
                    sb.AppendLine("</tr>");

                    var lstAfiliaciones = carrito.Where(w => w.CL_IDCLIENTE == itemPersona).ToList();
                    var lstAfiliacionesPersonaNemesis = new List<afiliaciones_carta_nemesis>();
                    foreach (var itemAfiliacion in lstAfiliaciones)
                    {
                        var numeroAfiliacion = itemAfiliacion.CR_IDCERTIFICADO;
                        var fechaInicioVigencia = itemAfiliacion.PAPDT_INICIO_VIGENCIA == null ? "-" : itemAfiliacion.PAPDT_INICIO_VIGENCIA.Value.ToShortDateString();
                        var fechaFinVigencia = itemAfiliacion.PAPDT_FIN_VIGENCIA == null ? "-" : itemAfiliacion.PAPDT_FIN_VIGENCIA.Value.ToShortDateString();

                        var strPeriodoAlcance = txtFechaPeriodoAlcanceInicio.Text + " al " + txtFechaPeriodoAlcanceFin.Text;
                        var objAfiliacionesCartaNemesis = new afiliaciones_carta_nemesis();
                        objAfiliacionesCartaNemesis.TIPO_PRODUCTO = itemAfiliacion.PR_DESCRIPCION;
                        objAfiliacionesCartaNemesis.NUMERO_AFILIACION = numeroAfiliacion;
                        objAfiliacionesCartaNemesis.FECHA_INICIO = itemAfiliacion.PAPDT_INICIO_VIGENCIA == null ? DateTime.MinValue : itemAfiliacion.PAPDT_INICIO_VIGENCIA.Value;
                        objAfiliacionesCartaNemesis.FECHA_FIN = itemAfiliacion.PAPDT_FIN_VIGENCIA;
                        objAfiliacionesCartaNemesis.PERIODO_ALCANCE = strPeriodoAlcance;
                        lstAfiliacionesPersonaNemesis.Add(objAfiliacionesCartaNemesis);
                        sb.AppendLine("<tr>");
                        sb.AppendLine("<td>" + itemAfiliacion.PR_DESCRIPCION + "</td>");
                        sb.AppendLine("<td>" + numeroAfiliacion + "</td>");
                        sb.AppendLine("<td>" + fechaInicioVigencia + "</td>");
                        sb.AppendLine("<td>" + fechaFinVigencia + "</td>");
                        sb.AppendLine("<td>" + strPeriodoAlcance + "</td>");
                        sb.AppendLine("</tr>");
                    }

                    sb.AppendLine("</table>");

                    sb.AppendLine("</body>");
                    sb.AppendLine("</html>");
                    objPersonaCartaNemesis.LST_AFILIACIONES = lstAfiliacionesPersonaNemesis;

                    lstPersonasCartaNemesis.Add(objPersonaCartaNemesis);
                }

                var jsonData = JsonConvert.SerializeObject(lstPersonasCartaNemesis);

                var objCartaNemesis = new CARTA_NEMESIS();
                objCartaNemesis.CAPVC_TIPO_PERSONA = "PN";
                objCartaNemesis.CAPVC_DATOS_ENVIADOS = jsonData;
                objCartaNemesis.CAPVC_CODIGO_SOLICITUD = txtCodigoSolicitud.Text;
                objCartaNemesis.CAPVC_CASO = txtCaso.Text;
                objCartaNemesis.CAPVC_SICOD = txtSicod.Text;
                objCartaNemesis.CAPVC_SOLICITUD = txtNumeroSolicitud.Text;
                objCartaNemesis.CAPVC_HTML_DATOS_ENVIADOS = sb.ToString();
                CPersonales cPersonales = new CPersonales();
                var response = cPersonales.RegistrarCartaNemesis(objCartaNemesis);

                var objArchivoRespuesta = _cDocumentos.Documento_Generar(
                            "NEM-001",
                            new List<occ_response_file__parametro>() {
                new occ_response_file__parametro { Nombre = "longCartaId", Valor = response.CARTA_ID },
                new occ_response_file__parametro { Nombre = "strFormato", Valor = "WORD" }
                            });
                string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));

                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc),
                    CONTENT_TYPE = "application/msword",
                    NOMBRE_ARCHIVO = "SC UIF " + response.CODIGO_CARTA + ".docx"
				};

				ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);

			}
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
		}

        protected void btnDescargarCartaPJ_Click(object sender, EventArgs e)
        {
            try
            {
                var carrito = (List<SPR_GETLIST_NEMESIS_PJ_Result>)Session["CARRITO_PJ"];
                if (carrito == null)
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'No existe informacion para generar la carta.');", true);
                    return;
                }
                var lstPersonas = carrito.GroupBy(x => x.NIT).Select(s => s.Key.TrimEnd()).ToList();

                var lstPersonasCartaNemesis = new List<persona_carta_nemesis>();

                var lstBuscaPersonasNemesis = (List<ocp_nemesis_coincidencias>)Session["LST_PERSONAS_NEMESIS_PJ"];

                StringBuilder sb = new StringBuilder();
                sb.Append(@"<html>");
                sb.AppendLine("<head>");
                sb.AppendLine("<title></title>");
                sb.AppendLine("<style>");
                sb.AppendLine(".center {width:10%; margin: auto;}");
                sb.AppendLine(".divNombre {text-align:center;font-weight:bold;font-family:Arial; font-size:12px;}");
                sb.AppendLine("table, th, td { text-align: center; border:1px solid black; border-collapse: collapse; font-family:Arial;font-size:10px;}");
                sb.AppendLine(".titulo {font-family:Arial;font-size:11px;font-weight:bold;background-color:#CCCCCC}");
                sb.AppendLine("</style>");
                sb.AppendLine("</head>");
                sb.AppendLine("<body class=\"center\">");

                foreach (var itemPersona in lstPersonas)
                {
                    var objPersonaCartaNemesis = new persona_carta_nemesis();
                    var objPersona = lstBuscaPersonasNemesis.Where(w => w.NIT == itemPersona.TrimEnd()).FirstOrDefault();

                    var nombrePersona = objPersona.RAZON_SOCIAL;// objPersona.PATERNO + " " + objPersona.MATERNO + " " + objPersona.NOMBRES;

                    objPersonaCartaNemesis.NIT = objPersona.NIT;
                    objPersonaCartaNemesis.RAZON_SOCIAL = objPersona.RAZON_SOCIAL;

                    sb.AppendLine("<div class=\"divNombre\">");
                    sb.AppendLine("<br />");
                    sb.AppendLine(nombrePersona);
                    sb.AppendLine("<br />");
                    sb.AppendLine("NRO NIT: " + objPersona.NIT);
                    sb.AppendLine("<br />");

                    sb.AppendLine("<table style=\"width:100%;\">");
                    sb.AppendLine("<tr>");
                    sb.AppendLine("<td class=\"titulo\">Tipo de Producto</td>");
                    sb.AppendLine("<td class=\"titulo\">N° de <br /> Poliza</td>");
                    sb.AppendLine("<td class=\"titulo\">Fecha Inicio <br /> de Afiliación</td>");
                    sb.AppendLine("<td class=\"titulo\">Fecha de Cierre <br /> de Afiliación</td>");
                    sb.AppendLine("<td class=\"titulo\">Periodo de <br /> Alcance</td>");
                    sb.AppendLine("</tr>");

                    var lstAfiliaciones = carrito.Where(w => w.NIT == itemPersona).ToList();
                    var lstAfiliacionesPersonaNemesis = new List<afiliaciones_carta_nemesis>();
                    foreach (var itemAfiliacion in lstAfiliaciones)
                    {
                        var numeroAfiliacion = itemAfiliacion.PAPVC_POLIZA;
                        var fechaInicioVigencia = itemAfiliacion.PAPDT_INICIO_VIGENCIA == null ? "-" : itemAfiliacion.PAPDT_INICIO_VIGENCIA.Value.ToShortDateString();
                        var fechaFinVigencia = itemAfiliacion.PAPDT_FIN_VIGENCIA == null ? "-" : itemAfiliacion.PAPDT_FIN_VIGENCIA.Value.ToShortDateString();

                        var strPeriodoAlcance = txtFechaAlcanceInicioPJ.Text + " al " + txtFechaAlcanceFinPJ.Text;
                        var objAfiliacionesCartaNemesis = new afiliaciones_carta_nemesis();
                        objAfiliacionesCartaNemesis.TIPO_PRODUCTO = itemAfiliacion.PR_DESCRIPCION;
                        objAfiliacionesCartaNemesis.NUMERO_AFILIACION = numeroAfiliacion;
                        objAfiliacionesCartaNemesis.FECHA_INICIO = itemAfiliacion.PAPDT_INICIO_VIGENCIA == null ? DateTime.MinValue : itemAfiliacion.PAPDT_INICIO_VIGENCIA.Value;
                        objAfiliacionesCartaNemesis.FECHA_FIN = itemAfiliacion.PAPDT_FIN_VIGENCIA;
                        objAfiliacionesCartaNemesis.PERIODO_ALCANCE = strPeriodoAlcance;
                        lstAfiliacionesPersonaNemesis.Add(objAfiliacionesCartaNemesis);
                        sb.AppendLine("<tr>");
                        sb.AppendLine("<td>" + itemAfiliacion.PR_DESCRIPCION + "</td>");
                        sb.AppendLine("<td>" + numeroAfiliacion + "</td>");
                        sb.AppendLine("<td>" + fechaInicioVigencia + "</td>");
                        sb.AppendLine("<td>" + fechaFinVigencia + "</td>");
                        sb.AppendLine("<td>" + strPeriodoAlcance + "</td>");
                        sb.AppendLine("</tr>");
                    }

                    sb.AppendLine("</table>");

                    sb.AppendLine("</body>");
                    sb.AppendLine("</html>");
                    objPersonaCartaNemesis.LST_AFILIACIONES = lstAfiliacionesPersonaNemesis;

                    lstPersonasCartaNemesis.Add(objPersonaCartaNemesis);
                }

                var jsonData = JsonConvert.SerializeObject(lstPersonasCartaNemesis);

                var objCartaNemesis = new CARTA_NEMESIS();
                objCartaNemesis.CAPVC_TIPO_PERSONA = "PJ";
                objCartaNemesis.CAPVC_DATOS_ENVIADOS = jsonData;
                objCartaNemesis.CAPVC_CODIGO_SOLICITUD = txtCodigoSolicitudPJ.Text;
                objCartaNemesis.CAPVC_CASO = txtCasoPJ.Text;
                objCartaNemesis.CAPVC_SICOD = txtSicodPJ.Text;
                objCartaNemesis.CAPVC_SOLICITUD = txtNumeroSolicitudPJ.Text;
                objCartaNemesis.CAPVC_HTML_DATOS_ENVIADOS = sb.ToString();
                CPersonales cPersonales = new CPersonales();

				var response = cPersonales.RegistrarCartaNemesis(objCartaNemesis);

				var objArchivoRespuesta = _cDocumentos.Documento_Generar(
                            "NEM-001",
                            new List<occ_response_file__parametro>() {
                new occ_response_file__parametro { Nombre = "longCartaId", Valor = response.CARTA_ID },
                new occ_response_file__parametro { Nombre = "strFormato", Valor = "WORD" }
                            });

				string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.RutaArchivoEnc));
				
		Session["DOWNLOAD"] = new OC_ARCHIVO()
				{
					BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc),
					CONTENT_TYPE = "application/msword",
					NOMBRE_ARCHIVO = "SC UIF " + response.CODIGO_CARTA + ".docx"
		};
				ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
			}
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
		}
        protected void BtnSeleccionar_Click(object sender, EventArgs e)
        {
            try
            {
                int intNumero = Convert.ToInt32(HidNumero.Value) - 1;
                string strTipo = HidTIpo.Value;
                var listaParametros = new List<Agente.ServicioDocumentos.CParameter>();
                if (strTipo == "PN")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PN"];
                    listaParametros = new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(DtblDatos.Rows[intNumero]["DESDE"].ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(DtblDatos.Rows[intNumero]["HASTA"].ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@TIPO_PERSONA", Value = "PN" },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NIT", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@CI", Value = DtblDatos.Rows[intNumero]["CI"].ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@COMPLEMENTO", Value = DtblDatos.Rows[intNumero]["COMPLEMENTO"].ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@EXTENSION", Value = DtblDatos.Rows[intNumero]["EXTENSION"].ToString().Trim().ToUpper() }
                    };
                }
                if (strTipo == "PJ")
                {
                    DataTable DtblDatos = (DataTable)Session["NEMESIS_COINCIDENCIAS_PJ"];
                    listaParametros = new List<Agente.ServicioDocumentos.CParameter>() {
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_DESDE", Value = DateTime.ParseExact(DtblDatos.Rows[intNumero]["DESDE"].ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@FECHA_HASTA", Value = DateTime.ParseExact(DtblDatos.Rows[intNumero]["HASTA"].ToString().Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture) },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@TIPO_PERSONA", Value = "PJ" },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@NIT", Value = DtblDatos.Rows[intNumero]["NIT"].ToString().Trim().ToUpper() },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@CI", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@COMPLEMENTO", Value = string.Empty },
                        new Agente.ServicioDocumentos.CParameter() { Key = "@EXTENSION", Value = string.Empty }
                    };
                }
                var objDocumento = _cDocumentos.GetReporteNemesisCSV(
                    "REP-013",
                    listaParametros,
                    new OC_RESPONSE_FILE() { NombreArchivo = "ConsultaNemesis_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss"), CarpetaSalida = string.Empty, BoolHistorico = false, FormatoSalida = "CSV" });
                if (objDocumento.RutaArchivoEnc != null)
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.RutaArchivoEnc));
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = objDocumento.ContentType, NOMBRE_ARCHIVO = objDocumento.NombreArchivo };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.warning('No existe información según los parametros indicados para generar el reporte.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}