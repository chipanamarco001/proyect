﻿using System;

namespace PresentacionWeb.Sitio.Vista.Exceptions
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
                return;
            string strMensajeError = Request.Params.Get("error");
            if (strMensajeError != null && !strMensajeError.Equals(string.Empty))
                lblMensajeError.Text = strMensajeError;
        }
    }
}