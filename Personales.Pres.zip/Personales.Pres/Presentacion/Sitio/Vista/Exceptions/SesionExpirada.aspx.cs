﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;

namespace Presentacion.Sitio.Vista.Exceptions
{
    public partial class SesionExpirada : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ClientScriptManager cs = Page.ClientScript;
            Session.Clear();
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
            SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");           
            LblTiemporSesion.Text = ((int)section.Timeout.TotalMinutes).ToString();
        }
    }
}