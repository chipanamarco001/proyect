﻿using Agente.ServicioCrediseguro;
using DevExpress.Export;
using DevExpress.Web.Bootstrap;
using DevExpress.XtraPrinting;
using Newtonsoft.Json;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Crediseguro;
using Presentacion.Sitio.Controladores.Personales;
using Presentacion.Sitio.Entidades;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class reporte_grafico_produccion : ControlUsuario
    {
        private string _strPeriodoContable;
        private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void CargaInicial()
        {
            try
            {
                _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
                List<ocp_presupuesto> listaPresupuesto = new List<ocp_presupuesto>();
                int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                if (File.Exists(Server.MapPath("~/UI/data/presupuesto-" + intGestion + ".json")))
                    listaPresupuesto = JsonConvert.DeserializeObject<List<ocp_presupuesto>>(File.ReadAllText(Server.MapPath("~/UI/data/presupuesto-" + intGestion + ".json")));
                var listaRegistros = _cCrediseguro.ReporteProduccionPorGestion(_strPeriodoContable, "PRODUCCION");
                var listaProduccionActual = listaRegistros.Where(w => w.GESTION == intGestion).ToList();
                var listaProduccionAnterior = listaRegistros.Where(w => w.GESTION == (intGestion - 1)).ToList();
                var listaBaseReporteProduccion = new ocp_base_reporte_produccion()
                {
                    ListaPresupuesto = listaPresupuesto,
                    ListaProduccionAnterior = listaProduccionAnterior,
                    ListaProduccionActual = listaProduccionActual
                };
                listaBaseReporteProduccion.GeneraBaseReporteProduccion();
                Session["reporte_grafico_produccion__base_reporte_produccion"] = listaBaseReporteProduccion;
                PgcReporte.ActiveTabIndex = 0;
                IniciarFormularios(0);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void IniciarFormularios(int intIndex)
        {
            try
            {
                var objBaseReporteProduccion = (ocp_base_reporte_produccion)Session["reporte_grafico_produccion__base_reporte_produccion"];
                int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                switch (intIndex)
                {
                    case 0:
                        Session["reporte_grafico_produccion__DatosProduccion"] = objBaseReporteProduccion.ListaProduccionActual;
                        GrvProduccion.DataBind();
                        break;
                    case 1:
                        ChtTotales.SettingsCommonSeries.ArgumentField = "Mes";
                        ChtTotales.SeriesCollection.Clear();
                        ChtTotales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                        ChtTotales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                        ChtTotales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                        ChtTotales.DataSource = objBaseReporteProduccion.ListaReporteTotales;
                        ChtTotales.DataBind();
                        ///
                        ChtDesgravamen.SettingsCommonSeries.ArgumentField = "Mes";
                        ChtDesgravamen.SeriesCollection.Clear();
                        ChtDesgravamen.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                        ChtDesgravamen.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                        ChtDesgravamen.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                        ChtDesgravamen.DataSource = objBaseReporteProduccion.ListaReporteDesgravamen;
                        ChtDesgravamen.DataBind();
                        ///
                        ChtBancaSeguros.SettingsCommonSeries.ArgumentField = "Mes";
                        ChtBancaSeguros.SeriesCollection.Clear();
                        ChtBancaSeguros.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                        ChtBancaSeguros.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                        ChtBancaSeguros.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                        ChtBancaSeguros.DataSource = objBaseReporteProduccion.ListaReporteBancaSeguros;
                        ChtBancaSeguros.DataBind();
                        ///
                        ChtGrupales.SettingsCommonSeries.ArgumentField = "Mes";
                        ChtGrupales.SeriesCollection.Clear();
                        ChtGrupales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                        ChtGrupales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                        ChtGrupales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                        ChtGrupales.DataSource = objBaseReporteProduccion.ListaReporteGrupales;
                        ChtGrupales.DataBind();
                        ///
                        ChtIndividuales.SettingsCommonSeries.ArgumentField = "Mes";
                        ChtIndividuales.SeriesCollection.Clear();
                        ChtIndividuales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                        ChtIndividuales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                        ChtIndividuales.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                        ChtIndividuales.DataSource = objBaseReporteProduccion.ListaReporteIndividuales;
                        ChtIndividuales.DataBind();
                        break;
                    case 2:
                         var listaProductos = objBaseReporteProduccion.ListaProduccionActual
                            .GroupBy(g => g.ID_PRODUCTO)
                            .Select(s => new SPR_CORE_REPORTE_PRODUCCION_Result {
                                ID_PRODUCTO = s.First().ID_PRODUCTO,
                                NOMBRE_PRODUCTO = s.First().ID_PRODUCTO + " - " + s.First().NOMBRE_PRODUCTO
                            }).ToList();
                        CmbProductos.DataSource = listaProductos;
                        CmbProductos.ValueField = "ID_PRODUCTO";
                        CmbProductos.TextField = "NOMBRE_PRODUCTO";
                        CmbProductos.DataBind();
                        break;
                }                
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnVerDatos_Click(object sender, EventArgs e)
        {
            try
            {
                int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                var objBaseReporteProduccion = (ocp_base_reporte_produccion)Session["reporte_grafico_produccion__base_reporte_produccion"];
                string strCommandName = ((BootstrapButton)sender).CommandName;
                List<ocp_reporte_produccion> listaReporteProduccion = new List<ocp_reporte_produccion>();
                switch (strCommandName)
                {
                    case "Totales":
                        listaReporteProduccion = objBaseReporteProduccion.ListaReporteTotales;
                        break;
                    case "Banca Seguros":
                        listaReporteProduccion = objBaseReporteProduccion.ListaReporteBancaSeguros;
                        break;
                    case "Desgravamen":
                        listaReporteProduccion = objBaseReporteProduccion.ListaReporteDesgravamen;
                        break;
                    case "Grupales":
                        listaReporteProduccion = objBaseReporteProduccion.ListaReporteGrupales;
                        break;
                    case "Individuales":
                        listaReporteProduccion = objBaseReporteProduccion.ListaReporteIndividuales;
                        break;
                    default:
                        listaReporteProduccion = null;
                        break;
                }
                Session["reporte_grafico_produccion__DatosGrafico"] = listaReporteProduccion;
                IniciarFormularios(1);
                PopDatosGrafico.ShowOnPageLoad = true;
                PopDatosGrafico.HeaderText = strCommandName.ToUpper();
                GrvDatosGrafico.Columns[1].Caption = "Producción " + (intGestion - 1);
                GrvDatosGrafico.Columns[2].Caption = "Producción " + intGestion;
                GrvDatosGrafico.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDescargarDatosGrafico_Click(object sender, EventArgs e)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                GrvDatosGrafico.ExportToXlsx(stream, new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });
                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = stream.ToArray(),
                    CONTENT_TYPE = "application/vnd.ms-excel",
                    NOMBRE_ARCHIVO = "DatosGrafico.xlsx"
                };
                stream.Close();
            }
            int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
            IniciarFormularios(1);
            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
        }
        protected void BtnDescargarDatosProduccion_Click(object sender, EventArgs e)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                GrvProduccion.ExportToXlsx(stream, new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });
                Session["DOWNLOAD"] = new OC_ARCHIVO()
                {
                    BYTE_ARRAY = stream.ToArray(),
                    CONTENT_TYPE = "application/vnd.ms-excel",
                    NOMBRE_ARCHIVO = "DatosProduccion.xlsx"
                };
                stream.Close();
            }
            int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
            IniciarFormularios(0);
            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDatosGrafico_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["reporte_grafico_produccion__DatosGrafico"] != null)
                    GrvDatosGrafico.DataSource = (List<ocp_reporte_produccion>)Session["reporte_grafico_produccion__DatosGrafico"];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProduccion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["reporte_grafico_produccion__DatosProduccion"] != null)
                    GrvProduccion.DataSource = (List<SPR_CORE_REPORTE_PRODUCCION_Result>)Session["reporte_grafico_produccion__DatosProduccion"];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void PgcReporte_ActiveTabChanged(object source, BootstrapPageControlEventArgs e)
        {
            try
            {
                IniciarFormularios(e.Tab.Index);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CmbProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var objBaseReporteProduccion = (ocp_base_reporte_produccion)Session["reporte_grafico_produccion__base_reporte_produccion"];
                int intGestion = DateTime.ParseExact(_strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                var listaProducto = objBaseReporteProduccion.DatosProductoReporte(CmbProductos.SelectedItem.Value.ToString());
                ChtProducto.TitleSettings.Text = CmbProductos.SelectedItem.Text.Replace(CmbProductos.SelectedItem.Value.ToString() + " - ", string.Empty);
                ChtProducto.SettingsCommonSeries.ArgumentField = "Mes";
                ChtProducto.SeriesCollection.Clear();
                ChtProducto.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                ChtProducto.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                ChtProducto.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Presupuesto", Name = "Presupuesto" });
                ChtProducto.DataSource = listaProducto;
                ChtProducto.DataBind();
                GrvDatosGraficoProducto.DataSource = listaProducto;
                GrvDatosGraficoProducto.Columns[1].Caption = "Producción " + (intGestion - 1);
                GrvDatosGraficoProducto.Columns[2].Caption = "Producción " + intGestion;
                GrvDatosGraficoProducto.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}