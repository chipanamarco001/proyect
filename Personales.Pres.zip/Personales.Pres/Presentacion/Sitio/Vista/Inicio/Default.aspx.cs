﻿using Presentacion.Lib;
using System;

namespace PresentacionWeb.Sitio.Vista.Inicio
{
    public partial class Default : ControlUsuario
    {
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso())
                this.CierraSesion();
            if (!IsPostBack)
            {
                Master.CargarMesProduccion();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
    }
}