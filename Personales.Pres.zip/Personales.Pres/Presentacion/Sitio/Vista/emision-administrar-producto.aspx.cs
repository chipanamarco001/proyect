﻿using Agente.ServicioPersonales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class emision_administrar_producto : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                CargaInicial();
            }
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cPersonales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void CargaInicial()
        {
            try
            {
                var listaProductos = _cPersonales.Producto_ObtenerListaProductos();
                var listaRamos = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PRODUCTO" && w.LEPVC_TEMA == "RAMO" && w.LEPBT_ACTIVO == true).ToList();
                foreach (var objProducto in listaProductos)
                {
                    var objRamo = listaRamos.Where(w => w.LEPVC_VALOR == objProducto.PRPCH_RAMO).FirstOrDefault();
                    if (objRamo != null)
                    {
                        objProducto.PRPCH_RAMO += " - " + objRamo.LEPVC_DESC_CORTA;
                    }
                }
                Session["emision_administrar_producto__listaProductos"] = listaProductos;
                GrvProductoActivo.DataBind();
                GrvProductoDeshabilitado.DataBind();
                BtnRegistrarProducto.ClientVisible = (_objUsuario.Area == "COMERCIAL") ? true : false;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProductoActivo_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaProductos = (List<PRODUCTO>)Session["emision_administrar_producto__listaProductos"];
                var listaProductosActivos = listaProductos.Where(w => w.PRPBT_ACTIVO == true).ToList();
                GrvProductoActivo.DataSource = listaProductosActivos.OrderBy(O => O.PRPCH_RAMO).ThenBy(O => O.PRSVC_LINEA_NEGOCIO);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProductoDeshabilitado_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaProductos = (List<PRODUCTO>)Session["emision_administrar_producto__listaProductos"];
                var listaProductosDeshabilitados = listaProductos.Where(w => w.PRPBT_ACTIVO == false).ToList();
                GrvProductoDeshabilitado.DataSource = listaProductosDeshabilitados.OrderBy(O => O.PRPCH_RAMO).ThenBy(O => O.PRSVC_LINEA_NEGOCIO);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProductoActivo_CustomButtonInitialize(object sender, DevExpress.Web.Bootstrap.BootstrapGridViewCustomButtonEventArgs e)
        {
            try
            {
                BootstrapGridView iGrvBandeja = (BootstrapGridView)sender;
                var objProductoActivo = (PRODUCTO)iGrvBandeja.GetRow(e.VisibleIndex);
                switch (e.ButtonID)
                {
                    case "Ver":
                        e.Visible = (objProductoActivo.PRPBT_FLAG_PARAMETRO) ? ((_objUsuario.Area != "SISTEMAS" && _objUsuario.Area != "TECNICA") ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False) : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "Parametros":
                        e.Visible = (_objUsuario.Area == "SISTEMAS" || _objUsuario.Area == "TECNICA") ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "Desactivar":
                        e.Visible = (_objUsuario.Area == "COMERCIAL") ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProductoDeshabilitado_CustomButtonInitialize(object sender, BootstrapGridViewCustomButtonEventArgs e)
        {
            try
            {
                BootstrapGridView iGrvBandeja = (BootstrapGridView)sender;
                var objProductoDeshabilitado = (PRODUCTO)iGrvBandeja.GetRow(e.VisibleIndex);
                switch (e.ButtonID)
                {
                    case "Activar":
                        e.Visible = (_objUsuario.Area == "COMERCIAL") ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccionBandeja_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccionBandeja.Contains("IdProducto") && HidAccionBandeja.Contains("Accion"))
                {
                    string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
                    var listaProductos = (List<PRODUCTO>)Session["emision_administrar_producto__listaProductos"];
                    var objProducto = listaProductos.Where(w => w.PRPVC_ID_PRODUCTO == strIdProducto).First();
                    var listaFactorTipo = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "FACTOR" && w.LEPVC_TEMA == "TIPO" && w.LEPBT_ACTIVO == true).ToList();
                    CmbPATipoAplicacion.Items.Clear();
                    CmbPATipoAplicacion.DataSource = listaFactorTipo;
                    CmbPATipoAplicacion.ValueField = "LEPVC_VALOR";
                    CmbPATipoAplicacion.TextField = "LEPVC_DESC_CORTA";
                    CmbPATipoAplicacion.DataBind();
                    CmbCCTipoAplicacion.Items.Clear();
                    CmbCCTipoAplicacion.DataSource = listaFactorTipo;
                    CmbCCTipoAplicacion.ValueField = "LEPVC_VALOR";
                    CmbCCTipoAplicacion.TextField = "LEPVC_DESC_CORTA";
                    CmbCCTipoAplicacion.DataBind();
                    CmbCBTipoAplicacion.Items.Clear();
                    CmbCBTipoAplicacion.DataSource = listaFactorTipo;
                    CmbCBTipoAplicacion.ValueField = "LEPVC_VALOR";
                    CmbCBTipoAplicacion.TextField = "LEPVC_DESC_CORTA";
                    CmbCBTipoAplicacion.DataBind();
                    PopProductoParametro.HeaderText = "PARAMETRIZACIÓN | " + objProducto.PRPVC_ID_PRODUCTO + " - " + objProducto.PRPVC_NOMBRE_COMERCIAL;
                    var listaParametros = _cPersonales.Producto_ObtenerListaParametrosPorId(strIdProducto);
                    if (listaParametros.Count > 0)
                    {
                        CmbPATipoAplicacion.Value = listaParametros.Where(w => w.PRPVC_TIPO == "PA").First().PRPVC_APLICACION;
                        CmbCCTipoAplicacion.Value = listaParametros.Where(w => w.PRPVC_TIPO == "CC").First().PRPVC_APLICACION;
                        CmbCBTipoAplicacion.Value = listaParametros.Where(w => w.PRPVC_TIPO == "CB").First().PRPVC_APLICACION;
                        TxtPAFactor.Value = listaParametros.Where(w => w.PRPVC_TIPO == "PA").First().PRPDC_FACTOR;
                        TxtCCFactor.Value = listaParametros.Where(w => w.PRPVC_TIPO == "CC").First().PRPDC_FACTOR;
                        TxtCBFactor.Value = listaParametros.Where(w => w.PRPVC_TIPO == "CB").First().PRPDC_FACTOR;
                    }
                    else
                    {
                        CmbPATipoAplicacion.Value = "PC";
                        CmbCCTipoAplicacion.Value = null;
                        CmbCBTipoAplicacion.Value = null;
                        TxtPAFactor.Value = null;
                        TxtCCFactor.Value = null;
                        TxtCBFactor.Value = null;
                    }
                    Session["emision_administrar_producto__listaParametros"] = listaParametros;
                    switch (HidAccionBandeja.Get("Accion").ToString())
                    {
                        case "Parametros":
                            CmbPATipoAplicacion.ClientEnabled = false;
                            CmbCCTipoAplicacion.ClientEnabled = true;
                            CmbCBTipoAplicacion.ClientEnabled = true;
                            CmbPATipoAplicacion.ReadOnly = true;
                            CmbCCTipoAplicacion.ReadOnly = false;
                            CmbCBTipoAplicacion.ReadOnly = false;
                            TxtPAFactor.ClientEnabled = true;
                            TxtCCFactor.ClientEnabled = true;
                            TxtCBFactor.ClientEnabled = true;
                            TxtPAFactor.ReadOnly = false;
                            TxtCCFactor.ReadOnly = false;
                            TxtCBFactor.ReadOnly = false;
                            ((BootstrapButton)PopProductoParametro.FindControl("BtnParametroContinuar")).ClientVisible = true;
                            LblParametroConfirmacion.Text = (listaParametros.Count == 0) ? 
                                "SE CREARÁ LA PARAMETRIZACIÓN PARA EL PRODUCTO CON LOS DATOS INGRESADOS EN EL FORMULARIO. ¿ESTÁ SEGURO(A) QUE DESEA REGISTRAR?" :
                                "SE ACTUALIZARÁ LA PARAMETRIZACIÓN DEL PRODUCTO CON LOS DATOS INGRESADOS EN EL FORMULARIO, TODAS LAS PÓLIZAS VINCULADAS A ESTA PARAMETRIZACIÓN SERÁN AFECTADAS DESDE ESTE MOMENTO. ¿ESTÁ SEGURO(A) QUE DESEA ACTUALIZAR?";
                            BtnParametroRegistrar.ClientVisible = (listaParametros.Count == 0);
                            BtnParametroActualizar.ClientVisible = (listaParametros.Count > 0);
                            PopProductoParametro.ShowOnPageLoad = true;
                            break;
                        case "Ver":
                            CmbPATipoAplicacion.ClientEnabled = false;
                            CmbCCTipoAplicacion.ClientEnabled = false;
                            CmbCBTipoAplicacion.ClientEnabled = false;
                            CmbPATipoAplicacion.ReadOnly = true;
                            CmbCCTipoAplicacion.ReadOnly = true;
                            CmbCBTipoAplicacion.ReadOnly = true;
                            TxtPAFactor.ClientEnabled = false;
                            TxtCCFactor.ClientEnabled = false;
                            TxtCBFactor.ClientEnabled = false;
                            TxtPAFactor.ReadOnly = true;
                            TxtCCFactor.ReadOnly = true;
                            TxtCBFactor.ReadOnly = true;
                            ((BootstrapButton)PopProductoParametro.FindControl("BtnParametroContinuar")).ClientVisible = false;
                            PopProductoParametro.ShowOnPageLoad = true;
                            break;
                    }
                    Session["emision_administrar_producto__IdProducto"] = strIdProducto;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDeshabilitarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccionBandeja.Contains("IdProducto"))
                {
                    string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
                    var objProducto = _cPersonales.Producto_ObtenerProductoPorId(strIdProducto);
                    objProducto.PRPBT_ACTIVO = false;
                    _cPersonales.Producto_Modificar(objProducto);
                    GrvProductoActivo.DataBind();
                    GrvProductoDeshabilitado.DataBind();
                    CargaInicial();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El producto seleccionado ha sido deshabilitado para la producción.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnActivarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccionBandeja.Contains("IdProducto"))
                {
                    string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
                    var objProducto = _cPersonales.Producto_ObtenerProductoPorId(strIdProducto);
                    objProducto.PRPBT_ACTIVO = true;
                    _cPersonales.Producto_Modificar(objProducto);
                    GrvProductoActivo.DataBind();
                    GrvProductoDeshabilitado.DataBind();
                    CargaInicial();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "002", "toastr.success('El producto seleccionado ha sido activado para la producción.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistrarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                CmbRamo.Items.Clear();
                var listaLexicosRamos = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PRODUCTO" && w.LEPVC_TEMA == "RAMO" && w.LEPBT_ACTIVO == true).ToList();
                var listaRamos = new List<LEXICO>();
                foreach (var objLexico in listaLexicosRamos)
                {
                    listaRamos.Add(new LEXICO {
                        LEPVC_VALOR = objLexico.LEPVC_VALOR,
                        LEPVC_DESC_CORTA = objLexico.LEPVC_VALOR + " - " + objLexico.LEPVC_DESC_CORTA
                    });
                }
                CmbRamo.DataSource = listaRamos;
                CmbRamo.ValueField = "LEPVC_VALOR";
                CmbRamo.TextField = "LEPVC_DESC_CORTA";
                CmbRamo.DataBind();
                Session["emision_administrar_producto__listaRamos"] = listaRamos;
                ///
                var listaTipoProducto = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PRODUCTO" && w.LEPVC_TEMA == "TIPO" && w.LEPBT_ACTIVO == true).ToList();
                CmbTipo.Items.Clear();
                CmbTipo.DataSource = listaTipoProducto;
                CmbTipo.ValueField = "LEPVC_VALOR";
                CmbTipo.TextField = "LEPVC_VALOR";
                CmbTipo.DataBind();
                Session["emision_administrar_producto__listaTipoProducto"] = listaTipoProducto;
                ///
                var listaLineaNegocioProducto = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "PRODUCTO" && w.LEPVC_TEMA == "LINEA_NEGOCIO" && w.LEPBT_ACTIVO == true).ToList();
                CmbLineaNegocio.Items.Clear();
                CmbLineaNegocio.DataSource = listaLineaNegocioProducto;
                CmbLineaNegocio.ValueField = "LEPVC_VALOR";
                CmbLineaNegocio.TextField = "LEPVC_VALOR";
                CmbLineaNegocio.DataBind();
                Session["emision_administrar_producto__listaLineaNegocioProducto"] = listaLineaNegocioProducto;
                ///
                TxtIdProducto.Value = null;
                TxtNombreProducto.Value = null;
                CmbRamo.Value = null;
                CmbTipo.Value = null;
                CmbLineaNegocio.Value = null;
                CmbFacturacion.Value = null;
                UpcArchivo.Dispose();
                PopNuevoProducto.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnRegistrarProductoConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                var objProducto = new PRODUCTO();
                objProducto.PRPVC_ID_PRODUCTO = TxtIdProducto.Text.Trim().ToUpper();
                objProducto.PRPVC_NOMBRE_COMERCIAL = TxtNombreProducto.Text.Trim().ToUpper();
                objProducto.PRPCH_RAMO = CmbRamo.SelectedItem.Value.ToString();
                objProducto.PRSVC_TIPO = CmbTipo.SelectedItem.Value.ToString();
                objProducto.PRSVC_LINEA_NEGOCIO = CmbLineaNegocio.SelectedItem.Value.ToString();
                var listaRamos = (List<LEXICO>)Session["emision_administrar_producto__listaRamos"];
                var strFacturacion = listaRamos.Where(w => w.LEPVC_VALOR == objProducto.PRPCH_RAMO).First().LEPVC_DESC_LARGA;
                objProducto.PRSBT_FLAG_FACTURACION = (strFacturacion == "FACTURA") ? true : false;
                objProducto.PRPBT_FLAG_PARAMETRO = false;
                objProducto.PRPCH_MODALIDAD = "93";
                objProducto.PRSBT_FLAG_CARGA = false;
                objProducto.PRSBT_FLAG_PRODUCCION = false;
                objProducto.PRSVC_PROCEDIMIENTO = string.Empty;
                objProducto.PRSVC_TIPO_RRC = string.Empty;
                var objProductoResult = _cPersonales.Producto_Agregar(objProducto);
                var objArchivoRespaldo = (OC_ARCHIVO)Session["emision_administrar_producto__archivoRespaldo"];
                string strRutaArchivos = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ARCHIVOS").First().LEPVC_VALOR;
                File.WriteAllBytes(strRutaArchivos + objProductoResult.PRPVC_ID_PRODUCTO + "_RespaldoRegistro" + objArchivoRespaldo.EXTENSION, objArchivoRespaldo.BYTE_ARRAY);
                PopNuevoProducto.ShowOnPageLoad = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "003", "toastr.success('El producto ha sido registrado exitosamente en la base de producción.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = UpcArchivo.UploadedFiles[0];
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["emision_administrar_producto__archivoRespaldo"] = new OC_ARCHIVO()
                {
                    CONTENT_TYPE = uploadedFile.ContentType,
                    EXTENSION = fileInfo.Extension,
                    NOMBRE_ARCHIVO = uploadedFile.FileName,
                    FILE_STREAM = uploadedFile.FileContent,
                    BYTE_ARRAY = uploadedFile.FileBytes
                };
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CallbackPanel_Callback(object sender, DevExpress.Web.CallbackEventArgsBase e)
        {
            string strIdProducto = TxtIdProducto.Text ?? string.Empty;
            var listaProductosActivos = (List<PRODUCTO>)Session["emision_administrar_producto__listaProductos"];
            TxtIdProducto.IsValid = true;
            if (listaProductosActivos.Exists(f => f.PRPVC_ID_PRODUCTO == strIdProducto.ToUpper().Trim()))
            {
                TxtIdProducto.IsValid = false;
                TxtIdProducto.Value = null;
                TxtIdProducto.ErrorText = "El Id de producto '" + strIdProducto.ToUpper() + "' ya existe en producción.";
            }
        }
        protected void BtnParametroRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                string strTipoRegistro = ((BootstrapButton)sender).CommandName;
                string strIdProducto = Session["emision_administrar_producto__IdProducto"].ToString();
                var listaParametrosRegistrados = (List<PRODUCTO_PARAMETRO>)Session["emision_administrar_producto__listaParametros"];
                var listaParametros = new List<PRODUCTO_PARAMETRO>{
                    new PRODUCTO_PARAMETRO
                    {
                        PRPVC_ID_PRODUCTO = strIdProducto,
                        PRPVC_TIPO = "PA",
                        PRPVC_TIPO_DESCRIPCION = "CÁLCULO DE LA PRIMA ADICIONAL",
                        PRPDC_FACTOR = Convert.ToDecimal(TxtPAFactor.Text.Trim()),
                        PRPVC_APLICACION = CmbPATipoAplicacion.SelectedItem.Value.ToString(),
                        PRPVC_APLICACION_DESCRIPCION = CmbPATipoAplicacion.SelectedItem.Text.ToString().Replace("% ", string.Empty),
                        PRSVC_COMENTARIO = (listaParametrosRegistrados.Count == 0) ? string.Empty : ""
                    },
                    new PRODUCTO_PARAMETRO
                    {
                        PRPVC_ID_PRODUCTO = strIdProducto,
                        PRPVC_TIPO = "CC",
                        PRPVC_TIPO_DESCRIPCION = "CÁLCULO DE LA COMISIÓN DE COBRANZA",
                        PRPDC_FACTOR = Convert.ToDecimal(TxtCCFactor.Text.Trim()),
                        PRPVC_APLICACION = CmbCCTipoAplicacion.SelectedItem.Value.ToString(),
                        PRPVC_APLICACION_DESCRIPCION = CmbCCTipoAplicacion.SelectedItem.Text.ToString().Replace("% ", string.Empty),
                        PRSVC_COMENTARIO = string.Empty
                    },
                    new PRODUCTO_PARAMETRO
                    {
                        PRPVC_ID_PRODUCTO = strIdProducto,
                        PRPVC_TIPO = "CB",
                        PRPVC_TIPO_DESCRIPCION = "CÁLCULO DE LA COMISIÓN DEL BRÓKER",
                        PRPDC_FACTOR = Convert.ToDecimal(TxtCBFactor.Text.Trim()),
                        PRPVC_APLICACION = CmbCBTipoAplicacion.SelectedItem.Value.ToString(),
                        PRPVC_APLICACION_DESCRIPCION = CmbCBTipoAplicacion.SelectedItem.Text.ToString().Replace("% ", string.Empty),
                        PRSVC_COMENTARIO = string.Empty
                    }
                };
                if (strTipoRegistro == "Registro")
                {
                    _cPersonales.Producto_AgregarParametro(listaParametros);
                }
                else
                {
                    _cPersonales.Producto_ModificarParametro(listaParametros);
                }
                PopProductoParametro.ShowOnPageLoad = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "004", "toastr.success('La parametrización del producto ha sido " + ((strTipoRegistro == "Registro") ? "registrada" : "actualizada") + " exitosamente en la base de producción.', 'PROCESO COMPLETADO', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}