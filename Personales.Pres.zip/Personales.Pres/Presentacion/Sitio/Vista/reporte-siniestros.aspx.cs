﻿using DevExpress.Spreadsheet;
using DevExpress.Web.Bootstrap;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Documentos;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Sitio.Vista
{
    public partial class reporte_siniestros : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        #region Sistema de Beneficios
        protected void BtnSiniestros_Click(object sender, EventArgs e)
        {
            string strTipoDocumento = ((BootstrapButton)sender).CommandName;
            try
            {
                if (strTipoDocumento == "Reaseguro")
                {
                    string strRutaPlantilla = Server.MapPath("~/UI/templates/SINIESTROS_REASEGURADOS.xlsx");
                    var DsetSiniestros = _cPersonales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_SINIESTROS_REASEGURADOS", new List<Agente.ServicioPersonales.CParameter>() { new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable } });
                    if (DsetSiniestros.Tables[0].Rows[0][0].ToString() == "TRUE" && DsetSiniestros.Tables[1].Rows.Count > 0)
                    {
                        Workbook DEWorkbook = new Workbook();
                        DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                        foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                        {
                            if (DEWorksheet.Name == "Reporte")
                            {
                                DEWorksheet.Cells["A1"].Value = "SINIESTROS REASEGURADOS - " + ((Label)Master.FindControl("LblMesProduccion")).Text;
                                DEWorksheet.Import(DsetSiniestros.Tables[1], false, 2, 0);
                                DEWorksheet.Range["A2:Z" + (DsetSiniestros.Tables[1].Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                                DEWorksheet.Range["P3:R" + (DsetSiniestros.Tables[1].Rows.Count + 2)].NumberFormat = "#,##0.00"; //formato numerico
                                DEWorksheet.Columns[4].NumberFormat = "dd/mm/yyyy";
                                DEWorksheet.Columns[7].NumberFormat = "dd/mm/yyyy";
                                DEWorksheet.Columns[8].NumberFormat = "dd/mm/yyyy";
                                DEWorksheet.Columns[11].NumberFormat = "dd/mm/yyyy";
                                DEWorksheet.Columns[12].NumberFormat = "dd/mm/yyyy";
                                DEWorksheet.Columns[25].NumberFormat = "dd/mm/yyyy"; //fecha nacimiento
                            }
                        }
                        byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                        Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = bReporte, CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "SiniestrosReasegurados_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "BtnSiniestrosReaseguro_Click(ERROR)", "toastr.warning('El registro de siniestros para este mes todavía no ha sido cerrado, por favor intente a partir del día " + DsetSiniestros.Tables[0].Rows[0][1].ToString() + ".', 'Sistema de Beneficios', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    }
                }
                else if (strTipoDocumento == "Validacion")
                {
                    var strRutaReporte = _cDocumentos.ReporteValidacionCesion(_strPeriodoContable);
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(strRutaReporte));
                    Session["DOWNLOAD"] = new OC_ARCHIVO() { BYTE_ARRAY = File.ReadAllBytes(strRutaArchivoEnc), CONTENT_TYPE = "application/xls", NOMBRE_ARCHIVO = "ValidacionSiniestros_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
    }
}