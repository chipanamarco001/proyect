﻿using DevExpress.Spreadsheet;
using Presentacion.Lib;
using Presentacion.Sitio.Controladores.Personales;
using PresentacionWeb.Sitio.Entidades;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.Sitio.Vista
{
    public partial class validacion_reservas_tecnicas : ControlUsuario
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        private string _strPeriodoContable;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                Session["validacion_reservas_tecnicas__datos"] = _cPersonales.DatosValidacionReservasTecnicas((string)Session["PERIODO_CONTABLE"], string.Empty);
                GrvDiferencias.DataBind();
            }
            _strPeriodoContable = (string)Session["PERIODO_CONTABLE"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (OC_ARCHIVO)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.NOMBRE_ARCHIVO);
                Response.BinaryWrite(objArchivo.BYTE_ARRAY);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDiferencias_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var dsDatos = (DataSet)Session["validacion_reservas_tecnicas__datos"];
                GrvDiferencias.DataSource = dsDatos.Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccion.Contains("Ramo"))
                {
                    var strRamo = HidAccion["Ramo"].ToString();
                    var DsetDatos = _cPersonales.DatosValidacionReservasTecnicas(_strPeriodoContable, strRamo);
                    int intNumeroAfiliaciones = 0;
                    for (int index = 0; index < DsetDatos.Tables[0].Rows.Count; index++)
                    {
                        if (DsetDatos.Tables[0].Rows[index][0].ToString() == strRamo)
                        {
                            intNumeroAfiliaciones = intNumeroAfiliaciones + Convert.ToInt32(DsetDatos.Tables[0].Rows[index][8].ToString());
                        }
                    }
                    if (intNumeroAfiliaciones <= 5000)
                    {
                        Workbook DEWorkbook = new Workbook();
                        DEWorkbook.LoadDocument(Server.MapPath("~/UI/templates/VALIDACION_RRC.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                        foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                        {
                            if (DEWorksheet.Name == "RRC")
                            {
                                DataTable DtblReservasTecnicas = DsetDatos.Tables[1];
                                DEWorksheet.Import(DtblReservasTecnicas, false, 2, 0);
                                CellRange objRange = DEWorksheet.Range["A2:V" + (DtblReservasTecnicas.Rows.Count + 2)];
                                objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                            }
                        }
                        Session["DOWNLOAD"] = new OC_ARCHIVO()
                        {
                            BYTE_ARRAY = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                            CONTENT_TYPE = "application/xls",
                            NOMBRE_ARCHIVO = "ValidacionRRC_" + strRamo + "_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx"
                        };
                    }
                    else
                    {
                        using (var ms = new MemoryStream())
                        {
                            TextWriter tw = new StreamWriter(ms);
                            tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}\t{18}\t{19}\t{20}\t{21}",
                                "MES_PRODUCCION",
                                "ID_PRODUCTO",
                                "RAMO",
                                "NIT_TOMADOR",
                                "POLIZA",
                                "INICIO_VIGENCIA",
                                "FIN_VIGENCIA",
                                "FECHA_AFILIACION",
                                "CERTIFICADO",
                                "TIPO_RRC",
                                "MESES_VIGENCIA",
                                "MES_ACTUAL",
                                "MONEDA",
                                "CONSITUCION_PRIMA_COMERCIAL",
                                "CONSITUCION_PRIMA_NETA",
                                "CONSITUCION_PRIMA_CEDIDA",
                                "LIBERACION_PRIMA_COMERCIAL",
                                "LIBERACION_PRIMA_NETA",
                                "LIBERACION_PRIMA_CEDIDA",
                                "RRC_CONSTITUCION",
                                "RRC_LIBERACION",
                                "RRC_PASIVO"));
                            tw.Write(Environment.NewLine);
                            foreach (DataRow objDataRow in DsetDatos.Tables[1].Rows)
                            {
                                tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}\t{18}\t{19}\t{20}\t{21}",
                                    objDataRow[0].ToString(),
                                    objDataRow[1].ToString(),
                                    objDataRow[2].ToString(),
                                    objDataRow[3].ToString(),
                                    objDataRow[4].ToString(),
                                    objDataRow[5].ToString(),
                                    objDataRow[6].ToString(),
                                    objDataRow[7].ToString(),
                                    objDataRow[8].ToString(),
                                    objDataRow[9].ToString(),
                                    objDataRow[10].ToString(),
                                    objDataRow[11].ToString(),
                                    objDataRow[12].ToString(),
                                    objDataRow[13].ToString(),
                                    objDataRow[14].ToString(),
                                    objDataRow[15].ToString(),
                                    objDataRow[16].ToString(),
                                    objDataRow[17].ToString(),
                                    objDataRow[18].ToString(),
                                    objDataRow[19].ToString(),
                                    objDataRow[20].ToString(),
                                    objDataRow[21].ToString()));
                                tw.Write(Environment.NewLine);
                            }
                            tw.Flush();
                            ms.Position = 0;
                            Session["DOWNLOAD"] = new OC_ARCHIVO()
                            {
                                BYTE_ARRAY = ms.ToArray(),
                                CONTENT_TYPE = "text/plain",
                                NOMBRE_ARCHIVO = "ValidacionRRC_" + strRamo + "_" + _strPeriodoContable + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt"
                            };
                        }
                    }
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}