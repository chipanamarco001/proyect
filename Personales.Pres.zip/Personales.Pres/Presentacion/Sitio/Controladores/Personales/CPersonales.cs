﻿using Agente;
using Agente.ServicioPersonales;
using Agente.ServicioProduccion;
using DocumentFormat.OpenXml.Bibliography;
using Presentacion.Parametros;
using Presentacion.Sitio.Vista.Produccion;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Security.Cryptography;
using System.Web;

namespace Presentacion.Sitio.Controladores.Personales
{
    public class CPersonales
    {
        private readonly IServicioPersonales _servicioPersonales = LocalizadorProxy.ServicioPersonales();
        public DataSet GetDatasetProcedimiento(string strNombreProcedimiento, List<CParameter> ListaParametros)
        {
            try
            {
                var objRequest = new GetDatasetProcedimientoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strNombreProcedimiento = strNombreProcedimiento;
                objRequest.ListaParametros = ListaParametros;
                var response = _servicioPersonales.GetDatasetProcedimiento(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetDatasetProcedimientoResult;
            }
            catch
            {
                throw;
            }
        }
        #region PERSONALES
        public bool TipoCambio_Registrar(string strMoneda, DateTime dtFecha, decimal decValorCompra, decimal decValorVenta)
        {
            try
            {
                var objRequest = new TipoCambio_RegistrarRequest
                {
                    strMoneda = strMoneda, 
                    dtFecha = dtFecha, 
                    decValorCompra = decValorCompra, 
                    decValorVenta = decValorVenta,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.TipoCambio_Registrar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.TipoCambio_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<SPR_GET_BANDEJA_PRODUCCION_Result> GetListaBandejaProduccion(string strPeriodoContable)
        {
            try
            {
                var objRequest = new GetListaBandejaProduccionRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaBandejaProduccion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaBandejaProduccionResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region Finanzas - Generar Contabilidad
        public List<ASIENTO_CONTABLE> GetListAsientosContablesPorPeriodo(string strPeriodoContable)
        {
            try
            {
                var objRequest = new GetListAsientosContablesPorPeriodoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListAsientosContablesPorPeriodo(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListAsientosContablesPorPeriodoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion        
        #region Finanzas - Cuadro de siniestros        
        #endregion
        #region CONFORMIDAD
        public CONFORMIDAD RegistrarConformidad(CONFORMIDAD objConformidad)
        {
            try
            {
                var objRequest = new RegistrarConformidadRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.objConformidad = objConformidad;
                var response = _servicioPersonales.RegistrarConformidad(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.RegistrarConformidadResult;
            }
            catch
            {
                throw;
            }
        }
        public List<CONFORMIDAD> ListaConformidadesPorPeriodo(string strPeriodoContable)
        {
            try
            {
                var objRequest = new ListaConformidadesPorPeriodoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strPeriodoContable = strPeriodoContable;
                var response = _servicioPersonales.ListaConformidadesPorPeriodo(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ListaConformidadesPorPeriodoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Conformidad_RevertirPorIdGrupo(string strPeriodo, string strIdGrupo, string strMotivo)
        {
            try
            {
                var objRequest = new Conformidad_RevertirPorIdGrupoRequest
                {
                    strPeriodo = strPeriodo,
                    strIdGrupo = strIdGrupo,
                    strMotivo = strMotivo,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Conformidad_RevertirPorIdGrupo(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Conformidad_RevertirPorIdGrupoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region LEXICO
        public List<LEXICO> GetListLexicoPorTabla(string strTabla)
        {
            try
            {
                var objRequest = new GetListLexicoPorTablaRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strTabla = strTabla;
                var response = _servicioPersonales.GetListLexicoPorTabla(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListLexicoPorTablaResult;
            }
            catch
            {
                throw;
            }
        }
        public List<LEXICO> GetListLexicoPorTablaYTema(string strTabla, string strTema)
        {
            try
            {
                var objRequest = new GetListLexicoPorTablaYTemaRequest()
                {
                    strTabla = strTabla,
                    strTema = strTema,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.GetListLexicoPorTablaYTema(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.GetListLexicoPorTablaYTemaResult;
            }
            catch
            {
                throw;
            }
        }
        public LEXICO Lexico_Registrar(LEXICO objLexico)
        {
            try
            {
                var objRequest = new Lexico_RegistrarRequest()
                {
                    objLexico = objLexico,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Lexico_Registrar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Lexico_Actualizar(LEXICO objLexico)
        {
            try
            {
                var objRequest = new Lexico_ActualizarRequest()
                {
                    objLexico = objLexico,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Lexico_Actualizar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_ActualizarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<LEXICO> Lexico_ObtenerListaActivos()
        {
            try
            {
                var objRequest = new Lexico_ObtenerListaActivosRequest
                {
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Lexico_ObtenerListaActivos(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_ObtenerListaActivosResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region ERROR_SISTEMA
        public ERROR_SISTEMA AgregarError(ERROR_SISTEMA objErrorSistema)
        {
            try
            {
                var objRequest = new AgregarErrorRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.objErrorSistema = objErrorSistema;
                var response = _servicioPersonales.AgregarError(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.AgregarErrorResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region PRODUCTO
        public List<PRODUCTO> GetListaProductosProduccion()
        {
            try
            {
                var objRequest = new GetListaProductosProduccionRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaProductosProduccion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaProductosProduccionResult;
            }
            catch
            {
                throw;
            }
        }
        public List<string> ListaIdProductosBCP()
        {
            try
            {
                var objRequest = new ListaIdProductosBCPRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.ListaIdProductosBCP(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ListaIdProductosBCPResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PRODUCTO_DOCUMENTO> GetListaProductoDocumentoPorId(string strIdProducto)
        {
            try
            {
                var objRequest = new GetListaProductoDocumentoPorIdRequest();
                objRequest.strIdProducto = strIdProducto;
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaProductoDocumentoPorId(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaProductoDocumentoPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PRODUCTO> Producto_ObtenerListaProductos()
        {
            try
            {
                var objRequest = new Producto_ObtenerListaProductosRequest()
                {
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_ObtenerListaProductos(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_ObtenerListaProductosResult;
            }
            catch
            {
                throw;
            }
        }
        public PRODUCTO Producto_Agregar(PRODUCTO objProducto)
        {
            try
            {
                var objRequest = new Producto_AgregarRequest()
                {
                    objProducto = objProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_Agregar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_AgregarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Producto_Modificar(PRODUCTO objProducto)
        {
            try
            {
                var objRequest = new Producto_ModificarRequest()
                {
                    objProducto = objProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_Modificar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_ModificarResult;
            }
            catch
            {
                throw;
            }
        }
        public PRODUCTO Producto_ObtenerProductoPorId(string strIdProducto)
        {
            try
            {
                var objRequest = new Producto_ObtenerProductoPorIdRequest()
                {
                    strIdProducto = strIdProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_ObtenerProductoPorId(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_ObtenerProductoPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PRODUCTO_PARAMETRO> Producto_ObtenerListaParametrosPorId(string strIdProducto)
        {
            try
            {
                var objRequest = new Producto_ObtenerListaParametrosPorIdRequest()
                {
                    strIdProducto = strIdProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_ObtenerListaParametrosPorId(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_ObtenerListaParametrosPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Producto_AgregarParametro(List<PRODUCTO_PARAMETRO> listaProductoParametro)
        {
            try
            {
                var objRequest = new Producto_AgregarParametroRequest()
                {
                    listaProductoParametro = listaProductoParametro,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_AgregarParametro(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_AgregarParametroResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Producto_ModificarParametro(List<PRODUCTO_PARAMETRO> listaProductoParametro)
        {
            try
            {
                var objRequest = new Producto_ModificarParametroRequest()
                {
                    listaProductoParametro = listaProductoParametro,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Producto_ModificarParametro(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Producto_ModificarParametroResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region POLIZA
        public List<string> GetListaPolizasPorLiquidacion(string strPeriodoContable, string strIdProducto)
        {
            try
            {
                var objRequest = new GetListaPolizasPorLiquidacionRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strIdProducto = strIdProducto;
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaPolizasPorLiquidacion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaPolizasPorLiquidacionResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PRODUCTO> ListaProductosColectivos()
        {
            try
            {
                var objRequest = new ListaProductosColectivosRequest()
                {
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ListaProductosColectivos(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaProductosColectivosResult;
            }
            catch
            {
                throw;
            }
        }
        public List<OCC_Tomador> ListaTomadoresPorIdProducto(string strIdProducto)
        {
            try
            {
                var objRequest = new ListaTomadoresPorIdProductoRequest()
                {
                    strIdProducto = strIdProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ListaTomadoresPorIdProducto(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaTomadoresPorIdProductoResult;
            }
            catch
            {
                throw;
            }
        }
        public List<POLIZA> ListaPolizasPorIdProductoYIdTomador(string strIdProducto, long longIdTomador)
        {
            try
            {
                var objRequest = new ListaPolizasPorIdProductoYIdTomadorRequest()
                {
                    strIdProducto = strIdProducto,
                    longIdTomador = longIdTomador,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ListaPolizasPorIdProductoYIdTomador(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaPolizasPorIdProductoYIdTomadorResult;
            }
            catch
            {
                throw;
            }
        }
        public OCC_Poliza ObtenerPolizaPorId(long longIdTomador, string strIdPoliza)
        {
            try
            {
                var objRequest = new ObtenerPolizaPorIdRequest()
                {
                    longIdTomador = longIdTomador,
                    strIdPoliza = strIdPoliza,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ObtenerPolizaPorId(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ObtenerPolizaPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public List<OCC_Broker> ListaBroker()
        {
            try
            {
                var objRequest = new ListaBrokerRequest()
                {
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ListaBroker(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaBrokerResult;
            }
            catch
            {
                throw;
            }
        }
        public List<OCC_Bandeja_Renovacion_Ampliacion> ListaPolizasRenovacionAmpliacion()
        {
            try
            {
                var objRequest = new ListaPolizasRenovacionAmpliacionRequest()
                {
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ListaPolizasRenovacionAmpliacion(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaPolizasRenovacionAmpliacionResult;
            }
            catch
            {
                throw;
            }
        }
        public POLIZA RegistrarRenovacionOAmpliacion(OCC_Poliza objOCCPoliza)
        {
            try
            {
                var objRequest = new RegistrarRenovacionOAmpliacionRequest()
                {
                    objOCCPoliza = objOCCPoliza,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.RegistrarRenovacionOAmpliacion(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.RegistrarRenovacionOAmpliacionResult;
            }
            catch
            {
                throw;
            }
        }
        public List<LIQUIDACION> ObtenerListaLiquidacionesPorPeriodoYProducto(string strPeriodoContable, string strIdProducto)
        {
            try
            {
                var objRequest = new ObtenerListaLiquidacionesPorPeriodoYProductoRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strIdProducto = strIdProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.ObtenerListaLiquidacionesPorPeriodoYProducto(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ObtenerListaLiquidacionesPorPeriodoYProductoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region USUARIOS
        public occ_usuario ValidaAccesoUsuario()
        {
            try
            {
                var objRequest = new ValidaAccesoUsuarioRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.ValidaAccesoUsuario(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ValidaAccesoUsuarioResult;
            }
            catch
            {
                throw;
            }
        }
        public List<USUARIO> ObtenerListaUsuariosActivos()
        {
            try
            {
                var objRequest = new ObtenerListaUsuariosActivosRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.ObtenerListaUsuariosActivos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ObtenerListaUsuariosActivosResult;
            }
            catch
            {
                throw;
            }
        }
        public List<USUARIO> Usuario_ObtenerListaPorIdRol(long longIdRol)
        {
            try
            {
                var objRequest = new Usuario_ObtenerListaPorIdRolRequest
                {
                    longIdRol = longIdRol,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Usuario_ObtenerListaPorIdRol(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Usuario_ObtenerListaPorIdRolResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region FORMULARIO PCC04
        public FORMULARIO_PCC04 ObtenerFormularioPCC04PorId(long longIdFormularioPCC04)
        {
            try
            {
                var objRequest = new ObtenerFormularioPCC04PorIdRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.longIdFormularioPCC04 = longIdFormularioPCC04;
                var response = _servicioPersonales.ObtenerFormularioPCC04PorId(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ObtenerFormularioPCC04PorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet FormulariosPCC04PorPeriodo(string strPeriodoContable)
        {
            try
            {
                var objRequest = new FormulariosPCC04PorPeriodoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strPeriodoContable = strPeriodoContable;
                var response = _servicioPersonales.FormulariosPCC04PorPeriodo(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.FormulariosPCC04PorPeriodoResult;
            }
            catch
            {
                throw;
            }
        }
        public FORMULARIO_PCC04 AgregarFormularioPCC04(FORMULARIO_PCC04 objFormularioPCC04)
        {
            try
            {
                var objRequest = new AgregarFormularioPCC04Request();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.objFormularioPCC04 = objFormularioPCC04;
                var response = _servicioPersonales.AgregarFormularioPCC04(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.AgregarFormularioPCC04Result;
            }
            catch
            {
                throw;
            }
        }
        public bool ActualizarFormularioPCC04(FORMULARIO_PCC04 objFormularioPCC04)
        {
            try
            {
                var objRequest = new ActualizarFormularioPCC04Request();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.objFormularioPCC04 = objFormularioPCC04;
                var response = _servicioPersonales.ActualizarFormularioPCC04(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ActualizarFormularioPCC04Result;
            }
            catch
            {
                throw;
            }
        }
        public bool EliminarFormularioPCC04(long longIdFormularioPCC04)
        {
            try
            {
                var objRequest = new EliminarFormularioPCC04Request();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.longIdFormularioPCC04 = longIdFormularioPCC04;
                var response = _servicioPersonales.EliminarFormularioPCC04(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.EliminarFormularioPCC04Result;
            }
            catch
            {
                throw;
            }
        }
        public DataTable GetTableFormularioPCC04PorPeriodo(string strPeriodoContable)
        {
            try
            {
                var objRequest = new GetListaFormularioPCC04PorPeriodoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strPeriodoContable = strPeriodoContable;
                var response = _servicioPersonales.GetListaFormularioPCC04PorPeriodo(objRequest);
                if (response.ValidationResult.Error && response.ValidationResult.ValidationErrors.Count > 0)
                {
                    throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
                }
                new CParametrosComplejos().ValidationResult(response);
                if (response.GetListaFormularioPCC04PorPeriodoResult != null)
                {
                    DataTable DtblFormulario = new DataTable();
                    DtblFormulario.Columns.Clear();
                    DtblFormulario.Columns.Add("ID_FORMULARIO", typeof(string));
                    DtblFormulario.Columns.Add("FECHA", typeof(string));
                    DtblFormulario.Columns.Add("CRS_CIUDAD", typeof(string));
                    DtblFormulario.Columns.Add("CRS_ZONA", typeof(string));
                    DtblFormulario.Columns.Add("CRS_DIRECCION", typeof(string));
                    DtblFormulario.Columns.Add("CRS_TELEFONO", typeof(string));
                    DtblFormulario.Columns.Add("CRS_FUNCIONARIO", typeof(string));
                    DtblFormulario.Columns.Add("CRS_SUPERVISOR", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_PERSONA", typeof(string));
                    DtblFormulario.Columns.Add("PN_NOMBRES", typeof(string));
                    DtblFormulario.Columns.Add("PN_APELLIDO_PATERNO", typeof(string));
                    DtblFormulario.Columns.Add("PN_APELLIDO_MATERNO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_TIPO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_NUMERO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_EXTENSION", typeof(string));
                    DtblFormulario.Columns.Add("PN_NACIONALIDAD", typeof(string));
                    DtblFormulario.Columns.Add("PN_PAIS_RESIDENCIA", typeof(string));
                    DtblFormulario.Columns.Add("PN_PROFESION", typeof(string));
                    DtblFormulario.Columns.Add("ACTIVIDAD", typeof(string));
                    DtblFormulario.Columns.Add("PN_LUGAR_TRABAJO", typeof(string));
                    DtblFormulario.Columns.Add("PN_CARGO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DIRECCION_TRABAJO", typeof(string));
                    DtblFormulario.Columns.Add("PJ_NIT", typeof(string));
                    DtblFormulario.Columns.Add("PJ_RAZON_SOCIAL", typeof(string));
                    DtblFormulario.Columns.Add("CIUDAD", typeof(string));
                    DtblFormulario.Columns.Add("DIRECCION", typeof(string));
                    DtblFormulario.Columns.Add("ZONA", typeof(string));
                    DtblFormulario.Columns.Add("TELEFONO", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_OPERACION", typeof(string));
                    DtblFormulario.Columns.Add("NATURALEZA_OPERACION", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_SEGURO", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_PLAZO_SEGURO", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_RAMO", typeof(string));
                    DtblFormulario.Columns.Add("MONEDA", typeof(string));
                    DtblFormulario.Columns.Add("MONTO", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_CORREDOR", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_TOMADOR", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_INTERMEDIARIO", typeof(string));                    
                    DtblFormulario.Columns.Add("NUMERO_POLIZA", typeof(string));
                    DtblFormulario.Columns.Add("NUMERO_CUENTA", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_ENTIDAD_FINANCIERA", typeof(string));
                    DtblFormulario.Columns.Add("NUMERO_CHEQUE", typeof(string));
                    //DtblFormulario.Columns.Add("REPOSICION", typeof(string));
                    DtblFormulario.Columns.Add("ORIGEN_RECURSOS", typeof(string));
                    DtblFormulario.Columns.Add("DESTINO_RECURSOS", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_NOMBRE", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_DOCUMENTO_NUMERO", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_DOCUMENTO_EXTENSION", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_CARGO", typeof(string));
                    DtblFormulario.Columns.Add("OBSERVACIONES", typeof(string));
                    foreach (var objFormulario in response.GetListaFormularioPCC04PorPeriodoResult)
                    {
                        string strIdFormulario = "000000" + objFormulario.FOPBI_ID_FORMULARIO.ToString();
                        DataRow dr = DtblFormulario.NewRow();
                        dr["ID_FORMULARIO"] = "CRSP-PCC04-" + strIdFormulario.Substring(strIdFormulario.Length - 6, 6);
                        dr["FECHA"] = objFormulario.FOPDT_FECHA.ToString("dd/MM/yyyy");
                        dr["CRS_CIUDAD"] = (objFormulario.FOPVC_CRS_CIUDAD ?? string.Empty);
                        dr["CRS_ZONA"] = (objFormulario.FOPVC_CRS_ZONA ?? string.Empty);
                        dr["CRS_DIRECCION"] = (objFormulario.FOPVC_CRS_DIRECCION ?? string.Empty);
                        dr["CRS_TELEFONO"] = (objFormulario.FOSVC_CRS_TELEFONO ?? string.Empty);
                        dr["CRS_FUNCIONARIO"] = (objFormulario.FOPVC_CRS_FUNCIONARIO ?? string.Empty);
                        dr["CRS_SUPERVISOR"] = (objFormulario.FOPVC_CRS_SUPERVISOR ?? string.Empty);
                        dr["TIPO_PERSONA"] = (objFormulario.FOPVC_TIPO_PERSONA ?? string.Empty);
                        dr["PN_NOMBRES"] = (objFormulario.FOPVC_PN_NOMBRES ?? string.Empty);
                        dr["PN_APELLIDO_PATERNO"] = (objFormulario.FOPVC_PN_APELLIDO_PATERNO ?? string.Empty);
                        dr["PN_APELLIDO_MATERNO"] = (objFormulario.FOSVC_PN_APELLIDO_MATERNO ?? string.Empty);
                        dr["PN_DOCUMENTO_TIPO"] = (objFormulario.FOPVC_PN_DOCUMENTO_TIPO ?? string.Empty);
                        dr["PN_DOCUMENTO_NUMERO"] = (objFormulario.FOPVC_PN_DOCUMENTO_NUMERO ?? string.Empty);
                        dr["PN_DOCUMENTO_EXTENSION"] = (objFormulario.FOSVC_PN_DOCUMENTO_EXTENSION ?? string.Empty);
                        dr["PN_NACIONALIDAD"] = (objFormulario.FOPVC_PN_NACIONALIDAD ?? string.Empty);
                        dr["PN_PAIS_RESIDENCIA"] = (objFormulario.FOPVC_PN_PAIS_RESIDENCIA ?? string.Empty);
                        dr["PN_PROFESION"] = (objFormulario.FOPVC_PN_PROFESION ?? string.Empty);
                        dr["ACTIVIDAD"] = (objFormulario.FOPVC_ACTIVIDAD ?? string.Empty);
                        dr["PN_LUGAR_TRABAJO"] = (objFormulario.FOSVC_PN_LUGAR_TRABAJO ?? string.Empty);
                        dr["PN_CARGO"] = (objFormulario.FOSVC_PN_CARGO ?? string.Empty);
                        dr["PN_DIRECCION_TRABAJO"] = (objFormulario.FOSVC_PN_DIRECCION_TRABAJO ?? string.Empty);
                        dr["PJ_NIT"] = (objFormulario.FOPVC_PJ_NIT ?? string.Empty);
                        dr["PJ_RAZON_SOCIAL"] = (objFormulario.FOPVC_PJ_RAZON_SOCIAL ?? string.Empty);
                        dr["CIUDAD"] = (objFormulario.FOPVC_CIUDAD ?? string.Empty);
                        dr["DIRECCION"] = (objFormulario.FOPVC_DIRECCION ?? string.Empty);
                        dr["ZONA"] = (objFormulario.FOPVC_ZONA ?? string.Empty);                        
                        dr["TELEFONO"] = (objFormulario.FOPVC_TELEFONO ?? string.Empty);
                        dr["TIPO_OPERACION"] = (objFormulario.FOPVC_TIPO_OPERACION ?? string.Empty);
                        dr["NATURALEZA_OPERACION"] = (objFormulario.FOPVC_NATURALEZA_OPERACION ?? string.Empty);
                        dr["TIPO_SEGURO"] = (objFormulario.FOSVC_TIPO_SEGURO ?? string.Empty);
                        dr["CODIGO_PLAZO_SEGURO"] = (objFormulario.FOPVC_CODIGO_PLAZO_SEGURO ?? string.Empty);
                        dr["CODIGO_RAMO"] = (objFormulario.FOSVC_CODIGO_RAMO ?? string.Empty);
                        dr["MONEDA"] = (objFormulario.FOPVC_MONEDA ?? string.Empty);
                        dr["MONTO"] = objFormulario.FOPDC_MONTO.ToString();
                        dr["NOMBRE_CORREDOR"] = (objFormulario.FOSVC_NOMBRE_CORREDOR ?? string.Empty);
                        dr["NOMBRE_TOMADOR"] = (objFormulario.FOPVC_NOMBRE_TOMADOR ?? string.Empty);
                        dr["NOMBRE_INTERMEDIARIO"] = (objFormulario.FOSVC_NOMBRE_INTERMEDIARIO ?? string.Empty);                        
                        dr["NUMERO_POLIZA"] = (objFormulario.FOPVC_NUMERO_POLIZA ?? string.Empty);
                        dr["NUMERO_CUENTA"] = (objFormulario.FOSVC_NUMERO_CUENTA ?? string.Empty);
                        dr["CODIGO_ENTIDAD_FINANCIERA"] = (objFormulario.FOSBI_CODIGO_ENTIDAD_FINANCIERA.ToString() ?? string.Empty);
                        dr["NUMERO_CHEQUE"] = (objFormulario.FOSVC_NUMERO_CHEQUE ?? string.Empty);
                        //dr["REPOSICION"] = (objFormulario.FOSVC_REPOSICION ?? string.Empty);
                        dr["ORIGEN_RECURSOS"] = (objFormulario.FOPVC_ORIGEN_RECURSOS ?? string.Empty);
                        dr["DESTINO_RECURSOS"] = (objFormulario.FOPVC_DESTINO_RECURSOS ?? string.Empty);
                        dr["DECLARANTE_NOMBRE"] = (objFormulario.FOSVC_DECLARANTE_NOMBRE ?? string.Empty);
                        dr["DECLARANTE_DOCUMENTO_NUMERO"] = (objFormulario.FOSVC_DECLARANTE_DOCUMENTO_NUMERO ?? string.Empty);
                        dr["DECLARANTE_DOCUMENTO_EXTENSION"] = (objFormulario.FOSVC_DECLARANTE_DOCUMENTO_EXTENSION ?? string.Empty);
                        dr["DECLARANTE_CARGO"] = (objFormulario.FOSVC_DECLARANTE_CARGO ?? string.Empty);
                        dr["OBSERVACIONES"] = (objFormulario.FOSVC_OBSERVACIONES ?? string.Empty);
                        DtblFormulario.Rows.Add(dr);
                    }
                    return DtblFormulario;
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
        public DataSet FormularioPCC04_ProduccionBancaSeguros(string strPeriodo, string strIdProducto)
        {
            try
            {
                var objRequest = new FormularioPCC04_ProduccionBancaSegurosRequest
                {
                    strPeriodo = strPeriodo,
                    strIdProducto = strIdProducto,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.FormularioPCC04_ProduccionBancaSeguros(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.FormularioPCC04_ProduccionBancaSegurosResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region ALERTA
        public List<ALERTA> ObtenerListaAlertas()
        {
            try
            {
                var objRequest = new ObtenerListaAlertasRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.ObtenerListaAlertas(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ObtenerListaAlertasResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DesactivarAlerta(ALERTA objAlerta)
        {
            try
            {
                var objRequest = new DesactivarAlertaRequest();
                objRequest.objAlerta = objAlerta;
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.DesactivarAlerta(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DesactivarAlertaResult;
            }
            catch
            {
                throw;
            }
        }
        public ALERTA AgregarAlerta(ALERTA objAlerta)
        {
            try
            {
                var objRequest = new AgregarAlertaRequest();
                objRequest.objAlerta = objAlerta;
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.AgregarAlerta(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.AgregarAlertaResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ActualizarAdjuntoAlerta(long longIdAlerta, List<occ_correo_archivo_adjunto> listaAdjuntosAlerta)
        {
            try
            {
                var objRequest = new ActualizarAdjuntoAlertaRequest();
                objRequest.longIdAlerta = longIdAlerta;
                objRequest.listaAdjuntosAlerta = listaAdjuntosAlerta;
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.ActualizarAdjuntoAlerta(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ActualizarAdjuntoAlertaResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region RESERVAS TECNICAS
        public DataSet DatosValidacionReservasTecnicas(string strPeriodoContable, string strRamo)
        {
            try
            {
                var objRequest = new DatosValidacionReservasTecnicasRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strRamo = strRamo,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioPersonales.DatosValidacionReservasTecnicas(objRequest);
                if (response.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = response.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return response.DatosValidacionReservasTecnicasResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region ANULACIONES
        public DataSet Anulacion_Bandeja(string strPeriodoContable, bool boolFlagBCP)
        {
            try
            {
                var objRequest = new Anulacion_BandejaRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    boolFlagBCP = boolFlagBCP,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Anulacion_Bandeja(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_BandejaResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet Anulacion_Buscar(string strTipo, string strIdProducto, string strNumeroPoliza, string strCertificado, DateTime dtFechaAfiliacion, string strDocumentoNumero, string strNombre, string strIdAfiliacion, bool boolFlagBCP)
        {
            try
            {
                var objRequest = new Anulacion_BuscarRequest()
                {
                    strTipo = strTipo,
                    strIdProducto = strIdProducto,
                    strNumeroPoliza = strNumeroPoliza,
                    strCertificado = strCertificado,
                    dtFechaAfiliacion = dtFechaAfiliacion,
                    strDocumentoNumero = strDocumentoNumero,
                    strNombre = strNombre,
                    strIdAfiliacion = strIdAfiliacion,
                    boolFlagBCP = boolFlagBCP,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Anulacion_Buscar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_BuscarResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region NEMESIS
        public List<SPR_GETLIST_NEMESIS_PN_Result> GetListaAfilacionesReporte13PN(DateTime? dtFechaDesde, DateTime? dtFechaHasta, string strIdCliente)
        {
            try
            {
                var objRequest = new GetListaAfilacionesReporte13PNRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.dtFechaDesde = dtFechaDesde;
                objRequest.dtFechaHasta = dtFechaHasta;
                objRequest.strIdCliente = strIdCliente;

                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaAfilacionesReporte13PN(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaAfilacionesReporte13PNResult;
            }
            catch
            {
                throw;
            }
        }

        public List<SPR_GETLIST_NEMESIS_PJ_Result> GetListaAfilacionesReporte13PJ(DateTime? dtFechaDesde, DateTime? dtFechaHasta, string strNit)
        {
            try
            {
                var objRequest = new GetListaAfilacionesReporte13PJRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
                objRequest.dtFechaDesde = dtFechaDesde;
                objRequest.dtFechaHasta = dtFechaHasta;
                objRequest.strNit = strNit;

                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioPersonales.GetListaAfilacionesReporte13PJ(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListaAfilacionesReporte13PJResult;
            }
            catch
            {
                throw;
            }
        }

        public SPWB_REGISTRAR_CARTA_NEMESIS_Result RegistrarCartaNemesis(CARTA_NEMESIS objCartaNemesis)
        {
            try
            {
                var objRequest = new RegistrarCartaNemesisRequest()
                {
                    objCartaNemesis = objCartaNemesis,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.RegistrarCartaNemesis(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.RegistrarCartaNemesisResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region SERVICIOS EXTERNOS
        public occ_amlc AMLC_ComsultaListasInternacionales(
            string strDocumentoTipo,
            string strDocumentoNumero,
            string strDocumentoComplemento,
            string strApellidoPaterno,
            string strApellidoMaterno,
            string strNombres)
        {
            try
            {
                var objRequest = new AMLC_ComsultaListasInternacionalesRequest()
                {
                    strDocumentoTipo = strDocumentoTipo,
                    strDocumentoNumero = strDocumentoNumero,
                    strDocumentoComplemento = strDocumentoComplemento,
                    strApellidoPaterno = strApellidoPaterno,
                    strApellidoMaterno = strApellidoMaterno,
                    strNombres = strNombres,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.AMLC_ComsultaListasInternacionales(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.AMLC_ComsultaListasInternacionalesResult;
            }
            catch(Exception ex)
            {
                throw;
            }
        }

		public occ_amlc_pj AMLC_ComsultaListasInternacionalesPJ(
			string strNumeroNit,
			string strRazonSocial)
		{
			try
			{
				var objRequest = new AMLC_ComsultaListasInternacionalesPJRequest()
				{
					strNumeroNit = strNumeroNit,
					strRazonSocial = strRazonSocial,
					objCredenciales = new CParametros().GetCredencialesPersonales(),
					ValidationResult = new CRSValidationResult()
				};
				var objResponse = _servicioPersonales.AMLC_ComsultaListasInternacionalesPJ(objRequest);
				if (objResponse.ValidationResult.Error)
				{
					HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.AMLC_ComsultaListasInternacionalesPJResult;
			}
			catch
			{
				throw;
			}
		}
		#endregion

		#region Respaldo Compliance
		public RESPALDO_COMPLIANCE RespaldoComplianceRegistrar(RESPALDO_COMPLIANCE objRespaldoCompliance)
		{
			try
			{
				var objRequest = new RespaldoComplianceRegistrarRequest();
				objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
				objRequest.ValidationResult = new CRSValidationResult();
				objRequest.objRespaldoCompliance = objRespaldoCompliance;
				var response = _servicioPersonales.RespaldoComplianceRegistrar(objRequest);
				new CParametrosComplejos().ValidationResult(response);
				return response.RespaldoComplianceRegistrarResult;
			}
			catch
			{
				throw;
			}
		}
		#endregion
		#region  Archivo contable y Archivos regulatorios
		public List<SPR_GET_ARCHIVO_CONTABLE_CARGADO_Result> GetArchivoContableCargado(string strPeriodo)
		{
			try
			{
				var objRequest = new GetArchivoContableCargadoRequest();
				objRequest.objCredenciales = new CParametros().GetCredencialesPersonales();
				objRequest.ValidationResult = new CRSValidationResult();
				objRequest.strPeriodo = strPeriodo;
				var response = _servicioPersonales.GetArchivoContableCargado(objRequest);
				new CParametrosComplejos().ValidationResult(response);
				return response.GetArchivoContableCargadoResult;
			}
			catch
			{
				throw;
			}
		}
        #endregion
        #region Contabilidad
        public bool Contabilidad_ValidarCarga(string strPeriodo)
        {
            try
            {
                var objRequest = new Contabilidad_ValidarCargaRequest
                {
                    strPeriodo = strPeriodo,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Contabilidad_ValidarCarga(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ValidarCargaResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Contabilidad_Registrar(List<CONTABILIDAD> listaContabilidad)
        {
            try
            {
                var objRequest = new Contabilidad_RegistrarRequest
                {
                    listaContabilidad = listaContabilidad,
                    objCredenciales = new CParametros().GetCredencialesPersonales(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioPersonales.Contabilidad_Registrar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}