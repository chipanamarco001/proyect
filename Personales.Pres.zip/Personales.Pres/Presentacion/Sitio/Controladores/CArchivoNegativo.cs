﻿using Agente;
using Agente.ServicioArchivoNegativo;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Web;

namespace Presentacion.Sitio.Controladores
{
    public class CArchivoNegativo
    {
        #region Configuracion Inicial
        private readonly IServicioNotasAps _iServicioArchivoNegativo = LocalizadorProxy.ServicioArchivoNegativo();
        public CREDENCIALES CredencialActual()
        {
            try
            {
                var objCredencial = new CREDENCIALES()
                {
                    USUARIO = new CParametros().GetCurrentUser(),
                    IP = new CParametros().GetCurrentIp(),
                    BROKER = string.Empty,
                    ENTIDAD = string.Empty,
                    TOMADOR = string.Empty
                };
                return objCredencial;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        public List<ARCHIVO_NEGATIVO> BuscarArchivoNegativo(string strNroDocumento)
        {
            try
            {
                var objRequest = new GetListArchivoNegativoByNroDocumentoRequest()
                {
                    strNroDocumento = strNroDocumento,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.GetListArchivoNegativoByNroDocumento(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.GetListArchivoNegativoByNroDocumentoResult;
            }
            catch
            {
                throw;
            }
        }
        public ARCHIVO_NEGATIVO GetArchivoNegativoById(long IdArchivoNegativo)
        {
            try
            {
                GetArchivoNegativoByIdRequest request = new GetArchivoNegativoByIdRequest(IdArchivoNegativo, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.GetArchivoNegativoById(request);
                return response.GetArchivoNegativoByIdResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> AgregarListaArchivoNegativo(List<ARCHIVO_NEGATIVO> lstArchivoNegativo)
        {
            try
            {
                AgregarListaArchivoNegativoRequest request = new AgregarListaArchivoNegativoRequest(lstArchivoNegativo, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.AgregarListaArchivoNegativo(request);
                return response.AgregarListaArchivoNegativoResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> GetListArchivoNegativoByNroDocumento(string strNroDocumento)
        {
            try
            {
                GetListArchivoNegativoByNroDocumentoRequest request = new GetListArchivoNegativoByNroDocumentoRequest(strNroDocumento, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.GetListArchivoNegativoByNroDocumento(request);
                return response.GetListArchivoNegativoByNroDocumentoResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> GetListArchivoNegativo(string strNroDocumento, string strPaterno, string strMaterno, string strNombre, string strAplicativo)
        {
            try
            {
                GetListArchivoNegativoRequest request = new GetListArchivoNegativoRequest(strNroDocumento, strPaterno, strMaterno, strNombre, strAplicativo, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.GetListArchivoNegativo(request);
                return response.GetListArchivoNegativoResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> GetListArchivoNegativoActivoInactivo(string strNroDocumento, string strPaterno, string strMaterno, string strNombre, string strAplicativo)
        {
            try
            {
                var request = new GetListArchivoNegativoActivoInactivoRequest(strNroDocumento, strPaterno, strMaterno, strNombre, strAplicativo, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.GetListArchivoNegativoActivoInactivo(request);
                return response.GetListArchivoNegativoActivoInactivoResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<SPWB_GET_LIST_BUSCA_CLIENTE_Result> GetListBeneficiarios(string strIdc, string strPaterno, string strMaterno)
        {
            try
            {
                GetListBeneficiariosRequest request = new GetListBeneficiariosRequest(strIdc, strPaterno, strMaterno, CredencialActual(), new CRSValidationResult());
                var response = _iServicioArchivoNegativo.GetListBeneficiarios(request);
                return response.GetListBeneficiariosResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async System.Threading.Tasks.Task<AgregarListaArchivoNegativoResponse> AgregarListaArchivoNegativoAsync(List<ARCHIVO_NEGATIVO> lstArchivoNegativo)
        {
            try
            {
                AgregarListaArchivoNegativoRequest request = new AgregarListaArchivoNegativoRequest();
                request.objArchivoNegativo = new List<ARCHIVO_NEGATIVO>();
                request.objCredenciales = CredencialActual();
                request.ValidationResult = new CRSValidationResult();
                request.objArchivoNegativo = lstArchivoNegativo;
                var response = _iServicioArchivoNegativo.AgregarListaArchivoNegativoAsync(request);
                return await response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> AgregarArchivoNegativo(List<ARCHIVO_NEGATIVO> objArchivoNegativo)
        {
            try
            {
                var objRequest = new AgregarListaArchivoNegativoRequest()
                {
                    objArchivoNegativo = objArchivoNegativo,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.AgregarListaArchivoNegativo(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.AgregarListaArchivoNegativoResult;
            }
            catch
            {
                throw;
            }
        }









        #region LEXICO
        public List<LEXICO> Lexico_ObtenerLista()
        {
            try
            {
                var objRequest = new Lexico_ObtenerListaRequest()
                {
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.Lexico_ObtenerLista(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_ObtenerListaResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region ARCHIVO NEGATIVO
        public List<ARCHIVO_NEGATIVO> ArchivoNegativo_ListaUsuario()
        {
            try
            {
                var objRequest = new ArchivoNegativo_ListaUsuarioRequest()
                {
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_ListaUsuario(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_ListaUsuarioResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ArchivoNegativo_Validar(string strDocumentoNumero, string strDocumentoComplemento)
        {
            try
            {
                var objRequest = new ArchivoNegativo_ValidarRequest()
                {
                    strDocumentoNumero = strDocumentoNumero,
                    strDocumentoComplemento = strDocumentoComplemento,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_Validar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_ValidarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> ArchivoNegativo_ListaAutorizacion(string strCorreo)
        {
            try
            {
                var objRequest = new ArchivoNegativo_ListaAutorizacionRequest()
                {
                    strCorreo = strCorreo,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_ListaAutorizacion(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_ListaAutorizacionResult;
            }
            catch
            {
                throw;
            }
        }
        public ARCHIVO_NEGATIVO ArchivoNegativo_Agregar(ARCHIVO_NEGATIVO objArchivoNegativo)
        {
            try
            {
                var objRequest = new ArchivoNegativo_AgregarRequest()
                {
                    objArchivoNegativo = objArchivoNegativo,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_Agregar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_AgregarResult;
            }
            catch
            {
                throw;
            }
        }
        public ESTADO_HISTORICO EstadoHistorico_Agregar(ESTADO_HISTORICO objEstadoHistorico)
        {
            try
            {
                var objRequest = new EstadoHistorico_AgregarRequest()
                {
                    objEstadoHistorico = objEstadoHistorico,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.EstadoHistorico_Agregar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.EstadoHistorico_AgregarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> ArchivoNegativo_ListaActiva(string strDocumentoNumero, string strApellidoPaterno, string strApellidoMaterno, string strNombres)
        {
            try
            {
                var objRequest = new ArchivoNegativo_ListaActivaRequest()
                {
                    strDocumentoNumero = strDocumentoNumero,
                    strApellidoPaterno = strApellidoPaterno,
                    strApellidoMaterno = strApellidoMaterno,
                    strNombres = strNombres,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_ListaActiva(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_ListaActivaResult;
            }
            catch
            {
                throw;
            }
        }
        public List<ARCHIVO_NEGATIVO> ArchivoNegativo_ListaHistorico(string strDocumentoNumero)
        {
            try
            {
                var objRequest = new ArchivoNegativo_ListaHistoricoRequest()
                {
                    strDocumentoNumero = strDocumentoNumero,
                    objCredenciales = CredencialActual(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _iServicioArchivoNegativo.ArchivoNegativo_ListaHistorico(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ArchivoNegativo_ListaHistoricoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}