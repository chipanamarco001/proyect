﻿using Agente;
using Agente.ServicioCoreDocumentos;
using Agente.ServicioDocumentos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Presentacion.Sitio.Controladores.CoreDocumentos
{
    public class CCoreDocumentos
    {
     
        private readonly Agente.ServicioCoreDocumentos.IServicioDocumentos _servicioCoreDocumentos = (Agente.ServicioCoreDocumentos.IServicioDocumentos)LocalizadorProxy.ServicioCoreDocumentos();

        public byte[] FirmarDocumentos(byte[] documento, string strIdUsuario)
        {
            try
            {


                var objCredencial = new Agente.ServicioCoreDocumentos.CREDENCIALES()
                {

                    USUARIO = strIdUsuario,
                    IP = "1.1.1.1",
                    ENTIDAD = string.Empty,
                    TOMADOR = string.Empty,
                    BROKER = string.Empty

                };

                var objVerificacion = new CrsValidationResult
                {
                    IsValid = true,
                    ValidationErrors = new List<Agente.ServicioCoreDocumentos.ListErrors>()
                };
                var objRequest = new FirmarDocumentoPdfBRequest();
                objRequest.strEntidad = "PERSONALES";
                objRequest.btArchivo = documento;
                objRequest.objCredenciales = objCredencial;
                objRequest.ValidationResult = objVerificacion;

                var objResponse = _servicioCoreDocumentos.FirmarDocumentoPdfB(objRequest);

                return objResponse.FirmarDocumentoPdfBResult;

            }
            catch
            {
                throw;
            }
        }
    }
}