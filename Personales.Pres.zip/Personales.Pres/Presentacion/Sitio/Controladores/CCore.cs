﻿using Agente;
using Agente.ServicioCore;
using System;
using System.Web;

namespace Presentacion.Sitio.Controladores
{
    public class CCore
    {
        private readonly IServicioCore _servicioCore = LocalizadorProxy.ServicioCore();
        public occ_usuario DatosDirectorioActivo(string strIdUsuario)
        {
            try
            {
                var objRequest = new DatosDirectorioActivoRequest()
                {
                    strIdUsuario = strIdUsuario,
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCore.DatosDirectorioActivo(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DatosDirectorioActivoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ValidarAutenticacion(string strIdUsuario, string strPassword)
        {
            try
            {
                var objRequest = new ValidarAutenticacionRequest()
                {
                    strIdUsuario = strIdUsuario,
                    strPassword = strPassword,
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCore.ValidarAutenticacion(objRequest);
                return objResponse.ValidarAutenticacionResult;
            }
            catch
            {
                throw;
            }
        }
        public decimal ObtenerTipoCambioERP()
        {
            try
            {
                return _servicioCore.ObtenerTipoCambioERP("USD", DateTime.Today, "COMPRA");
            }
            catch
            {
                throw;
            }
        }
        public decimal TipoCambio_Obtener(string strMoneda, DateTime dtFecha, string strTipo)
        {
            try
            {
                return _servicioCore.ObtenerTipoCambioERP(strMoneda, dtFecha, strTipo);
            }
            catch
            {
                throw;
            }
        }
    }
}