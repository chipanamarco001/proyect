﻿using Agente.ServicioApi.ApiFacturacion.Dto;
using Agente.ServicioCrsApi.ApiFacturacion;
using Agente.ServicioCrsApi.ApiFacturacion.Dto;
using Agente.ServicioCrsApi.CrsApiConfig;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using System.Web;

namespace Presentacion.Sitio.Controladores.ApiFacturacion
{
    public class FacturacionController
    {
        private readonly IHttpClientService _facturacion = new HttpClientService();

        public async Task<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>> ObtenerFacturasPorFechasEstado(SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request data)
        {

            var result = new CrsApiResponse<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>();
            try
            {
                var urlBase = ParametrosFacturacion.ObtenerFacturasPorFechasEstado;
                CParametros cParameters = new CParametros();
                var credentials = new OcCredenciales()
                {
                    usuario = cParameters.GetCurrentUser(),
                    ip = cParameters.GetCurrentIp(),
                    contraseña = ParametrosFacturacion.ContraseñaAplicativo
                };
                var request = new CrsApiRequest<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request>
                {
                    solicitud = data,
                    credenciales = credentials
                };
                result = await _facturacion.PostAsync<CrsApiRequest<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request>, List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>(urlBase, request).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception ex)
            {
               // await RegistrarError(ex, credentials);
            }
            return null;
        }

        #region Lexico
                
        public async Task<List<LexicoResponse>> ObtenerListaLexicoPorTablaTema(LexicoTablaTemaRequest data)
        {

            var result = new CrsApiResponse<List<LexicoResponse>>();
            CParametros cParameters = new CParametros();
            var credentials = new OcCredenciales()
            {
                usuario = cParameters.GetCurrentUser(),
                ip = cParameters.GetCurrentIp(),
                contraseña = ParametrosFacturacion.ContraseñaAplicativo
            };
            try
            {
                var urlBase = ParametrosFacturacion.ObtenerListaLexicoPorTablaTema;     
                var request = new CrsApiRequest<LexicoTablaTemaRequest>
                {
                    solicitud = data,
                    credenciales = credentials
                };
                result = await _facturacion.PostAsync<CrsApiRequest<LexicoTablaTemaRequest>, List<LexicoResponse>>(urlBase, request).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null? "Error en consumo de servicio": result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception ex)
            {
                //await RegistrarError(ex, credentials);
                throw;
            }
            return null;
        }

        #endregion

        #region Errores

        public async Task<ErrorRespuestaDto> RegistrarError(Exception ex, OcCredenciales credentials)
        {
            try
            {
                StackTrace trace = new StackTrace(ex, true);
                StackFrame frame = trace.GetFrame(trace.FrameCount - 1);
                MethodBase method = frame.GetMethod();
                var registrarErrorRequest = new ErrorRegistrarDto
                {
                    mensaje = ex.Message,
                    innerException = ex.InnerException?.ToString(),
                    stackTrace = ex.StackTrace,
                    metodo = frame.GetMethod().Name,
                    pagina = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"
                };

                var urlBase = ParametrosFacturacion.urlSaveError;
                CParametros cParameters = new CParametros();                
                var request = new CrsApiRequest<ErrorRegistrarDto>
                {
                    solicitud = registrarErrorRequest,
                    credenciales = credentials
                };
                var result = await _facturacion.PostAsync<CrsApiRequest<ErrorRegistrarDto>, ErrorRespuestaDto>(urlBase, request, null).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception)
            {
                throw;
            }

        }

        #endregion

        #region Facturas

        public async Task<GenerarArchivCsvResponse> RegistrarFacturacion(List<ActFacturasDto> data)
        {
            var result = new CrsApiResponse<GenerarArchivCsvResponse>();
            CParametros cParameters = new CParametros();
            var credentials = new OcCredenciales()
            {
                usuario = cParameters.GetCurrentUser(),
                ip = cParameters.GetCurrentIp(),
                contraseña = ParametrosFacturacion.ContraseñaAplicativo
            };
            try
            {
                var urlBase = ParametrosFacturacion.RegistrarFacturacion;                
                var request = new CrsApiRequest<List<ActFacturasDto>>
                {
                    solicitud = data,
                    credenciales = credentials
                };

                // Fixing the syntax errors and type issues
                result = await _facturacion.PostAsync<CrsApiRequest<List<ActFacturasDto>>, GenerarArchivCsvResponse>(urlBase, request).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception ex)
            {
                //await RegistrarError(ex, credentials);
                throw;
            }
            return null;
        }

        public async Task<GenerarArchivCsvResponse> ObtenerArchivoCsvIdLote(CsvLoteDto data)
        {
            var result = new CrsApiResponse<GenerarArchivCsvResponse>();
            CParametros cParameters = new CParametros();
            var credentials = new OcCredenciales()
            {
                usuario = cParameters.GetCurrentUser(),
                ip = cParameters.GetCurrentIp(),
                contraseña = ParametrosFacturacion.ContraseñaAplicativo
            };
            try
            {
                var urlBase = ParametrosFacturacion.ObtenerArchivoCsvIdLote;               
                var request = new CrsApiRequest<CsvLoteDto>
                {
                    solicitud = data,
                    credenciales = credentials
                };

                // Fixing the syntax errors and type issues
                result = await _facturacion.PostAsync<CrsApiRequest<CsvLoteDto>, GenerarArchivCsvResponse>(urlBase, request).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception ex)
            {
                //await RegistrarError(ex, credentials);
                throw;
            }
            return null;
        }

        public async Task<RespActFacturasDto> RegistrarAnulacion(List<ActFacturasDto> data)
        {
            var result = new CrsApiResponse<RespActFacturasDto>();
            CParametros cParameters = new CParametros();
            var credentials = new OcCredenciales()
            {
                usuario = cParameters.GetCurrentUser(),
                ip = cParameters.GetCurrentIp(),
                contraseña = ParametrosFacturacion.ContraseñaAplicativo
            };
            try
            {
                var urlBase = ParametrosFacturacion.RegistrarAnulacion;                
                var request = new CrsApiRequest<List<ActFacturasDto>>
                {
                    solicitud = data,
                    credenciales = credentials
                };

                // Fixing the syntax errors and type issues
                result = await _facturacion.PostAsync<CrsApiRequest<List<ActFacturasDto>>, RespActFacturasDto>(urlBase, request).ConfigureAwait(false);
                if (result == null)
                {
                    return null;
                }
                if (result.hasError)
                {
                    throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
                }
                return result.result;
            }
            catch (Exception ex)
            {
                //await RegistrarError(ex, credentials);
                throw;
            }
            return null;
        }


        #endregion

        #region Lote Facturas

        //public async Task<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>> ObtenerFacturasPorFechasEstado(SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request data)
        //{

        //    var result = new CrsApiResponse<List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>();
        //    try
        //    {
        //        var urlBase = ParametrosFacturacion.ObtenerFacturasPorFechasEstado;
        //        CParametros cParameters = new CParametros();
        //        var credentials = new OcCredenciales()
        //        {
        //            usuario = cParameters.GetCurrentUser(),
        //            ip = cParameters.GetCurrentIp(),
        //            contraseña = "tes"
        //        };
        //        var request = new CrsApiRequest<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request>
        //        {
        //            solicitud = data,
        //            credenciales = credentials
        //        };
        //        result = await _facturacion.PostAsync<CrsApiRequest<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Request>, List<SPR_OBTENER_FACTURACION_MASIVA_POR_FECHAS_ESTADO_Result>>(urlBase, request).ConfigureAwait(false);
        //        if (result == null)
        //        {
        //            return null;
        //        }
        //        if (result.hasError)
        //        {
        //            throw new Exception(result.messages.FirstOrDefault() == null ? "Error en consumo de servicio" : result.messages.FirstOrDefault().TechnicalMessage);
        //        }
        //        return result.result;
        //    }
        //    catch (Exception ex)
        //    {
        //        // await RegistrarError(ex, credentials);
        //    }
        //    return null;
        //}

        #endregion
    }
}