﻿using Agente;
using Agente.ServicioInfoUsuarios;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.Sitio.Controladores.InfoUsuarios
{
    public class CInfoUsuarios
    {
        private readonly IServicioInfoUsuarios _servicioInfoUsuarios = LocalizadorProxy.ServicioInfoUsuarios();
        public OC_USUARIOS GetObjUsuarioAdirectory(string strUserId)
        {
            //Log.Inicio();
            try
            {
                //Log.Debug("Accion: obtener usuario active directory por matricula; Recurso: servicio captado en Presentacion");
                var response = _servicioInfoUsuarios.GetUserInformation(strUserId, string.Empty, new CParametros().GetCredencialesInfoUsuarios());
                //Log.Fin();
                return response;
            }
            catch
            {
                //Log.Error(ex);
                //throw;
                return null;
            }
        }
        public bool GetConfirmAuthentication(string strMatricula, string strPassword)
        {
            //Log.Inicio();
            try
            {
                //Log.Debug("Accion: Verificacion de usuario por login y password; Recurso: servicio captado en Presentacion");

                var response = _servicioInfoUsuarios.GetConfirmAuthentication(strMatricula, strPassword, new CParametros().GetCredencialesInfoUsuarios());

                //Log.Fin();
                return response;
            }
            catch (Exception ex)
            {
                //Log.Error(ex);
                throw;
            }
        }
    }
}