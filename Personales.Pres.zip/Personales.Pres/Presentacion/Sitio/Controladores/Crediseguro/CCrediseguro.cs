﻿using Agente;
using Agente.ServicioCrediseguro;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;

namespace Presentacion.Sitio.Controladores.Crediseguro
{
    public class CCrediseguro
    {
        private readonly IServicioCrediseguro _servicioCrediseguro = LocalizadorProxy.ServicioCrediseguro();
        public DataSet GetDatasetProcedimiento(string strNombreProcedimiento, List<CParameter> ListaParametros)
        {
            try
            {
                var objRequest = new GetDatasetProcedimientoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                objRequest.strNombreProcedimiento = strNombreProcedimiento;
                objRequest.ListaParametros = ListaParametros;
                var response = _servicioCrediseguro.GetDatasetProcedimiento(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetDatasetProcedimientoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DERBCP_ReprocesarRecargos(string strPeriodoContable)
        {
            try
            {
                var objRequest = new DERBCP_ReprocesarRecargosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.DERBCP_ReprocesarRecargos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DERBCP_ReprocesarRecargosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool SEGDES_ReprocesarRecargos(string strPeriodoContable)
        {
            try
            {
                var objRequest = new SEGDES_ReprocesarRecargosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.SEGDES_ReprocesarRecargos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.SEGDES_ReprocesarRecargosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DERBCP_RegistrarRecargo(string strPeriodoContable, string strOperacion, decimal decSaldoDeudorUSD, decimal decInteresDevengadoUSD)
        {
            try
            {
                var objRequest = new DERBCP_RegistrarRecargoRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strOperacion = strOperacion;
                objRequest.decSaldoDeudorUSD = decSaldoDeudorUSD;
                objRequest.decInteresDevengadoUSD = decInteresDevengadoUSD;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.DERBCP_RegistrarRecargo(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DERBCP_RegistrarRecargoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool SEGDES_RegistrarRecargo(string strPeriodoContable, string strOperacion, decimal decSaldoDeudorUSD, decimal decInteresDevengadoUSD)
        {
            try
            {
                var objRequest = new SEGDES_RegistrarRecargoRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strOperacion = strOperacion;
                objRequest.decSaldoDeudorUSD = decSaldoDeudorUSD;
                objRequest.decInteresDevengadoUSD = decInteresDevengadoUSD;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.SEGDES_RegistrarRecargo(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.SEGDES_RegistrarRecargoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool VGESCO_RegistrarDatos(string strPeriodoContable, bool boolReproceso, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new VGESCO_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.boolReproceso = boolReproceso;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.strWorksheet = strWorksheet;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.VGESCO_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.VGESCO_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ECOMEV_RegistrarDatos(string strPeriodoContable, bool boolReproceso, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new ECOMEV_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.boolReproceso = boolReproceso;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.strWorksheet = strWorksheet;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.ECOMEV_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ECOMEV_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool BCP_RegistrarDatos(string strPeriodoContable, string strIdProducto)
        {
            try
            {
                var objRequest = new BCP_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strIdProducto = strIdProducto;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.BCP_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.BCP_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool BCP_DesgravamenCapitalConstante(string strPeriodoContable)
        {
            try
            {
                var objRequest = new BCP_DesgravamenCapitalConstanteRequest
                {
                    strPeriodoContable = strPeriodoContable,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };                
                var response = _servicioCrediseguro.BCP_DesgravamenCapitalConstante(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.BCP_DesgravamenCapitalConstanteResult;
            }
            catch
            {
                throw;
            }
        }
        public bool SEGECP_RegistrarDatos(string strPeriodoContable, bool boolReproceso, string strNombreArchivo)
        {
            try
            {
                var objRequest = new SEGECP_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.boolReproceso = boolReproceso;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.SEGECP_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.SEGECP_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool SEGECV_RegistrarDatos(string strPeriodoContable, bool boolReproceso, string strNombreArchivo)
        {
            try
            {
                var objRequest = new SEGECV_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.boolReproceso = boolReproceso;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.SEGECV_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.SEGECV_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool VGESCO_GenerarCertificados(string strPeriodoContable)
        {
            try
            {
                var objRequest = new VGESCO_GenerarCertificadosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.VGESCO_GenerarCertificados(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.VGESCO_GenerarCertificadosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool RegistrarDatosDiaconiaVida(string strIdProducto, string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new RegistrarDatosDiaconiaVidaRequest() {
                    strIdProducto = strIdProducto,
                    strPeriodoContable = strPeriodoContable,
                    strNombreArchivo = strNombreArchivo,
                    strWorksheet = strWorksheet,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };                
                var response = _servicioCrediseguro.RegistrarDatosDiaconiaVida(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.RegistrarDatosDiaconiaVidaResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DESDIA_RegistrarDatos(string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new DESDIA_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.strWorksheet = strWorksheet;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.DESDIA_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DESDIA_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool EditarAnulacion(POLIZAS_ANULADAS objPolizaAnulada)
        {
            try
            {
                var objRequest = new EditarAnulacionRequest();
                objRequest.objPolizaAnulada = objPolizaAnulada;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.EditarAnulacion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.EditarAnulacionResult;
            }
            catch
            {
                throw;
            }
        }
        public bool EliminarAnulacion(POLIZAS_ANULADAS objPolizaAnulada)
        {
            try
            {
                var objRequest = new EliminarAnulacionRequest();
                objRequest.objPolizaAnulada = objPolizaAnulada;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.EliminarAnulacion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.EliminarAnulacionResult;
            }
            catch
            {
                throw;
            }
        }        
        public List<SPR_CORE_REPORTE_PRODUCCION_Result> ReporteProduccionPorGestion(string strPeriodoContable, string strTipo)
        {
            try
            {
                var objRequest = new ReporteProduccionPorGestionRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strTipo = strTipo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.ReporteProduccionPorGestion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ReporteProduccionPorGestionResult;
            }
            catch
            {
                throw;
            }
        }
        public bool CHKAVE_RegistrarDatos(string strPeriodoContable, bool boolReproceso, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new CHKAVE_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.boolReproceso = boolReproceso;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.strWorksheet = strWorksheet;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.CHKAVE_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.CHKAVE_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DESCSL_RegistrarDatos(string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new DESCSL_RegistrarDatosRequest() { 
                    strPeriodoContable = strPeriodoContable,
                    strNombreArchivo = strNombreArchivo,
                    strWorksheet = strWorksheet,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.DESCSL_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DESCSL_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DESECO_RegistrarDatos(string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new DESECO_RegistrarDatosRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strNombreArchivo = strNombreArchivo,
                    strWorksheet = strWorksheet,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.DESECO_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DESECO_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Ecofuturo_RegistrarDatos(string strPeriodoContable, string strIdProducto, string strNombreArchivo)
        {
            try
            {
                var objRequest = new Ecofuturo_RegistrarDatosRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strIdProducto = strIdProducto,
                    strNombreArchivo = strNombreArchivo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.Ecofuturo_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.Ecofuturo_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Ecofuturo_RegistrarAnulacion(string strPeriodoContable, string strIdProducto, string strNombreArchivo)
        {
            try
            {
                var objRequest = new Ecofuturo_RegistrarAnulacionRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strIdProducto = strIdProducto,
                    strNombreArchivo = strNombreArchivo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.Ecofuturo_RegistrarAnulacion(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.Ecofuturo_RegistrarAnulacionResult;
            }
            catch
            {
                throw;
            }
        }
        #region ANULACIONES
        public bool Anulacion_Registrar(POLIZAS_ANULADAS objAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_RegistrarRequest()
                {
                    objAnulacion = objAnulacion,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.Anulacion_Registrar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_Eliminar(long longIdAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_EliminarRequest()
                {
                    longIdAnulacion = longIdAnulacion,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.Anulacion_Eliminar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_EliminarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_Modificar(POLIZAS_ANULADAS objAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_ModificarRequest()
                {
                    objAnulacion = objAnulacion,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.Anulacion_Modificar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_ModificarResult;
            }
            catch
            {
                throw;
            }
        }
        public POLIZAS_ANULADAS Anulacion_ObtenerObjetoPorId(long longIdAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_ObtenerObjetoPorIdRequest()
                {
                    longIdAnulacion = longIdAnulacion,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.Anulacion_ObtenerObjetoPorId(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_ObtenerObjetoPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_RegistrarLista(List<POLIZAS_ANULADAS> listaAnulaciones)
        {
            try
            {
                var objRequest = new Anulacion_RegistrarListaRequest()
                {
                    listaAnulaciones = listaAnulaciones,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.Anulacion_RegistrarLista(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_RegistrarListaResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region DESBDP
        public bool DESBDP_RegistrarDatos(string strPeriodoContable)
        {
            try
            {
                var objRequest = new DESBDP_RegistrarDatosRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.DESBDP_RegistrarDatos(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DESBDP_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet DESBDP_BaseSeguimiento(string strPeriodo)
        {
            try
            {
                var objRequest = new DESBDP_BaseSeguimientoRequest()
                {
                    strPeriodo = strPeriodo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.DESBDP_BaseSeguimiento(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DESBDP_BaseSeguimientoResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet DESBDP_Validacion(string strPeriodo)
        {
            try
            {
                var objRequest = new DESBDP_ValidacionRequest()
                {
                    strPeriodo = strPeriodo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.DESBDP_Validacion(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DESBDP_ValidacionResult;
            }
            catch
            {
                throw;
            }
        }
        public bool DESBDP_RegistrarListaNegra(string strNombreArchivo)
        {
            try
            {
                var objRequest = new DESBDP_RegistrarListaNegraRequest()
                {
                    strNombreArchivo = strNombreArchivo,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.DESBDP_RegistrarListaNegra(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DESBDP_RegistrarListaNegraResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet DESBDP_ObtenerListaNegra()
        {
            try
            {
                var objRequest = new DESBDP_ObtenerListaNegraRequest()
                {
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioCrediseguro.DESBDP_ObtenerListaNegra(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DESBDP_ObtenerListaNegraResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion


        #region Desgravamen diaconia - capital constante

        public bool DESDIA_CAP_CONSTANTE_RegistrarDatos(string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new DESDIA_CAP_CONSTANTE_RegistrarDatosRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strNombreArchivo = strNombreArchivo;
                objRequest.strWorksheet = strWorksheet;
                objRequest.objCredenciales = new CParametros().GetCredencialesCrediseguro();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioCrediseguro.DESDIA_CAP_CONSTANTE_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.DESDIA_CAP_CONSTANTE_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }

        #endregion
        public bool VGTNEX_RegistrarDatos(string strPeriodoContable, string strNombreArchivo, string strWorksheet)
        {
            try
            {
                var objRequest = new VGTNEX_RegistrarDatosRequest()
                {
                    strPeriodoContable = strPeriodoContable,
                    strNombreArchivo = strNombreArchivo,
                    strWorksheet = strWorksheet,
                    objCredenciales = new CParametros().GetCredencialesCrediseguro(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioCrediseguro.VGTNEX_RegistrarDatos(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.VGTNEX_RegistrarDatosResult;
            }
            catch
            {
                throw;
            }
        }
    }
}