﻿using Agente;
using Agente.ServicioAzure;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;

namespace Presentacion.Sitio.Controladores.Azure
{
    public class CAzure
    {
        private readonly IServicioAzure _servicioAzure = LocalizadorProxy.ServicioAzure();
        public List<LEXICOS> GetListLexicosPorTablaYTema(string strTabla, string strTema)
        {
            try
            {
                var objRequest = new GetListLexicosPorTablaYTemaRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesAzure();
                objRequest.strTabla = strTabla;
                objRequest.strTema = strTema;
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioAzure.GetListLexicosPorTablaYTema(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListLexicosPorTablaYTemaResult;
            }
            catch
            {
                throw;
            }
        }
        public List<DENUNCIA_FORMULARIO> GetListDenunciaFormulario()
        {
            try
            {
                var objRequest = new GetListDenunciaFormularioRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesAzure();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioAzure.GetListDenunciaFormulario(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListDenunciaFormularioResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public DENUNCIA_FORMULARIO GetListChildDenunciaFormulario(long longIdDenunciaFormulario)
        {
            try
            {
                var objRequest = new GetListChildDenunciaFormularioRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesAzure();
                objRequest.longIdDenunciaFormulario = longIdDenunciaFormulario;
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioAzure.GetListChildDenunciaFormulario(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListChildDenunciaFormularioResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public DENUNCIA_DOCUMENTO ModificarDenunciaDocumento(DENUNCIA_DOCUMENTO objDenunciaDocumento)
        {
            try
            {
                var objRequest = new ModificarDenunciaDocumentoRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesAzure();
                objRequest.objDenunciaDocumento = objDenunciaDocumento;
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioAzure.ModificarDenunciaDocumento(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ModificarDenunciaDocumentoResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public List<SPWB_GETLIST_DENUNCIA_FORMULARIO_Result> GetListDenunciaFormularioReporte()
        {
            try
            {
                var objRequest = new GetListDenunciaFormularioReporteRequest();
                objRequest.objCredenciales = new CParametros().GetCredencialesAzure();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioAzure.GetListDenunciaFormularioReporte(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetListDenunciaFormularioReporteResult;
            }
            catch
            {
                throw;
            }
        }
        public List<DENUNCIA_DOCUMENTO> ListaArchivosDenunciaPorId(long longIdDenuncia)
        {
            try
            {
                var objRequest = new ListaArchivosDenunciaPorIdRequest()
                {
                    longIdDenuncia = longIdDenuncia,
                    objCredenciales = new CParametros().GetCredencialesAzure(),
                    ValidationResult = new CRSValidationResult()
                };
                var response = _servicioAzure.ListaArchivosDenunciaPorId(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.ListaArchivosDenunciaPorIdResult;
            }
            catch
            {
                throw;
            }
        }
    }
}