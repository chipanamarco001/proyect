﻿using Agente;
using Agente.ServicioARegulatorios;
using Agente.ServicioDocumentos;
using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.Web;
using CRSValidationResult = Agente.ServicioDocumentos.CRSValidationResult;

namespace Presentacion.Sitio.Controladores.Documentos
{
    public class CDocumentos
    {
        private readonly IServicioDocumentos _servicioDocumentos = LocalizadorProxy.ServicioDocumentos();
        public OC_RESPONSE_FILE GetDocumento(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetDocumentoRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetDocumento(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetDocumentoResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteReaseguroGrupales(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteReaseguroGrupalesRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteReaseguroGrupales(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteReaseguroGrupalesResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteReaseguroGenerico(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteReaseguroGenericoRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteReaseguroGenerico(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteReaseguroGenericoResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteReaseguroDesgravamen(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteReaseguroDesgravamenRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteReaseguroDesgravamen(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteReaseguroDesgravamenResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteProducto(string strIdProducto, string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteProductoRequest();
                objRequest.strIdProducto = strIdProducto;
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteProducto(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteProductoResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteRegulatorioTXT(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteRegulatorioTXTRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteRegulatorioTXT(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteRegulatorioTXTResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteNemesisCSV(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteNemesisCSVRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteNemesisCSV(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteNemesisCSVResult;
            }
            catch
            {
                throw;
            }
        }
        public string GetReporteAsientosContables(string strPeriodoContable, string strRutaRepositorio)
        {
            try
            {
                var objRequest = new GetReporteAsientosContablesRequest();
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.strRutaRepositorio = strRutaRepositorio;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteAsientosContables(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteAsientosContablesResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetFormularioPCC04(long longIdFormulario)
        {
            try
            {
                var objRequest = new GetFormularioPCC04Request{
                    longIdFormulario = longIdFormulario,
                    objCredenciales = new CParametros().GetCredencialesDocumentos(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioDocumentos.GetFormularioPCC04(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.GetFormularioPCC04Result;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteValidacionDesgravamen(string strIdProducto, string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteValidacionDesgravamenRequest();
                objRequest.strIdProducto = strIdProducto;
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objResponseFile = objResponseFile;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetReporteValidacionDesgravamen(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetReporteValidacionDesgravamenResult;
            }
            catch
            {
                throw;
            }
        }
        public List<OC_RESPONSE_FILE> GetLiquidacionDESBDP(string strIdDocumento, string strPeriodoContable)
        {
            try
            {
                var objRequest = new GetLiquidacionDESBDPRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.strPeriodoContable = strPeriodoContable;
                objRequest.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objRequest.ValidationResult = new CRSValidationResult();
                var response = _servicioDocumentos.GetLiquidacionDESBDP(objRequest);
                new CParametrosComplejos().ValidationResult(response);
                return response.GetLiquidacionDESBDPResult;
            }
            catch
            {
                throw;
            }
        }
        public string ReporteValidacionCesion(string strPeriodoContable)
        {
            try
            {
                var response = _servicioDocumentos.ReporteValidacionCesion(
                    new ReporteValidacionCesionRequest() {
                        strPeriodoContable = strPeriodoContable,
                        objCredenciales = new CParametros().GetCredencialesDocumentos(),
                        ValidationResult = new CRSValidationResult()
                });
                new CParametrosComplejos().ValidationResult(response);
                return response.ReporteValidacionCesionResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE CHKAVE_GenerarCertificados(string strIdDocumento, long longIdLiquidacion)
        {
            try
            {
                var objRequest = new CHKAVE_GenerarCertificadosRequest()
                {
                    strIdDocumento = strIdDocumento,
                    longIdLiquidacion = longIdLiquidacion,
                    objCredenciales = new CParametros().GetCredencialesDocumentos(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioDocumentos.CHKAVE_GenerarCertificados(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.CHKAVE_GenerarCertificadosResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE Documento_Generar(string strIdDocumento, List<occ_response_file__parametro> listaParametros)
        {
            try
            {
                var objRequest = new Documento_GenerarRequest()
                {
                    strIdDocumento = strIdDocumento,
                    listaParametros = listaParametros,
                    objCredenciales = new CParametros().GetCredencialesDocumentos(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioDocumentos.Documento_Generar(objRequest);
                if (objResponse.ValidationResult.Error)
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Documento_GenerarResult;
            }
            catch
            {
                throw;
            }
        }
        public OC_RESPONSE_FILE GetReporteCompliance(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
        {
            try
            {
                var objRequest = new GetReporteComplianceRequest() {
                    strIdDocumento = strIdDocumento,
                    listaParametros = listaParametros,
                    objResponseFile = objResponseFile,
                    objCredenciales = new CParametros().GetCredencialesDocumentos(),
                    ValidationResult = new CRSValidationResult()
                };
                var objResponse = _servicioDocumentos.GetReporteCompliance(objRequest);
                if (objResponse.ValidationResult.Error) 
                {
                    HttpContext.Current.Session["ERROR_LIST"] = objResponse.ValidationResult.ValidationErrors;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.GetReporteComplianceResult;
            }
            catch
            {
                throw;
            }
        }

        #region Archivos Regulatorios


        public OC_RESPONSE_FILE GetReportesArchivosRegulatorios(string strIdDocumento, List<CParameter> listaParametros, OC_RESPONSE_FILE objResponseFile)
            //(string strIdDocumento, DateTime datPeriodo, string strNombreArchivo, string strFormatoSalida)
        {
            IServicioDocumentos _servicioDocumentos = LocalizadorProxy.ServicioDocumentos();
            try
            {               
                var objPartesProduccion = new GetReportesArchivosRegulatoriosRequest();
                objPartesProduccion.strIdDocumento = strIdDocumento;
                objPartesProduccion.listaParametros = listaParametros;
                objPartesProduccion.objCredenciales = new CParametros().GetCredencialesDocumentos();
                objPartesProduccion.objResponseFile = objResponseFile;

                var response = _servicioDocumentos.GetReportesArchivosRegulatorios(objPartesProduccion);

                return response.GetReportesArchivosRegulatoriosResult;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                LocalizadorProxy.Close(_servicioDocumentos);
            }
        }

        #endregion
    }
}