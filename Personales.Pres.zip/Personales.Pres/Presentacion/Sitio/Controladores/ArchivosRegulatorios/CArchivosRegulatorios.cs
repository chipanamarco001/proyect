﻿using Agente.ServicioARegulatorios;
using Agente;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Presentacion.Parametros;
using Agente.ServicioDocumentos;

namespace Presentacion.Sitio.Controladores.ArchivosRegulatorios
{
	public class CArchivosRegulatorios
	{
		private readonly IServicioARegulatorios _servicioArchivosRegulatorios = LocalizadorProxy.ServicioARegulatorios();

        //public List<SPIN_REP_PARTES_PRODUCCION_PERSONALES_BS_Result> GetListPartesProduccionPersonalesBs(DateTime datPeriodo)
        //{
        //    IServicioARegulatorios _servicioARegulatorios = LocalizadorProxy.ServicioARegulatorios();
        //    try
        //    {                
        //        var response = _servicioARegulatorios.GetListPartesProduccionPersonalesBs(datPeriodo, new CParametros().GetCredencialesARegulatorios());
               
        //        return response;
        //    }
        //    catch (Exception ex)
        //    {               
        //        throw;
        //    }
        //    finally
        //    {
        //        LocalizadorProxy.Close(_servicioARegulatorios);
        //    }
        //}

    }
}