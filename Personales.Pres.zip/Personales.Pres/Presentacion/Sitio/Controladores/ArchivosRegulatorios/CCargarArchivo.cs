﻿using Agente.ServicioARegulatorios;
using Agente;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;
using Presentacion.Parametros;
using System.Data;
using System.Text;
using PresentacionWeb.Sitio.Entidades;
using DevExpress.XtraRichEdit;

namespace Presentacion.Sitio.Controladores.ArchivosRegulatorios
{
	public class CCargarArchivo
	{
		private readonly IServicioARegulatorios _servicioArchivoContabilidad = LocalizadorProxy.ServicioARegulatorios();

		public bool GetValidFile(OC_ARCHIVO fileupload, string strExtension, ref string strFileExtension)
		{
			try
			{
				//FileUpload fu = fileupload;
				if (fileupload.BYTE_ARRAY != null)
				{
					var extension = Path.GetExtension(fileupload.NOMBRE_ARCHIVO);
					if (extension != null)
					{
						String fileExtension = extension.ToLower();

						string[] allowedExtensions = strExtension.Split(',');
						foreach (string extensionSelected in allowedExtensions)
						{
							if (fileExtension == "." + extensionSelected.ToLower())
							{
								strFileExtension = fileExtension;
								return true;
							}
						}
					}
				}
				return false;
			}
			catch (Exception ex)
			{				
				throw;
			}

		}
		public string GuardarFileTemporal(string idUsuario, FileUpload file, string rutaArchivo, string strFileExtension)
		{
			try
			{
				if (File.Exists(rutaArchivo + idUsuario + strFileExtension)) { File.Delete(rutaArchivo + idUsuario + strFileExtension); }
				file.SaveAs(rutaArchivo + idUsuario + strFileExtension);
				return idUsuario + strFileExtension;
			}
			catch (Exception ex)
			{
				throw;
			}

		}

		public string GuardarFileTemporal(string idUsuario, OC_ARCHIVO file, string rutaArchivo, string strFileExtension)
		{
			try
			{
				if (File.Exists(rutaArchivo + idUsuario + strFileExtension)) { File.Delete(rutaArchivo + idUsuario + strFileExtension); }
				rutaArchivo = rutaArchivo + idUsuario + strFileExtension;

				RichEditDocumentServer objDocumentServer = new RichEditDocumentServer();
				byte[] documentBytes = file.BYTE_ARRAY;
				using (MemoryStream memoryStream = new MemoryStream(documentBytes))
				{
					objDocumentServer.LoadDocument(memoryStream, DevExpress.XtraRichEdit.DocumentFormat.OpenXml);
				}
				using (FileStream fileStream = new FileStream(rutaArchivo, FileMode.Create, FileAccess.Write))
				{
					objDocumentServer.SaveDocument(fileStream, DevExpress.XtraRichEdit.DocumentFormat.OpenXml);
				}
				objDocumentServer.Dispose();
				return idUsuario + strFileExtension;
			}
			catch (Exception ex)
			{
				throw;
			}

		}
		public List<COLUMNAS_ARCHIVOS> GetListColumnasByArchivo(string strIdArchivoContabilidad)
		{			
			try
			{				
				var response = _servicioArchivoContabilidad.GetListColumnasByArchivo(strIdArchivoContabilidad, true, new CParametros().GetCredencialesARegulatorios());
				
				return response;
			}
			catch (Exception ex)
			{				
				throw;
			}
		}
		public bool SaveArchivoRecibido(string strDestinationTableName, DataTable dtDataTable)
		{			
			try
			{
				dtDataTable.TableName = strDestinationTableName;
				//Log.Debug("Accion: Realiza el vaciado a la tablas temporales; Recurso: servicio captado en Presentacion");
				var response = _servicioArchivoContabilidad.SaveArchivoRecibido(strDestinationTableName, dtDataTable, new CParametros().GetCredencialesARegulatorios());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{				
				throw;
			}

		}
		public string GetDatatableFileTxt(string strRutaArchivo, string strNombreArchivo, List<COLUMNAS_ARCHIVOS> lstColumnas, ref DataTable dtblArchivoDetalle, ref List<string> lstErroresArchivo, ref List<string> linesError, string strIdArchivoContabilidad, char chrSeparador)
		{

			dtblArchivoDetalle.Clear();
			dtblArchivoDetalle.Dispose();

			foreach (COLUMNAS_ARCHIVOS oColumnas in lstColumnas)
			{
				if (oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_ID_USER_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APDT_FECHA_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_PERIODO")
				{
					dtblArchivoDetalle.Columns.Add(new DataColumn(oColumnas.CAVC_NOMBRE_COLUMNA));
				}

			}
			string[] registros = File.ReadAllLines(strRutaArchivo + strNombreArchivo, Encoding.UTF8);
			var countColumn = registros[0].Split(chrSeparador);

			for (int fila = 0; fila < registros.Count(); fila++)
			{

				string[] datos = registros[fila].Split(chrSeparador);
				DataRow dr = dtblArchivoDetalle.NewRow();
				for (int index = 0; index < dtblArchivoDetalle.Columns.Count; index++)
				{
					dr[index] = HttpUtility.HtmlDecode(datos[index]);


				}
				dtblArchivoDetalle.Rows.Add(dr);
			}
			return null;
		}

		public string GetDatatableFileTxtFile(OC_ARCHIVO file, List<COLUMNAS_ARCHIVOS> lstColumnas, ref DataTable dtblArchivoDetalle, ref List<string> lstErroresArchivo, char chrSeparador)
		{

			dtblArchivoDetalle.Clear();
			dtblArchivoDetalle.Dispose();

			foreach (COLUMNAS_ARCHIVOS oColumnas in lstColumnas)
			{
				if (oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_ID_USER_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APDT_FECHA_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_PERIODO")
				{
					dtblArchivoDetalle.Columns.Add(new DataColumn(oColumnas.CAVC_NOMBRE_COLUMNA));
				}

			}
			//string[] registros = File.ReadAllLines(strRutaArchivo + strNombreArchivo, Encoding.UTF8);
			//var countColumn = registros[0].Split(chrSeparador);

			//for (int fila = 0; fila < registros.Count(); fila++)
			//{

			//	string[] datos = registros[fila].Split(chrSeparador);
			//	DataRow dr = dtblArchivoDetalle.NewRow();
			//	for (int index = 0; index < dtblArchivoDetalle.Columns.Count; index++)
			//	{
			//		dr[index] = HttpUtility.HtmlDecode(datos[index]);


			//	}
			//	dtblArchivoDetalle.Rows.Add(dr);
			//}

			using (StreamReader sr = new StreamReader(new MemoryStream(file.BYTE_ARRAY)))
			{
				while (sr.Peek() > -1)
				{
					var readLine = sr.ReadLine();
					if (readLine != null)
					{
						object[] currentLine = readLine.Split(chrSeparador);
						dtblArchivoDetalle.Rows.Add(currentLine);
						//object[] currentLine = sr.ReadLine().Split(new char[] { '|' });
						//dt.Rows.Add(currentLine);
					}
				}
			}
			return null;
		}
	}
}