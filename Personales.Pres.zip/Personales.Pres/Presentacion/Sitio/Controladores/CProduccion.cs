﻿using Agente;
using System;
using System.Web;
using Agente.ServicioProduccion;
using System.Collections.Generic;

namespace Presentacion.Sitio.Controladores
{
    public class CProduccion
    {
        private readonly IServicioProduccion _iServicioProduccion = LocalizadorProxy.ServicioProduccion();
        private Credencial CredencialActual()
        {
            try
            {
                var objUsuario = (Agente.ServicioPersonales.occ_usuario)HttpContext.Current.Session["SessionUsuario"];
                var objCredencial = new Credencial()
                {
                    IdUsuario = objUsuario.Matricula,
                    IPv4 = ObtenerIPv4(),
                    Dispositivo = ObtenerDispositivo()
                };
                return objCredencial;
            }
            catch
            {
                throw;
            }
        }
        private string ObtenerIPv4()
        {
            try
            {
                string strIPv4 = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (string.IsNullOrEmpty(strIPv4))
                {
                    strIPv4 = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                }
                return strIPv4;
            }
            catch
            {
                throw;
            }
        }
        private string ObtenerDispositivo()
        {
            try
            {
                string strDispositivo = HttpContext.Current.Request.UserAgent.ToString().ToLower();
                if (string.IsNullOrEmpty(strDispositivo))
                    strDispositivo = HttpContext.Current.Request.Headers["User-Agent"];
                return strDispositivo;
            }
            catch
            {
                throw;
            }
        }
        public bool Correo_Enviar(occ_correo objCorreo)
        {
            try
            {
                var objRequest = new Correo_EnviarRequest()
                {
                    objCorreo = objCorreo,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioProduccion.Correo_Enviar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    var listaErrores = objResponse.objExcepciones.Errores;
                    List<Agente.ServicioPersonales.ListErrors> listaLocalErrores = new List<Agente.ServicioPersonales.ListErrors>();
                    foreach (var objError in listaErrores)
                    {
                        listaLocalErrores.Add(new Agente.ServicioPersonales.ListErrors {
                            ErrorMessage = objError.Mensaje,
                            ErrorUsuario = objError.Pagina,
                            InnerException = objError.InnerException, 
                            MethodName = objError.Metodo,
                            StackTrace = objError.StackTrace
                        });
                    }
                    HttpContext.Current.Session["ERROR_LIST"] = listaLocalErrores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Correo_EnviarResult;
            }
            catch
            {
                throw;
            }
        }
    }
}