﻿using Presentacion.Sitio.Controladores.Personales;
using System;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.UI;

namespace Presentacion.Sitio.Controles
{
    public partial class Cabecera : UserControl
    {
        private readonly CPersonales _cPersonales = new CPersonales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarDatos();
            }
        }
        public void CargarDatos()
        {
            var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
            DateTime dtPeriodoProceso = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
            DateTime dtPeriodo = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PUBLICACION").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
            CmbPeriodoContable.Items.Clear();
            while (dtPeriodo <= dtPeriodoProceso)
            {
                string strMesProduccion = dtPeriodo.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodo.AddMonths(1).Year.ToString();
                CmbPeriodoContable.Items.Add(strMesProduccion, dtPeriodo.ToString("yyyyMM"));
                dtPeriodo = dtPeriodo.AddMonths(1);
            }
            CmbPeriodoContable.Value = dtPeriodoProceso.ToString("yyyyMM");
            LblMesProduccion.Text = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString();
            Session["PERIODO_CONTABLE"] = dtPeriodoProceso.ToString("yyyyMM");
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strPeriodoContable = CmbPeriodoContable.SelectedItem.Value.ToString();
                Session["PERIODO_CONTABLE"] = strPeriodoContable;
                DateTime dtPeriodoProceso = DateTime.ParseExact(strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                LblMesProduccion.Text = dtPeriodoProceso.AddMonths(1).ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.AddMonths(1).Year.ToString();
                PopCambioPeriodo.ShowOnPageLoad = false;
                Session["CAMBIO_PERIODO_CONTABLE"] = strPeriodoContable;
                DataBind();
            }
            catch (Exception ex)
            {
                RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void RegistrarError(Exception objException, string strPagina, string strMetodo)
        {
            try
            {
                var objResponse = _cPersonales.AgregarError(new Agente.ServicioPersonales.ERROR_SISTEMA()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objException.Message == null) ? string.Empty : objException.Message,
                    ERPVC_STACK_TRACE = (objException.StackTrace == null) ? string.Empty : objException.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objException.InnerException == null) ? string.Empty : "Message: " + objException.InnerException.Message,
                        (objException.InnerException == null) ? string.Empty : " - ",
                        (objException.InnerException == null) ? string.Empty : "StackTrace: " + objException.InnerException.StackTrace)
                });
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=Se ha producido un error en el proceso, para mayor información revise el detalle registrado bajo el ID: " + objResponse.ERPBI_ID_ERROR);
            }
            catch (Exception ex)
            {
                Response.Redirect("~/Sitio/Vista/Exceptions/Error.aspx?error=" + ex.Message);
            }
        }
    }
}