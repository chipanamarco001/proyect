﻿using System;
using System.Globalization;

namespace Presentacion.Lib
{
    public class funciones
    {
        public static int CalcularEdad(DateTime dtFechaNacimiento, int intMesesPlazo)
        {
            try
            {
                DateTime dtFechaEvaluada = DateTime.Now.AddMonths(intMesesPlazo);
                int intEdad = -1;
                intEdad = (
                    ((365 * dtFechaEvaluada.Year) - (365 * dtFechaNacimiento.Year)) +
                    ((dtFechaEvaluada.Month - dtFechaNacimiento.Month) * 30) +
                    (dtFechaEvaluada.Day - dtFechaNacimiento.Day)) / 365;
                return intEdad;
            }
            catch
            {
                throw;
            }
        }
        public static DateTime? GetDateTime(string strValor, string strFormato)
        {
            try
            {
                if (strValor != string.Empty)
                {
                    string strValorCalculo = string.Empty;
                    if (strValor.Length >= strFormato.Length)
                        strValorCalculo = strValor.Substring(0, strFormato.Length);
                    if (IsDate(strValor))
                    {
                        DateTime dtFecha;
                        bool success = DateTime.TryParse(strValor, out dtFecha);
                        return dtFecha;
                    }
                    if (IsDate2(strValorCalculo, strFormato))
                    {
                        DateTime eval1 = DateTime.ParseExact(strValorCalculo, strFormato, CultureInfo.InvariantCulture);
                        return eval1;
                    }
                    else if (IsOADate2(strValor))
                    {
                        DateTime eval2 = DateTime.FromOADate(Convert.ToDouble(strValor));
                        return eval2;
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
        public static decimal GetDecimal(string valor)
        {
            try
            {
                if (valor != string.Empty)
                    return Convert.ToDecimal(valor);
                else return 0;
            }
            catch
            {
                return 0;
            }
        }
        private static bool IsDate2(string value, string format)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                return true;
            }
            catch
            {
                return false;
            }
        }
        private static bool IsDate(string strFecha)
        {
            try
            {
                DateTime dtFecha;
                bool success = DateTime.TryParse(strFecha, out dtFecha);
                return success;
            }
            catch
            {
                return false;
            }
        }
        private static bool IsOADate2(string value)
        {
            try
            {
                DateTime fecha = DateTime.FromOADate(Convert.ToDouble(value));
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool EsDecimal(string strValorAnalizado)
        {
            try
            {
                decimal decResultado;
                return decimal.TryParse(strValorAnalizado, out decResultado);
            }
            catch
            {
                return false;
            }
        }
    }
}