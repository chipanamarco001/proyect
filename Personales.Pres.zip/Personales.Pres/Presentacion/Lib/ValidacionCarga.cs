﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;

namespace Presentacion.Lib
{
    public class ValidacionCarga
    {
        private FormatoValidacion _formatoValidacion = new FormatoValidacion();
        public List<string> Validacion_SEGECP(DataTable DtblDatos)
        {
            try
            {
                List<string> listaErrores = new List<string>();
                var objValidacion = _formatoValidacion.SEGECP();
                for (int index = 0; index < DtblDatos.Rows.Count; index++)
                {
                    listaErrores.Add(ValidarTipoChar("ID Cliente", index + 1, DtblDatos.Rows[index][0].ToString().Trim(), "IDCLIENTE", objValidacion));
                    listaErrores.Add(ValidarTipoChar("ID Certificado", index + 1, DtblDatos.Rows[index][1].ToString().Trim(), "IDCERTIFICADO", objValidacion));
                    listaErrores.Add(ValidarTipoChar("Nombres", index + 1, DtblDatos.Rows[index][6].ToString().Trim(), "NOMBRES", objValidacion));
                    listaErrores.Add(ValidarTipoChar("IDC", index + 1, DtblDatos.Rows[index][7].ToString().Trim(), "IDC", objValidacion));
                    listaErrores.Add(ValidarTipoDate("Fecha Nacimiento", index + 1, DtblDatos.Rows[index][10].ToString().Trim(), "yyyy-MM-dd", "FECHA_NACIMIENTO", objValidacion));
                    listaErrores.Add(ValidarTipoDate("Fecha Afiliación", index + 1, DtblDatos.Rows[index][23].ToString().Trim(), "yyyy-MM-dd", "FECHA_AFILIACION", objValidacion));
                }
                int contador = 0;
                List<string> listaRespuesta = new List<string>();
                for (int index = 0; index < listaErrores.Count; index++)
                {
                    if (listaErrores[index].Trim() != string.Empty)
                    {
                        listaRespuesta.Add(listaErrores[index].Trim());
                        contador++;
                    }
                }
                return listaRespuesta;
            }
            catch
            {
                throw;
            }
        }
        public List<string> Validacion_SEGECV(DataTable DtblDatos)
        {
            try
            {
                List<string> listaErrores = new List<string>();
                var objValidacion = _formatoValidacion.SEGECV();
                for (int index = 0; index < DtblDatos.Rows.Count; index++)
                {
                    listaErrores.Add(ValidarTipoChar("ID Cliente", index + 1, DtblDatos.Rows[index][0].ToString().Trim(), "IDCLIENTE", objValidacion));
                    listaErrores.Add(ValidarTipoChar("ID Certificado", index + 1, DtblDatos.Rows[index][1].ToString().Trim(), "IDCERTIFICADO", objValidacion));
                    listaErrores.Add(ValidarTipoChar("Nombres", index + 1, DtblDatos.Rows[index][9].ToString().Trim(), "NOMBRES", objValidacion));
                    listaErrores.Add(ValidarTipoChar("IDC", index + 1, DtblDatos.Rows[index][10].ToString().Trim(), "IDC", objValidacion));
                    listaErrores.Add(ValidarTipoDate("Fecha Nacimiento", index + 1, DtblDatos.Rows[index][13].ToString().Trim(), "yyyy-MM-dd", "FECHA_NACIMIENTO", objValidacion));
                    listaErrores.Add(ValidarTipoDate("Fecha Afiliación", index + 1, DtblDatos.Rows[index][22].ToString().Trim(), "yyyy-MM-dd", "FECHA_AFILIACION", objValidacion));
                }
                int contador = 0;
                List<string> listaRespuesta = new List<string>();
                for (int index = 0; index < listaErrores.Count; index++)
                {
                    if (listaErrores[index].Trim() != string.Empty)
                    {
                        listaRespuesta.Add(listaErrores[index].Trim());
                        contador++;
                    }
                }
                return listaRespuesta;
            }
            catch
            {
                throw;
            }
        }
        public List<string> Validacion_DESBDP(DataTable DtblDatos)
        {
            try
            {
                //List<string> listaErrores = new List<string>();
                //var objValidacion = _formatoValidacion.SEGECP();
                //for (int index = 0; index < DtblDatos.Rows.Count; index++)
                //{
                //    listaErrores.Add(ValidarTipoChar("ID Cliente", index + 1, DtblDatos.Rows[index][0].ToString().Trim(), "IDCLIENTE", objValidacion));
                //    listaErrores.Add(ValidarTipoChar("ID Certificado", index + 1, DtblDatos.Rows[index][1].ToString().Trim(), "IDCERTIFICADO", objValidacion));
                //    listaErrores.Add(ValidarTipoChar("Nombres", index + 1, DtblDatos.Rows[index][6].ToString().Trim(), "NOMBRES", objValidacion));
                //    listaErrores.Add(ValidarTipoChar("IDC", index + 1, DtblDatos.Rows[index][7].ToString().Trim(), "IDC", objValidacion));
                //    listaErrores.Add(ValidarTipoDate("Fecha Nacimiento", index + 1, DtblDatos.Rows[index][10].ToString().Trim(), "yyyy-MM-dd", "FECHA_NACIMIENTO", objValidacion));
                //    listaErrores.Add(ValidarTipoDate("Fecha Afiliación", index + 1, DtblDatos.Rows[index][23].ToString().Trim(), "yyyy-MM-dd", "FECHA_AFILIACION", objValidacion));
                //}
                //int contador = 0;
                List<string> listaRespuesta = new List<string>();
                //for (int index = 0; index < listaErrores.Count; index++)
                //{
                //    if (listaErrores[index].Trim() != string.Empty)
                //    {
                //        listaRespuesta.Add(listaErrores[index].Trim());
                //        contador++;
                //    }
                //}
                return listaRespuesta;
            }
            catch
            {
                throw;
            }
        }
















        #region Tipo de datos
        public string ValidarTipoChar(string columna, int registro, string valor, string tipoValidacion, List<FormatoValidacion> listaValidacion)
        {
            try
            {
                string minimo = string.Empty, maximo = string.Empty;
                bool flagEmpty = false;
                if (listaValidacion.Count > 0)
                    foreach (FormatoValidacion objValidacion in listaValidacion)
                        if (objValidacion.strTipoValidacion == tipoValidacion)
                        {
                            minimo = objValidacion.strMinimo;
                            maximo = objValidacion.strMaximo;
                            flagEmpty = objValidacion.boolFlagEmpty;
                        }
                if (valor == string.Empty || valor.ToUpper() == "NULL")
                {
                    if (flagEmpty)
                        return string.Empty;
                    else return "Error en la columna '" + columna + "', registro nro. " + registro + ": Datos vacios o nulos no estan permitidos.";
                }
                else
                {
                    if (minimo != string.Empty)
                    {
                        if (valor == minimo)
                            return string.Empty;
                        else if (maximo != string.Empty)
                        {
                            if (valor == maximo)
                                return string.Empty;
                            else return "Error en la columna '" + columna + "', registro nro. " + registro + ": El valor proporcionado es incorrecto.";
                        }
                    }
                    if (maximo != string.Empty)
                    {
                        if (valor == maximo)
                            return string.Empty;
                        else return "Error en la columna '" + columna + "', registro nro. " + registro + ": El valor proporcionado es incorrecto.";
                    }
                    return string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        public string ValidarTipoDate(string columna, int registro, string valor, string formato, string tipoValidacion, List<FormatoValidacion> listaValidacion)
        {
            try
            {
                string minimo = string.Empty, maximo = string.Empty;
                bool flagEmpty = false;
                if (listaValidacion.Count > 0)
                    foreach (FormatoValidacion objValidacion in listaValidacion)
                        if (objValidacion.strTipoValidacion == tipoValidacion)
                        {
                            minimo = objValidacion.strMinimo;
                            maximo = objValidacion.strMaximo;
                            flagEmpty = objValidacion.boolFlagEmpty;
                        }
                if (valor == string.Empty || valor.ToUpper() == "NULL")
                {
                    if (flagEmpty)
                        return string.Empty;
                    else return "Error en la columna '" + columna + "', registro nro. " + registro + ": Datos vacios o nulos no estan permitidos.";
                }
                else
                {
                    if (formato != string.Empty)
                    {
                        if (valor.Length >= formato.Length)
                        {
                            valor = valor.Substring(0, formato.Length);
                        }
                    }

                    if (!IsDate(valor, formato))
                        return "Error en la columna '" + columna + "', registro nro. " + registro + ": El tipo de dato proporcionado no puede ser evaluado.";
                    DateTime eval = DateTime.ParseExact(valor, formato, CultureInfo.InvariantCulture);
                    if (minimo != string.Empty)
                    {
                        if (eval < DateTime.ParseExact(minimo, "yyyyMMdd", CultureInfo.InvariantCulture))
                            return "Error en la columna '" + columna + "', registro nro. " + registro + ": La fecha proporcionada no puede ser menor que " + DateTime.ParseExact(minimo, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy") + ".";
                    }
                    if (maximo != string.Empty)
                    {
                        if (eval > DateTime.ParseExact(maximo, "yyyyMMdd", CultureInfo.InvariantCulture))
                            return "Error en la columna '" + columna + "', registro nro. " + registro + ": La fecha proporcionado no puede ser mayor que " + DateTime.ParseExact(maximo, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy") + ".";
                    }
                    return string.Empty;
                }
            }
            catch
            {
                throw;
            }
        }
        public bool IsDate(string value, string format)
        {
            try
            {
                DateTime fecha = DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
    public class FormatoValidacion
    {
        public string strTipo { get; set; }
        public string strFormato { get; set; }
        public string strMinimo { get; set; }
        public string strMaximo { get; set; }
        public bool boolFlagEmpty { get; set; }
        public decimal? decTipoCambio { get; set; }
        public string strTipoValidacion { get; set; }
        public List<FormatoValidacion> SEGECP()
        {
            var objValidacion = new List<FormatoValidacion>();
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDCLIENTE" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDCERTIFICADO" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDC" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "NOMBRES" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DATE", strFormato = "yyyy-MM-dd", strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "FECHA_NACIMIENTO" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DATE", strFormato = "yyyy-MM-dd", strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "FECHA_AFILIACION" });
            return objValidacion;
        }
        public List<FormatoValidacion> SEGECV()
        {
            var objValidacion = new List<FormatoValidacion>();
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDCLIENTE" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDCERTIFICADO" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "IDC" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "VARCHAR", strFormato = string.Empty, strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "NOMBRES" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DATE", strFormato = "yyyy-MM-dd", strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "FECHA_NACIMIENTO" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DATE", strFormato = "yyyy-MM-dd", strMinimo = string.Empty, strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "FECHA_AFILIACION" });
            return objValidacion;
        }
        public List<FormatoValidacion> DESBDP()
        {
            var objValidacion = new List<FormatoValidacion>();
            objValidacion.Add(new FormatoValidacion() { strTipo = "INT", strFormato = string.Empty, strMinimo = "18", strMaximo = "71", boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "EDAD_INGRESO" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "INT", strFormato = string.Empty, strMinimo = "18", strMaximo = "76", boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "EDAD_PERMANENCIA" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DECIMAL", strFormato = string.Empty, strMinimo = "0.15", strMaximo = string.Empty, boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "TASA_MINIMA_MIGRADA" });
            objValidacion.Add(new FormatoValidacion() { strTipo = "DECIMAL", strFormato = string.Empty, strMinimo = "0.80", strMaximo = "3.48", boolFlagEmpty = false, decTipoCambio = null, strTipoValidacion = "TASA_CREDISEGURO" });            
            return objValidacion;
        }
    }
}
