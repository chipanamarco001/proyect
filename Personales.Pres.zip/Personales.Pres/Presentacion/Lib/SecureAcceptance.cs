﻿using Presentacion.Parametros;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace PresentacionWeb.Lib
{
    public static class SecureAcceptance
    {        
        public static string GetOrganizationID()
        {
            return Cryptography.Decrypt(CParametros.GetOrganizationID());
        }
        public static string GetMerchantID()
        {
            return Cryptography.Decrypt(CParametros.GetMerchantID());
        }
        public static string GetAccessKey()
        {
            return Cryptography.Decrypt(CParametros.GetAccessKey());
        }
        public static string GetProfileID()
        {
            return Cryptography.Decrypt(CParametros.GetProfileID());
        }
        public static string GetPostURL()
        {
            return CParametros.GetPostURL();
        }
        public static string GetSignature(IDictionary<string, string> paramsArray)
        {
            return Sign(BuildDataToSign(paramsArray), Cryptography.Decrypt(CParametros.GetSecretKey()));
        }
        private static string Sign(string data, string secretKey)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] keyByte = encoding.GetBytes(secretKey);
            HMACSHA256 hmacsha256 = new HMACSHA256(keyByte);
            byte[] messageBytes = encoding.GetBytes(data);
            return Convert.ToBase64String(hmacsha256.ComputeHash(messageBytes));
        }
        private static string BuildDataToSign(IDictionary<string, string> paramsArray)
        {
            string[] signedFieldNames = paramsArray["signed_field_names"].Split(',');
            IList<string> dataToSign = new List<string>();
            foreach (string signedFieldName in signedFieldNames)
                dataToSign.Add(signedFieldName + "=" + paramsArray[signedFieldName]);
            return CommaSeparate(dataToSign);
        }
        private static string CommaSeparate(IList<string> dataToSign)
        {
            return string.Join(",", dataToSign);
        }
    }
}