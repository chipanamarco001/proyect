﻿using Agente.ServicioPersonales;

namespace Presentacion.Lib
{
    public class ValidaUsuario : System.Web.UI.Page
    {
        public bool ValidaUsuarioYAcceso(string strIdUsuario, string strPagina)
        {
            try
            {
                bool boolEsValido = false;
                if (!(Session["SessionUsuario"] is occ_usuario) || Session["SessionUsuario"] == null)
                {
                    Response.Redirect("~/Sitio/Vista/Login/Default.aspx");
                }
                else
                {                    
                    var objUsuario = (occ_usuario)Session["SessionUsuario"];
                    foreach (var objMenu in objUsuario.Menu)
                    {
                        if (ResolveUrl(objMenu.PaginaUrl) == strPagina && objUsuario.Matricula == strIdUsuario)
                        {
                            boolEsValido = true;
                            break;
                        }
                    }
                }
                return boolEsValido;
            }
            catch
            {
                throw;
            }
        }
    }
}