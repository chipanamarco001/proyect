﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace PresentacionWeb.Lib
{
    public class Cryptography
    {
        private static byte[] byteCRSKey = Encoding.Unicode.GetBytes("@F3970289B83A!W1");
        private static byte[] byteCRSIV = new byte[] { 3, 18, 5, 4, 9, 19, 5, 7, 21, 18, 15, 0, 19, 0, 1, 0 };
        private static string EncryptStringToBytes_Aes(string strInputText)
        {
            if (strInputText == null || strInputText.Length <= 0)
                throw new ArgumentNullException("strInputText");
            byte[] byteEncryptedText;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = byteCRSKey;
                aesAlg.IV = byteCRSIV;
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(strInputText);
                        }
                        byteEncryptedText = msEncrypt.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(byteEncryptedText);
        }
        private static string DecryptStringFromBytes_Aes(string strInputText)
        {
            if (strInputText == null || strInputText.Length <= 0)
                throw new ArgumentNullException("strInputText");
            byte[] byteInput = Convert.FromBase64String(strInputText);
            string strDecryptedInput = null;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = byteCRSKey;
                aesAlg.IV = byteCRSIV;
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(byteInput))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            strDecryptedInput = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            return strDecryptedInput;
        }
        public static string Encrypt(string strInput)
        {
            return EncryptStringToBytes_Aes(strInput);
        }
        public static string Decrypt(string strInput)
        {
            return DecryptStringFromBytes_Aes(strInput);
        }
    }
}