﻿using System.Threading.Tasks;
using Agente.CheckService.Models.Base;
namespace Agente
{
    public interface IHttpClientService
    {
        Task<TResponse> GetAsync<TResponse>(string url, string token);
        Task<ResponseService<TResponse>> PostAsync<TRequest, TResponse>(string url, TRequest data, string token) where TResponse:class;
        //Task<TResponse> PutAsync<TRequest, TResponse>(string url, TRequest data, string token);
        //Task<bool> DeleteAsync(string url);
    }
}
