﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class AseguradoRequest
    {
        public long idAfiliacion { get; set; } = 0;
        public long numeroAsegurado { get; set; } = 0;
        public string tipoDocumento { get; set; } = string.Empty;
        public string numeroDocumento { get; set; } = string.Empty;
        public string complementoDocumento { get; set; } = string.Empty;
        public string extensionDocumento { get; set; } = string.Empty;
        public string apellidoPaterno { get; set; } = string.Empty;
        public string apellidoMaterno { get; set; } = string.Empty;
        public string apellidoCasada { get; set; } = string.Empty;
        public string nombre { get; set; } = string.Empty;
        public DateTime? fechaNacimiento { get; set; } = null;
        public string correo { get; set; } = string.Empty;
        public string departamento { get; set; } = string.Empty;
        public string ciudad { get; set; } = string.Empty;
        public string zona { get; set; } = string.Empty;
        public string direccion { get; set; } = string.Empty;
        public string numeroCelular { get; set; } = string.Empty;
        public string estadoCivil { get; set; } = string.Empty;
        public string genero { get; set; } = string.Empty;
        public string nacionalidad { get; set; } = string.Empty;
        public string ocupacion { get; set; } = string.Empty;

        public long idCarga { get; set; } = 0;
    }
    public class AseguradoResponse
    {
        public long idAsegurado { get; set; }

        public string mensaje { get; set; } 

        public bool exito { get; set; }
    }
}
