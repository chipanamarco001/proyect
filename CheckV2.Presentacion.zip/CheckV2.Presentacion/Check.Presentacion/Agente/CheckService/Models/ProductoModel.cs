﻿using Agente.CheckService.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class CobroRequest
    {
        public long idAfiliacion { get; set; }
        public long? idCupon { get; set; }
        public string tipoCobro { get; set; } = null;
        public string codigo { get; set; } = null;
        public string jsonSolicitud { get; set; } = null;
    }
    public class CobroRepsonse
    {
        public long idCobro { get; set; }
        public long idAfiliacion { get; set; }

       
    }
 
}
