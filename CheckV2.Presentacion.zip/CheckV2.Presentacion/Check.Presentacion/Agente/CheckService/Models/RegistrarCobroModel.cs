﻿using Agente.CheckService.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class ProductoRequest
    {
        public Credentials credenciales { get; set; }
    }
    public class ProductoRepsonse
    {
        public string idProducto { get; set; }
        public string nombreComercial { get; set; }
        public string modalidad { get; set; }
        public string ramo { get; set; }
        public string tipo { get; set; }
        public bool flagFacturacion { get; set; }
         public SubProducto subProducto { get; set; }
    }
    public class SubProducto { 
        public string idSubProducto { get; set; }
        public string idProducto { get; set; }
        public long numeroNivel { get; set; }
        public string descripcion { get; set; }
    }
}
