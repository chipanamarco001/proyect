﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class BeneficiarioRequest
    {
        public long idAfiliacion { get; set; } = 0;

        public string tipoDocumento { get; set; } = string.Empty;

        public string numeroDocumento { get; set; } = string.Empty;

        public string complementoDocumento { get; set; } = string.Empty;

        public string extensionDocumento { get; set; } = string.Empty;

        public string apellidoPaterno { get; set; }= string.Empty;

        public string apellidoMaterno { get; set; } = string.Empty;

        public string apellidoCasada { get; set; } = string.Empty;

        public string nombre { get; set; } = string.Empty;

        public DateTime? fechaNacimiento { get; set; } = null;

        public string parentesco { get; set; } = string.Empty;

        public decimal factorParticipacion { get; set; } = 0;

        public string entidadFinanciera { get; set; } = string.Empty; 

        public string numeroCuenta { get; set; } = string.Empty;

           public string telefono { get; set; } = string.Empty;

        public int idCarga { get; set; } = 0;
    }
    public class BeneficiarioResponse
    {
        public long idBeneficiario { get; set; }

        public string mensaje { get; set; } 

        public bool exito { get; set; }
    }
}
