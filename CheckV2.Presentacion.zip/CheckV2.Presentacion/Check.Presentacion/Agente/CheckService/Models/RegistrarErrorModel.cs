﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class RegistrarErrorRequest
    {
        public HttpStatusCode? codigoError { get; set; }
        public string pagina { get; set; } = null;
        public string metodo { get; set; } = null;
        public string mensaje { get; set; } = null;
        public string stackTrace { get; set; } = null;
        public string innerException { get; set; } = null;
    }

    public class RegistrarErrorResponse
    {
        public bool registrado { get; set; }
    }
}
