﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class SubProductoRequest
    {
        public string idProducto { get; set; }
        public string descripcion { get; set; }

    }
    public class SubProductoResponse
    {
        public long idSubProducto { get; set; }
        public string idProducto { get; set; }
        public long numeroNivel { get; set; }
        public string descripcion { get; set; }
    }
}
