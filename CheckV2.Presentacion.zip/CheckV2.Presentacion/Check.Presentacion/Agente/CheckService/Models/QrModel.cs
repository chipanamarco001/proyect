﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class QrRequest
    {
        public string moneda { get; set; }
        public decimal monto { get; set; }
        public string glosa { get; set; }
        public string numeroCelular { get; set; }
        public List<Coleccion> coleccion { get; set; }
    }
    public class Coleccion
    {
        public string name { get; set; }
        public string parameter { get; set; }
        public string paremeter { get; set; }
        public string value { get; set; }

    }


    public class QrResponse
    {
        public data  data { get; set; }
        public string state { get; set; }
        public string message { get; set; }
    }
    public class data
    {
        public int id { get; set; }
        public byte[] qrImage { get; set; }
        public string expirationDate { get; set; }
        public string status { get; set; }
        public string description { get; set; }
    }
}
