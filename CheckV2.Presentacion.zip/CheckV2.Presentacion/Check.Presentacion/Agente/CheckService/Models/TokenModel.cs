﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class TokenResponse
    {
        public string token { get; set; }
    }
    public class TokenRequest
    {
        public string usuario { get; set; }
        public string pass { get; set; }
    }
}
