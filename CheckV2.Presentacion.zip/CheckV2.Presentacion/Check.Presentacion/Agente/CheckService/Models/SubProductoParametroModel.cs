﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class SubProductoParametroRequest
    {
        public long idSubProducto { get; set; }

    }

    public class SubProductoParametroResponse
    {
        public long idSubProducto { get; set; }
        public string descripcion { get; set; }
        public string Aclaracion { get; set; }
        public string Valor { get; set; }
        public string Tipo { get; set; }
        public long NumeroNivel { get; set; }
    }
}
