﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class AfiliacionColectivaRequest
    {
        public long idSubProducto { get; set; }
        public long numeroNivel { get; set; }
        public string estadoAfiliacion { get; set; }
        public string departamento { get; set; }
        public bool flagInnominado { get; set; }
        public string comentarios { get; set; }
        public bool estadoActivo { get; set; }
         public long idCarga { get; set; }
    }
    public class AfiliacionColectivaResponse
    {
        public long idAfiliacion { get; set; }

        public string mensaje { get; set; }

        public bool exito { get; set; }
    }
}
