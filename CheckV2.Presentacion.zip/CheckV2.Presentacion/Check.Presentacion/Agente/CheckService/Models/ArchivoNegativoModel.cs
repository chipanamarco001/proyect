﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class ArchivoNegativoRequest
    {
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
    }

    public class ArchivoNegativoResponse
    {
        public ocRespuestaValidacionLista validacionAMLC { get; set; }

        public ocRespuestaValidacionLista validacionAN { get; set; }
    }
    public class ocRespuestaValidacionLista
    {
        public string entidad { get; set; }
        public string respuesta { get; set; }
        public string respuestaAdjunto { get; set; }
        public DateTime fechaHora { get; set; }
        public bool estado { get; set; }

       
    }
}
