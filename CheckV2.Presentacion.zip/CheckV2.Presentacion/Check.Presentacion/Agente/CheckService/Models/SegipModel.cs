﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class SegipRequest
    {
        public string numeroDocumento { get; set; }
        public string complemento { get; set; }
        public DateTime fechaNacimiento { get; set; }
        public string nombre { get; set; }
        public string apPaterno { get; set; }
        public string apMaterno { get; set; }
        public string ciudad { get; set; }
        public string nacionalidad { get; set; }
        public string tipoDocumento { get; set; }
    }
    public class SegipResponse
    {
        public int codigoRespuesta { get; set; }
        public string codigoUnico { get; set; }
        public string contratacionJson { get; set; }
        public string descripcionRespuesta { get; set; }
        public bool esValido { get; set; }
        public string mensaje { get; set; }
        public string tipoMensaje { get; set; }
        public DateTime? horaRespuesta { get; set; }
        public bool coincidenciaNroDocumento { get; set; }
        public bool coincidenciaComplemento { get; set; }
        public bool coincidenciaPaterno { get; set; }
        public bool coincidenciaMaterno { get; set; }
        public bool coincidenciaNombres { get; set; }
        public bool coincidenciaPaisNacimiento { get; set; }
        public bool coincidenciaDepartamentoNacimiento { get; set; }
        public bool coincidenciaFechaNacimiento { get; set; }
    }
}
