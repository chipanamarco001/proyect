﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class EnviarCorreoRequest
    {
        public long idAfiliacion { get; set; }
    }
    public class EnviarCorreoResponse
    {
        public bool enviado { get; set; }
    }
}
