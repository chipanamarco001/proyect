﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agente.CheckService.Models
{
    public class OtpRequest
    {
        public string correo { get; set; }
        public string numero { get; set; }
        public string numeroDocumento { get; set; }
    }
    public class OtpResponse
    {
        public int CodigoRespuesta { get; set; }
        public DateTime FechaConsulta { get; set; }
        public string Message { get; set; }
        public List<string> Information = new List<string>();
    }

    public class OtpValidRequest
    {
        public string codigo { get; set; }
        public string numeroDocumento { get; set; }
    }
 
}
