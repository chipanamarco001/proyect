﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.Yape.site.misc
{
    public partial class pagina_no_encontrada : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            var master = (YapePage)this.Master;
            master.panelHeader.Visible = false;
            master.panelFooter.Visible = false;
        }
    }
}