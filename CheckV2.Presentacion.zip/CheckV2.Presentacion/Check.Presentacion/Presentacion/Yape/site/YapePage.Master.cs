﻿using Agente.CheckService.Models;
using Presentacion.Yape.controllers;
using Presentacion.Yape.site.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Agente.CheckService.Models.Base;
using DevExpress.Web.Bootstrap;
using DevExpress.Web;
using System.Configuration;
using System.Web.Configuration;
namespace Presentacion.Yape.site
{
    public partial class YapePage : System.Web.UI.MasterPage
    {

        public Panel panelHeader
        {
            get { return pnlHeader; }
        }
        public Panel panelFooter
        {
            get { return pnlFooter; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ClientScriptManager cs = Page.ClientScript;
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
            SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
            int timeout = (int)section.Timeout.TotalMinutes * 1000 * 60;
            cs.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + timeout + ");", true);

            if (!IsPostBack)
            {


            }



        }

        protected void btnAtras_Click(object sender, EventArgs e)
        {
            IMasterPageHandler handler = this.Page as IMasterPageHandler;
            if (handler != null)
            {
                handler.HandleMasterPageAction();
            }
        }
    }
}