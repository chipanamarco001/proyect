﻿using Agente.CheckService.Models.Base;
using Agente.CheckService.Models;
using DevExpress.Web.Bootstrap;
using Presentacion.Yape.controllers;
using Presentacion.Yape.site.interfaces;
using System;
using Presentacion.Parameters;
using DevExpress.Web;
using System.Linq;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Presentacion.Yape.entities;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using Presentacion.Yape.libs;
using System.Net;
using System.Threading.Tasks;
using Serilog;

namespace Presentacion.Yape.site.page
{
    public partial class Default : System.Web.UI.Page, IMasterPageHandler
    {
        CLexico cLexico = new CLexico();
        CSubProducto cSubProducto = new CSubProducto();
        CSubProductoParametro cSubProductoParametro = new CSubProductoParametro();
        CParameters parameters = new CParameters();
        CToken cToken = new CToken();
        CRegistrarError cRegistrarError = new CRegistrarError();
        public void HandleMasterPageAction()
        {
            if (pnlInicio.Visible)
            {
                Session["Page"] = null;
                return;
            }
            else if (pnlCoberturas.Visible)
            {
                Session["Page"] = "Inicio";

                pnlInicio.Visible = true;
                pnlCoberturas.Visible = false;
            }
            // Implement any master page specific actions here
        }

        private string ObtenerTokenConEspera(int maxIntentos = 5, int milisegundosEspera = 1000)
        {
            try
            {
                for (int intento = 1; intento <= maxIntentos; intento++)
                {
                    var tokenRequest = new TokenRequest
                    {
                        usuario = CParametersSite.usuarioTk,
                        pass = CParametersSite.passTk
                    };
                    if (tokenRequest == null)
                    {
                        
                    }
                  
                    if (string.IsNullOrEmpty(tokenRequest.usuario) || string.IsNullOrEmpty(tokenRequest.pass))
                    {
                        return null;
                    }
                 
                    var tokenResponse = cToken.ObtenerToken(tokenRequest);

                    if (tokenResponse.Result.status == HttpStatusCode.OK)
                    {
                        CSeriLog.Inicio(parameters.GetCurrentUser(), parameters.GetCurrentIp(), Request.Browser.Browser, Request.Browser.Version, parameters.DetectarSistemaOperativo(Request.UserAgent));
                        return tokenResponse.Result.result.token;
                    }
                    else if (tokenResponse.Result.status == HttpStatusCode.Unauthorized || tokenResponse.Result.status == HttpStatusCode.NoContent)
                    {
                        //registrsr error
                        CSeriLog.Inicio(parameters.GetCurrentUser(), parameters.GetCurrentIp(), Request.Browser.Browser, Request.Browser.Version, parameters.DetectarSistemaOperativo(Request.UserAgent));
                        CSeriLog.Debug($"Intento de Token User:{CParametersSite.usuarioTk}, Password:{CParametersSite.passTk} de {maxIntentos} para obtener token fallido. Código de estado: {tokenResponse.Result.status}. Mensaje: {tokenResponse.Result.messages.FirstOrDefault()?.UserMessage}");
                        Response.Redirect("~/Yape/site/misc/no-autorizado.aspx", true);
                    }
                    else
                    {
                        //registrar error
                        CSeriLog.Inicio(parameters.GetCurrentUser(), parameters.GetCurrentIp(), Request.Browser.Browser, Request.Browser.Version, parameters.DetectarSistemaOperativo(Request.UserAgent));
                        CSeriLog.Error($"Intento de Token User:{CParametersSite.usuarioTk}, Password:{CParametersSite.passTk} de {maxIntentos} para obtener token fallido. Código de estado: {tokenResponse.Result.status}. Mensaje: {tokenResponse.Result.messages.FirstOrDefault()?.UserMessage}");

                        Response.Redirect("~/Yape/site/misc/error.aspx");
                    }


                    System.Threading.Thread.Sleep(milisegundosEspera);
                }

                return null;
            }
            catch (Exception ex)
            {
                
                Log.Error(ex, "Pagina: DatosPersonales.aspx, Accion: ObtenerTokenConEspera");
                return null;

            }
        }
        private void SessionClean()
        {
            Session["Page"] = null;
            Session["SubProducto"] = null;
            Session["ListSubProductoParametro"] = null;
            Session["DatosPersona"] = null;
            Session["Beneficiario"] = null;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Token"] == null)
            {
                var token = ObtenerTokenConEspera();

                if (string.IsNullOrEmpty(token))
                {
                    Response.Redirect("~/Yape/site/misc/no-autorizado.aspx");
                    return;
                }

                Session["Token"] = token;
            }



            if (IsPostBack)
            {
                return;
            }

            SessionClean();

            string browserName = Request.Browser.Browser;
            string browserVersion = Request.Browser.Version;

            if (Session["Page"] != null)
            {
                if (Session["Page"].ToString() == "Coberturas")
                {
                    pnlInicio.Visible = false;
                    pnlCoberturas.Visible = true;
                }
                else
                {
                    pnlInicio.Visible = true;
                    pnlCoberturas.Visible = false;
                }
            }
            else
            {
                pnlInicio.Visible = true;
                pnlCoberturas.Visible = false;

            }
            var lexicoRequest = new LexicoRequest() { tabla = "PREGUNTAS", tema = "YAPE" };
            var tokens = Session["Token"] as string;
        
            var listPreguntas = cLexico.ObtenerListaLexicoPorTablaTema(lexicoRequest, tokens);

            if (listPreguntas.Result.status == HttpStatusCode.OK)
            {

                ctrlAcordion1.Groups.Clear();
                ctrlAcordion2.Groups.Clear();
                var list1 = listPreguntas.Result.result.Where(x => x.valor == "SECCION1");
                var list2 = listPreguntas.Result.result.Where(x => x.valor == "SECCION2");

                foreach (var oLexcio in list1)
                {

                    BootstrapAccordionGroup group = new BootstrapAccordionGroup(oLexcio.descripcion1);
                    BootstrapAccordionItem item = new BootstrapAccordionItem(oLexcio.descripcion2);
                    group.Items.Add(item);
                    ctrlAcordion1.Groups.Add(group);
                }
                foreach (var oLexcio in list2)
                {

                    BootstrapAccordionGroup group = new BootstrapAccordionGroup(oLexcio.descripcion1);
                    BootstrapAccordionItem item = new BootstrapAccordionItem(oLexcio.descripcion2);
                    group.Items.Add(item);
                    ctrlAcordion2.Groups.Add(group);
                }

                ctrlAcordion1.AutoCollapse = true;
                ctrlAcordion2.AutoCollapse = true;
            }
            else
            {
                //registrar error
                ctrlAcordion1.Groups.Clear();
                ctrlAcordion2.Groups.Clear();
            }

            var SubProductoRequest = new SubProductoRequest() { idProducto = CParametersSite.idProducto, descripcion = CParametersSite.subProductoDescripcion };
            var listSubProducto = cSubProducto.ObtenerSubProductoPorIdProdDescripcion(SubProductoRequest,  tokens);
            if (listSubProducto.Result.status == HttpStatusCode.OK)
            {
                Session["SubProducto"] = listSubProducto.Result.result;
                var idSubProducto = listSubProducto.Result.result.idSubProducto;
                var SuProductoParametroRequest = new SubProductoParametroRequest() { idSubProducto = (long)idSubProducto };
                var listSubProductoParametro = cSubProductoParametro.ObtenerProductoParametroPorIdSubProducto(SuProductoParametroRequest, tokens);
                if (listSubProductoParametro.Result.status == HttpStatusCode.OK)
                {
                    Session["ListSubProductoParametro"] = listSubProductoParametro.Result.result;
                    var jsonCoberturas = listSubProductoParametro.Result.result.Where(x => x.Tipo == "COBERTURAS").FirstOrDefault().Valor;
                    List<CoberturaModel> lstCoberturas = JsonConvert.DeserializeObject<List<CoberturaModel>>(jsonCoberturas);
                    RepeatCoberturas.DataSource = lstCoberturas;
                    RepeatCoberturas.DataBind();
                    var jsonPrima = listSubProductoParametro.Result.result.Where(x => x.Tipo == "PRIMA_BOB").FirstOrDefault().Valor;
                    lblPrima.Text = jsonPrima;
                    lblPrima1.Text = jsonPrima;
                    lblPrima2.Text = jsonPrima;
                    var jsonMoneda = listSubProductoParametro.Result.result.Where(x => x.Tipo == "MONEDA").FirstOrDefault().Valor;
                    lblMoneda.Text = jsonMoneda == "BOB" ? "Bs" : "";
                    lblMoneda1.Text = jsonMoneda == "BOB" ? "Bs" : "";
                    lblMoneda2.Text = jsonMoneda == "BOB" ? "Bs" : "";
                    var jsonVigencia = listSubProductoParametro.Result.result.Where(x => x.Tipo == "VIGENCIA").FirstOrDefault().Valor;
                    lblVigencia.Text = jsonVigencia.ToLower();
                    lblVigencia1.Text = jsonVigencia.ToLower();
                    lblVigencia2.Text = jsonVigencia.ToLower();

                    var jsonEdadMin = listSubProductoParametro.Result.result.Where(x => x.Tipo == "EDAD_MIN_ING").FirstOrDefault().Valor;
                    lblEdadMin.Text = jsonEdadMin;
                    var jsonEdadMax = listSubProductoParametro.Result.result.Where(x => x.Tipo == "EDAD_MAX_ING").FirstOrDefault().Valor;
                    lblEdadMax.Text = jsonEdadMax;
                }

            }
            else
            {
                //registrar error
                Response.Redirect("~/Yape/site/misc/error.aspx");
            }


        }

        protected void btnVerMas_Click(object sender, EventArgs e)
        {
            pnlInicio.Visible = false;
            pnlCoberturas.Visible = true;
            Log.Information("Usuario: {Usuario} con Ip: {Ip} ha iniciado el proceso de ver mas coberturas del seguro Yape.", parameters.GetCurrentUser(), parameters.GetCurrentIp());
        }

        protected void btnComprarSeguro_Click(object sender, EventArgs e)
        {
            if (recaptcha.Validate(Request["g-recaptcha-response"]))
            {
                Log.Information("Usuario: {Usuario} con Ip: {Ip} ha iniciado el proceso de compra del seguro Yape.", parameters.GetCurrentUser(), parameters.GetCurrentIp());
                Session["Page"] = "Coberturas";
                Response.Redirect("~/Yape/site/page/DatosPersonales.aspx");

            }
            else
            {
                //TxtPassword.Value = null;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "onloadCallback();", true);
            }
        }


    }
}