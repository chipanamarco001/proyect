﻿
using Agente.CheckService.Models;
using Agente.CheckService.Models.Base;
using Presentacion.Parameters;
using Presentacion.Yape.controllers;
using Presentacion.Yape.site.interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Serilog;
using static System.Collections.Specialized.BitVector32;
using Presentacion.Yape.libs;
using DevExpress.Web.Internal;
using Newtonsoft.Json;

namespace Presentacion.Yape.site.page
{
    public partial class BeneficiarioConfirmacion : System.Web.UI.Page, IMasterPageHandler
    {
        CLexico cLexico = new CLexico();
        CParameters parameters = new CParameters();
        CAfiliacionColectiva cAfiliacionColectiva = new CAfiliacionColectiva();
        CAsegurado cAsegurado = new CAsegurado();
        CBeneficiario cBeneficiario = new CBeneficiario();
        CQr cQRr = new CQr();
        CCobro cCobro = new CCobro();


        public void HandleMasterPageAction()
        {
            if (pnlBeneficiarioConfirmacion.Visible)
            {
                Session["Page"] = "pnlConfirmacion";
                Response.Redirect("~/Yape/site/page/DatosPersonales.aspx");
            }
            else if (pnlAfiliacionConfirmacion.Visible)
            {
                Session["Page"] = "BeneficiarioConfirmacion";
                pnlBeneficiarioConfirmacion.Visible = true;
                pnlAfiliacionConfirmacion.Visible = false;
            }

            // Implement any master page specific actions here
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Token"] == null)
            {
                Response.Redirect("~/Yape/site/page/Default.aspx");
            }
            if (IsPostBack)
            {
                return;
            }
            if (Session["Page"] != null)
            {
                if (Session["Page"].ToString() == "ConfirmacionAfiliacion")
                {
                    pnlBeneficiarioConfirmacion.Visible = false;
                    pnlAfiliacionConfirmacion.Visible = true;
                }
                else
                {
                    pnlBeneficiarioConfirmacion.Visible = true;
                    pnlAfiliacionConfirmacion.Visible = false;
                }
            }
            else
            {
                Session["Page"] = null;
                Response.Redirect("~/Yape/site/page/Default.aspx");
            }

            //Obtenemos las opciones del parentesco
            var lexicoRequest = new LexicoRequest() { tabla = "PARENTESCO", tema = "BENEF_AFILIACION" };
            var tokens = Session["Token"] as string;
            try
            {
                var listParentesco = cLexico.ObtenerListaLexicoPorTablaTema(lexicoRequest, tokens);
                //list;
                if (listParentesco.Result.status == HttpStatusCode.OK)
                {
                    Log.Information("Lista de parentescos obtenida correctamentep para Ip: {Ip}", parameters.GetCurrentIp());

                    cmbParentesco.TextField = "descripcion1";
                    cmbParentesco.ValueField = "valor";
                    cmbParentesco.DataSource = listParentesco.Result.result;
                    cmbParentesco.DataBind();

                }

                else if (listParentesco.Result.status == HttpStatusCode.Unauthorized)
                {
                    Log.Error("Error al obtener la lista de parentescos para Ip: {Ip}. Status: Unauthorized", parameters.GetCurrentIp());
                    Response.Redirect("~/Yape/site/misc/no-autorizado.aspx");

                }

                else if (listParentesco.Result.status == HttpStatusCode.InternalServerError)
                {
                    Log.Error("Error al obtener la lista de parentescos para Ip: {Ip}. Status: InternalServerError", parameters.GetCurrentIp());
                    Response.Redirect("~/Yape/site/misc/error.aspx");
                }
                else
                {

                    lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                    modalMensaje.ShowOnPageLoad = true;
                    Log.Error("Error al obtener la lista de parentescos para Ip: {Ip}. Status: {Status}", parameters.GetCurrentIp(), listParentesco.Result.status);
                    return;
                }
            }
            catch (Exception ex)
            {
                lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                modalMensaje.ShowOnPageLoad = true;
                Log.Error("Error al cargar los parentescos: {Message}", ex.Message);

            }
        }

        protected void btnComprarSeguro_Click(object sender, EventArgs e)
        {

            var tokens = Session["Token"] as string;
            var credential = new Credentials()
            {
                usuario = parameters.GetCurrentUser(),
                ip = parameters.GetCurrentIp()
            };
            Log.Information("Iniciando proceso de compra de seguro para usuario: {Usuario}, IP: {Ip}", parameters.GetCurrentUser(), parameters.GetCurrentIp());
            if(Session["SubProducto"]==null|| Session["ListSubProductoParametro"]==null || Session["DatosPersona"]==null)
            {
                Log.Error("Error al iniciar el proceso de compra de seguro: Datos necesarios no encontrados en la sesión para usuario: {Usuario}, IP: {Ip}", parameters.GetCurrentUser(), parameters.GetCurrentIp());
                lblMensaje.Text = "Datos necesarios no fueron encotrados. Ingresa nuevamente a la pagina";
                modalMensaje.ShowOnPageLoad = true;
                return;
            }
            var subProducto = (SubProductoResponse)Session["SubProducto"];
            var listSubProductoParametro = (List<SubProductoParametroResponse>)Session["ListSubProductoParametro"];
            var datosAsegurado = (AseguradoRequest)Session["DatosPersona"];
            var guardarDatosAfiliacion = new AfiliacionColectivaRequest()
            {
                idSubProducto = subProducto.idSubProducto,
                numeroNivel = subProducto.numeroNivel,
                estadoAfiliacion = "PENDIENTE",
                departamento = "LA PAZ",  // VERIFICAR DE DONDE
                flagInnominado = false,
                comentarios = "",
                idCarga = 0,
                estadoActivo = true
            };
            try
            {
                var ObtenerDatosAfiliacion = cAfiliacionColectiva.RegistrarAfiliacionColectiva(guardarDatosAfiliacion, tokens);
                if (ObtenerDatosAfiliacion.Result.status == HttpStatusCode.OK)
                {
                    var obtenerIdAfiliacion = ObtenerDatosAfiliacion.Result.result.idAfiliacion;
                    Log.Information("Afiliación colectiva registrada correctamente para usuario: {Usuario}, IP: {Ip}, IdAfiliacion: {IdAfiliacion}", parameters.GetCurrentUser(), parameters.GetCurrentIp(), obtenerIdAfiliacion);
                    datosAsegurado.idAfiliacion = obtenerIdAfiliacion;
                    var obtenerIdAsegurado = cAsegurado.RegistrarAsegurado(datosAsegurado, tokens);

                    if (obtenerIdAsegurado.Result.status == HttpStatusCode.OK)
                    {
                        Log.Information("Asegurado registrado correctamente con ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}", obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                        var obtenerDatosBenefiarioRegistro = new BeneficiarioRequest()
                        {
                            idAfiliacion = obtenerIdAfiliacion,
                            nombre = txtNobreBeneficiario.Text.ToUpper(),
                            parentesco = cmbParentesco.Text.ToUpper(),
                            telefono = txtNumeroTelefono.Text.ToUpper()
                        };

                        var obtenerDatosBeneficiario = cBeneficiario.RegistrarBeneficiario(obtenerDatosBenefiarioRegistro, tokens);
                        if (obtenerDatosBeneficiario.Result.status == HttpStatusCode.OK)
                        {
                            Log.Information("Beneficiario registrado correctamente para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                            var generarQR = new QrRequest()
                            {
                                moneda = listSubProductoParametro.Where(x => x.Tipo == "MONEDA").FirstOrDefault().Valor,
                                monto = Convert.ToDecimal(listSubProductoParametro.Where(x => x.Tipo == "PRIMA_BOB").FirstOrDefault().Valor),
                                glosa = "YAPE VIDA " + subProducto.idProducto + "-" + obtenerIdAfiliacion,
                                numeroCelular = datosAsegurado.numeroCelular,
                                coleccion = new List<Coleccion>()
                            {
                                new Coleccion()
                                {
                                    name = "YAPE",
                                    parameter = "INDIVIDUAL",
                                    paremeter = "idAfiliacion",
                                    value = obtenerIdAfiliacion.ToString()
                                },

                            }
                            };

                            var qrResult = cQRr.GenerarQrDebito(generarQR, tokens);

                            if (qrResult.Result.status == HttpStatusCode.OK)
                            {
                                Log.Information("QR generado correctamente para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip} , Datos:{Datos}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), generarQR);
                                var imgQR = qrResult.Result.result.data.qrImage;

                                var cobroRequest = new CobroRequest()
                                {
                                    idAfiliacion = obtenerIdAfiliacion,
                                    
                                    idCupon = null,
                                    tipoCobro = "QR-BCP",
                                    codigo = qrResult.Result.result.data.id.ToString(),
                                    jsonSolicitud = JsonConvert.SerializeObject(generarQR)
                                };

                                var registrarCobro= cCobro.RegistrarCobroInicial(cobroRequest, tokens);

                                if (registrarCobro.Result.status == HttpStatusCode.OK)
                                {
                                    Log.Information("Cobro generado correctamente para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip} , Datos:{Datos}, IdQr: {IdQr}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), qrResult.Result.result.data.id.ToString());

                                    imgQRR.ContentBytes = imgQR;
                                    Session["Page"] = "BeneficiarioConfirmacion";
                                    ClientScriptManager csQR = Page.ClientScript;
                                    int timeout = CParametersSite.timerQR * 1000 * 60;
                                    csQR.RegisterStartupScript(this.GetType(), "SessionAlertQR", "SessionExpireAlertQR(" + timeout + ");", true);
                                    pnlQR.ShowOnPageLoad = true;
                                }
                                else if (registrarCobro.Result.status == HttpStatusCode.Unauthorized)
                                {
                                    Log.Debug("Error al registrar Cobro para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}, IdQr: {IdQr}. Status: Unauthorized ", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), qrResult.Result.result.data.id.ToString());
                                    Response.Redirect("~/Yape/site/misc/no-autorizado.aspx");

                                }

                                else if (registrarCobro.Result.status == HttpStatusCode.InternalServerError)
                                {
                                    Log.Debug("Error al generar QR para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}, IdQr: {IdQr}. Status: InternalServerError", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), qrResult.Result.result.data.id.ToString());
                                    lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                                    modalMensaje.ShowOnPageLoad = true;
                                    return;
                                    //Response.Redirect("~/Yape/site/misc/error.aspx", true);
                                }
                                else
                                {
                                    Log.Debug("Error al generar QR para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: {Status}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), qrResult.Result.status);
                                    lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                                    modalMensaje.ShowOnPageLoad = true;
                                    return;

                                }




                            }
                            else if (qrResult.Result.status == HttpStatusCode.Unauthorized)
                            {
                                Log.Debug("Error al generar QR para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: Unauthorized", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                                Response.Redirect("~/Yape/site/misc/no-autorizado.aspx");

                            }

                            else if (qrResult.Result.status == HttpStatusCode.InternalServerError)
                            {
                                Log.Debug("Error al generar QR para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: InternalServerError", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                                lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                                modalMensaje.ShowOnPageLoad = true;
                                return;
                                //Response.Redirect("~/Yape/site/misc/error.aspx", true);
                            }
                            else
                            {
                                Log.Debug("Error al generar QR para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: {Status}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), qrResult.Result.status);
                                lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                                modalMensaje.ShowOnPageLoad = true;
                                return;

                            }

                        }
                        else if (obtenerDatosBeneficiario.Result.status == HttpStatusCode.Unauthorized)
                        {
                            Log.Debug("Error al registrar beneficiario para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: Unauthorized", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                            Response.Redirect("~/Yape/site/misc/no-autorizado.aspx");

                        }

                        else if (obtenerDatosBeneficiario.Result.status == HttpStatusCode.InternalServerError)
                        {
                            Log.Debug("Error al registrar beneficiario para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: InternalServerError", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp());
                            lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                            modalMensaje.ShowOnPageLoad = true;
                            return;
                            //Response.Redirect("~/Yape/site/misc/error.aspx", true);
                        }
                        else
                        {
                            Log.Debug("Error al registrar beneficiario para afiliación ID: {IdAfiliacion} y asegurado ID: {IdAsegurado} para usuario: {Usuario}, IP: {Ip}. Status: {Status}", obtenerIdAfiliacion, obtenerIdAsegurado.Result.result.idAsegurado, parameters.GetCurrentUser(), parameters.GetCurrentIp(), obtenerDatosBeneficiario.Result.status);
                            lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                            modalMensaje.ShowOnPageLoad = true;
                            return;

                        }


                    }
                }
                else if (ObtenerDatosAfiliacion.Result.status == HttpStatusCode.Unauthorized)
                {
                    Log.Debug("Error al registrar afiliación colectiva para usuario: {Usuario}, IP: {Ip}. Status: Unauthorized", parameters.GetCurrentUser(), parameters.GetCurrentIp());
                    Response.Redirect("~/Yape/site/misc/no-autorizado.aspx", true);

                }

                else if (ObtenerDatosAfiliacion.Result.status == HttpStatusCode.InternalServerError)
                {
                    Log.Debug("Error al registrar afiliación colectiva para usuario: {Usuario}, IP: {Ip}. Status: InternalServerError", parameters.GetCurrentUser(), parameters.GetCurrentIp());
                    Response.Redirect("~/Yape/site/misc/error.aspx");
                }
                else
                {
                    Log.Debug("Error al registrar afiliación colectiva para usuario: {Usuario}, IP: {Ip}. Status: {Status}", parameters.GetCurrentUser(), parameters.GetCurrentIp(), ObtenerDatosAfiliacion.Result.status);
                    lblMensaje.Text = "Disculpa por los inconvenientes. estamos solucionando el problema";
                    modalMensaje.ShowOnPageLoad = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Pagina: BeneficiarioConfirmacion.aspx, Accion: btnComprarSeguro_Click");
                Response.Redirect("~/Yape/site/misc/error.aspx");

            }
        }

        protected void btnLlenarDatos_Click(object sender, EventArgs e)
        {
            Log.Debug("btnLlenarDatos_Click: Iniciando proceso de llenado de datos para usuario: {Usuario}, IP: {Ip}", parameters.GetCurrentUser(), parameters.GetCurrentIp());
            pnlExpiracion.ShowOnPageLoad = false;
            pnlAfiliacionConfirmacion.Visible = true;
        }

        protected void BtnDescargarQR_Click(object sender, EventArgs e)
        {
            Log.Information("BtnDescargarQR_Click: Iniciando proceso de descarga de QR para usuario: {Usuario}, IP: {Ip}", parameters.GetCurrentUser(), parameters.GetCurrentIp());

            pnlQR.ShowOnPageLoad = false;
            pnlBeneficiarioConfirmacion.Visible = false;
            pnlAfiliacionConfirmacion.Visible = true;
            byte[] imagenBytes = imgQRR.ContentBytes;
            if (imagenBytes != null)
            {
                Response.Clear();
                Response.ContentType = "image/jpeg"; // Cambia según el tipo real
                Response.AddHeader("Content-Disposition", "attachment; filename=imagen.jpg");
                Response.BinaryWrite(imagenBytes);
                Response.End();
            }




        }

    }
}