﻿using Presentacion.Yape.site.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Agente.CheckService.Models;
using Presentacion.Yape.controllers;
using Agente.CheckService.Models.Base;
using Presentacion.Parameters;
using System.Text.RegularExpressions;
using System.IO;
using System.Net;
using  Serilog;
using System.Web.UI.WebControls.WebParts;

namespace Presentacion.Yape.site.page
{
    public partial class DatosPersonales : System.Web.UI.Page, IMasterPageHandler
    {
        CAsegurado cAsegurado = new CAsegurado();
        COtp cOtp = new COtp();
        CSegip cSegip = new CSegip();
        CArchivoNegativo cArchivo = new CArchivoNegativo();
        CParameters parameters = new CParameters();
        public void HandleMasterPageAction()
        {
            if (pnlDAtosPersonales.Visible)
            {
                Session["Page"] = "Coberturas";
                Response.Redirect("~/Yape/site/page/Default.aspx");
            }
            else if (pnlConfirmacion.Visible)
            {
                Session["Page"] = "DatosPersonales";
                pnlDAtosPersonales.Visible = true;
                pnlConfirmacion.Visible = false;
            }

            // Implement any master page specific actions here
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Token"] == null)
            {
                Response.Redirect("~/Yape/site/page/Default.aspx");
            }
            if (IsPostBack)
            {
                return;
            }
            if (Session["Page"] != null)
            {
                if (Session["Page"].ToString() == "Confirmacion")
                {
                    pnlDAtosPersonales.Visible = false;
                    pnlConfirmacion.Visible = true;
                }
                else
                {
                    pnlDAtosPersonales.Visible = true;
                    pnlConfirmacion.Visible = false;
                }
            }
            else
            {
                Session["Page"] = null;
                Response.Redirect("~/Yape/site/page/Default.aspx");
            }
        }

        protected void btnComprarSeguro_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string paterno = txtPaterno.Text;
            string correo = txtCorreo.Text;
            string celular = txtCelular.Text;
            string idc = txtIdc.Text;
            DateTime? fechaNacimiento = txtFechaNacimiento.Date;

            // Expresiones regulares
            string regexCorreo = @"^[\w\.-]+@[\w\.-]+\.\w{2,}$";
            string regexCelular = @"^(\+?591)?[67]\d{7}$";

            if (string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(paterno) ||
                string.IsNullOrWhiteSpace(correo) ||
                string.IsNullOrWhiteSpace(celular) ||
                string.IsNullOrWhiteSpace(idc) ||
                fechaNacimiento == null)
            {
                lblMensaje.Text = "Por favor, completa todos los campos obligatorios.";
                modalMensaje.ShowOnPageLoad = true;
                return;
            }
            else if (!Regex.IsMatch(correo, regexCorreo))
            {
                lblMensaje.Text = "El correo electrónico no tiene un formato válido.";
                modalMensaje.ShowOnPageLoad = true;
                return;
            }
            else if (!Regex.IsMatch(celular, regexCelular))
            {
                lblMensaje.Text = "El número de celular no es válido para Bolivia.";
                modalMensaje.ShowOnPageLoad = true;
                return;
            }
          


            // validar si el check esta presionado
            if (!chkAceptarSeguro.Checked)
            {
               // Mostrar mensaje de error
                lblMensaje.Text = "Debe aceptar los términos y condiciones.";
               modalMensaje.ShowOnPageLoad = true;
                return;
            }
            //rescatamos el Token
            var token = Session["Token"].ToString();

            // rescatamos datos del formulario al objeto asegurado
            var datosPersona = new AseguradoRequest()
            {
                nombre = txtNombre.Text.ToUpper(),
                apellidoPaterno = txtPaterno.Text.ToUpper(),
                apellidoMaterno = txtMaterno.Text.ToUpper(),
                correo = txtCorreo.Text.ToUpper(),
                numeroCelular = txtCelular.Text,
                numeroDocumento = txtIdc.Text,
                fechaNacimiento = txtFechaNacimiento.Date
            };
            //guardams en session
            Session["DatosPersona"] = datosPersona;

           //validacion de listas internacionales y segip
            var segipRequest = new SegipRequest()
            {
                numeroDocumento = txtIdc.Text,
                complemento = txtComplemento.Text.ToUpper(),
                fechaNacimiento = txtFechaNacimiento.Date,
                apPaterno = txtPaterno.Text.ToUpper(),
                apMaterno = txtMaterno.Text.ToUpper(),
                nombre = txtNombre.Text.ToUpper(),
                nacionalidad = "",
                ciudad = "",
                tipoDocumento = ""
            };

            try
            {
                var validacionSegip = cSegip.ValidacionSegipCampoACampo(segipRequest, token);
                if (validacionSegip.Result.status == HttpStatusCode.OK)
                {

                    var responseSegip = validacionSegip.Result.result;
                    if (responseSegip.esValido)
                    {
                        Log.Debug("Validación Segip exitosa para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                        Log.Information("Validación Segip exitosa para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                        var archivoNegRequest = new ArchivoNegativoRequest()
                        {
                            numeroDocumento = txtIdc.Text,
                            complemento = txtComplemento.Text.ToUpper(),

                        };
                        var validacionArchivoNegativo = cArchivo.ValidarLInternacionalesANegativo(archivoNegRequest, token);
                        if (validacionArchivoNegativo.Result.status == HttpStatusCode.OK)
                        {
                            if (validacionArchivoNegativo.Result.result.validacionAMLC.estado && validacionArchivoNegativo.Result.result.validacionAN.estado)
                            {
                                Log.Debug("Validación Listas Internacionales  y Archivo Negativo exitosa para el número de documento: { NumeroDocumento}, Ip: { Ip}", txtIdc.Text, parameters.GetCurrentIp());
                                Log.Information("Validación Listas Internacionales  y Archivo Negativo exitosa para el número de documento: { NumeroDocumento}, Ip: { Ip}", txtIdc.Text, parameters.GetCurrentIp());
                                var otpRequest = new OtpRequest()
                                {
                                    correo = txtCorreo.Text,
                                    numero = txtCelular.Text,
                                    numeroDocumento = txtIdc.Text,
                                };


                                var otp = cOtp.ObtenerCodigoOtp(otpRequest, token);
                                if (otp.Result.status == HttpStatusCode.OK)
                                {
                                    Log.Debug("Código OTP generado exitosamente para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                                    Log.Information("Código OTP generado exitosamente para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                                    var codigo = otp.Result.result.CodigoRespuesta;
                                    var codigo1 = otp.Result.result.Message;
                                    var codigo2 = otp.Result.result.FechaConsulta;
                                    pnlDAtosPersonales.Visible = false;
                                    pnlConfirmacion.Visible = true;
                                }
                                else
                                {
                                    Log.Debug("Error al obtener el código OTP: {Message}, Ip: {Ip}", otp.Result.errors?.FirstOrDefault()?.MessageError ?? "No se registró ningún error.", parameters.GetCurrentIp());
                                    lblMensaje.Text = "Error al obtener el código OTP. Por favor, inténtalo de nuevo más tarde.";
                                    modalMensaje.ShowOnPageLoad = true;
                                    return;
                                }


                            }
                            else
                            {
                                Log.Debug("Validación Listas Internacionales o Archivo Negativo fallida para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                                lblMensaje.Text = "Tus datos no son válidos según las listas internacionales o negativo. Por favor, verifica tu información.";
                                modalMensaje.ShowOnPageLoad = true;
                                // observado por archivo negativo
                            }
                        }
                        else
                        {
                            Log.Debug("Error al validar listas internacionales o negativo: {Message}, Ip: {Ip}", validacionArchivoNegativo.Result.errors?.FirstOrDefault()?.MessageError ?? "No se registró ningún error.", parameters.GetCurrentIp());
                            lblMensaje.Text = "Error al validar los datos en la lista internacional o negativo. Por favor, inténtalo de nuevo más tarde.";
                            modalMensaje.ShowOnPageLoad = true;
                            return;
                        }

                    }
                    else
                    {
                        Log.Debug("Validación Segip fallida para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                        lblMensaje.Text = "Los datos ingresados no son válidos según la validación del Segip. Por favor, verifica tu información.";
                        modalMensaje.ShowOnPageLoad = true;
                        return;

                    }


                }
                else
                {
                    Log.Debug("Error al validar Segip: {Message}, Ip: {Ip}", validacionSegip.Result.errors?.FirstOrDefault()?.MessageError ?? "No se registró ningún error.",parameters.GetCurrentIp());
                    lblMensaje.Text = "Ocurrio un error inesperado";
                    modalMensaje.ShowOnPageLoad = true;
                    return;
                }
            }
            catch(Exception ex)
            {
                Log.Error(ex, "Pagina: DatosPersonales.aspx, Accion: btnComprarSeguro_Click");
                Response.Redirect("~/Yape/site/misc/error.aspx");

            }



        }

        protected void btnContinuar_Click(object sender, EventArgs e)
        {
            try
            {


                var otpValidRequest = new OtpValidRequest()
                {
                    codigo = key1.Text + key2.Text + key3.Text + key4.Text + key5.Text + key6.Text,
                    numeroDocumento = txtIdc.Text
                };
                //rescatamos el Token
                var token = Session["Token"].ToString();
                // rescatar credenciales del usuario

                var otpValid = cOtp.ValidarCodigoOtp(otpValidRequest, token);
                if (otpValid.Result.status == HttpStatusCode.OK)
                {
                    if (otpValid.Result.result.CodigoRespuesta == 0)
                    {
                        Session["Page"] = "pnlConfirmacion";
                        Response.Redirect("~/Yape/site/page/BeneficiarioConfirmacion.aspx",false);
                   
                        //Log.Debug("Código OTP validado exitosamente para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                        //Log.Information("Código OTP validado exitosamente para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                    }
                    else
                    {
                        Log.Debug("Código OTP inválido o expirado para el número de documento: {NumeroDocumento}, Ip: {Ip}", txtIdc.Text, parameters.GetCurrentIp());
                        lblMensaje.Text = "El código OTP ingresado es incorrecto o ha expirado. Por favor, intenta nuevamente.";
                        modalMensaje.ShowOnPageLoad = true;
                        return;
                    }

                }
                else
                {
                    Log.Debug("Error al validar el código OTP: {Message}, Ip: {Ip}", otpValid.Result.errors?.FirstOrDefault()?.MessageError ?? "No se registró ningún error.", parameters.GetCurrentIp());
                    lblMensaje.Text = "Tu código es incorrecto o paso el límite de tiempo, intenta otra vez..";
                    modalMensaje.ShowOnPageLoad = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Pagina: DatosPersonales.aspx, Accion: btnContinuar_Click");
                Response.Redirect("~/Yape/site/misc/error.aspx");

            }
        }

        protected void lnkTerminoCondiciones_Click (object sender, EventArgs e)
        {
            try
            {
                Log.Information("Descarga de términos y condiciones iniciada por el usuario con IP: {Ip}", parameters.GetCurrentIp());
                string filePath = Server.MapPath("~/Yape/assets/file/TERMINOSYCONDICIONES.pdf");
                Response.ContentType = "application/pdf";
                Response.AppendHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(filePath));
                Response.WriteFile(filePath);
                Response.End();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Pagina: DatosPersonales.aspx, Accion: lnkTerminoCondiciones_Click");
                return;

            }
        }
    }
}