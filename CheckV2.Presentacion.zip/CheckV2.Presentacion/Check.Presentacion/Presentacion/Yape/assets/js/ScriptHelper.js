﻿
function mostrarFechaHora() {
    var ahora = new Date();

    // Opciones para formato específico
    var opcionesFecha = { day: 'numeric', month: 'short', year: 'numeric' };
    var opcionesHora = { hour: 'numeric', minute: 'numeric', hour12: true };

    var fecha = new Intl.DateTimeFormat('es-ES', opcionesFecha).format(ahora);
    var hora = new Intl.DateTimeFormat('es-ES', opcionesHora).format(ahora);

    document.getElementById("fecha-hora").innerHTML = fecha + " - " + hora;
}

setInterval(mostrarFechaHora, 1000);





