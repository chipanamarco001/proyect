﻿using Agente;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Agente.CheckService.Models;
using Agente.CheckService.Models.Base;
using Presentacion.Parameters;
using System.Net;
using Serilog;
using System.Diagnostics;
using System.Reflection;


namespace Presentacion.Yape.controllers
{
    public class CLexico
    {
        private readonly IHttpClientService lexicoService = new HttpClientService();

        public async Task<ResponseService<List<LexicoResponse>>> ObtenerListaLexicoPorTablaTema(LexicoRequest data, string token)
        {

            var result = new ResponseService<List<LexicoResponse>>();
            try
            {
                var urlBase = CParameters.urlGetLexicoPorTablaTema;
                CParameters cParameters = new CParameters();
                var credentials = new Credentials()
                {
                    usuario = cParameters.GetCurrentUser(),
                    ip = cParameters.GetCurrentIp(),
                };
                var request = new RequestService<LexicoRequest>
                {
                    solicitud = data,
                    credenciales = credentials
                };
                result = await lexicoService.PostAsync<RequestService<LexicoRequest>, List<LexicoResponse>>(urlBase, request, token).ConfigureAwait(false);

                return result;
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                StackFrame frame = trace.GetFrame(trace.FrameCount - 1);
                MethodBase method = frame.GetMethod();
                var cRegistrarError = new CRegistrarError();
                var registrarErrorRequest = new RegistrarErrorRequest
                {
                    codigoError = result.status,
                    mensaje = ex.Message,
                    innerException = ex.InnerException?.ToString(),
                    stackTrace = ex.StackTrace,
                    metodo = frame.GetMethod().Name,
                    pagina = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"

                };
                try
                {
                    var registrarErrorResponse = await cRegistrarError.RegistrarError(registrarErrorRequest).ConfigureAwait(false);
                }
                catch (Exception exInterno)
                {
                    Log.Error("Error al {Metodo}: {Message}", "RegistrarError", exInterno.Message);
                }
                Log.Error("Error al {Metodo} : {Message}", frame.GetMethod().Name, ex.Message);
                return new ResponseService<List<LexicoResponse>>
                {
                    hasError = true,
                    result = null,
                    status = HttpStatusCode.BadRequest,
                    errors = new List<Error>()
                    {
                        new Error
                            {
                                MessageError = ex.Message,
                                InnerException = ex.InnerException.ToString(),
                                StackTrace = ex.StackTrace,
                                MethodName = frame.GetMethod().Name,
                                PropertyName = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"
                            }
                    }
                };
            }
        }
    }
}