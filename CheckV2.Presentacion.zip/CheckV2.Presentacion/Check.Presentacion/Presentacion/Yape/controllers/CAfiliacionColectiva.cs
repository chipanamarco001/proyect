﻿
using Agente.CheckService.Models.Base;
using Agente.CheckService.Models;
using Presentacion.Parameters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Agente;
using Serilog;
using System.Net;
using System.Diagnostics;
using System.Reflection;

namespace Presentacion.Yape.controllers
{
    public class CAfiliacionColectiva
    {
        private readonly IHttpClientService afiliacionService = new HttpClientService();

        public async Task<ResponseService<AfiliacionColectivaResponse>> RegistrarAfiliacionColectiva(AfiliacionColectivaRequest data, string token)
        {
          
            var result = new ResponseService<AfiliacionColectivaResponse>();
            try
            {
                var urlBase = CParameters.urlSaveAfiliacion;
                CParameters cParameters = new CParameters();
                var credentials = new Credentials()
                {
                    usuario = cParameters.GetCurrentUser(),
                    ip = cParameters.GetCurrentIp(),
                };
                var request = new RequestService<AfiliacionColectivaRequest>
                {
                    solicitud = data,
                    credenciales = credentials
                };
                result = await afiliacionService.PostAsync<RequestService<AfiliacionColectivaRequest>, AfiliacionColectivaResponse>(urlBase, request, token).ConfigureAwait(false);

                return result;
            }
            catch (Exception ex)
            {
                StackTrace trace = new StackTrace(ex, true);
                StackFrame frame = trace.GetFrame(trace.FrameCount - 1);
                MethodBase method = frame.GetMethod();
                var cRegistrarError = new CRegistrarError();
                var registrarErrorRequest = new RegistrarErrorRequest
                {
                    codigoError = result.status,
                    mensaje = ex.Message,
                    innerException = ex.InnerException?.ToString(),
                    stackTrace = ex.StackTrace,
                    metodo = frame.GetMethod().Name,
                    pagina = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"

                };
                try
                {
                    var registrarErrorResponse = await cRegistrarError.RegistrarError(registrarErrorRequest).ConfigureAwait(false);
                }
                catch (Exception exInterno)
                {
                    Log.Error("Error al {Metodo}: {Message}", "RegistrarError", exInterno.Message);
                }
                Log.Error("Error al {Metodo} : {Message}", frame.GetMethod().Name, ex.Message);
                return new ResponseService<AfiliacionColectivaResponse>
                {
                    hasError = true,
                    result = null,
                    status = HttpStatusCode.BadRequest,
                    errors = new List<Error>()
                    {
                        new Error
                            {
                                MessageError = ex.Message,
                                InnerException = ex.InnerException.ToString(),
                                StackTrace = ex.StackTrace,
                                MethodName = frame.GetMethod().Name,
                                PropertyName = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"
                            }
                    }
                };
            }
           

        }
    }
}