﻿using Agente;
using System;
using Agente.CheckService.Models;
using Agente.CheckService.Models.Base;
using Newtonsoft.Json.Linq;
using Presentacion.Parameters;
using System.Threading.Tasks;
using Serilog;
using System.Net;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Linq;

namespace Presentacion.Yape.controllers
{
    public class CToken
    {
        private readonly IHttpClientService TokenService = new HttpClientService();

        public async Task<ResponseService<TokenResponse>> ObtenerToken(TokenRequest token)
        {
            var result = new ResponseService<TokenResponse>();
            try
            {

                var urlBase = CParameters.urlLogin;
                result = await TokenService.PostAsync<TokenRequest, TokenResponse>(urlBase, token, null).ConfigureAwait(false);

                return result;
            }
            catch (Exception ex)
            {  
                StackTrace trace = new StackTrace(ex, true);
                StackFrame frame = trace.GetFrame(trace.FrameCount - 1);
                MethodBase method = frame.GetMethod();
                var cRegistrarError = new CRegistrarError();
                var registrarErrorRequest = new RegistrarErrorRequest
                {
                    codigoError = result.status,
                    mensaje = ex.Message,
                    innerException = ex.InnerException?.ToString(),
                    stackTrace = ex.StackTrace,
                    metodo = frame.GetMethod().Name,
                    pagina = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"

                };
                Log.Error("Error al {Metodo}por tabla tema: {Message}", frame.GetMethod().Name, ex.Message);
                try
                {
                    var registrarErrorResponse = await cRegistrarError.RegistrarError(registrarErrorRequest).ConfigureAwait(false);
                }
                catch (Exception exInterno)
                {
                    Log.Error("Error al {Metodo}: {Message}", "RegistrarError", exInterno.Message);
                }
              
                return new ResponseService<TokenResponse>
                {
                    hasError = true,
                    result = null,
                    status = HttpStatusCode.BadRequest,
                    errors = new List<Error>()
                    {
                        new Error
                            {
                                MessageError = ex.Message,
                                InnerException = ex.InnerException.ToString(),
                                StackTrace = ex.StackTrace,
                                MethodName = frame.GetMethod().Name,
                                PropertyName = method.DeclaringType != null ? method.DeclaringType.FullName : "Clase desconocida"
                            }
                    }
                };
            }

        }
    }
}