﻿
using Agente.CheckService.Models.Base;
using Agente.CheckService.Models;
using Presentacion.Parameters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Agente;
using Serilog;

namespace Presentacion.Yape.controllers
{
    public class CRegistrarError
    {
        private readonly IHttpClientService afiliacionService = new HttpClientService();

        public async Task<ResponseService<RegistrarErrorResponse>> RegistrarError(RegistrarErrorRequest data)
        {
            try
            {


                var urlBase = CParameters.urlSaveError;
                CParameters cParameters = new CParameters();
                var credentials = new Credentials()
                {
                    usuario = cParameters.GetCurrentUser(),
                    ip = cParameters.GetCurrentIp(),
                };
                var request = new RequestService<RegistrarErrorRequest>
                {
                    solicitud = data,
                    credenciales = credentials
                };
                var result = await afiliacionService.PostAsync<RequestService<RegistrarErrorRequest>, RegistrarErrorResponse>(urlBase, request, null).ConfigureAwait(false);

                return result;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error al Registrar en servicio Error Log");
                return null;
            }

        }
    }
}