﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.Yape.entities
{
    public class CoberturaModel
    {
public string CODIGO { get; set; }
public string	DESCRIPCION { get; set; }
		public string TIPO { get; set; }
		public string MONEDA {  get; set; }
		public decimal SUMA_ASEGURADA { get; set; }
		public string DESCRIPCION_SUMA_ASEGURADA { get; set; }
		public bool FLAG_COBERTURA_PRINCIPAL { get; set; }
		public long DIAS_CARENCIA { get; set; }
		public decimal TASA_COMERCIAL { get; set; }
    }
}