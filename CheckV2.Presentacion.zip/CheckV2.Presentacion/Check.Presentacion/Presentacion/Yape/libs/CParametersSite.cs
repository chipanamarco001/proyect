﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static System.Net.WebRequestMethods;

namespace Presentacion.Yape.libs
{
    public  class CParametersSite
        
    {
        // armar contructor
       

        public static string idProducto = "CHKYVG";
        public static  string subProductoDescripcion= "YAPE VIDA";
        public static string enlaceWS= "https://wa.me/+59122175900";
        public static string enlaceFc = "https://wa.me/+59122175900";
        public static string enlaceIn = "https://wa.me/+59122175900";
        public static string usuarioTk= "admin";
        public static string passTk= "admin";
        public static int timerQR = 30;
    }
}