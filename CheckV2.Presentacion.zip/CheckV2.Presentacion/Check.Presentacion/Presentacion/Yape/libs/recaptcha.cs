﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;

namespace Presentacion.Yape.libs
{
    public class recaptcha
    {
        public static bool Validate(string response)
        {
            var secretKey = ConfigurationManager.AppSettings["RecaptchaSecretKey"];
            var client = new WebClient();
            var result = client.DownloadString($"https://www.google.com/recaptcha/api/siteverify?secret={secretKey}&response={response}");
            var serializer = new JavaScriptSerializer();
            dynamic jsonObject = serializer.Deserialize<object>(result);
            return jsonObject["success"];
        }
    }
}