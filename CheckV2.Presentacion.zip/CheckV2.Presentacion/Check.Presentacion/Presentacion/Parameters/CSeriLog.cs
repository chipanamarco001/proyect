﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Diagnostics;
using Serilog;
using System.Configuration;

namespace Presentacion.Parameters
{
    public static class CSeriLog
    {
        private static string _usuario;
        private static string _ip;
        private static string _BrowserName;
        private static string _BrowserVersion;
        private static string _SistemaOperativo;



        public static void Debug(string message)
        {
            Log.Debug(message);
        }

        public static void Info(string message)
        {
            Log.Information(message);
        }

        public static void Error(string message, Exception ex = null)
        {
            if (ex != null)
                Log.Error(ex, message);
            else
                Log.Error(message);
        }


        public static void Inicio(string strUsuario, string strIp, string BrowserName, string BrowserVersion, string SistemaOperativo)
        { //iniciar serilog
            _usuario = strUsuario;
            _ip = strIp;
            _BrowserName = BrowserName;
            _BrowserVersion = BrowserVersion;
            _SistemaOperativo = SistemaOperativo;
            string rutaLog = ConfigurationManager.AppSettings["RutaLogs"];
            MethodBase methodo = new StackTrace().GetFrame(1).GetMethod();
           string nombreMetodo = methodo.Name;
            string nombreClase = methodo.DeclaringType.Name;
            Serilog.Log.Logger = new Serilog.LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.File(rutaLog, rollingInterval: RollingInterval.Day)
                .CreateLogger();
            Serilog.Log.Information(" Clase:["+ nombreClase + "] / Metodo:[" + nombreMetodo + "] / Usuario:[" + _usuario + "] / IP:[" + _ip + "] / Browser:[" + _BrowserName + "] / Verison-Browser:[" + _BrowserVersion + "] / Sistema-Operativo:[" + _SistemaOperativo + "]");
        }
        public static void Fin()
        {

            //finalizar serilog
            Serilog.Log.CloseAndFlush();
        }
    }
}