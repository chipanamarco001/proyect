﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Web;


namespace Presentacion.Parameters
{
    public class CParameters
    {
        public static string UrlCheckBase = "https://devcrs02/Crs.Check.core";
        //public static string UrlCheckBase = "https://localhost:7066";
        #region Afiliacion
        public static string urlSaveAfiliacion = UrlCheckBase + "/api/Afiliacion/RegistrarAfiliacionColectiva";
        public static string urlGetAfiliacion = UrlCheckBase + "/api/Afiliacion/ObtenerAfiliacionPorId";
        public static string urlSaveAsegurado = UrlCheckBase + "/api/Afiliacion/RegistrarAsegurado";
        public static string urlSaveBeneficiario = UrlCheckBase + "/api/Afiliacion/RegistrarBeneficiario";
        #endregion
        #region Autenticacion
        public static string urlLogin = UrlCheckBase + "/api/Autenticacion/IniciarSesion";
        #endregion
        #region Configuracion
        public static string urlGetLexicoPorTabla = UrlCheckBase + "/api/Configuracion/ObtenerListaLexicoPorTabla";
        public static string urlGetLexicoPorTablaTema = UrlCheckBase + "/api/Configuracion/ObtenerListaLexicoPorTablaTema";
        public static string urlGetListClienteYapePorDocumentoCorreo = UrlCheckBase + "/api/Configuracion/ObtenerListaClienteYapePorDocumentoCorreo";
        public static string urlGetListProductoActivo = UrlCheckBase + "/api/Configuracion/ObtenerListaProductoActivo";
        public static string urlGetProductoParametroPorIdSubProducto = UrlCheckBase + "/api/Configuracion/ObtenerProductoParametroPorIdSubProducto";
        public static string urlGetSubProductoPorIdProdDescripcion = UrlCheckBase + "/api/Configuracion/ObtenerSubProductoPorIdProdDescripcion";
        public static string urlSaveError = UrlCheckBase + "/api/Configuracion/RegistrarError";

        #endregion
        #region Cobro
        public static string urlRegistrarCobro = UrlCheckBase + "/api/Cobros/RegistrarCobroInicial";
        #endregion
        #region Transacciones
        public static string urlGetOtp = UrlCheckBase + "/api/Transacciones/ObtenerCodigoOtp";
        public static string urlValidOtp = UrlCheckBase + "/api/Transacciones/ValidarCodigoOtp";
        public static string urlgenerarQrDebito = UrlCheckBase + "/api/Transacciones/GenerarQrDebito";
        public static string urlValidSegipCampoACampo = UrlCheckBase + "/api/Transacciones/ValidacionSegipCampoACampo";
        public static string urlValidarLInternacionalesANegativo = UrlCheckBase + "/api/Transacciones/ValidarLInternacionalesANegativo";
        public static string urlValidarEnviarCorreoYape = UrlCheckBase + "/api/Transacciones/EnviarCorreoYape";
        public static string urlGetCertificadoYape = UrlCheckBase + "/api/Transacciones/ObtenerCertificadoYape";
        #endregion
        public string GetCurrentUser()
        {
            string strIdUsuario = string.Empty;
            var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
            strIdUsuario = (HttpContext.Current.User.Identity.Name != string.Empty) ? HttpContext.Current.User.Identity.Name : ((windowsIdentity != null) ? windowsIdentity.Name : string.Empty);

            return strIdUsuario;
        }

        public string GetCurrentIp()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return null;

        }
       


        public string DetectarSistemaOperativo(string userAgent)
        {
            if (userAgent.Contains("Windows NT 10.0"))
                return "Windows 10";
            else if (userAgent.Contains("Windows NT 6.3"))
                return "Windows 8.1";
            else if (userAgent.Contains("Windows NT 6.2"))
                return "Windows 8";
            else if (userAgent.Contains("Windows NT 6.1"))
                return "Windows 7";
            else if (userAgent.Contains("Mac OS X"))
                return "Mac OS X";
            else if (userAgent.Contains("Linux"))
                return "Linux";
            else if (userAgent.Contains("Android"))
                return "Android";
            else if (userAgent.Contains("iPhone"))
                return "iOS";
            else
                return "Sistema operativo desconocido";
        }



    }
}