﻿using Agente.ServicioGenerales;
using Presentacion.controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Configuration;
using System.Web.Configuration;
using System.Web.UI;
using System.Text;
using System.Globalization;

namespace Presentacion
{
    public partial class Site : System.Web.UI.MasterPage
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                return;
            }
            if (Session["SessionUsuario"] == null)
            {
                Response.Redirect("~/site/auth/login.aspx");
            }
            else
            {
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                LblNombreUsuario.Text = objUsuario.NombreCompleto + " (" + objUsuario.Matricula + ")";
                LblCorreoUsuario.Text = objUsuario.Correo;
                AsignaNombrePagina(HttpContext.Current.Request.CurrentExecutionFilePath);
                UlMenuUsuario.InnerHtml = new StringBuilder().Append(MenuUsuario(objUsuario.Menu)).ToString();
            }
            int intTimeout = Timeout();
            HidTimeout.Value = intTimeout.ToString();
            Page.ClientScript.RegisterStartupScript(this.GetType(), "SessionAlert", "SessionExpireAlert(" + intTimeout + ");", true);
            CargarMesProduccion();
        }
        private static int Timeout()
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
            SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
            return Convert.ToInt32(section.Timeout.TotalMinutes * 1000 * 60);
        }
        public void AsignaNombrePagina(string strPagina)
        {
            try
            {
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                var listaPagina = objUsuario.Menu.Where(w => w.Tipo == "PAGINA");
                foreach (var objMenu in listaPagina)
                {
                    if (ResolveUrl(objMenu.PaginaUrl) == strPagina)
                    {
                        LblNombrePagina.Text = string.IsNullOrEmpty(objMenu.PaginaNombre) ? Page.Title : objMenu.PaginaNombre;
                        LblModloActivo.Text = objMenu.Contenedor;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected string MenuUsuario(List<occ_menu> listaMenu)
        {
            try
            {
                string strHtml = string.Empty;
                strHtml += "<li class='menu-item'>" + "<a href='" + ResolveUrl("~/site/misc/inicio.aspx") + "' class='menu-link'>" + "<i class='menu-icon tf-icons bx bx-home'></i>" + "<div data-i18n='Inicio'>Inicio</div>" + "</a>" + "</li>";
                int intCantidadNiveles = listaMenu.Max(m => m.Nivel);
                bool boolToggle = false;
                var listaNivel1 = listaMenu.Where(w => w.Nivel == 1 && w.IdMenuPadre == null).OrderBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                string strContenedor = string.Empty;
                foreach (var objMenu in listaNivel1)
                {
                    if (boolToggle && strContenedor != string.Empty && strContenedor != objMenu.Contenedor)
                    {
                        strHtml += "</ul></li>";
                        boolToggle = false;
                        strContenedor = string.Empty;
                    }
                    if (!boolToggle && !string.IsNullOrEmpty(objMenu.Contenedor))
                    {
                        strHtml += 
                            "<li class='menu-item'>" + 
                                "<a href='javascript:void(0);' class='menu-link menu-toggle'>" + 
                                    "<i class='menu-icon tf-icons bx bx-collection'></i>" + 
                                    "<div data-i18n='" + objMenu.Contenedor + "'>" + objMenu.Contenedor + "</div>" + 
                                "</a>" + 
                                "<ul class='menu-sub'>";
                        strContenedor = objMenu.Contenedor;
                        boolToggle = true;
                    }
                    if (objMenu.Tipo == "PAGINA")
                    {
                        strHtml += 
                            "<li class='menu-item'>" +                            
                                "<a href='" + ResolveUrl(objMenu.PaginaUrl) + "' class='menu-link'>"+
                                    ((strContenedor == string.Empty) ? "<i class=\"menu-icon tf-icons bx bx-detail\"></i>" : string.Empty) +
                                    "<div class='text-truncate' data-i18n='" + (string.IsNullOrEmpty(objMenu.PaginaNombre) ? objMenu.Contenedor : objMenu.PaginaNombre) + "'>" + (string.IsNullOrEmpty(objMenu.PaginaNombre) ? objMenu.Contenedor : objMenu.PaginaNombre) + "</div>" + 
                                "</a>" + 
                            "</li>";
                    }
                    else if (objMenu.Tipo == "CARPETA")
                    {
                        strHtml += 
                            "<li class='menu-item'>" + 
                                "<a href='javascript:void(0);' class='menu-link menu-toggle'>" + 
                                    "<i class='menu-icon tf-icons bx bx-collection'></i>" + 
                                    "<div class='text-truncate' data-i18n='" + objMenu.PaginaNombre + "'>" + objMenu.PaginaNombre + "</div>" + 
                                "</a>" + 
                                "<ul class='menu-sub'>";
                        var listaNivel2 = listaMenu.Where(w => w.IdMenuPadre == objMenu.IdMenu).OrderBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                        foreach (var objNivel2 in listaNivel2)
                        {
                            if (objNivel2.Tipo == "PAGINA")
                            {
                                strHtml +=
                                    "<li class='menu-item'>" +
                                        "<a href='" + ResolveUrl(objNivel2.PaginaUrl) + "' class='menu-link'>" +
                                            "<i class=\"menu-icon tf-icons bx bx-detail\"></i>" +
                                            "<div class='text-truncate' data-i18n='" + objNivel2.PaginaNombre + "'>" + objNivel2.PaginaNombre + "</div>" +
                                        "</a>" +
                                    "</li>";
                            }
                            else if (objNivel2.Tipo == "CARPETA")
                            {
                                strHtml += 
                                    "<li class='menu-item'>" + 
                                        "<a href='javascript:void(0);' class='menu-link menu-toggle'>" + 
                                            "<div data-i18n='" + objNivel2.PaginaNombre + "'>" + objNivel2.PaginaNombre + "</div>" + 
                                        "</a>" + 
                                        "<ul class='menu-sub'>";
                                var listaNivel3 = listaMenu.Where(w => w.IdMenuPadre == objNivel2.IdMenu).OrderBy(o => o.NivelOrden).ThenBy(o => o.PaginaOrden).ToList();
                                foreach (var objNivel3 in listaNivel3)
                                {
                                    if (objNivel3.Tipo == "PAGINA")
                                    {
                                        strHtml += 
                                            "<li class='menu-item'>" + 
                                                "<a href='" + ResolveUrl(objNivel3.PaginaUrl) + "' class='menu-link'>" + 
                                                    "<div data-i18n='" + objNivel3.PaginaNombre + "'>" + objNivel3.PaginaNombre + "</div>" + 
                                                "</a>" + 
                                            "</li>"; 
                                        strHtml += "</ul></li>";
                                    }
                                }
                            }
                        }
                        strHtml += "</ul></li>";
                    }
                }
                if (boolToggle)
                    strHtml += "</ul></li>";
                strHtml += "<li class='menu-item'>" + "<a href='" + ResolveUrl("~/site/auth/login.aspx") + "' class='menu-link'>" + "<i class='menu-icon tf-icons bx bx-power-off'></i>" + "<div data-i18n='CerrarSesion'>Cerrar Sesión</div>" + "</a>" + "</li>";
                return strHtml;
            }
            catch
            {
                throw;
            }
        }
        public void RegistrarExcepcion(Exception objExcepcion, string strPagina, string strMetodo)
        {
            try
            {
                if (Session["LISTA_EXCEPCIONES"] != null)
                {
                    var listaErrores = (List<Excepcion>)Session["LISTA_EXCEPCIONES"];
                    foreach (var objError in listaErrores)
                    {
                        var objResponseError = _cGenerales.Error_Registrar(new ERROR()
                        {
                            ERPVC_PAGINA = (string.IsNullOrEmpty(objError.Pagina) ? string.Empty : objError.Pagina),
                            ERPVC_METODO = (string.IsNullOrEmpty(objError.Metodo) ? string.Empty : objError.Metodo),
                            ERPVC_MENSAJE = (string.IsNullOrEmpty(objError.Mensaje) ? string.Empty : objError.Mensaje),
                            ERPVC_STACK_TRACE = (string.IsNullOrEmpty(objError.StackTrace) ? string.Empty : objError.StackTrace),
                            ERPVC_INNER_EXCEPTION = (string.IsNullOrEmpty(objError.InnerException) ? string.Empty : objError.InnerException)
                        });
                    }
                }
                var objResponse = _cGenerales.Error_Registrar(new ERROR()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objExcepcion.Message == null) ? string.Empty : objExcepcion.Message,
                    ERPVC_STACK_TRACE = (objExcepcion.StackTrace == null) ? string.Empty : objExcepcion.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objExcepcion.InnerException == null) ? string.Empty : "Message: " + objExcepcion.InnerException.Message,
                        (objExcepcion.InnerException == null) ? string.Empty : "StackTrace: " + objExcepcion.InnerException.StackTrace)
                });
                Session["ErrorMensaje"] = "Se ha producido un error en el proceso.";
                Response.Redirect("~/site/misc/error.aspx", false);
            }
            catch (Exception ex)
            {
                Session.Clear();
                Session["ErrorMensaje"] = ex.Message;
                Response.Redirect("~/site/misc/error.aspx", false);
            }
        }
        public void CargarMesProduccion()
        {
            try
            {
                var objLexico = _cGenerales.ListaLexicosPorTabla("MES_PRODUCCION");                
                DateTime dtPeriodoProcesoActual = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                DateTime dtPeriodo = DateTime.ParseExact(objLexico.Where(w => w.LEPVC_TEMA == "PUBLICACION").FirstOrDefault().LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                CmbPeriodoContable.Items.Clear();
                while (dtPeriodo <= dtPeriodoProcesoActual)
                {
                    string strMesProduccionLiteral = dtPeriodo.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodo.Year.ToString();
                    CmbPeriodoContable.Items.Add(strMesProduccionLiteral, dtPeriodo.ToString("yyyyMM"));
                    dtPeriodo = dtPeriodo.AddMonths(1);
                }
                string strMesProduccion = (Session["MES_PRODUCCION"] == null) ? dtPeriodoProcesoActual.ToString("yyyyMM") : Session["MES_PRODUCCION"].ToString();
                DateTime dtPeriodoProceso = DateTime.ParseExact(strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                CmbPeriodoContable.Value = strMesProduccion;
                LblMesProduccion.Text = dtPeriodoProceso.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.Year.ToString();
                Session["MES_PRODUCCION"] = strMesProduccion;
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strPeriodoContable = CmbPeriodoContable.SelectedItem.Value.ToString();
                Session["MES_PRODUCCION"] = strPeriodoContable;
                DateTime dtPeriodoProceso = DateTime.ParseExact(strPeriodoContable + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                LblMesProduccion.Text = dtPeriodoProceso.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtPeriodoProceso.Year.ToString();
                PopCambioPeriodo.ShowOnPageLoad = false;
                Response.Redirect(HttpContext.Current.Request.Url.AbsoluteUri, false);
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}