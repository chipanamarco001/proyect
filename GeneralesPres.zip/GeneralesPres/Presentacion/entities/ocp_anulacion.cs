﻿using System;

namespace Presentacion.entities
{
    public class ocp_anulacion
    {
        public string IdProducto { get; set; }
        public long IdAfiliacion { get; set; }
        public string Poliza { get; set; }
        public string NumeroCertificado { get; set; }
        public string DocumentoNumero { get; set; }
        public string Moneda { get; set; }
        public DateTime FechaInicioVigencia { get; set; }
        public DateTime FechaFinVigencia { get; set; }
        public decimal PrimaComercial { get; set; }
        public decimal PrimaNeta { get; set; }
        public decimal PrimaAdicional { get; set; }
        public decimal ImporteIVA { get; set; }
        public decimal ComisionBroker { get; set; }
        public decimal PrimaCedida { get; set; }
        public decimal FactorPrimaNeta { get; set; }
        public int DiasVigenciaAfiliacion { get; set; }
        public string TipoAnulacion { get; set; }
        public int Diferimiento_Aniversarios { get; set; }
        public DateTime Diferimiento_Desde { get; set; }
        public DateTime Diferimiento_Hasta { get; set; }
        public int Diferimiento_Dias { get; set; }
        public decimal Diferimiento_Prima{ get; set; }
        public decimal Diferimiento_Saldo { get; set; }


        public static decimal FactorPlazosCortos(int intMesesCorridos)
        {
            try
            {
                decimal decFactor = 0;
                switch (intMesesCorridos)
                {
                    case 1:
                    case 2:
                    case 3: decFactor = 0.45m; break;
                    case 4: decFactor = 0.50m; break;
                    case 5: decFactor = 0.60m; break;
                    case 6: decFactor = 0.70m; break;
                    case 7: decFactor = 0.75m; break;
                    case 8: decFactor = 0.85m; break;
                    case 9: decFactor = 0.90m; break;
                    case 10:
                    case 11:
                    case 12: decFactor = 1; break;
                    default: decFactor = 0; break;
                }
                return decFactor;
            }
            catch
            {
                throw;
            }
        }
        public static int MesesCorridos(string strProducto, int intDiasCorridos)
        {
            try
            {
                int intMesesCorridos = 0;
                intMesesCorridos =
                    Convert.ToInt32((strProducto == "CRSVSP") ?
                        (((Convert.ToDecimal(intDiasCorridos) / 30.00m) - Math.Truncate(Convert.ToDecimal(intDiasCorridos) / 30.00m) <= 0.50m) ?
                            Math.Truncate(Convert.ToDecimal(intDiasCorridos) / 30.00m) :
                            Math.Truncate((Convert.ToDecimal(intDiasCorridos) / 30.00m) + 1.0000m)) :
                        Convert.ToInt32(Math.Round(Convert.ToDecimal(intDiasCorridos) / 30.00m, 0)));
                return intMesesCorridos;
            }
            catch
            {
                throw;
            }
        }
        public static decimal Prorrateo(decimal decImporte, int intDiasVigencia, int intDiasCorridos)
        {
            try
            {
                decimal decPrimaAnulada = 0;
                decPrimaAnulada = decImporte - Math.Round((decImporte / Convert.ToDecimal(intDiasVigencia)) * Convert.ToDecimal(intDiasCorridos), 2);
                return decPrimaAnulada;
            }
            catch
            {
                throw;
            }
        }
        public static decimal PlazosCortos(decimal decImporte, decimal decPlazosCortos)
        {
            try
            {
                decimal decPrimaAnulada = 0;
                decPrimaAnulada = decImporte - Math.Round(decImporte * decPlazosCortos, 2);
                return decPrimaAnulada;
            }
            catch
            {
                throw;
            }
        }
    }
}