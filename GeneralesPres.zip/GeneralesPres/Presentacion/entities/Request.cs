﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.entities
{
    public class Request
    {
        public string NumeroDocumento { get; set; }
        public string Complemento { get; set; }
        public string Nombres { get; set; }
        public string PrimerApellido { get; set; }
        public string SegundoApellido { get; set; }
        public string FechaNacimiento { get; set; }
        public string LugarNacimientoPais { get; set; }
        public string LugarNacimientoDepartamento { get; set; }
        public string LugarNacimientoProvincia { get; set; }
        public string LugarNacimientoLocalidad { get; set; }
    }
}