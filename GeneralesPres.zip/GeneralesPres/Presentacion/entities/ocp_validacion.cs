﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.entities
{
	public class ocp_validacion
	{
       
    }
	public class ocp_validacion_in
	{
        public string condicion { get; set; }

        public string formula_valor { get; set; }

        public string tipo_dato { get; set; }
    }

}