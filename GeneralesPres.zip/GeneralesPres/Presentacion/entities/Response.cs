﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.entities
{
    public class Response
    {
        public int ApellidoEsposo { get; set; }
        public int Complemento { get; set; }
        public int FechaNacimiento { get; set; }
        public int LugarNacimientoDepartamento { get; set; }
        public int LugarNacimientoLocalidad { get; set; }
        public int LugarNacimientoPais { get; set; }
        public int LugarNacimientoProvincia { get; set; }
        public int NumeroDocumento { get; set; }
        public int Nombres { get; set; }
        public int PrimerApellido { get; set; }
        public int ProfesionOcupacion { get; set; }
        public int SegundoApellido { get; set; }
        public int ComplementoVisible { get; set; }
        public string Print()
        {
            return $"{PrimerApellido}, {SegundoApellido}, {Nombres}, {FechaNacimiento}, {NumeroDocumento}";
        }

        public string PrintFialed()
        {
            string observations = String.Empty;
            if (NumeroDocumento != 1)
            {
                observations += "Numero de Documento";
            }
            if (Complemento != 1)
            {
                observations += String.IsNullOrEmpty(observations) ? "Complemento" : ";Complemento";
            }
            if (PrimerApellido != 1)
            {
                observations += String.IsNullOrEmpty(observations) ? "Apellido Paterno" : ";Apellido Paterno";
            }
            if (SegundoApellido != 1)
            {
                observations += String.IsNullOrEmpty(observations) ? "Apellido Materno" : ";Apellido Materno";
            }
            if (Nombres != 1)
            {
                observations += String.IsNullOrEmpty(observations) ? "Nombre" : ";Nombre";
            }
            if (FechaNacimiento != 1)
            {
                observations += String.IsNullOrEmpty(observations) ? "Fecha de Nacimiento" : ";Fecha de Nacimiento";
            }
            return observations;
        }
    }
}