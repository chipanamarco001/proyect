﻿using System.Collections.Generic;

namespace Presentacion.entities
{
    public class ocp_cuadro_cierre
    {
        public string Ramo { get; set; }
        public string TipoTomador { get; set; }
        public string NitTomador { get; set; }
        public string NombreTomador { get; set; }
        public string NumeroPoliza { get; set; }
        public string IdProducto { get; set; }
        public string NombreProducto { get; set; }
        public string Moneda { get; set; }
        public decimal PrimaComercial { get; set; }
        public decimal PrimaNeta { get; set; }
        public decimal PrimaAdicional { get; set; }
        public decimal ImporteIVA { get; set; }
        public decimal ImporteIT { get; set; }
        public decimal ComisionCobranza { get; set; }
        public decimal AporteAPS { get; set; }
        public decimal AporteFPA { get; set; }
        public decimal SumaAsegurada { get; set; }
        public string NombreBroker { get; set; }
        public decimal ComisionBroker { get; set; }

        public bool Anulacion { get; set; }
        public decimal AnulacionPrimaComercial { get; set; }
        public decimal AnulacionPrimaNeta { get; set; }
        public decimal AnulacionPrimaAdicional { get; set; }
        public decimal AnulacionComisionBroker { get; set; }
        
        public string NombreReasegurador { get; set; }
        public decimal PrimaCedida { get; set; }
        public decimal ComisionReaseguro { get; set; }
        public decimal SumaCedida { get; set; }
        public decimal AnulacionPrimaCedida { get; set; }
        public decimal AnulacionComisionReaseguro { get; set; }
        public decimal AnulacionSumaCedida { get; set; }

        public decimal ConstitucionRRC { get; set; }
        public decimal LiberacionRRC { get; set; }
        public decimal PasivoRRC { get; set; }
        public List<ocp_configuracion_producto> ListaConfiguracionProducto { get; set; }

        public decimal DiferidoPrimaNeta { get; set; }
        public decimal DiferidoPrimaAdicional { get; set; }
    }
    public class ocp_configuracion_producto
    {
        public string IdProducto { get; set; }
        public string Tipo { get; set; }
        public decimal Porcentaje { get; set; }
        public string Formula { get; set; }
    }
}