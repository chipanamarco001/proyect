﻿namespace Presentacion.entities
{
    public class ocp_contabilidad_validacion
    {
        public string Glosa { get; set; }
        public string Descripcion { get; set; }
        public string IdProducto { get; set; }
        public string Moneda { get; set; }
        public decimal ImporteProduccion { get; set; }
        public decimal ImporteAsientos { get; set; }
        public decimal Diferencia { get; set; }
    }
    public class ocp_parametro_proceso_contable
    {
        public string ID_PRODUCTO { get; set; }
    }
}