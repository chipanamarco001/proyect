﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.entities
{
	public class ocp_carta_nemesis
	{
	}
	public class persona_carta_nemesis 
	{
        public string ID_PERSONA { get; set; }

        public string NOMBRE_PERSONA { get; set; }

        public string PATERNO { get; set; }

        public string MATERNO { get; set; }

        public string NOMBRE { get; set; }

        public string NUMERO_DOCUMENTO { get; set; }

        public string EXTENSION { get; set; }

        public string COMPLEMENTO { get; set; }

        public string DOCUMENTO { get; set; }

        public List<afiliaciones_carta_nemesis> LST_AFILIACIONES { get; set; }
    }

	public class afiliaciones_carta_nemesis
	{
        //public string ID_PERSONA { get; set; }
        public string TIPO_PRODUCTO { get; set; }

        public long NUMERO_AFILIACION { get; set; }

        public DateTime FECHA_INICIO { get; set; }

        public DateTime? FECHA_FIN { get; set; }

        public string PERIODO_ALCANCE { get; set; }
    }
}