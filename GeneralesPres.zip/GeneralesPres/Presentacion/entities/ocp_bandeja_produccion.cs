﻿using System.Collections.Generic;

namespace Presentacion.entities
{
    public class ocp_bandeja_produccion
    {
        public string ModalidadRamo { get; set; }
        public string NombreProducto { get; set; }
        public string IdProducto { get; set; }
        public string Moneda { get; set; }
        public decimal PrimaComercial { get; set; }
        public decimal ComisionCobranza { get; set; }
        public int CantidadRegistros { get; set; }
        public bool FlagCarga { get; set; }
        public string TipoCarga { get; set; }
        public bool FlagProduccion { get; set; }
        public string Procedimiento { get; set; }
        public string ImagenEstado { get; set; }
        public List<ocp_bandeja_produccion__documento> ListaDocumentos { get; set; }
    }
    public class ocp_bandeja_produccion__documento
    {
        public string IdDocumento { get; set; }
        public string Nombre { get; set; }
        public string Formato { get; set; }
    }
}