﻿namespace Presentacion.entities
{
    public class ocp_reportes_tecnica
    {
        public string Descripcion { get; set; }
        public string Tipo { get; set; }
        public string IdDocumento { get; set; }
    }
}