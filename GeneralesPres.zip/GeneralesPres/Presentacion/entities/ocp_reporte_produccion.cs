﻿using Agente.ServicioGenerales;
using System.Collections.Generic;
using System.Linq;

namespace Presentacion.entities
{
    public class ocp_reporte_produccion
    {
        public string Mes { get; set; }
        public decimal Anterior { get; set; }
        public decimal Actual { get; set; }
    }
    public class ocp_base_reporte_produccion
    {
        public List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> ListaProduccionAnterior { get; set; }
        public List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> ListaProduccionActual { get; set; }
        public List<ocp_reporte_produccion> ListaReporteTotales { get; set; }
        public void GeneraBaseReporteProduccion()
        {
            this.ListaReporteTotales = DatosTotalesReporte(this.ListaProduccionAnterior, this.ListaProduccionActual);
        }
        protected List<ocp_reporte_produccion> DatosTotalesReporte(List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> listaAnterior, List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> listaActual)
        {
            try
            {
                var listaReporte = new List<ocp_reporte_produccion>
                {
                    new ocp_reporte_produccion() { Mes = "Enero", Anterior = listaAnterior.Sum(s => s.ENERO) ?? 0, Actual = listaActual.Sum(s => s.ENERO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Febrero", Anterior = listaAnterior.Sum(s => s.FEBRERO) ?? 0, Actual = listaActual.Sum(s => s.FEBRERO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Marzo", Anterior = listaAnterior.Sum(s => s.MARZO) ?? 0, Actual = listaActual.Sum(s => s.MARZO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Abril", Anterior = listaAnterior.Sum(s => s.ABRIL) ?? 0, Actual = listaActual.Sum(s => s.ABRIL) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Mayo", Anterior = listaAnterior.Sum(s => s.MAYO) ?? 0, Actual = listaActual.Sum(s => s.MAYO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Junio", Anterior = listaAnterior.Sum(s => s.JUNIO) ?? 0, Actual = listaActual.Sum(s => s.JUNIO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Julio", Anterior = listaAnterior.Sum(s => s.JULIO) ?? 0, Actual = listaActual.Sum(s => s.JULIO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Agosto", Anterior = listaAnterior.Sum(s => s.AGOSTO) ?? 0, Actual = listaActual.Sum(s => s.AGOSTO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Septiembre", Anterior = listaAnterior.Sum(s => s.SEPTIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.SEPTIEMBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Octubre", Anterior = listaAnterior.Sum(s => s.OCTUBRE) ?? 0, Actual = listaActual.Sum(s => s.OCTUBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Noviembre", Anterior = listaAnterior.Sum(s => s.NOVIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.NOVIEMBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Diciembre", Anterior = listaAnterior.Sum(s => s.DICIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.DICIEMBRE) ?? 0 }
                };
                return listaReporte;
            }
            catch
            {
                throw;
            }
        }
        public List<ocp_reporte_produccion> DatosProductoReporte(string strIdProducto)
        {
            try
            {
                List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> listaAnterior = this.ListaProduccionAnterior.Where(w => w.ID_PRODUCTO == strIdProducto).ToList();
                List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> listaActual = this.ListaProduccionActual.Where(w => w.ID_PRODUCTO == strIdProducto).ToList();
                var listaReporte = new List<ocp_reporte_produccion>
                {
                    new ocp_reporte_produccion() { Mes = "Enero", Anterior = listaAnterior.Sum(s => s.ENERO) ?? 0, Actual = listaActual.Sum(s => s.ENERO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Febrero", Anterior = listaAnterior.Sum(s => s.FEBRERO) ?? 0, Actual = listaActual.Sum(s => s.FEBRERO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Marzo", Anterior = listaAnterior.Sum(s => s.MARZO) ?? 0, Actual = listaActual.Sum(s => s.MARZO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Abril", Anterior = listaAnterior.Sum(s => s.ABRIL) ?? 0, Actual = listaActual.Sum(s => s.ABRIL) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Mayo", Anterior = listaAnterior.Sum(s => s.MAYO) ?? 0, Actual = listaActual.Sum(s => s.MAYO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Junio", Anterior = listaAnterior.Sum(s => s.JUNIO) ?? 0, Actual = listaActual.Sum(s => s.JUNIO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Julio", Anterior = listaAnterior.Sum(s => s.JULIO) ?? 0, Actual = listaActual.Sum(s => s.JULIO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Agosto", Anterior = listaAnterior.Sum(s => s.AGOSTO) ?? 0, Actual = listaActual.Sum(s => s.AGOSTO) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Septiembre", Anterior = listaAnterior.Sum(s => s.SEPTIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.SEPTIEMBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Octubre", Anterior = listaAnterior.Sum(s => s.OCTUBRE) ?? 0, Actual = listaActual.Sum(s => s.OCTUBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Noviembre", Anterior = listaAnterior.Sum(s => s.NOVIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.NOVIEMBRE) ?? 0 },
                    new ocp_reporte_produccion() { Mes = "Diciembre", Anterior = listaAnterior.Sum(s => s.DICIEMBRE) ?? 0, Actual = listaActual.Sum(s => s.DICIEMBRE) ?? 0 }
                };
                return listaReporte;
            }
            catch
            {
                throw;
            }
        }
    }
}