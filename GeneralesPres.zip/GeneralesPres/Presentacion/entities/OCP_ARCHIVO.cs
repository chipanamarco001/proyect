﻿using System.IO;

namespace Presentacion.entities
{
    public class ocp_archivo
    {
        public string ContentType { get; set; }
        public string Extension { get; set; }
        public string Nombre { get; set; }
        public Stream FileStream { get; set; }
        public byte[] ByteArray { get; set; }
    }
}