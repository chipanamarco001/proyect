﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Web;

namespace Presentacion.libs
{
	public class ExcelQuery
	{
		private string _fileRoot = String.Empty;
		private string _fileName = String.Empty;
		private string _query = String.Empty;

		private List<string> _queryMasivo = new List<string>();

		public ExcelQuery(string fileRoot, string fileName)
		{
			this._fileRoot = fileRoot;
			this._fileName = fileName;
		}

		public ExcelQuery(string fileRoot, string fileName, string query)
		{
			this._fileRoot = fileRoot;
			this._fileName = fileName;
			this._query = query;
		}

		public ExcelQuery(string fileRoot, string fileName, List<string> query)
		{
			this._fileRoot = fileRoot;
			this._fileName = fileName;
			this._queryMasivo = query;
		}

		public DataTable GetDataTable()
		{
			var dtblResult = new DataTable();
			using (var oleConnection = new OleDbConnection(ExcelAceConnectionString(_fileRoot + _fileName)))
			{
				var oleCommand = new OleDbCommand();
				oleCommand.Connection = oleConnection;
				var oleDataAdapter = new OleDbDataAdapter(oleCommand);
				oleCommand.CommandText = _query;
				try
				{
					oleConnection.Open();
					oleDataAdapter.Fill(dtblResult);
				}
				catch
				{
					throw;
				}
			}
			return dtblResult;
		}

		public void UpdateExcelCell()
		{
			try
			{
				using (var oleConnection = new OleDbConnection(ExcelUpdateConnectionString(_fileRoot + _fileName)))
				{
					var oleCommand = new OleDbCommand();
					oleConnection.Open();
					oleCommand.Connection = oleConnection;
					oleCommand.CommandText = _query;
					oleCommand.ExecuteNonQuery();
				}
			}
			catch
			{
				throw;
			}
		}

		public void UpdateExcelPage()
		{
			try
			{
				using (var oleConnection = new OleDbConnection(ExcelUpdateConnectionString(_fileRoot + _fileName)))
				{
					var oleCommand = new OleDbCommand();
					oleConnection.Open();
					oleCommand.Connection = oleConnection;
					for (int index = 0; index < _queryMasivo.Count; index++)
					{
						oleCommand.CommandText = _queryMasivo[index];
						oleCommand.ExecuteNonQuery();
					}
				}
			}
			catch
			{
				throw;
			}
		}

		public DataTable GetSheets()
		{
			using (var oleConnection = new OleDbConnection(ExcelAceConnectionString(_fileRoot + _fileName)))
			{
				try
				{
					oleConnection.Open();
					return oleConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
				}
				catch
				{
					throw;
				}
			}
		}

		/*Lista la hojas de Excel*/
		private List<string> Sheets()
		{
			try
			{
				string result = string.Empty;

				DataTable dtblSheets = GetSheets();
				var listSheets = new List<string>();
				foreach (DataRow drSheet in dtblSheets.Rows)
				{
					if (drSheet["TABLE_NAME"].ToString().EndsWith("$") || drSheet["TABLE_NAME"].ToString().EndsWith("$'"))
					{
						string sheet = (drSheet["TABLE_NAME"].ToString()).Replace("$", string.Empty);
						if (!listSheets.Contains(sheet))
						{
							listSheets.Add(sheet);
						}
					}
				}
				/*****/
				dtblSheets.Clear();
				dtblSheets.Dispose();
				/*****/
				return listSheets;
			}
			catch
			{
				throw;
			}
		}


		public string ListSheet(ref int intNroSheet)
		{
			var lstSheets = Sheets();
			intNroSheet = lstSheets.Count();
			string html = string.Empty;
			for (var index = 0; index < intNroSheet; index++)
				html += "<tr><td><input type='hidden'  id='HidNombrePestana" + index + "' name='HidNombrePestana" + index + "' runat='server'  value=" + lstSheets[index] + " /> <div class='checkbox'><label><input class='chkDefault' type='checkbox' id='ChkPestana" + index + "' name='ChkPestana'  onclick='CambiarSeleccion(this.id);'>  &nbsp;&nbsp;&nbsp;" + lstSheets[index] + " </label></div></td></tr>";
			return html;
		}

		public List<string> ListHojas()
		{
			return Sheets();

		}


		public static string ExcelAceConnectionString(string fileName)
		{
			var conn = new OleDbConnectionStringBuilder(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + "; Persist Security Info=False;Extended Properties='Excel 12.0;HDR=YES'");
			return conn.ConnectionString;
		}

		public static string ExcelUpdateConnectionString(string fileName)
		{
			var conn = new OleDbConnectionStringBuilder(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties=\"Excel 12.0 Xml;HDR=YES\"");
			return conn.ConnectionString;
		}
	}
}