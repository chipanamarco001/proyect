﻿using Agente.ServicioGenerales;
using System.Linq;

namespace Presentacion.libs
{
    public class SesionUsuario : System.Web.UI.Page
    {
        protected occ_usuario _objUsuario;
        public bool ValidaUsuarioYAcceso(string strPagina)
        {
            try
            {
                bool boolEsValido = false;
                if (Session["SessionUsuario"] == null)
                {
                    Session.Clear();
                    CierraSesion();
                }
                else
                {
                    var objUsuario = (occ_usuario)Session["SessionUsuario"];
                    var listaPagina = objUsuario.Menu.Where(w => w.Tipo == "PAGINA");
                    foreach (var objMenu in listaPagina)
                    {
                        string check = ResolveUrl(objMenu.PaginaUrl);
                        if (ResolveUrl(objMenu.PaginaUrl) == strPagina)
                        {
                            this._objUsuario = (occ_usuario)Session["SessionUsuario"];
                            boolEsValido = true;
                            break;
                        }
                    }
                }
                return boolEsValido;
            }
            catch
            {
                throw;
            }
        }
        public bool ValidaUsuarioYAcceso()
        {
            try
            {
                if (Session["SessionUsuario"] == null)
                {
                    Session.Clear();
                    CierraSesion();
                }
                return true;
            }
            catch
            {
                throw;
            }
        }
        public void CierraSesion()
        {
            Session.Clear();
            Response.Redirect("~/site/auth/login.aspx");
        }
    }
}