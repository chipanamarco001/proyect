﻿using Agente.SericioAfiliacionBroker;
using Presentacion.controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.libs
{
    public class Productos
    {
        public static bool CompletarDatos(string IdquienVende, string IdAquienVende,ref PERSONA_NATURAL_PB persona,ref AFILIACION afiliacion, ref AFILIACION_DATOS datos)
        {
            //datos fijos
            afiliacion.AFPBI_ID_QR = 9999999;
            afiliacion.PRPVC_ID_PRODUCTO = "CHKMED";
            afiliacion.NIPVC_ID_NIVEL = "CKDEME_N1";
            afiliacion.LXPVC_MONEDA = "BOB";
            afiliacion.AFPBT_ESTADO_AFILIACION = true;
            afiliacion.AFPVC_ESTADO_AFILIACION = "AFILIADO";
            afiliacion.LXPVC_ENTIDAD = "PERSONALES";
            afiliacion.AFPVC_ID_POLIZA = "CRS-CKDEME";
            afiliacion.AFPVC_CUENTA_PAGO = "";
            afiliacion.AFPVC_SUCURSAL = "";
            afiliacion.AFPVC_CANAL = "PLATAFORMA_BROKER";
            afiliacion.AFPVC_ID_BROKER = IdquienVende;
            afiliacion.AFPVC_ID_TOMADOR = IdAquienVende;
            persona.LXPVC_ENTIDAD = "GENERALES";
            persona.PEPVC_PARENTESCO = "";
            //datos.AFPVC_DATO1_DESCRIPCION = "DEPORTE";
            //datos.AFPVC_DATO2_DESCRIPCION = "COBERTURA_DIAS";
            //datos.AFPVC_DATO3_DESCRIPCION = "GASTOS_ACCIDENTE";
            //datos.AFPVC_DATO4_DESCRIPCION = "MONTO_INDEMNIZAR";



            //calculamos fecha fin de vigencia
            switch (afiliacion.LXPVC_TIPO_AFILIACION)
            {
                case "PLAN BASICO":
                    afiliacion.AFPDT_FECHA_FIN_VIGENCIA = afiliacion.AFPDT_FECHA_INICIO_VIGENCIA.AddYears(1);
                    afiliacion.NIPVC_ID_NIVEL = "CKDEME_N1";
                    afiliacion.AFPDC_PRIMA_COMERCIAL = 500;

                    break;
                case "PLAN INTERMEDIO":
                    afiliacion.AFPDT_FECHA_FIN_VIGENCIA = afiliacion.AFPDT_FECHA_INICIO_VIGENCIA.AddYears(1);
                    afiliacion.NIPVC_ID_NIVEL = "CKDEME_N1";
                    afiliacion.AFPDC_PRIMA_COMERCIAL = 650;
                    break;
                case "PLAN PREMIUM":
                    afiliacion.AFPDT_FECHA_FIN_VIGENCIA = afiliacion.AFPDT_FECHA_INICIO_VIGENCIA.AddYears(1);
                    afiliacion.NIPVC_ID_NIVEL = "CKDEME_N1";
                    afiliacion.AFPDC_PRIMA_COMERCIAL = 800;
                    break;
                default:

                    break;
            }

            //ESTADO CIVIL    ESTADO CIVIL    ECSO  SOLTERO(A)      SOLTERO(A)
            //ESTADO CIVIL    ESTADO CIVIL    ECCA  CASADO(A)       CASADO(A)
            //ESTADO CIVIL    ESTADO CIVIL    ECDI  DIVORCIADO(A)   DIVORCIADO(A)
            //ESTADO CIVIL    ESTADO CIVIL    ECVI  VIUDO(A)        VIUDO(A)
            switch (persona.LXPVC_ESTADO_CIVIL)
            {
                case "SOLTERO(A)":
                    persona.LXPVC_ESTADO_CIVIL = "ECSO";
                    break;
                case "CASADO(A)":
                    persona.LXPVC_ESTADO_CIVIL = "ECCA";
                    break;
                case "DIVORCIADO(A)":
                    persona.LXPVC_ESTADO_CIVIL = "ECDI";
                    break;
                case "VIUDO(A)":
                    persona.LXPVC_ESTADO_CIVIL = "ECVI";
                    break;
                default:
                    break;
            }

            //CIUDAD DEPARTAMENTO    801 Beni         BENI
            //CIUDAD DEPARTAMENTO    301 Cochabamba   COCHABAMBA
            //CIUDAD DEPARTAMENTO    201 La Paz       LA PAZ
            //CIUDAD DEPARTAMENTO    401 Oruro        ORURO
            //CIUDAD DEPARTAMENTO    901 Pando        PANDO
            //CIUDAD DEPARTAMENTO    501 Potosi       POTOSI
            //CIUDAD DEPARTAMENTO    701 Santa Cruz   SANTA CRUZ
            //CIUDAD DEPARTAMENTO    101 Chuquisaca   CHUQUISACA
            //CIUDAD DEPARTAMENTO    601 Tarija       TARIJA
            if (persona.PEPVC_CIUDAD != null)
            {
                switch (persona.PEPVC_CIUDAD.ToUpper())
                {
                    case "BENI":
                        persona.PEPVC_CIUDAD = "801";
                        afiliacion.AFPVC_DEPARTAMENTO = "801";
                        break;
                    case "COCHABAMBA":
                        persona.PEPVC_CIUDAD = "301";
                        afiliacion.AFPVC_DEPARTAMENTO = "301";
                        break;
                    case "LA PAZ":
                        persona.PEPVC_CIUDAD = "201";
                        afiliacion.AFPVC_DEPARTAMENTO = "201";
                        break;
                    case "ORURO":
                        persona.PEPVC_CIUDAD = "401";
                        afiliacion.AFPVC_DEPARTAMENTO = "401";
                        break;
                    case "PANDO":
                        persona.PEPVC_CIUDAD = "901";
                        afiliacion.AFPVC_DEPARTAMENTO = "901";
                        break;
                    case "POTOSI":
                        persona.PEPVC_CIUDAD = "501";
                        afiliacion.AFPVC_DEPARTAMENTO = "501";
                        break;
                    case "SANTA CRUZ":
                        persona.PEPVC_CIUDAD = "701";
                        afiliacion.AFPVC_DEPARTAMENTO = "701";
                        break;
                    case "CHUQUISACA":
                        persona.PEPVC_CIUDAD = "101";
                        afiliacion.AFPVC_DEPARTAMENTO = "101";
                        break;
                    case "TARIJA":
                        persona.PEPVC_CIUDAD = "601";
                        afiliacion.AFPVC_DEPARTAMENTO = "601";
                        break;
                    case "EXTRANJERO":
                        persona.PEPVC_CIUDAD = "EXTRANJERO";
                        afiliacion.AFPVC_DEPARTAMENTO = "EXTRANJERO";
                        break;
                    default:
                        break;
                }
            }
            return true;
        }
        public static RespuestaCore EjecutarAfiliacion(ServicioAfiliacionBrokerClient conexionCore, ref PERSONA_NATURAL_PB persona, ref AFILIACION afiliacion, ref AFILIACION_DATOS datos, ref List<BENEFICIARIO> beneficiarios, CREDENCIALES credenciales, out long idAfiliacion, out string idPersona)
        {
            RespuestaCore respuestaCampos = new RespuestaCore();
            respuestaCampos.ExisteError = false;
            respuestaCampos.MensajeError = string.Empty;
            persona.PEPVC_TIPO_DOCUMENTO = EsBoliviano(persona.PESVC_LUGAR_NACIMIENTO) ? "CIN" : "CIE";

            persona.PEPVC_PATERNO = persona.PEPVC_PATERNO.Trim();
            persona.PEPVC_MATERNO = persona.PEPVC_MATERNO.Trim();

            VALIDACION_LISTAS_RESTRICTIVAS validationResponse = conexionCore.ValidarPersonaListas(persona, null, afiliacion, credenciales);

            if (validationResponse == null || validationResponse.VAPBI_ID_VALIDACION == null || validationResponse.VAPBI_ID_VALIDACION <= 0)
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = "(Hubo un problema al momento de la validación)";
                idAfiliacion = -1;
                idPersona = null;
                return respuestaCampos;
            }

            if (validationResponse.VAPBT_PROVEEDOR1_RESPUESTA_ESTADO == false)
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = "(Esta en Listas Internacionales)";
                idAfiliacion = -1;
                idPersona = null;
                return respuestaCampos;
            }

            if (validationResponse.VAPBT_PROVEEDOR2_RESPUESTA_ESTADO == false)
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = "(Validación Segip con discrepancias)";
                idAfiliacion = -1;
                idPersona = null;
                return respuestaCampos;
            }

            if (validationResponse.VAPBT_PROVEEDOR3_RESPUESTA_ESTADO == false && persona.PEPVC_CI != "9863167")
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = "(Está en Archivo Negativo)";
                idAfiliacion = -1;
                idPersona = null;
                return respuestaCampos;
            }
            datos.AFPVC_DATO21 = validationResponse.VAPBI_ID_VALIDACION.ToString();
            datos.AFPVC_DATO21_DESCRIPCION = "ID_VALIDACION_LISTAS";
            afiliacion.AFPBT_ARCHIVOS_LOGS = false;

            var responseAfiliacion = conexionCore.SaveUpdateAfiliacionCheck(persona, afiliacion, datos, beneficiarios, credenciales);

            if (responseAfiliacion == null || responseAfiliacion.ID_AFILIACION == null || responseAfiliacion.ID_AFILIACION <= 0)
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = "(Hubo un problema al momento de la afiliacion)";
                idAfiliacion = -1;
                idPersona = null;
                return respuestaCampos;
            }

            CRSValidationResult validacion = new CRSValidationResult();
            AFILIACION afi = conexionCore.UpdateConfirmAfiliacionCheck((long)responseAfiliacion.ID_AFILIACION, credenciales, ref validacion);

            idAfiliacion = 0;
            idPersona = "";

            return respuestaCampos;
        }
        public static bool EsBoliviano(string lugar)
        {
            string[] ciudadesBolivia = new string[] { "BOLIVIA", "LA PAZ", "COCHABAMBA", "SANTA CRUZ", "ORURO", "POTOSI", "CHUQUISACA", "SUCRE", "TARIJA", "BENI", "PANDO" };
            return ciudadesBolivia.Contains(lugar);
        }

    }
}