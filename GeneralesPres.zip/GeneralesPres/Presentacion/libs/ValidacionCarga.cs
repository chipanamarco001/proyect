﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Presentacion.libs
{
	public class ValidacionCarga
	{
		public List<string> ValidacionByProduct(string strIdProduct, DataTable DtblDatos)
		{
			try
			{
				List<string> listaErrores = new List<string>();
				//string jsonConfigValidation = @"{'product':'test','config': [{ 'column':'','type':'char' }  ]}";
				string jsonConfigValidation = @"{'product':'test','config': [{ 'column':'','type':'char','validation': [{  'type':'','format':'','min_value':'','max_value':'','flag_empty':'' }    ] }  ]}";

				var configValidation = JsonConvert.DeserializeObject<json_validation>(jsonConfigValidation);

				foreach (var itemConfig in configValidation.config)
				{					
					switch (itemConfig.type_column)
					{
						//case 6:
						//	Console.WriteLine("Today is Saturday.");
						//	break;
						//case 7:
						//	Console.WriteLine("Today is Sunday.");
						//	break;
						default:
							Console.WriteLine("Looking forward to the Weekend.");
							break;
					}
					// Outputs "Looking forward to the Weekend."

				}

				return listaErrores;
			}
			catch(Exception ex)
			{
				throw;
			}
		}

		public bool validaPrueba()
		{
			return true;
		}
	}

	public class json_validation 
	{
        public string product { get; set; }

        public List<cconfig> config { get; set; }
    }

	public class cconfig 
	{
        public string column { get; set; }

        public string type_column { get; set; }

        public List<cvalidation> validation { get; set; }
    }

	public class cvalidation 
	{
        public string type { get; set; }

        public string format { get; set; }
    }


	
}