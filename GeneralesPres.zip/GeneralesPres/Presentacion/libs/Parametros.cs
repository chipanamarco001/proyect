﻿using System;
using System.Configuration;
using System.Web;

namespace Presentacion.libs
{
	public class Parametros
    {
        private const string strNombreEmpresa = "Crediseguro S.A.";
        private const string strNombreSistema = "Sistema Core de Generales";
        private const string strNombreCortoSistema = "Generales";
		public static string AplicativoSiniestro = "SINIESTROS";
		public static string AplicativoReceptor = "RECEPTOR_ARCHIVOS";
		public static string AplicativoCore = "CRS_CORE";
		public static string AplicativoComun = "COMMON";
		public static string EntornoSiniestros = "SINIESTRO";
		public static string EntornoProduccion = "PRODUCCION";
		public string ObtenerIdUsuario()
        {
            try
            {
                string strIdUsuario = string.Empty;
                var windowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent();
                if (windowsIdentity != null)
                    strIdUsuario = (HttpContext.Current.User.Identity.Name != string.Empty) ? HttpContext.Current.User.Identity.Name : windowsIdentity.Name;
                strIdUsuario = strIdUsuario.Split(new[] { "\\" }, StringSplitOptions.None)[1];
                strIdUsuario = strIdUsuario.ToUpper();
                return strIdUsuario;
            }
            catch
            {
                throw;
            }
        }
        public string ObtenerIPv4()
        {
            try
            {
                string strIPv4 = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (string.IsNullOrEmpty(strIPv4))
                    strIPv4 = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                return strIPv4;
            }
            catch
            {
                throw;
            }
        }
        public string ObtenerDispositivo()
        {
            try
            {
                string strDispositivo = HttpContext.Current.Request.UserAgent.ToString().ToLower();
                if (string.IsNullOrEmpty(strDispositivo))
                    strDispositivo = HttpContext.Current.Request.Headers["User-Agent"];
                return strDispositivo;
            }
            catch
            {
                throw;
            }
        }
        public static string ObtenerNombreEmpresa()
        {
            return strNombreEmpresa;
        }
        public static string ObtenerNombreSistema()
        {
            return strNombreSistema;
        }
        public static string ObtenerNombreCortoSistema()
        {
            return strNombreCortoSistema;
        }
        public static string ObtenerNitTomdor()
        {
            return ConfigurationManager.AppSettings["NitTomador"];
        }

		public void ValidationResult(dynamic objectResponse)
		{
			if (objectResponse.ValidationResult.Error)
			{
				System.Web.HttpContext.Current.Session["ERROR_LIST"] = objectResponse.ValidationResult.ValidationErrors;
				throw new Exception("Se ha presentado un error inesperado.");
			}
		}
	}
}