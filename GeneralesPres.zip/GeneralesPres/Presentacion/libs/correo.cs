﻿using DevExpress.Spreadsheet.Charts;
using Presentacion.controllers;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Reflection;
using System.Text;

namespace Presentacion.libs
{
    public class correo
    {
        public static bool Enviar(ocp_correo objCorreo)
        {
            try
            {
                var objMailMessage = new MailMessage();
                objMailMessage.From = new MailAddress("bolcrsprod@crediseguro.com.bo", "Bolivia - Crediseguro Producción");
                ///Envio Correo Destinatarios  
                foreach (string strCorreo in objCorreo.ListaCorreoDestinatario)
                    objMailMessage.To.Add(new MailAddress(strCorreo));
                ///Destinatarios con copia a:
                foreach (string strCorreo in objCorreo.ListaCorreoCopia)
                    objMailMessage.CC.Add(new MailAddress(strCorreo));
                objMailMessage.CC.Add(new MailAddress("bolcrsprod@crediseguro.com.bo"));
                ///Files attachment -  lista de
                foreach (var objArchivoAdjunto in objCorreo.ListaArchivosAdjuntos)
                {
                    if (objArchivoAdjunto.FlagBytes)
                        objMailMessage.Attachments.Add(new Attachment(new MemoryStream(objArchivoAdjunto.Bytes), objArchivoAdjunto.Nombre));
                    else
                        objMailMessage.Attachments.Add(new Attachment(new MemoryStream(File.ReadAllBytes(objArchivoAdjunto.Ruta)), objArchivoAdjunto.Nombre));
                }
                objMailMessage.Subject = objCorreo.Asunto;
                AlternateView objAlternateView = AlternateView.CreateAlternateViewFromString(objCorreo.Contenido, Encoding.UTF8, MediaTypeNames.Text.Html);
                foreach (var objImagen in objCorreo.ListaImagenes)
                {
                    LinkedResource objLinkedResource = new LinkedResource(new MemoryStream(objImagen.Bytes));
                    objLinkedResource.ContentId = objImagen.ContentId;
                    objAlternateView.LinkedResources.Add(objLinkedResource);
                }
                objMailMessage.AlternateViews.Add(objAlternateView);
                objMailMessage.IsBodyHtml = objCorreo.FlagHtml;
                objMailMessage.Body = objCorreo.Contenido;
                objMailMessage.Priority = objCorreo.Prioridad;
                using (var objSmtpClient = new SmtpClient())
                    objSmtpClient.Send(objMailMessage);
                objMailMessage.Dispose();
                return true;
            }
            catch
            {
                throw;
            }
        }        
    }
    public class ocp_correo
    {
        public string Asunto { get; set; }
        public List<string> ListaCorreoDestinatario { get; set; }
        public List<string> ListaCorreoCopia { get; set; }
        public bool FlagHtml { get; set; }
        public string Contenido { get; set; }
        public List<ocp_correo_archivo_adjunto> ListaArchivosAdjuntos { get; set; }
        public List<ocp_correo_imagen> ListaImagenes { get; set; }
        public MailPriority Prioridad { get; set; }
        public ocp_correo()
        {
            this.ListaCorreoDestinatario = new List<string>();
            this.ListaCorreoCopia = new List<string>();
            this.ListaArchivosAdjuntos = new List<ocp_correo_archivo_adjunto>();
            this.ListaImagenes = new List<ocp_correo_imagen>();
        }
    }
    public class ocp_correo_archivo_adjunto
    {
        public bool FlagBytes { get; set; }
        public byte[] Bytes { get; set; }
        public string Ruta { get; set; }
        public string Nombre { get; set; }
    }
    public class ocp_correo_imagen
    {
        public string ContentId { get; set; }
        public byte[] Bytes { get; set; }
    }
}