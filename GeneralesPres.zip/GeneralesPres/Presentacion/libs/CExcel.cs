﻿using DevExpress.Utils.CommonDialogs.Internal;
using DevExpress.Utils.CommonDialogs;
using DevExpress.XtraSpreadsheet;
using DocumentFormat.OpenXml.Packaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DevExpress.Spreadsheet;
using System.Data;
using DevExpress.Spreadsheet.Export;
using Agente.ServicioArchivoProducto;
using DevExpress.XtraSpreadsheet.PrintLayoutEngine;
using System.Text.RegularExpressions;
using System.Text;
using Agente.ServicioGenerales;

namespace Presentacion.libs
{
	public class CExcel
	{
		public static WorksheetPart GetWorksheetPartByName(SpreadsheetDocument document, string sheetName)
		{
			IEnumerable<DocumentFormat.OpenXml.Spreadsheet.Sheet> sheets = document.WorkbookPart.Workbook.GetFirstChild<DocumentFormat.OpenXml.Spreadsheet.Sheets>().Elements<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == sheetName);
			if (sheets.Count() == 0)
			{
				return null;
			}
			string relationshipId = sheets.First().Id.Value;
			WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(relationshipId);
			return worksheetPart;
		}

		//public void test()
		//{
		//	if (openFileDialog1.ShowDialog() == DialogResult.OK)
		//	{
		//		string str1 = openFileDialog1.FileName;

		//		spreadsheetControl1.LoadDocument(str1);

		//		DevExpress.Spreadsheet.IWorkbook workbook = spreadsheetControl1.Document;

		//		foreach (Worksheet sheet in workbook.Worksheets)
		//		{
		//			string fileName = string.Format("{0}.csv", sheet.Name);
		//		}
		//	}
		//}

		public List<string> ListSheets(byte[] ArchivoExcel)
		{
			Workbook DEWorkbook = new Workbook();
			DEWorkbook.LoadDocument(ArchivoExcel, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
			var lstHojas = new List<string>();
			foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
			{
				lstHojas.Add(DEWorksheet.Name);
				//if (DEWorksheet.Name == "MOVIMIENTOS")
				//{ }

			}
			return lstHojas;			
		}

		public DataTableExporter DatosArchivo(byte[] ArchivoExcel, TIPO_PRODUCTO objTipoProducto)
		{
			try
			{
				Workbook workbook = new Workbook();
				workbook.LoadDocument(ArchivoExcel, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
				Worksheet worksheet = workbook.Worksheets[0];

				//CellRange range3 = worksheet.Selection;
				CellRange range = worksheet.GetUsedRange();

				CellRange rangeData = worksheet.GetUsedRange();

				for (int i = 0; i < objTipoProducto.TPIN_NRO_FILA_CABECERA.Value; i++)
				{
					rangeData = rangeData.Exclude(worksheet.Rows[i]);
				}
				
				bool rangeHasHeaders = true;// this.barCheckItemHasHeaders1.Checked;

				//Definimos el datatable
				DataTable dataTable = worksheet.CreateDataTable(rangeData, rangeHasHeaders);
								
				//Creamos las columnas del datatable utilizando la definicion de tipo de producto 
				for (int col = 0; col < range.ColumnCount; col++)
				{
					//CellValueType cellType = range[0, col].Value.Type;
					//var rowCabecera = range[1, col].Value;
					var rowCabecera = range[objTipoProducto.TPIN_NRO_FILA_CABECERA.Value, col].Value;
					CellValueType cellType = range[objTipoProducto.TPIN_NRO_FILA_CONTENIDO.Value, col].Value.Type;
					
					for (int r = 1; r < range.RowCount; r++)
					{
						if (cellType != range[r, col].Value.Type)
						{
							dataTable.Columns[col].ColumnName = Regex.Replace(rowCabecera.TextValue, @"\s+", " ");
							//dataTable.Columns[col].ColumnName = GetClearContent(rowCabecera.TextValue);							
							dataTable.Columns[col].DataType = typeof(string);
							
							break;
						}
					}
				}

				//vaciamos el contenido de la hoja en el datatable definido anteriormente
				range = range.Exclude(worksheet.Rows[0]);
				DataTableExporter exporter = worksheet.CreateDataTableExporter(rangeData, dataTable, rangeHasHeaders);

				// Handle value conversion errors.
				exporter.CellValueConversionError += exporter_CellValueConversionError;

				// Perform the export.
				exporter.Export();

				return exporter;
			}
			catch (Exception ex)
			{
				throw;
			}
		}
		//https://docs.devexpress.com/WindowsForms/16463/controls-and-libraries/spreadsheet/examples/data-import-and-export/how-to-export-a-worksheet-range-to-a-data-table
		//https://supportcenter.devexpress.com/ticket/details/t882745/question-about-behavior-of-worksheet-getusedrange-w-respect-to-null-cells

		private string GetClearContent(string strValue) {

			string simboloshtml = Regex.Replace(strValue, @"\t|\n|\r", "").TrimStart().TrimEnd();

			string espaciosExtra = Regex.Replace(simboloshtml, @"\s+", "_");

			//string palabaConTildes = "áéíóúñ";

			string palabaSinTildes = Regex.Replace(espaciosExtra.Normalize(NormalizationForm.FormD), @"[^a-zA-z0-9 ]+", "");

			return palabaSinTildes.ToUpper();
		}
		

		void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
		{
			//MessageBox.Show("Error in cell " + e.Cell.GetReferenceA1());
			e.DataTableValue = null;
			e.Action = DataTableExporterAction.Continue;
		}
		public DataTable DatosArchivo2(byte[] ArchivoExcel, string strFileName, string strQuery)
		{
			try
			{
				Workbook workbook = new Workbook();
				workbook.LoadDocument(ArchivoExcel, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
				Worksheet worksheet = workbook.Worksheets[0];

				DataTable model = new DataTable("Products");
				model.Columns.Add("Product", typeof(string));
				model.Columns.Add("Price", typeof(float));
				model.Columns.Add("Quantity", typeof(Int32));

				model.Rows.Add("Chocolade", 5, 15);
				model.Rows.Add("Konbu", 9, 55);
				model.Rows.Add("Geitost", 15, 70);

				worksheet.DataBindings.BindToDataSource(model, 0, 2);
				//var function = new ExcelQuery(strFileRoot, strFileName, strQuery);
				//return function.GetDataTable();

				return null;
			}
			catch (Exception ex)
			{
				throw;
			}
		}


		public DataTable DatosArchivo(string strFileRoot, string strFileName, string strQuery)
		{			
			try
			{				
				var function = new ExcelQuery(strFileRoot, strFileName, strQuery);				
				return function.GetDataTable();
			}
			catch (Exception ex)
			{
				throw;
			}
		}

		//private void ListSheets()
		//{
		//	int index = 0;

		//	Excel.Range rng = this.Application.get_Range("A1");

		//	foreach (Excel.Worksheet displayWorksheet in this.Application.Worksheets)
		//	{
		//		rng.get_Offset(index, 0).Value2 = displayWorksheet.Name;
		//		index++;
		//	}
		//}
	}
}