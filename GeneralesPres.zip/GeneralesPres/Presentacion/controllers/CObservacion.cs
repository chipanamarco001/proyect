﻿using Agente.SericioAfiliacionBroker;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Presentacion.controllers
{
    public class CObservacion
    {
        public List<DetalleObservacion> ListaObservaciones { get; set; }
        public string NombreArchivo { get; set; }
        public string RutaArchivo { get; set; }
        public long IDAfiliacionMasiva { get; set; }

        public CObservacion(string nombreArchivo, long idAfiliacionMasiva)
        {
            ListaObservaciones = new List<DetalleObservacion>();
            NombreArchivo = "Response_" + nombreArchivo.Replace(".xlsx", ".txt").Replace(".xls", ".txt");
            RutaArchivo = System.Configuration.ConfigurationManager.AppSettings["RutaRespuesta"];
            IDAfiliacionMasiva = idAfiliacionMasiva;
        }

        public bool TieneObservaciones()
        {
            if (ListaObservaciones.Count > 0)
                return true;
            else
                return false;
        }

        public void RegistrarObservacion(int fila, string deFormato, string deCampos, string deNegocio)
        {
            if (ListaObservaciones == null)
            {
                ListaObservaciones = new List<DetalleObservacion>();
            }

            DetalleObservacion observacion = ListaObservaciones.Where(x => x.fila == fila).FirstOrDefault();
            bool adicionarALaLista = false;
            if (observacion == null)
            {
                observacion = new DetalleObservacion();
                observacion.fila = fila;
                adicionarALaLista = true;
            }

            if (deFormato.Trim() != string.Empty)
                observacion.mensajeValidacionFormato = deFormato;
            if (deCampos.Trim() != string.Empty)
                observacion.mensajeValidacionCampos = deCampos;
            if (deNegocio.Trim() != string.Empty)
                observacion.mensajeValidacionNegocio = deNegocio;

            if (adicionarALaLista)
            {
                ListaObservaciones.Add(observacion);
            }
        }
        public void CrearArchivoDeObservacionesYRegistrarComoObservado(CREDENCIALES credenciales)
        {
            //procesamos la lista de observaciones para que se registre
            List<string> listaTexto = new List<string>();
            foreach (var item in ListaObservaciones)
            {
                listaTexto.Add(item.TextoParaArchivo());
            }

            //consumimos el servicio
            IServicioAfiliacionBroker objServicio = new ServicioAfiliacionBrokerClient("ServicioAfiliacionBrokerHttpEndPoint");
            var objActualizarEstadoAfiliacionMasivaRequest = new ActualizarEstadoAfiliacionMasivaRequest();
            objActualizarEstadoAfiliacionMasivaRequest.intIdAfiliacionMasiva = IDAfiliacionMasiva;
            objActualizarEstadoAfiliacionMasivaRequest.strPathRespuesta = RutaArchivo;
            objActualizarEstadoAfiliacionMasivaRequest.strNombreArchivoRespuesta = NombreArchivo;
            objActualizarEstadoAfiliacionMasivaRequest.objCredenciales = credenciales;
            objActualizarEstadoAfiliacionMasivaRequest.ValidationResult = new CRSValidationResult();
            objActualizarEstadoAfiliacionMasivaRequest.strEstado = "OBSERVADO";
            var registroActualizado = objServicio.ActualizarEstadoAfiliacionMasiva(objActualizarEstadoAfiliacionMasivaRequest);
            if (registroActualizado.ValidationResult.Error == true)
                throw new Exception(ValidationErrorsAString(registroActualizado.ValidationResult.ValidationErrors));

           // File.WriteAllLines(Path.Combine(RutaArchivo, NombreArchivo), listaTexto);
        }
        public string ValidationErrorsAString(List<ListErrors> lista)
        {
            string respuesta = string.Empty;
            foreach (var item in lista)
            {
                respuesta = respuesta + "(" + item.ErrorMessage + ")";
            }
            return respuesta;
        }
    }
    public class DetalleObservacion
    {
        public int fila { get; set; }
        public string mensajeValidacionFormato { get; set; }
        public string mensajeValidacionCampos { get; set; }
        public string mensajeValidacionNegocio { get; set; }

        public string TextoParaArchivo()
        {
            return String.Format("La fila numero {0}. {1}{2}{3} ",
                         fila,
                         mensajeValidacionFormato,
                         mensajeValidacionNegocio,
                         mensajeValidacionCampos);
        }
    }
}