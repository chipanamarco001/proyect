﻿using Agente;
using Agente.SericioAfiliacionBroker;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace Presentacion.controllers
{
    public class CAfiliacionMasiva
    {
        private readonly IServicioAfiliacionBroker _servicioAfiliacionBroker = Proxy.SericioAfiliacionBroker();
        public List<string> Afiliacion(ocp_archivo documento)
        {
            try
            {
                string broker = "PRFN-0625";
                var objCredenciales = new CREDENCIALES
                {
                    ENTIDAD = "PERSONALES",
                    USUARIO = "MASIVOBKER",
                    IP = "172.31.103.106",
                    BROKER = broker,
                    TOMADOR = "Combose"
                };
                CRSValidationResult objValidacionResult = new CRSValidationResult();
                AFILIACIONES_MASIVAS objAfiliacionMasiva = new AFILIACIONES_MASIVAS();
                objAfiliacionMasiva.AFPVC_PATH_CARGA = "";
                objAfiliacionMasiva.AFPVC_PATH_RESPUESTA = "";
                objAfiliacionMasiva.AFPVC_NOMBRE_ARCHIVO_CARGA = "";
                objAfiliacionMasiva.AFPVC_NOMBRE_ARCHIVO = documento.Nombre;
                objAfiliacionMasiva.AFPVC_NOMBRE_ARCHIVO_RESPUESTA = null;
                objAfiliacionMasiva.AFPVC_ESTADO = "PENDIENTE";
                objAfiliacionMasiva.AFPVC_ID_EMPRESA_QUE_VENDE = " ";
                objAfiliacionMasiva.AFPVC_ID_EMPRESA_A_QUIEN_VENDE = null;
                objAfiliacionMasiva.AFPVC_ID_PRODUCTO = "CHKMED";
                AgregarAfiliacionMasivaRequest objAfilicionMasivaRequest = new AgregarAfiliacionMasivaRequest();
                objAfilicionMasivaRequest.objAfiliacionMasiva = objAfiliacionMasiva;
                objAfilicionMasivaRequest.objCredenciales = objCredenciales;
                objAfilicionMasivaRequest.ValidationResult = objValidacionResult;
                AgregarAfiliacionMasivaResponse cargaMasiva = _servicioAfiliacionBroker.AgregarAfiliacionMasiva(objAfilicionMasivaRequest);
                var data = cargaMasiva.AgregarAfiliacionMasivaResult;
                //validaiones del producto

                int fila = 1;
                var objRequestValidacion = new GetListValidacionByBrokerProductoRequest();
                objRequestValidacion.objCredenciales = objCredenciales;
                objRequestValidacion.ValidationResult = new CRSValidationResult();
                objRequestValidacion.strIdProducto = "CHKMED";
                var lstValidaciones = _servicioAfiliacionBroker.GetListValidacionByBrokerProducto(objRequestValidacion).GetListValidacionByBrokerProductoResult;
                CObservacion observacionParaUnArchivo = new CObservacion(data.AFPVC_NOMBRE_ARCHIVO_CARGA, data.AFPBI_ID_AFILIACION_MASIVA);//(data.AFPVC_NOMBRE_ARCHIVO_CARGA, data.AFPBI_ID_AFILIACION_MASIVA)
                Productos productos = new Productos();
                ServicioAfiliacionBrokerClient clienteParaValidacion = new ServicioAfiliacionBrokerClient();
                using (MemoryStream stream = new MemoryStream())
                {
                    stream.Write(documento.ByteArray, 0, (int)documento.ByteArray.Length);
                    using (SpreadsheetDocument spreadSheetDocument = SpreadsheetDocument.Open(stream, false))
                    {
                        WorkbookPart workbookPart = spreadSheetDocument.WorkbookPart;
                        IEnumerable<Sheet> sheets = spreadSheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();


                        string relationshipId = sheets.First().Id.Value;
                        WorksheetPart worksheetPart = (WorksheetPart)spreadSheetDocument.WorkbookPart.GetPartById(relationshipId);
                        Worksheet workSheet = worksheetPart.Worksheet;
                        SheetData sheetData = workSheet.GetFirstChild<SheetData>();
                        IEnumerable<Row> rows = sheetData.Descendants<Row>();
                        string documentId = String.Empty;
                        string tieneInvalidez = String.Empty;
                        bool isCellphoneEnsurance = false;
                        if (objRequestValidacion.strIdProducto == "CHKMED")//data.AFPVC_ID_PRODUCTO
                        {
                            lstValidaciones = lstValidaciones.Where(v => v.VAPIN_ORDEN_COL_ARCH != 23).ToList();
                            foreach (Row row in rows.Skip(1))
                            {
                                fila++;
                                int filaExcel;
                                var valueValidacion = GetCellValue(spreadSheetDocument, row.Descendants<Cell>().ElementAt(0));
                                if (!int.TryParse(valueValidacion, out filaExcel))
                                {
                                    break;
                                }
                                var objPersonaNatural = new PERSONA_NATURAL_PB();
                                var objAfiliacion = new AFILIACION();
                                var objAfiliacionDatos = new AFILIACION_DATOS();
                                var lstBeneficiarios = new List<BENEFICIARIO>();
                                string mensajeErrorValidacionFormato;
                                bool ExisteError = CValidacion.ValidacionFormatoColumnas(spreadSheetDocument, row, lstValidaciones, ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos, ref lstBeneficiarios, out mensajeErrorValidacionFormato);
                                if (ExisteError)
                                {
                                    //return "el siguiente error "+ExisteError+"en la fila"+fila;
                                    observacionParaUnArchivo.RegistrarObservacion(fila, mensajeErrorValidacionFormato, string.Empty, string.Empty);
                                }
                                Productos.CompletarDatos("COBOSER", "COBOSER", ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos);
                                RespuestaCore validaciondeCampos = CValidacion.ValidacionDeCampos(ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos ,ref lstBeneficiarios);
                                RespuestaCore validacionNegocio = CValidacion.ValidacionDeNegocio(ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos, ref lstBeneficiarios);
                                if (validaciondeCampos.ExisteError)
                                {
                                    observacionParaUnArchivo.RegistrarObservacion(fila, string.Empty, validaciondeCampos.MensajeError, string.Empty);
                                }
                                if (validacionNegocio.ExisteError)
                                {
                                    observacionParaUnArchivo.RegistrarObservacion(fila, string.Empty, string.Empty, validacionNegocio.MensajeError);
                                }
                                if (observacionParaUnArchivo.TieneObservaciones())
                                {
                                    observacionParaUnArchivo.CrearArchivoDeObservacionesYRegistrarComoObservado(objCredenciales);
                                }
                                else
                                {
                                    long idAfiliacion;
                                    string idPersona;
                                    RespuestaCore validacionAfiliacion = Productos.EjecutarAfiliacion(clienteParaValidacion, ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos, ref lstBeneficiarios, objCredenciales, out idAfiliacion, out idPersona);//// como hace la afiliacion
                                    if (validacionAfiliacion.ExisteError)
                                    {
                                        observacionParaUnArchivo.RegistrarObservacion(fila, string.Empty, string.Empty, validacionAfiliacion.MensajeError);
                                    }
                                    observacionParaUnArchivo.RegistrarObservacion(fila, string.Empty, string.Empty, "SE AFILIO CORRECTAMENTE");
                                }

                            }


                        }

                    }

                }
                if(observacionParaUnArchivo.ListaObservaciones.Count != 0)
                {
                    List<string> listaTexto = new List<string>();
                    foreach (var item in observacionParaUnArchivo.ListaObservaciones)
                    {
                        listaTexto.Add(item.TextoParaArchivo());
                    }

                    return listaTexto;

                }
                else
                {
                    List<string> listaTexto = new List<string>();
                    listaTexto.Add("no hay ningun dato");
                    return listaTexto;
                }
                
            }
            catch
            {
                throw;
            }

        }
        private string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
                return "";
            string value = cell.CellValue.InnerXml;

            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }
    }
}