﻿using Agente;
using Agente.ServicioLexico;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.controllers
{
	public class CLexico
	{
		#region Configuracion Inicial
		private readonly IServicioLexico _servicioLexico = Proxy.ServicioLexico();
		private readonly CGenerales _cGenerales = new CGenerales();
		public CREDENCIALES CredencialActual()
		{
			try
			{
				var objCredencial = new CREDENCIALES()
				{
					USUARIO = new Parametros().ObtenerIdUsuario(),
					IP = new Parametros().ObtenerIPv4()
				};
				return objCredencial;
			}
			catch
			{
				throw;
			}
		}
		#endregion
		
		#region Lexico
		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result> GetListLexicoByAppNameTablaTema(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla y tema; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTablaTema(Parametros.AplicativoReceptor, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result> GetListLexicoByAppNameTablaTema(string strApp, string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla y tema; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTablaTema(strApp, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		public SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result GetObjLexicoByAppNameTablaTema(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla y tema; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetObjLexicoByAppNameTablaTema(Parametros.AplicativoReceptor, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_Result> GetListLexicoByAppNameTabla(string strTabla)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTabla(Parametros.AplicativoReceptor, strTabla, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_Result> GetListLexicoByAppNameTabla(string strAppName, string strTabla)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTabla(strAppName, strTabla, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		#endregion


		#region uif pc004

		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result> GetListLexicoSiniestroByAppNameTablaTema(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla y tema; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTablaTema(Parametros.AplicativoSiniestro, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_Result> GetListLexicoSiniestroByAppNameTabla(string strTabla)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: Obtener Lista de lexico segun tabla; Recurso: Servicio captado en Presentacion ");
				var response = _servicioLexico.GetListLexicoByAppNameTabla(Parametros.AplicativoSiniestro, strTabla, CredencialActual());
				//Log.Fin();
				return response;

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		#endregion


		//receptor de archivos

		public SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result GetObjLexicoByAppNameTablaTemaUrl(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de objeto complejo  de relacion producto tabla; Recurso: servicio captado en Presentacion");

				var response = _servicioLexico.GetObjLexicoByAppNameTablaTema(Parametros.AplicativoComun, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result> GetObjLexicoByAppNameTablaTema(string strTabla, string strTema, bool core)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de objeto complejo  de relacion producto tabla; Recurso: servicio captado en Presentacion");

				var response = _servicioLexico.GetListLexicoByAppNameTablaTema(core ? Parametros.AplicativoCore : Parametros.AplicativoSiniestro, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		//Obtener lista de Extensiones Carnet
		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_Result> GetListLexicoByAppNameTabla(string strTabla, bool core)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de objeto complejo  de relacion producto tabla; Recurso: servicio captado en Presentacion");
				List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_Result> response = null;
				response = _servicioLexico.GetListLexicoByAppNameTabla(core ? Parametros.AplicativoCore : Parametros.AplicativoSiniestro, strTabla, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result> GetObjLexicoByAppNameTablaTemaGenerico(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de objeto complejo  de relacion producto tabla; Recurso: servicio captado en Presentacion");

				var response = _servicioLexico.GetListLexicoByAppNameTablaTema(Parametros.AplicativoSiniestro, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_Result GetObjLexByAppNameTablaTemaGenerico(string strTabla, string strTema)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de objeto complejo  de relacion producto tabla; Recurso: servicio captado en Presentacion");

				var response = _servicioLexico.GetObjLexicoByAppNameTablaTema(Parametros.AplicativoSiniestro, strTabla, strTema, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}


		public SPWB_GETLIST_LEX_APPNAME_BY_TABLA_TEMA_VALOR_Result GetObjLexicoByAppNameTablaTemaValorGenerico(string strTabla, string strTema, string strValor)
		{
			//Log.Inicio();
			try
			{
				var response = _servicioLexico.GetObjLexicoByAppNameTablaTemaValor(Parametros.AplicativoSiniestro, strTabla, strTema, strValor, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

	}
}