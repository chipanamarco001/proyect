﻿using Agente.SericioAfiliacionBroker;
using DevExpress.Spreadsheet;
using DevExpress.XtraRichEdit.Commands.Internal;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Globalization;
using System.Linq;
using System.Web;
using Cell = DocumentFormat.OpenXml.Spreadsheet.Cell;
using Row = DocumentFormat.OpenXml.Spreadsheet.Row;


namespace Presentacion.controllers
{
    public class CValidacion
    {
        public static bool Ejecutar(string schemaAUsar, string datoAValidar)
        {
            JSchema schemaDeValidacion = JSchema.Parse(schemaAUsar);
            string textoAValidar = JsonConvert.SerializeObject((new AValidar(datoAValidar)));
            JObject objAValidar = JObject.Parse(textoAValidar);
            bool respuesta = objAValidar.IsValid(schemaDeValidacion);
            return respuesta;
        }
        public static bool ValidacionFormatoColumnas(SpreadsheetDocument spreadSheetDocument, Row row, List<VALIDACION> lstValidaciones, ref PERSONA_NATURAL_PB objPersonaNatural, ref AFILIACION objAfiliacion, ref AFILIACION_DATOS objAfiliacionDatos, ref List<BENEFICIARIO> lstBeneficiarios, out string respuestaTexto)
        {
            respuestaTexto = string.Empty;
            bool ExisteError = false;
            foreach (var itemValidacion in lstValidaciones)
            {
                var valueValidacion = GetCellValue(spreadSheetDocument, row.Descendants<Cell>().ElementAt(itemValidacion.VAPIN_ORDEN_COL_ARCH));
                int paraConvertircampoTipoFecha;
                double parahora;
                if (itemValidacion.VAPVC_JSON.Contains("date") && int.TryParse(valueValidacion, out paraConvertircampoTipoFecha))
                {
                    DateTime dt = DateTime.FromOADate(paraConvertircampoTipoFecha);
                    valueValidacion = dt.ToString("yyyy-MM-dd");
                }
                if (itemValidacion.VAPVC_JSON.Contains("time") && double.TryParse(valueValidacion, out parahora))
                {
                    DateTime dt = DateTime.FromOADate(parahora);
                    valueValidacion = dt.ToString("HH:mm:ss");
                }

                if (!Ejecutar(itemValidacion.VAPVC_JSON, valueValidacion))
                {
                    var dato = valueValidacion.ToString();
                    respuestaTexto = respuestaTexto + "(" + itemValidacion.VAPVC_MENSAJE + ")"; //"(Columna "+itemValidacion.VAPIN_ORDEN_COL_ARCH+" "+ itemValidacion.LXPVC_CAMPO + " | " + itemValidacion.VAPVC_MENSAJE+")";
                    ExisteError = true;
                    continue;
                }
                GetObjMetodoAfiliacion(itemValidacion.LXPVC_CAMPO, valueValidacion, ref objPersonaNatural, ref objAfiliacion, ref objAfiliacionDatos, ref lstBeneficiarios);
            }

            return ExisteError;
        }

        private static string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
                return "";
            string value = cell.CellValue.InnerXml;

            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }
        public static bool GetObjMetodoAfiliacion(string strColumnName, string valueCampo, ref PERSONA_NATURAL_PB objPersonaNatural, ref AFILIACION objAfiliacion, ref AFILIACION_DATOS objAfiliacionDatos, ref List<BENEFICIARIO> lstBeneficiarios)
        {
            var objBeneficiario1 = new BENEFICIARIO();
            var objBeneficiario2 = new BENEFICIARIO();
            var objBeneficiario3 = new BENEFICIARIO();
            var objBeneficiario4 = new BENEFICIARIO();
            var objBeneficiario5 = new BENEFICIARIO();
            //var columnName = itemValidacion.LXPVC_CAMPO;
            switch (strColumnName)
            {
                #region Persona Natural

                case "APELLIDO_PATERNO":
                    objPersonaNatural.PEPVC_PATERNO = valueCampo;
                    break;
                case "APELLIDO_MATERNO":
                    objPersonaNatural.PEPVC_MATERNO = valueCampo;
                    break;
                case "NOMBRE":
                    objPersonaNatural.PEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "CI":
                    objPersonaNatural.PEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "EXTENSION":
                    objPersonaNatural.LXPVC_EXTENSION = valueCampo;
                    break;

                case "FECHA_DE_NACIMIENTO":
                    //DateTime fechaSalida = DateTime.ParseExact(objAfiliacionDatos.AFPVC_DATO3.ToString(), "dd/MM/yyyy hh:mm:ss", CultureInfo.InvariantCulture);

                    DateTime fechaNacimiento = (DateTime)SqlDateTime.MinValue;

                    try
                    {
                        fechaNacimiento = DateTime.ParseExact(valueCampo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    { }

                    objPersonaNatural.PEPDT_FECHA_NACIMIENTO = fechaNacimiento;
                    break;
                case "COMPLEMENTO":
                    objPersonaNatural.PEPVC_COMPLEMENTO_IDC = valueCampo;
                    break;
                case "ESTADO_CIVIL":
                    objPersonaNatural.LXPVC_ESTADO_CIVIL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "CORREO_ELECTRONICO":
                    objPersonaNatural.PEPVC_CORREO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    objAfiliacion.PEPVC_CORREO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DIRECCION":
                    objPersonaNatural.PEPVC_DIRECCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                case "ZONA":
                    objPersonaNatural.PEPVC_ZONA = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NUMERO":
                    objPersonaNatural.PEPVC_NUMERO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "CALLE":
                    objPersonaNatural.PEPVC_CALLE = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "LUGAR_DE_RESIDENCIA":
                    objPersonaNatural.PEPVC_CIUDAD = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PROFECION_U_OCUPACION":
                    objPersonaNatural.PEPVC_OCUPACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                case "NACIONALIDAD":
                    objPersonaNatural.PEPVC_NACIONALIDAD = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO":
                    objPersonaNatural.PEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "TELEFONO":
                    objPersonaNatural.PEPVC_TELEFONO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "GENERO":
                    objPersonaNatural.LXPVC_GENERO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "FIRMA":
                    byte[] firma = null;
                    try
                    {
                        firma = Convert.FromBase64String(valueCampo);
                    }
                    catch (Exception)
                    { }

                    objPersonaNatural.PEPVC_FIRMA = firma;
                    break;

                case "ENTIDAD":
                    objPersonaNatural.LXPVC_ENTIDAD = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    objAfiliacion.LXPVC_ENTIDAD = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "TIPO_DOCUMENTO":
                    objPersonaNatural.PEPVC_TIPO_DOCUMENTO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "LUGAR_DE_NACIMIENTO":
                    objPersonaNatural.PESVC_LUGAR_NACIMIENTO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                #endregion

                #region AFiliacion

                /*case "CORREO":
                    objAfiliacion.PEPVC_CORREO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;*/
                /*case "ID_PERSONA_NATURAL":
                    objAfiliacion.PEPVC_ID_PERSONA_NATURAL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;*/
                case "ID_QR":
                    objAfiliacion.AFPBI_ID_QR = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToInt64(valueCampo);
                    break;
                case "PLAN_DE_ASISTENCIA":
                    objAfiliacion.LXPVC_TIPO_AFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "ID_PRODUCTO":
                    objAfiliacion.PRPVC_ID_PRODUCTO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "ID_NIVEL":
                    objAfiliacion.NIPVC_ID_NIVEL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "ID_POLIZA":
                    objAfiliacion.AFPVC_ID_POLIZA = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PRIMA_COMERCIAL":
                    objAfiliacion.AFPDC_PRIMA_COMERCIAL = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "MONEDA":
                    objAfiliacion.LXPVC_MONEDA = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "ID_OBJETO_ASEGURADO":
                    objAfiliacion.OBPBI_ID_OBJETO_ASEGURADO = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToInt64(valueCampo);
                    break;
                case "ID_CERTIFICADO":
                    objAfiliacion.CEPVC_ID_CERTIFICADO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "FLAG_MANCOMUNO":
                    objAfiliacion.AFSBT_FLAG_MANCOMUNO = string.IsNullOrEmpty(valueCampo) ? false : Convert.ToBoolean(valueCampo);
                    break;
                case "CUENTA_PAGO":
                    objAfiliacion.AFPVC_CUENTA_PAGO = valueCampo;
                    break;
                case "DESDE":
                case "FECHA_INICIO_VIGENCIA":
                    DateTime fechaInicioVigencia = (DateTime)SqlDateTime.MinValue;

                    try
                    {
                        fechaInicioVigencia = DateTime.ParseExact(valueCampo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    { }

                    objAfiliacion.AFPDT_FECHA_INICIO_VIGENCIA = fechaInicioVigencia;
                    break;
                case "FECHA_FIN_VIGENCIA":
                    DateTime fechaFinVigencia = (DateTime)SqlDateTime.MinValue;

                    try
                    {
                        fechaFinVigencia = DateTime.ParseExact(valueCampo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    { }

                    objAfiliacion.AFPDT_FECHA_FIN_VIGENCIA = fechaFinVigencia;
                    break;
                case "FECHA_CANCELACION":
                    DateTime fechaCancelacion = (DateTime)SqlDateTime.MinValue;

                    try
                    {
                        fechaCancelacion = DateTime.ParseExact(valueCampo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    { }
                    objAfiliacion.AFPDT_FECHA_CANCELACION = fechaCancelacion;
                    break;


                case "MOTIVO_DESAFILIACION":
                    objAfiliacion.AFPVC_MOTIVO_DESAFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "OBS_DESAFILIACION":
                    objAfiliacion.AFPVC_OBS_DESAFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "BT_ESTADO_AFILIACION":
                    objAfiliacion.AFPBT_ESTADO_AFILIACION = string.IsNullOrEmpty(valueCampo) ? false : Convert.ToBoolean(valueCampo);
                    break;
                case "VC_ESTADO_AFILIACION":
                    objAfiliacion.AFPVC_ESTADO_AFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "TIPO_AFILIACION":
                    objAfiliacion.LXPVC_TIPO_AFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "DEPARTAMENTO":
                    objAfiliacion.AFPVC_DEPARTAMENTO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "SUCURSAL":
                    objAfiliacion.AFPVC_SUCURSAL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "CANAL":
                    objAfiliacion.AFPVC_CANAL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                /*case "ENTIDAD":
                    objAfiliacion.LXPVC_ENTIDAD = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;*/
                case "RAZON_SOCIAL":
                    objAfiliacion.AFPVC_RAZON_SOCIAL = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "NIT":
                    objAfiliacion.AFPVC_NIT = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                #endregion

                #region Datos AFiliacion

                /*case "ID_AFILIACION":
                    objAfiliacion.AFPBI_ID_AFILIACION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;*/
                case "DATO1":
                    objAfiliacionDatos.AFPVC_DATO1 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO1_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO1_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO2":
                    objAfiliacionDatos.AFPVC_DATO2 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO2_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO2_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO3":
                    objAfiliacionDatos.AFPVC_DATO3 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO3_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO3_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO4":
                    objAfiliacionDatos.AFPVC_DATO4 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO4_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO4_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO5":
                    objAfiliacionDatos.AFPVC_DATO5 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO5_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO5_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                case "DATO6":
                    objAfiliacionDatos.AFPVC_DATO6 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO6_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO6_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO7":
                    objAfiliacionDatos.AFPVC_DATO7 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO7_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO7_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO8":
                    objAfiliacionDatos.AFPVC_DATO8 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO8_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO8_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO9":
                    objAfiliacionDatos.AFPVC_DATO9 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO9_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO9_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO10":
                    objAfiliacionDatos.AFPVC_DATO10 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO10_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO10_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                case "DATO11":
                    objAfiliacionDatos.AFPVC_DATO11 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO11_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO11_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO12":
                    objAfiliacionDatos.AFPVC_DATO12 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO12_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO12_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO13":
                    objAfiliacionDatos.AFPVC_DATO13 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO13_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO13_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO14":
                    objAfiliacionDatos.AFPVC_DATO14 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO14_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO14_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO15":
                    objAfiliacionDatos.AFPVC_DATO15 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO15_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO15_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO26":
                    objAfiliacionDatos.AFPVC_DATO26 = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "DATO26_DESCRIPCION":
                    objAfiliacionDatos.AFPVC_DATO26_DESCRIPCION = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                #endregion

                #region Beneficiarios

                case "APELLIDO_PATERNO_B1":
                    objBeneficiario1.BEPVC_APELLIDO_PATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "APELLIDO_MATERNO_B1":
                    objBeneficiario1.BEPVC_APELLIDO_MATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NOMBRES_B1":
                    objBeneficiario1.BEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO_B1":
                    objBeneficiario1.BEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PORCENTAJE_B1":
                    objBeneficiario2.BEPVC_PORCENTAJE = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "CI_B1":
                    objBeneficiario2.BEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "APELLIDO_PATERNO_B2":
                    objBeneficiario2.BEPVC_APELLIDO_PATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "APELLIDO_MATERNO_B2":
                    objBeneficiario2.BEPVC_APELLIDO_MATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NOMBRES_B2":
                    objBeneficiario2.BEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO_B2":
                    objBeneficiario2.BEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PORCENTAJE_B2":
                    objBeneficiario2.BEPVC_PORCENTAJE = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "CI_B2":
                    objBeneficiario2.BEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "APELLIDO_PATERNO_B3":
                    objBeneficiario3.BEPVC_APELLIDO_PATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "APELLIDO_MATERNO_B3":
                    objBeneficiario3.BEPVC_APELLIDO_MATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NOMBRES_B3":
                    objBeneficiario3.BEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO_B3":
                    objBeneficiario3.BEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PORCENTAJE_B3":
                    objBeneficiario3.BEPVC_PORCENTAJE = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "CI_B3":
                    objBeneficiario3.BEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;


                case "APELLIDO_PATERNO_B4":
                    objBeneficiario4.BEPVC_APELLIDO_PATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "APELLIDO_MATERNO_B4":
                    objBeneficiario4.BEPVC_APELLIDO_MATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NOMBRES_B4":
                    objBeneficiario4.BEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO_B4":
                    objBeneficiario4.BEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PORCENTAJE_B4":
                    objBeneficiario4.BEPVC_PORCENTAJE = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "CI_B4":
                    objBeneficiario4.BEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;

                case "APELLIDO_PATERNO_B5":
                    objBeneficiario5.BEPVC_APELLIDO_PATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "APELLIDO_MATERNO_B5":
                    objBeneficiario5.BEPVC_APELLIDO_MATERNO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "NOMBRES_B5":
                    objBeneficiario5.BEPVC_NOMBRES = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PARENTESCO_B5":
                    objBeneficiario5.BEPVC_PARENTESCO = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                case "PORCENTAJE_B5":
                    objBeneficiario5.BEPVC_PORCENTAJE = string.IsNullOrEmpty(valueCampo) ? 0 : Convert.ToDecimal(valueCampo);
                    break;
                case "CI_B5":
                    objBeneficiario5.BEPVC_CI = string.IsNullOrEmpty(valueCampo) ? null : valueCampo;
                    break;
                #endregion

                default:
                    // code block
                    break;
            }

            if (objBeneficiario1.BEPVC_APELLIDO_PATERNO != null || objBeneficiario1.BEPVC_APELLIDO_MATERNO != null || objBeneficiario1.BEPVC_NOMBRES != null || objBeneficiario1.BEPVC_PARENTESCO != null || objBeneficiario1.BEPVC_PORCENTAJE != 0)
            { lstBeneficiarios.Add(objBeneficiario1); }

            if (objBeneficiario2.BEPVC_APELLIDO_PATERNO != null || objBeneficiario2.BEPVC_APELLIDO_MATERNO != null || objBeneficiario2.BEPVC_NOMBRES != null || objBeneficiario2.BEPVC_PARENTESCO != null || objBeneficiario2.BEPVC_PORCENTAJE != 0)
            { lstBeneficiarios.Add(objBeneficiario2); }

            if (objBeneficiario3.BEPVC_APELLIDO_PATERNO != null || objBeneficiario3.BEPVC_APELLIDO_MATERNO != null || objBeneficiario3.BEPVC_NOMBRES != null || objBeneficiario3.BEPVC_PARENTESCO != null || objBeneficiario3.BEPVC_PORCENTAJE != 0)
            { lstBeneficiarios.Add(objBeneficiario3); }

            if (objBeneficiario4.BEPVC_APELLIDO_PATERNO != null || objBeneficiario4.BEPVC_APELLIDO_MATERNO != null || objBeneficiario4.BEPVC_NOMBRES != null || objBeneficiario4.BEPVC_PARENTESCO != null || objBeneficiario4.BEPVC_PORCENTAJE != 0)
            { lstBeneficiarios.Add(objBeneficiario4); }

            if (objBeneficiario5.BEPVC_APELLIDO_PATERNO != null || objBeneficiario5.BEPVC_APELLIDO_MATERNO != null || objBeneficiario5.BEPVC_NOMBRES != null || objBeneficiario5.BEPVC_PARENTESCO != null || objBeneficiario5.BEPVC_PORCENTAJE != 0)
            { lstBeneficiarios.Add(objBeneficiario5); }

            if (lstBeneficiarios.Count == 0)
            {
                lstBeneficiarios.Add(new BENEFICIARIO
                {
                    AFPBI_ID_AFILIACION = objAfiliacion.AFPBI_ID_AFILIACION,
                    BEPVC_APELLIDO_PATERNO = String.Empty,
                    BEPVC_APELLIDO_MATERNO = String.Empty,
                    BEPVC_NOMBRES = "HEREDEROS DE LEY",
                    BEPVC_PORCENTAJE = 100,
                    BEPVC_PARENTESCO = String.Empty
                });
            }

            return true;
        }
        public static RespuestaCore ValidacionDeCampos(ref PERSONA_NATURAL_PB persona, ref AFILIACION afiliacion, ref AFILIACION_DATOS datos, ref List<BENEFICIARIO> lstBeneficiarios)
        {
            RespuestaCore respuestaCampos = new RespuestaCore();
            respuestaCampos.ExisteError = false;
            respuestaCampos.MensajeError = string.Empty;
   
            if (persona.PEPVC_PATERNO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo AP_PATERNO faltante)"; }
            if (persona.PEPVC_MATERNO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo AP_MATERNO faltante)"; }
            if (persona.PEPVC_NOMBRES == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo NOMBRES faltante)"; }
            if (persona.PEPVC_CI == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo CI faltante)"; }
            if (persona.PEPDT_FECHA_NACIMIENTO == null || persona.PEPDT_FECHA_NACIMIENTO == (DateTime)SqlDateTime.MinValue) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo FECHA_NACIMIENTO faltante)"; }
            if (persona.PEPVC_COMPLEMENTO_IDC == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo COMPLEMENTO_IDC faltante)"; }
            if (persona.LXPVC_ESTADO_CIVIL == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ESTADO_CIVIL faltante)"; }
            if (persona.PEPVC_CORREO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo CORREO faltante)"; }
            if (afiliacion.PEPVC_CORREO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo CORREO faltante)"; }
            if (persona.PEPVC_DIRECCION == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo DIRECCION faltante)"; }
            if (persona.PEPVC_CIUDAD == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo CIUDAD faltante)"; }
            if (persona.PEPVC_OCUPACION == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo OCUPACION faltante)"; }
            if (persona.PEPVC_NACIONALIDAD == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo NACIONALIDAD faltante)"; }
            if (persona.PEPVC_TELEFONO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo TELEFONO faltante)"; }
            //if (persona.LXPVC_GENERO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo GENERO faltante)"; }
            if (persona.LXPVC_ENTIDAD == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ENTIDAD faltante)"; }
            if (afiliacion.LXPVC_ENTIDAD == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ENTIDAD faltante)"; }
            if (persona.PESVC_LUGAR_NACIMIENTO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo LUGAR_NACIMIENTO faltante)"; }



            if (afiliacion.AFPBI_ID_QR == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ID_QR faltante)"; }
            if (afiliacion.PRPVC_ID_PRODUCTO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ID_PRODUCTO faltante)"; }
            if (afiliacion.NIPVC_ID_NIVEL == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo ID_NIVEL faltante)"; }
            if (afiliacion.AFPDC_PRIMA_COMERCIAL == 0) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo PRIMA_COMERCIAL faltante)"; }
            if (afiliacion.LXPVC_MONEDA == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo MONEDA faltante)"; }
            if (afiliacion.AFPDT_FECHA_INICIO_VIGENCIA == null || afiliacion.AFPDT_FECHA_INICIO_VIGENCIA == (DateTime)SqlDateTime.MinValue) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo FECHA_INICIO_VIGENCIA faltante)"; }
            if (afiliacion.AFPVC_ESTADO_AFILIACION == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo VC_ESTADO_AFILIACION faltante)"; }
            //if (afiliacion.AFPVC_DEPARTAMENTO == null) { respuestaCampos.ExisteError = true; respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Campo DEPARTAMENTO faltante)"; }

            
            return respuestaCampos;
        }
        public static RespuestaCore ValidacionDeNegocio(ref PERSONA_NATURAL_PB persona, ref AFILIACION afiliacion, ref AFILIACION_DATOS datos, ref List<BENEFICIARIO> lstBeneficiarios)
        {
            RespuestaCore respuestaCampos = new RespuestaCore();
            respuestaCampos.ExisteError = false;
            respuestaCampos.MensajeError = string.Empty;

            //validacion edad
            if (persona.PEPDT_FECHA_NACIMIENTO == null || afiliacion.AFPDT_FECHA_INICIO_VIGENCIA == null || persona.PEPDT_FECHA_NACIMIENTO == (DateTime)SqlDateTime.MinValue || persona.PEPDT_FECHA_NACIMIENTO == (DateTime)SqlDateTime.MinValue)
            {
                respuestaCampos.ExisteError = true;
                respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(Datos faltantes para calculo de edad)";
            }
            else
            {
                int edad = CalcularEdad(persona.PEPDT_FECHA_NACIMIENTO, afiliacion.AFPDT_FECHA_INICIO_VIGENCIA);
                if (edad > 64 || edad < 3)
                {
                    respuestaCampos.ExisteError = true;
                    respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(La fecha de nacimiento no es válida o fuera de rango)";
                }
            }
            //switch (datos.AFPVC_DATO3)
            //{
            //    case "800":
            //    case "1000":
            //    case "1400":
            //    case "6000":
            //    case "1800":
            //    case "3600":
            //    case "11000":
            //        switch (datos.AFPVC_DATO4)
            //        {
            //            case "30000":
            //            case "4000":
            //            case "5000":
            //            case "6000":
            //            case "7000":
            //            case "8000":
            //            case "9000":
            //            case "10000":
            //            case "18000":
            //            case "35000":
            //                break;
            //            default:
            //                respuestaCampos.ExisteError = true;
            //                respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(El monto de la cobertura de vida no corresponde a la de gastos medicos)";
            //                break;
            //        }
            //        break;
                
            //    default:
            //        respuestaCampos.ExisteError = true;
            //        respuestaCampos.MensajeError = respuestaCampos.MensajeError + "(El monto de gastos medicos no valido)";
            //        break;
            //}
            

            
            return respuestaCampos;
        }
        public static int CalcularEdad(DateTime fechaNacimiento, DateTime fechaInicioVigencia)
        {
            // Obtiene la fecha actual:
            DateTime fechaActual = fechaInicioVigencia; 
            if (fechaNacimiento > fechaActual)
            {
                return -1;
            }
            else
            {
                int edad = fechaActual.Year - fechaNacimiento.Year;
                if (fechaNacimiento.Month > fechaActual.Month)
                {
                    --edad;
                }

                return edad;
            }
        }
    }


    
    public class AValidar
    {
        public string data { get; set; }

        public AValidar(string dato)
        {
            data = dato;
        }
    }

    public class RespuestaCore
    {
        public string MensajeError { get; set; }
        public bool ExisteError { get; set; }

        public RespuestaCore()
        {
            MensajeError = "Proceso NO ejecutado";
            ExisteError = true;
        }
    }



}