﻿using Agente;
using Agente.ServicioDocumentos;
using Agente.ServicioLexico;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Presentacion.controllers
{
	public class CDocumentos
	{
        public CDocumentos()
        {
        }
        #region Configuracion Inicial
        private readonly IServicioDocumentos _servicioDocumentos = Proxy.ServicioDocumentos();
		public Agente.ServicioDocumentos.CREDENCIALES CredencialActual()
		{
			try
			{
				var objCredencial = new Agente.ServicioDocumentos.CREDENCIALES()
				{
					USUARIO = new Parametros().ObtenerIdUsuario(),
					IP = new Parametros().ObtenerIPv4()
				};
				return objCredencial;
			}
			catch
			{
				throw;
			}
		}
		#endregion
		
		public GetDocumentParametroResponse GetDocumentParametro(string strIdDocumento, string strIdDenuncia, string strEstado)
		{
			//Log.Inicio();
			try
			{//"@ID_LIQUIDACION"
				var objCredenciales = CredencialActual();// new CParametros().GetCredencialesDocumentos();
				var lstParametros = new List<CParametrosSQL>();
				var oParametros = new CParametrosSQL
				{
					Key = "@idDenuncia",
					Value = strIdDenuncia
				};
				lstParametros.Add(oParametros);
				var oParametros2 = new CParametrosSQL
				{
					Key = "@estado",
					Value = strEstado
				};
				lstParametros.Add(oParametros2);
				var oParametros3 = new CParametrosSQL
				{
					Key = "@idUsuario",
					Value = objCredenciales.USUARIO
				};
				lstParametros.Add(oParametros3);


				var objGetWordDocumentRequest = new GetDocumentParametroRequest()
				{
					parameterList = lstParametros,
					strIdDocumento = strIdDocumento,
					objCredenciales = objCredenciales
				};

				//Log.Debug("Accion: Documento word; Recurso: servicio captado en Presentacion");

				var response = _servicioDocumentos.GetDocumentParametro(objGetWordDocumentRequest);

				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
        public byte[] FirmarDocumentos(byte[] documento, string strIdUsuario)
        {
            try
            {

               
                var objCredencial = new Agente.ServicioDocumentos.CREDENCIALES()
                {

                    USUARIO = strIdUsuario,
                    IP = "1.1.1.1",
                    ENTIDAD = string.Empty,
                    TOMADOR = string.Empty,
                    BROKER = string.Empty

                };

                var objVerificacion = new CrsValidationResult
                {
                    IsValid = true,
                    ValidationErrors = new List<ListErrors>()
                };
                var objRequest = new FirmarDocumentoPdfBRequest();
                objRequest.strEntidad = "GENERALES";
                objRequest.btArchivo = documento;
                objRequest.objCredenciales = objCredencial;
                objRequest.ValidationResult = objVerificacion;

                var objResponse = _servicioDocumentos.FirmarDocumentoPdfB(objRequest);

                return objResponse.FirmarDocumentoPdfBResult;

            }
            catch
            {
                throw;
            }
        }

    }
}