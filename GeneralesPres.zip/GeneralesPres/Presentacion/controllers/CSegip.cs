﻿using Agente;
using Agente.SericioAfiliacionBroker;
using Agente.ServiceSegip;
using DevExpress.Spreadsheet;
using DocumentFormat.OpenXml.Packaging;
using Presentacion.entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using static DevExpress.Utils.HashCodeHelper.Primitives;


namespace Presentacion.controllers
{
    public class CSegip
    {
        private readonly IServicioExternoInstitucion _servicioSegip = Proxy.ServicioSegip();
        

        public byte[] Verificador(byte[] datos)
        {
            int institutionId = 259;
            string user = "milton.hernandez";
            string password = "Segip2024";
            string finalUserKey = "M362034809547";
            string authNumber = String.Empty;
            bool isLocal = true;
            int isBolivianPerson = isLocal ? 1 : 2;
            try
            {
                // string _strRutaArchivos = (@"D:\B04953\repositorio\PruebasExcel\prueba.xlsx");
                byte[] archivoExcel = datos;//File.ReadAllBytes(_strRutaArchivos);


                Workbook DEWorkbook = new Workbook();
                using (MemoryStream stream = new MemoryStream(archivoExcel))
                {
                    DEWorkbook.LoadDocument(stream, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                }

                Request Requests = new Request();
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    CellRange usedRange = DEWorksheet.GetUsedRange();
                    int realRowCount = 0;
                    int realColumnCount = 0;
                    for (int rowIndex = usedRange.TopRowIndex; rowIndex <= usedRange.BottomRowIndex; rowIndex++)
                    {
                        bool hasContent = false;

                        for (int colIndex = usedRange.LeftColumnIndex; colIndex <= usedRange.RightColumnIndex; colIndex++)
                        {
                            Cell cell = DEWorksheet.Cells[rowIndex, colIndex];
                            if (cell.Value != null && !string.IsNullOrWhiteSpace(cell.Value.ToString()))
                            {
                                hasContent = true;
                                break;
                            }
                        }
                        if (hasContent)
                        {
                            realRowCount++;
                        }
                    }
                    for (int colIndex = usedRange.LeftColumnIndex; colIndex <= usedRange.RightColumnIndex; colIndex++)
                    {
                        bool hasContent = false;

                        for (int rowIndex = usedRange.TopRowIndex; rowIndex <= usedRange.BottomRowIndex; rowIndex++)
                        {
                            Cell cell = DEWorksheet.Cells[rowIndex, colIndex];
                            if (cell.Value != null && !string.IsNullOrWhiteSpace(cell.Value.ToString()))
                            {
                                hasContent = true;
                                break;
                            }
                        }

                        if (hasContent)
                        {
                            realColumnCount++;
                        }
                    }

                    int columnaError = usedRange.RightColumnIndex + 1; // Primera columna vacía a la derecha
                    for (int row = 1; row <= realRowCount - 1; row++)
                    {
                        var numeroDocumento = DEWorksheet.Cells[row, 10].Value?.ToString();
                        var complemento = DEWorksheet.Cells[row, 12].Value?.ToString();
                        var nombre = DEWorksheet.Cells[row, 7].Value?.ToString();
                        var apellidoPaterno = DEWorksheet.Cells[row, 8].Value?.ToString();
                        var apellidoMaterno = DEWorksheet.Cells[row, 9].Value?.ToString();
                        var fechaRaw = DEWorksheet.Cells[row, 17].Value?.ToString();
                        Cell cell = DEWorksheet.Cells[row, 17];
                        string formato = cell.NumberFormat;
                        DateTime fechaNacimiento;
                        if (formato != "dd/mm/yyyy;@")
                        {
                            DEWorksheet.Cells[row, columnaError].Value = "Formato de fecha invalido";
                        }
                        else
                        {
                            if (DateTime.TryParse(fechaRaw, out fechaNacimiento))
                            {
                                string fechaFormateada = fechaNacimiento.ToString("dd/MM/yyyy");
                                if (!string.IsNullOrWhiteSpace(numeroDocumento) || !string.IsNullOrWhiteSpace(nombre) || !string.IsNullOrWhiteSpace(apellidoPaterno) || !string.IsNullOrWhiteSpace(fechaRaw))
                                {
                                    Requests.NumeroDocumento = numeroDocumento.Trim();
                                    Requests.Complemento = complemento.ToUpper();
                                    Requests.FechaNacimiento = fechaFormateada;
                                    Requests.Nombres = nombre.ToUpper();
                                    Requests.PrimerApellido = apellidoPaterno.Trim().ToUpper();
                                    Requests.SegundoApellido = apellidoMaterno.Trim().ToUpper();
                                    Requests.LugarNacimientoDepartamento = "LA PAZ";
                                    Requests.LugarNacimientoLocalidad = "";
                                    Requests.LugarNacimientoPais = "BOLIVIA";
                                    Requests.LugarNacimientoProvincia = "MURILLO";
                                    string requestfinal = System.Text.Json.JsonSerializer.Serialize(Requests);

                                    var response = _servicioSegip.ConsultaDatoPersonaContrastacion(259, user, password, finalUserKey, "", requestfinal, isBolivianPerson);

                                    if (response.ContrastacionEnFormatoJson == null && response.DescripcionRespuesta == "No se encontró el registro")
                                    {
                                        DEWorksheet.Cells[row, columnaError].Value = "Dato no encontrado";
                                    }

                                    var model = System.Text.Json.JsonSerializer.Deserialize<Response>(response.ContrastacionEnFormatoJson);

                                    if (model.NumeroDocumento == 1 && model.Nombres == 1 && model.PrimerApellido == 1 && model.SegundoApellido == 1 && model.FechaNacimiento == 1)
                                    {
                                        DEWorksheet.Cells[row, columnaError].Value = "Dato reconocido";
                                    }
                                    else
                                    {
                                        DEWorksheet.Cells[row, columnaError].Value = model.PrintFialed();
                                    }
                                }
                                else
                                {
                                    DEWorksheet.Cells[row, columnaError].Value = "Formato de fecha invalido";
                                }
                            }
                            else
                            {
                                DEWorksheet.Cells[row, columnaError].Value = "Formato de fecha invalido";
                            }

                        }
                    }
                }
                using (MemoryStream outputStream = new MemoryStream())
                {
                    DEWorkbook.SaveDocument(outputStream, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                    byte[] excelModificado = outputStream.ToArray();

                    return excelModificado;
                }
            }
            catch
            {
                throw;
            }
        }

        
        
    }
}