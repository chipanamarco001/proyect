﻿using Agente;
using Agente.ServicioDocumentos;
using Agente.ServicioGenerales;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Web;

namespace Presentacion.controllers
{
    public class CGenerales
    {
        #region Configuracion Inicial
        private readonly IServicioGenerales _iServicioGenerales = Proxy.ServicioGenerales();        
        public Credencial CredencialActual()
        {
            try
            {
                var objCredencial = new Credencial()
                {
                    IdUsuario = new Parametros().ObtenerIdUsuario(),
                    IPv4 = new Parametros().ObtenerIPv4(),
                    Dispositivo = new Parametros().ObtenerDispositivo()
                };
                return objCredencial;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region LOG_ERRORES
        public bool Error_Registrar(ERROR objLogError)
        {
            try
            {
                var objRequest = new Error_RegistrarRequest
                {
                    objLogError = objLogError,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Error_Registrar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Error_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region LEXICO
        public List<LEXICO> ListaLexicosPorTabla(string strTabla)
        {
            try
            {
                var objRequest = new ListaLexicosPorTablaRequest
                {
                    strTabla = strTabla,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ListaLexicosPorTabla(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaLexicosPorTablaResult;
            }
            catch
            {
                throw;
            }
        }
        public List<LEXICO> ListaLexicosPorTablaYTema(string strTabla, string strTema)
        {
            try
            {
                var objRequest = new ListaLexicosPorTablaYTemaRequest
                {
                    strTabla = strTabla,
                    strTema = strTema,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ListaLexicosPorTablaYTema(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaLexicosPorTablaYTemaResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Lexico_Registrar(LEXICO objLexico)
        {
            try
            {
                var objRequest = new Lexico_RegistrarRequest
                {
                    objLexico = objLexico,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Lexico_Registrar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Lexico_Actualizar(LEXICO objLexico)
        {
            try
            {
                var objRequest = new Lexico_ActualizarRequest
                {
                    objLexico = objLexico,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Lexico_Actualizar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_ActualizarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<LEXICO> Lexico_ObtenerListaActivos()
        {
            try
            {
                var objRequest = new Lexico_ObtenerListaActivosRequest
                {
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Lexico_ObtenerListaActivos(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Lexico_ObtenerListaActivosResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region USUARIOS
        public occ_usuario ValidaAccesoUsuario()
        {
            try
            {
                var objRequest = new ValidaAccesoUsuarioRequest
                {
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ValidaAccesoUsuario(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ValidaAccesoUsuarioResult;
            }
            catch
            {
                throw;
            }
        }
        public List<USUARIO> ObtenerListaUsuariosActivos()
        {
            try
            {
                var objRequest = new ObtenerListaUsuariosActivosRequest
                {
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ObtenerListaUsuariosActivos(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ObtenerListaUsuariosActivosResult;
            }
            catch
            {
                throw;
            }
        }
        public occ_usuario DatosDirectorioActivo(string strIdUsuario)
        {
            try
            {
                var objRequest = new DatosDirectorioActivoRequest
                {
                    strIdUsuario = strIdUsuario,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.DatosDirectorioActivo(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.DatosDirectorioActivoResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ValidarAutenticacion(string strIdUsuario, string strPassword)
        {
            try
            {
                var objRequest = new ValidarAutenticacionRequest
                {
                    strIdUsuario = strIdUsuario,
                    strPassword = strPassword,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ValidarAutenticacion(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                return objResponse.ValidarAutenticacionResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region CONTABILIDAD
        public List<SPR_LISTA_PRODUCTOS_Result> Contabilidad_ObtenerListaProductosPorMes(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_ObtenerListaProductosPorMesRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ObtenerListaProductosPorMes(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ObtenerListaProductosPorMesResult;
            }
            catch
            {
                throw;
            }
        }
        public PROCESO_CONTABLE Contabilidad_ObtenerProcesoContable(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_ObtenerProcesoContableRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ObtenerProcesoContable(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ObtenerProcesoContableResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PROCESO_CONTABLE> Contabilidad_ListaProcesosContablesPorMes(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_ListaProcesosContablesPorMesRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ListaProcesosContablesPorMes(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ListaProcesosContablesPorMesResult;
            }
            catch
            {
                throw;
            }
        }
        public List<PROCESO_CONTABLE> Contabilidad_ObtenerListaProcesosContablesCompletados(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_ObtenerListaProcesosContablesCompletadosRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ObtenerListaProcesosContablesCompletados(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ObtenerListaProcesosContablesCompletadosResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Contabilidad_RegistrarProcesoContable(PROCESO_CONTABLE objProcesoContable)
        {
            try
            {
                var objRequest = new Contabilidad_RegistrarProcesoContableRequest
                {
                    objProcesoContable = objProcesoContable,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_RegistrarProcesoContable(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_RegistrarProcesoContableResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Contabilidad_ActualizarProcesoContable(PROCESO_CONTABLE objProcesoContable)
        {
            try
            {
                var objRequest = new Contabilidad_ActualizarProcesoContableRequest
                {
                    objProcesoContable = objProcesoContable,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ActualizarProcesoContable(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ActualizarProcesoContableResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Contabilidad_Generar(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_GenerarRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_Generar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_GenerarResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet Contabilidad_Validar(string strMesProduccion)
        {
            try
            {
                var objRequest = new Contabilidad_ValidarRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_Validar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ValidarResult;
            }
            catch
            {
                throw;
            }
        }
        public List<ASIENTO_CONTABLE> Contabilidad_ObtenerAsientosContablesPorNumeroProceso(string strMesProduccion, int intNumeroProceso)
        {
            try
            {
                var objRequest = new Contabilidad_ObtenerAsientosContablesPorNumeroProcesoRequest
                {
                    strMesProduccion = strMesProduccion,
                    intNumeroProceso = intNumeroProceso,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Contabilidad_ObtenerAsientosContablesPorNumeroProceso(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Contabilidad_ObtenerAsientosContablesPorNumeroProcesoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region CONFORMIDAD
        public List<occ_detalle_conformidades> Conformidad_ObtenerDetalleConformidades(string strMesProduccion, int intNumeroProceso)
        {
            try
            {
                var objRequest = new Conformidad_ObtenerDetalleConformidadesRequest
                {
                    strMesProduccion = strMesProduccion,
                    intNumeroProceso = intNumeroProceso,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Conformidad_ObtenerDetalleConformidades(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Conformidad_ObtenerDetalleConformidadesResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Conformidad_Registrar(CONFORMIDAD objConformidad)
        {
            try
            {
                var objRequest = new Conformidad_RegistrarRequest
                {
                    objConformidad = objConformidad,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Conformidad_Registrar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Conformidad_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet Conformidad_CuadroCierre(string strMesProduccion)
        {
            try
            {
                var objRequest = new Conformidad_CuadroCierreRequest
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Conformidad_CuadroCierre(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Conformidad_CuadroCierreResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region DOCUMENTOS
        public occ_archivo_respuesta Documento_AsientosContables(string strMesProduccion, int intNumeroProceso)
        {
            try
            {
                var objRequest = new Documento_AsientosContablesRequest
                {
                    strMesProduccion = strMesProduccion,
                    intNumeroProceso = intNumeroProceso,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Documento_AsientosContables(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Documento_AsientosContablesResult;
            }
            catch
            {
                throw;
            }
        }
        public occ_archivo_respuesta Documento_Generar(string strIdDocumento, List<occ_archivo_respuesta__parametros> listaParametros)
        {
            try
            {
                var objRequest = new Documento_GenerarRequest
                {
                    strIdDocumento = strIdDocumento,
                    listaParametros = listaParametros,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Documento_Generar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Documento_GenerarResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region BANDEJA PRODUCCION
        public List<SPR_GET_BANDEJA_PRODUCCION_Result> GetListaBandejaProduccion(string strMesProduccion)
		{
			try
			{
				var objRequest = new GetListaBandejaProduccionRequest
				{
					strMesProduccion = strMesProduccion,
					objCredencial = CredencialActual(),
					objExcepciones = new occ_excepciones()
				};
				var objResponse = _iServicioGenerales.GetListaBandejaProduccion(objRequest);
				if (!objResponse.objExcepciones.EsValido)
				{
					HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.GetListaBandejaProduccionResult;
			}
			catch
			{
				throw;
			}
		}
        public bool BandejaProduccion_EjecutarProcedimiento(string strMesProduccion, string strIdProducto)
        {
            try
            {
                var objRequest = new BandejaProduccion_EjecutarProcedimientoRequest()
                {
                    strMesProduccion = strMesProduccion,
                    strIdProducto = strIdProducto,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.BandejaProduccion_EjecutarProcedimiento(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.BandejaProduccion_EjecutarProcedimientoResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region RESERVAS TECNICAS
        public DataSet ReservasTecnicas_Validacion(string strMesProduccion, string strRamo)
        {
            try
            {
                var objRequest = new ReservasTecnicas_ValidacionRequest()
                {
                    strMesProduccion = strMesProduccion,
                    strRamo = strRamo,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ReservasTecnicas_Validacion(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ReservasTecnicas_ValidacionResult;
            }
            catch
            {
                throw;
            }
        }
        public bool ReservasTecnicas_Cargar(string strMesProduccion)
        {
            try
            {
                var objRequest = new ReservasTecnicas_CargarRequest()
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ReservasTecnicas_Cargar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ReservasTecnicas_CargarResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region ANULACIONES
        public DataSet Anulacion_Bandeja(string strMesProduccion)
        {
            try
            {
                var objRequest = new Anulacion_BandejaRequest()
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_Bandeja(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_BandejaResult;
            }
            catch
            {
                throw;
            }
        }
        public DataSet Anulacion_Buscar(string strTipo, string strIdProducto, string strNumeroPoliza, string strCertificado, DateTime dtFechaAfiliacion, string strDocumentoNumero, string strNombre, long longIdAfiliacion)
        {
            try
            {
                var objRequest = new Anulacion_BuscarRequest()
                {
                    strTipo = strTipo,
                    strIdProducto = strIdProducto,
                    strNumeroPoliza = strNumeroPoliza,
                    strCertificado = strCertificado,
                    dtFechaAfiliacion = dtFechaAfiliacion,
                    strDocumentoNumero = strDocumentoNumero,
                    strNombre = strNombre,
                    longIdAfiliacion = longIdAfiliacion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_Buscar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_BuscarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_Registrar(ANULACION objAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_RegistrarRequest()
                {
                    objAnulacion = objAnulacion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_Registrar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_RegistrarResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_RegistrarLista(List<ANULACION> listaAnulaciones)
        {
            try
            {
                var objRequest = new Anulacion_RegistrarListaRequest()
                {
                    listaAnulaciones = listaAnulaciones,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_RegistrarLista(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_RegistrarListaResult;
            }
            catch
            {
                throw;
            }
        }
        public bool Anulacion_Modificar(ANULACION objAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_ModificarRequest()
                {
                    objAnulacion = objAnulacion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_Modificar(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_ModificarResult;
            }
            catch
            {
                throw;
            }
        }
        public ANULACION Anulacion_ObtenerAnulacionPorId(long longIdAnulacion)
        {
            try
            {
                var objRequest = new Anulacion_ObtenerAnulacionPorIdRequest()
                {
                    longIdAnulacion = longIdAnulacion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Anulacion_ObtenerAnulacionPorId(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Anulacion_ObtenerAnulacionPorIdResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region SINIESTROS
        public DataSet Siniestros_Validacion(string strMesProduccion)
        {
            try
            {
                var objRequest = new Siniestros_ValidacionRequest()
                {
                    strMesProduccion = strMesProduccion,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Siniestros_Validacion(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Siniestros_ValidacionResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #region VISTAS
        public List<VISTA_PRODUCTO> ListaProductos()
        {
            try
            {
                var objRequest = new ListaProductosRequest()
                {
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.ListaProductos(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.ListaProductosResult;
            }
            catch
            {
                throw;
            }
        }
		#endregion

		public DataSet GetDatasetProcedimiento(string strNombreProcedimiento, List<Parameter> ListaParametros)
		{
			try
			{
				var objRequest = new GetDatasetProcedimientoRequest();
                objRequest.objCredencial = CredencialActual();
                objRequest.objExcepciones = new occ_excepciones();
				objRequest.strNombreProcedimiento = strNombreProcedimiento;
				objRequest.ListaParametros = ListaParametros;
				var response = _iServicioGenerales.GetDatasetProcedimiento(objRequest);
				//new Parametros().ValidationResult(response);
				return response.GetDatasetProcedimientoResult;
			}
			catch
			{
				throw;
			}
		}

        public DataTable GetTableFormularioPCC04PorPeriodo(string strPeriodoContable)
        {
            try
            {
                var objRequest = new GetListaFormularioPCC04PorPeriodoRequest();
                objRequest.objCredencial = CredencialActual();
				objRequest.objExcepciones = new occ_excepciones();
				objRequest.strPeriodoContable = strPeriodoContable;
                var response = _iServicioGenerales.GetListaFormularioPCC04PorPeriodo(objRequest);
                if (!response.objExcepciones.EsValido && response.objExcepciones.Errores.Count > 0)
                {
                    throw new Exception(response.objExcepciones.Errores[0].Mensaje);
                }
                //new CParametrosComplejos().ValidationResult(response);
                if (response.GetListaFormularioPCC04PorPeriodoResult != null)
                {
                    DataTable DtblFormulario = new DataTable();
                    DtblFormulario.Columns.Clear();
                    DtblFormulario.Columns.Add("ID_FORMULARIO", typeof(string));
                    DtblFormulario.Columns.Add("FECHA", typeof(string));
                    DtblFormulario.Columns.Add("CRS_CIUDAD", typeof(string));
                    DtblFormulario.Columns.Add("CRS_ZONA", typeof(string));
                    DtblFormulario.Columns.Add("CRS_DIRECCION", typeof(string));
                    DtblFormulario.Columns.Add("CRS_TELEFONO", typeof(string));
                    DtblFormulario.Columns.Add("CRS_FUNCIONARIO", typeof(string));
                    DtblFormulario.Columns.Add("CRS_SUPERVISOR", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_PERSONA", typeof(string));
                    DtblFormulario.Columns.Add("PN_NOMBRES", typeof(string));
                    DtblFormulario.Columns.Add("PN_APELLIDO_PATERNO", typeof(string));
                    DtblFormulario.Columns.Add("PN_APELLIDO_MATERNO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_TIPO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_NUMERO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DOCUMENTO_EXTENSION", typeof(string));
                    DtblFormulario.Columns.Add("PN_NACIONALIDAD", typeof(string));
                    DtblFormulario.Columns.Add("PN_PAIS_RESIDENCIA", typeof(string));
                    DtblFormulario.Columns.Add("PN_PROFESION", typeof(string));
                    DtblFormulario.Columns.Add("ACTIVIDAD", typeof(string));
                    DtblFormulario.Columns.Add("PN_LUGAR_TRABAJO", typeof(string));
                    DtblFormulario.Columns.Add("PN_CARGO", typeof(string));
                    DtblFormulario.Columns.Add("PN_DIRECCION_TRABAJO", typeof(string));
                    DtblFormulario.Columns.Add("PJ_NIT", typeof(string));
                    DtblFormulario.Columns.Add("PJ_RAZON_SOCIAL", typeof(string));
                    DtblFormulario.Columns.Add("CIUDAD", typeof(string));
                    DtblFormulario.Columns.Add("DIRECCION", typeof(string));
                    DtblFormulario.Columns.Add("ZONA", typeof(string));
                    DtblFormulario.Columns.Add("TELEFONO", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_OPERACION", typeof(string));
                    DtblFormulario.Columns.Add("NATURALEZA_OPERACION", typeof(string));
                    DtblFormulario.Columns.Add("TIPO_SEGURO", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_PLAZO_SEGURO", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_RAMO", typeof(string));
                    DtblFormulario.Columns.Add("MONEDA", typeof(string));
                    DtblFormulario.Columns.Add("MONTO", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_CORREDOR", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_TOMADOR", typeof(string));
                    DtblFormulario.Columns.Add("NOMBRE_INTERMEDIARIO", typeof(string));
                    DtblFormulario.Columns.Add("NUMERO_POLIZA", typeof(string));
                    DtblFormulario.Columns.Add("NUMERO_CUENTA", typeof(string));
                    DtblFormulario.Columns.Add("CODIGO_ENTIDAD_FINANCIERA", typeof(string));
                    DtblFormulario.Columns.Add("NUMERO_CHEQUE", typeof(string));
                    //DtblFormulario.Columns.Add("REPOSICION", typeof(string));
                    DtblFormulario.Columns.Add("ORIGEN_RECURSOS", typeof(string));
                    DtblFormulario.Columns.Add("DESTINO_RECURSOS", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_NOMBRE", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_DOCUMENTO_NUMERO", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_DOCUMENTO_EXTENSION", typeof(string));
                    DtblFormulario.Columns.Add("DECLARANTE_CARGO", typeof(string));
                    DtblFormulario.Columns.Add("OBSERVACIONES", typeof(string));
                    foreach (var objFormulario in response.GetListaFormularioPCC04PorPeriodoResult)
                    {
                        string strIdFormulario = "000000" + objFormulario.FUIN_ID_FORMULARIO.ToString();
                        DataRow dr = DtblFormulario.NewRow();
                        dr["ID_FORMULARIO"] = "CRSP-PCC04-" + strIdFormulario.Substring(strIdFormulario.Length - 6, 6);
                        dr["FECHA"] = objFormulario.FUDT_FECHA.ToString("dd/MM/yyyy");
                        dr["CRS_CIUDAD"] = (objFormulario.FUVC_CRS_CIUDAD ?? string.Empty);
                        dr["CRS_ZONA"] = (objFormulario.FUVC_CRS_ZONA ?? string.Empty);
                        dr["CRS_DIRECCION"] = (objFormulario.FUVC_CRS_DIRECCION ?? string.Empty);
                        dr["CRS_TELEFONO"] = (objFormulario.FUVC_CRS_TELEFONO ?? string.Empty);
                        dr["CRS_FUNCIONARIO"] = (objFormulario.FUVC_NOMBRE_FUNCIONARIO_RECEPTOR ?? string.Empty);//(objFormulario.FOPVC_CRS_FUNCIONARIO ?? string.Empty);
						dr["CRS_SUPERVISOR"] = (objFormulario.FUVC_NOMBRE_SUPERVISOR ?? string.Empty); //(objFormulario.FOPVC_CRS_SUPERVISOR ?? string.Empty);
                        dr["TIPO_PERSONA"] = (objFormulario.FUVC_TIPO_PERSONA ?? string.Empty);
                        dr["PN_NOMBRES"] = (objFormulario.FUVC_NOMBRE_DECLARANTE ?? string.Empty);
                        dr["PN_APELLIDO_PATERNO"] = (objFormulario.FUVC_PN_PATERNO ?? string.Empty);//(objFormulario.FOPVC_PN_APELLIDO_PATERNO ?? string.Empty);
                        dr["PN_APELLIDO_MATERNO"] = (objFormulario.FUVC_PN_MATERNO_CASADA ?? string.Empty);//; (objFormulario.FOSVC_PN_APELLIDO_MATERNO ?? string.Empty);
						dr["PN_DOCUMENTO_TIPO"] = (objFormulario.FUVC_PN_TIPO_DOCUMENTO_IDENTIDAD ?? string.Empty);
                        dr["PN_DOCUMENTO_NUMERO"] = (objFormulario.FUVC_PN_NUMERO_DOCUMENTO_IDENTIDAD ?? string.Empty);
                        dr["PN_DOCUMENTO_EXTENSION"] = (objFormulario.FUVC_PN_LUGAR_EXPEDICION ?? string.Empty);//(objFormulario.FOSVC_PN_DOCUMENTO_EXTENSION ?? string.Empty);
						dr["PN_NACIONALIDAD"] = (objFormulario.FUVC_PN_NACIONALIDAD ?? string.Empty);
                        dr["PN_PAIS_RESIDENCIA"] = (objFormulario.FUVC_PN_PAIS_RESIDENCIA ?? string.Empty);
                        dr["PN_PROFESION"] = (objFormulario.FUVC_PN_PROFESION ?? string.Empty);
                        dr["ACTIVIDAD"] = (objFormulario.FUVC_PN_ACTIVIDAD_ECONOMICA ?? string.Empty);
                        dr["PN_LUGAR_TRABAJO"] = string.Empty;// (objFormulario.FOSVC_PN_LUGAR_TRABAJO ?? string.Empty);
                        dr["PN_CARGO"] = (objFormulario.FUVC_CARGO_DECLARANTE ?? string.Empty);
                        dr["PN_DIRECCION_TRABAJO"] = (objFormulario.FUVC_PN_DIRECCION_TRABAJO ?? string.Empty);
                        dr["PJ_NIT"] = (objFormulario.FUVC_PJ_NIT ?? string.Empty);
                        dr["PJ_RAZON_SOCIAL"] = (objFormulario.FUVC_PJ_RAZON_SOCIAL ?? string.Empty);
                        dr["CIUDAD"] = (objFormulario.FUVC_PJ_CIUDAD ?? string.Empty);
                        dr["DIRECCION"] = (objFormulario.FUVC_PJ_DIRECCION ?? string.Empty);
                        dr["ZONA"] = (objFormulario.FUVC_PJ_ZONA ?? string.Empty);
                        dr["TELEFONO"] = (objFormulario.FUVC_PJ_TELEFONO ?? string.Empty);
                        dr["TIPO_OPERACION"] = (objFormulario.FUVC_TIPO_OPERACION ?? string.Empty);
                        dr["NATURALEZA_OPERACION"] = (objFormulario.FUVC_NATURALEZA_OPERACION ?? string.Empty);
                        dr["TIPO_SEGURO"] = (objFormulario.FUVC_TIPO_SEGURO ?? string.Empty);
                        dr["CODIGO_PLAZO_SEGURO"] = (objFormulario.FUVC_PLAZO_SEGURO ?? string.Empty);
                        dr["CODIGO_RAMO"] = (objFormulario.FUVC_RAMO_SEGURO ?? string.Empty);
                        dr["MONEDA"] = (objFormulario.FUVC_MONEDA_SEGURO ?? string.Empty);
                        dr["MONTO"] = objFormulario.FUVC_MONEDA_SEGURO.ToString();
                        dr["NOMBRE_CORREDOR"] = (objFormulario.FUVC_NOMBRE_CORREDOR_PARA_OPERACION ?? string.Empty); ;// (objFormulario.FOSVC_NOMBRE_CORREDOR ?? string.Empty);
                        dr["NOMBRE_TOMADOR"] = string.Empty; //(objFormulario.FOPVC_NOMBRE_TOMADOR ?? string.Empty);
						dr["NOMBRE_INTERMEDIARIO"] = (objFormulario.FUVC_NOMBRE_INTERMEDIARIO_PARA_OPERACION ?? string.Empty); //(objFormulario.FOSVC_NOMBRE_INTERMEDIARIO ?? string.Empty);
						dr["NUMERO_POLIZA"] = (objFormulario.FUVC_NRO_POLIZA_OPERACION ?? string.Empty);//(objFormulario.FOPVC_NUMERO_POLIZA ?? string.Empty);
						dr["NUMERO_CUENTA"] = (objFormulario.FUVC_NRO_CUENTA_PARA_SINIESTRO_RESCATE ?? string.Empty);//(objFormulario.FOSVC_NUMERO_CUENTA ?? string.Empty);
						dr["CODIGO_ENTIDAD_FINANCIERA"] = string.Empty;//(objFormulario.FOSBI_CODIGO_ENTIDAD_FINANCIERA.ToString() ?? string.Empty);
						dr["NUMERO_CHEQUE"] = (objFormulario.FUVC_NRO_CHEQUE_PARA_SINIESTRO_RESCATE ?? string.Empty);
                        //dr["REPOSICION"] = (objFormulario.FOSVC_REPOSICION ?? string.Empty);
                        dr["ORIGEN_RECURSOS"] = (objFormulario.FUVC_ORIGEN_RECURSOS ?? string.Empty);
                        dr["DESTINO_RECURSOS"] = (objFormulario.FUVC_DESTINO_RECURSOS ?? string.Empty);
                        dr["DECLARANTE_NOMBRE"] = (objFormulario.FUVC_NOMBRE_DECLARANTE ?? string.Empty);
                        dr["DECLARANTE_DOCUMENTO_NUMERO"] = (objFormulario.FUVC_NRO_DOCUMENTO_IDENTIDAD_DECLARANTE ?? string.Empty);
                        dr["DECLARANTE_DOCUMENTO_EXTENSION"] = (objFormulario.FUVC_EXPEDICION_DOCUMENTO_IDENTIDAD_DECLARANTE ?? string.Empty); //(objFormulario.FOSVC_DECLARANTE_DOCUMENTO_EXTENSION ?? string.Empty);
						dr["DECLARANTE_CARGO"] = (objFormulario.FUVC_CARGO_DECLARANTE ?? string.Empty);
                        dr["OBSERVACIONES"] = (objFormulario.FUVC_OBSERVACIONES ?? string.Empty);
                        DtblFormulario.Rows.Add(dr);
                    }
                    return DtblFormulario;
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
		#region Carta Nemesis
		public SPWB_REGISTRAR_CARTA_NEMESIS_Result RegistrarCartaNemesis(CARTA_NEMESIS objCartaNemesis)
		{
			try
			{
				var objRequest = new RegistrarCartaNemesisRequest()
				{
					objCartaNemesis = objCartaNemesis,
					objCredencial = CredencialActual(),
					objExcepciones = new occ_excepciones()
				};
				var objResponse = _iServicioGenerales.RegistrarCartaNemesis(objRequest);
				if (!objResponse.objExcepciones.EsValido)
				{
					HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.RegistrarCartaNemesisResult;
			}
			catch
			{
				throw;
			}
		}
		#endregion
		public bool RegistrarLstAnulacionProduccionMes(List<ANULACION_PRODUCCION_MES> lstAnulacion)
		{
			try
			{
                var objRequest = new RegistrarLstAnulacionProduccionMesRequest()
                {
                    lstAnulacion = lstAnulacion,
					objCredencial = CredencialActual(),
					objExcepciones = new occ_excepciones()
				};
				var objResponse = _iServicioGenerales.RegistrarLstAnulacionProduccionMes(objRequest);
				if (!objResponse.objExcepciones.EsValido)
				{
					HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.RegistrarLstAnulacionProduccionMesResult;
			}
			catch(Exception ex)
			{
				throw;
			}
		}
		public List<ANULACION_PRODUCCION_MES> ObtenerAnulacionesPendientes()
		{
			try
			{
				var objRequest = new ObtenerAnulacionesPendientesRequest()
				{
					objCredencial = CredencialActual(),
					objExcepciones = new occ_excepciones()
				};
				var objResponse = _iServicioGenerales.ObtenerAnulacionesPendientes(objRequest);
				if (!objResponse.objExcepciones.EsValido)
				{
					HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.ObtenerAnulacionesPendientesResult;
			}
			catch
			{
				throw;
			}
		}
		public bool AnularProduccionMes()
		{
			try
			{
				var objRequest = new AnularProduccionMesRequest()
				{					
					objCredencial = CredencialActual(),
					objExcepciones = new occ_excepciones()
				};
				var objResponse = _iServicioGenerales.AnularProduccionMes(objRequest);
				if (!objResponse.objExcepciones.EsValido)
				{
					HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
					throw new Exception("Se ha presentado un error inesperado.");
				}
				return objResponse.AnularProduccionMesResult;
			}
			catch
			{
				throw;
			}
		}
        #region  Archivo contable y Archivos regulatorios
        public List<SPR_GET_ARCHIVO_CONTABLE_CARGADO_Result> GetArchivoContableCargado(string strMesProduccion)
        
        {
            try
            {
                var objRequest = new GetArchivoContableCargadoRequest()
                {
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones(),
                    strPeriodo = strMesProduccion
                };
                var objResponse = _iServicioGenerales.GetArchivoContableCargado(objRequest);
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.GetArchivoContableCargadoResult;
            }
            catch
            {
                throw;
            }
        }
        public occ_archivo_respuesta GetReportesArchivosRegulatorios(string strIdDocumento, List<Parameter> listaParametros, occ_archivo_respuesta objResponseFile)
        {
            IServicioDocumentos _servicioDocumentos = Proxy.ServicioDocumentos();
            try
            {
                var objRequest = new GetReportesArchivosRegulatoriosRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objCredencial = CredencialActual();
                objRequest.objResponseFile = objResponseFile;
                var response = _iServicioGenerales.GetReportesArchivosRegulatorios(objRequest);
                if (!response.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = response.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return response.GetReportesArchivosRegulatoriosResult;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                Proxy.Close(_servicioDocumentos);
            }
        }
        public occ_archivo_respuesta GetReporteRegulatorioTXT(string strIdDocumento, List<Parameter> listaParametros, occ_archivo_respuesta objResponseFile)
        {
            IServicioDocumentos _servicioDocumentos = Proxy.ServicioDocumentos();
            try
            {
                var objRequest = new GetReporteRegulatorioTXTRequest();
                objRequest.strIdDocumento = strIdDocumento;
                objRequest.listaParametros = listaParametros;
                objRequest.objCredencial = CredencialActual();
                objRequest.objResponseFile = objResponseFile;
                var response = _iServicioGenerales.GetReporteRegulatorioTXT(objRequest);
                if (!response.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = response.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return response.GetReporteRegulatorioTXTResult;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                Proxy.Close(_servicioDocumentos);
            }
        }
        #endregion
        #region REPORTES
        public List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result> Reporte_GraficaProduccion(string strMesProduccion, string strTipo)
        {
            try
            {
                var objRequest = new Reporte_GraficaProduccionRequest()
                {
                    strMesProduccion = strMesProduccion,
                    strTipo = strTipo,
                    objCredencial = CredencialActual(),
                    objExcepciones = new occ_excepciones()
                };
                var objResponse = _iServicioGenerales.Reporte_GraficaProduccion(objRequest);                
                if (!objResponse.objExcepciones.EsValido)
                {
                    HttpContext.Current.Session["LISTA_EXCEPCIONES"] = objResponse.objExcepciones.Errores;
                    throw new Exception("Se ha presentado un error inesperado.");
                }
                return objResponse.Reporte_GraficaProduccionResult;
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}