﻿using Agente;
using Agente.ServicioSiniestroDenuncia;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Presentacion.controllers
{
	public class CReserva
	{
		private readonly IServicioSiniestroDenuncia _servicioDenuncia = Proxy.ServiciosSiniestroDenuncia();
		//string strContexto = ConfigurationManager.AppSettings["CONTEXTO"];

		#region Configuracion Inicial
		//private readonly IServicioArchivoProducto _servicioArchivoProducto = Proxy.ServicioArchivoProducto();
		//private readonly CGenerales _cGenerales = new CGenerales();
		public CREDENCIALES CredencialActual()
		{
			try
			{
				var objCredencial = new CREDENCIALES()
				{
					USUARIO = new Parametros().ObtenerIdUsuario(),
					IP = new Parametros().ObtenerIPv4()
				};
				return objCredencial;
			}
			catch
			{
				throw;
			}
		}
		#endregion

		public List<SPDE_GETLIST_UIF_CUMULO_PC004_Result> GetListCumulosPc004(string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener lista de cumulos mayores a 10000 dolares; Recurso: servicio captado en Presentacion");

				List<SPDE_GETLIST_UIF_CUMULO_PC004_Result> response = _servicioDenuncia.GetListCumulosPc004(strContexto, CredencialActual());
				//List<SPDE_GETLIST_UIF_CUMULO_PC004_Result> response = _servicioDenuncia.GetListCumulosPc004("SINIESTROS", CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public SPDE_GETDATA_PARA_FORMULARIO_PC004_Result GetPc004Data(string strIdPoliza, string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener datos para formulario pc004; Recurso: servicio captado en Presentacion");

				var response = _servicioDenuncia.GetPc004Data(0, strIdPoliza, strContexto, CredencialActual());
				//var response = _servicioDenuncia.GetPc004Data(0, strIdPoliza, strContexto, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public SPDE_GETDATA_PARA_FORMULARIO_PC004_Result GetPc004Data(long longIdAfiliacion, string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion: obtener datos para formulario pc004; Recurso: servicio captado en Presentacion");

				var response = _servicioDenuncia.GetPc004Data(longIdAfiliacion, null, strContexto, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public long SaveFormularioPC004(FORMULARIO_PC004 objPC004, string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion:registro de datos formulario pc004; Recurso: servicio captado en Presentacion");
				objPC004.FUVC_CONTEXTO = strContexto;
				var response = _servicioDenuncia.SaveFormularioPC004(objPC004, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPDE_GETDATA_DOCUMENTO_FORMULARIO_PC004_Result> GetDataDocumentoFormulario(long idFormulario, string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion:registro de datos formulario pc004; Recurso: servicio captado en Presentacion");
				var response = _servicioDenuncia.GetDataDocumentoFormulario(idFormulario, strContexto, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}
		public FORMULARIO_PC004 GetFormularioPc004ById(long idFormulario, string strContexto)
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion:registro de datos formulario pc004; Recurso: servicio captado en Presentacion");
				var response = _servicioDenuncia.GetFormularioPc004ById(idFormulario, strContexto, CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}

		public List<SPDE_GET_PC004_CORREDORAS_INTERMEDIARIAS_Result> GetListCorredorasIntermediarias()
		{
			//Log.Inicio();
			try
			{
				//Log.Debug("Accion:registro de datos formulario pc004; Recurso: servicio captado en Presentacion");
				var response = _servicioDenuncia.GetListCorredorasIntermediarias(CredencialActual());
				//Log.Fin();
				return response;
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				throw;
			}
		}


	}
}