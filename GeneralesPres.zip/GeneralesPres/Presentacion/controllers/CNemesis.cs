﻿using Agente;
using Agente.ServicioCierre;
using Agente.ServicioGenerales;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Presentacion.controllers
{
	public class CNemesis
	{
		#region Configuracion Inicial
		//private readonly IServicioArchivoProducto _servicioArchivoProducto = Proxy.ServicioArchivoProducto();
		//private readonly CGenerales _cGenerales = new CGenerales();
		public CREDENCIALES CredencialActual()
		{
			try
			{
				var objCredencial = new CREDENCIALES()
				{
					USUARIO = new Parametros().ObtenerIdUsuario(),
					IP = new Parametros().ObtenerIPv4()
				};
				return objCredencial;
			}
			catch
			{
				throw;
			}
		}

		#endregion
		public List<SPWB_GETLIST_PERSONAS_NEMESIS_Result> GetListPersonasNemesis(string cI_NIT, string nOMBRES_RAZON_SOCIAL, string aPELLIDO_PATERNO, string aPELLIDO_MATERNO, DateTime fECHA_INICIO, DateTime fECHA_FIN)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetListPersonasNemesisRequest request = new GetListPersonasNemesisRequest();
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();// parametros.GetCredencialesCierre();
				request.cI_NIT = cI_NIT;
				request.nOMBRES_RAZON_SOCIAL = nOMBRES_RAZON_SOCIAL;
				request.aPELLIDO_PATERNO = aPELLIDO_PATERNO;
				request.aPELLIDO_MATERNO = aPELLIDO_MATERNO;
				request.fECHA_INICIO = fECHA_INICIO;
				request.fECHA_FIN = fECHA_FIN;
				var response = _servicioCierre.GetListPersonasNemesis(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetListPersonasNemesisResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}
		public List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result> GetListAfiliacionesByPersonaNemesis(string iD_PERSONA, DateTime fECHA_INICIO, DateTime fECHA_FIN)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetListAfiliacionesByPersonaNemesisRequest request = new GetListAfiliacionesByPersonaNemesisRequest();
				request.iD_PERSONA = iD_PERSONA;
				request.fECHA_INICIO = fECHA_INICIO;
				request.fECHA_FIN = fECHA_FIN;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetListAfiliacionesByPersonaNemesis(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetListAfiliacionesByPersonaNemesisResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_JURIDICA_NEMESIS_Result> GetListAfiliacionesByPersonaJuridicaNemesis(string iD_PERSONA, DateTime fECHA_INICIO, DateTime fECHA_FIN)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetListAfiliacionesByPersonaJuridicaNemesisRequest request = new GetListAfiliacionesByPersonaJuridicaNemesisRequest();
				request.iD_PERSONA = iD_PERSONA;
				request.fECHA_INICIO = fECHA_INICIO;
				request.fECHA_FIN = fECHA_FIN;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetListAfiliacionesByPersonaJuridicaNemesis(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetListAfiliacionesByPersonaJuridicaNemesisResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public SPWB_GET_DATOS_OPERACION_NEMESIS_Result GetDatosOperacionByIdClienteYIdAfiliacion(string iD_PERSONA, long IdAfiliacion)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetDatosOperacionByIdClienteYIdAfiliacionRequest request = new GetDatosOperacionByIdClienteYIdAfiliacionRequest();
				request.iD_PERSONA = iD_PERSONA;
				request.iD_Afiliacion = IdAfiliacion;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetDatosOperacionByIdClienteYIdAfiliacion(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetDatosOperacionByIdClienteYIdAfiliacionResult.FirstOrDefault();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}
		public SPWB_GET_DATOS_OPERACION_JURIDICA_NEMESIS_Result GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPöliza(string ID_TOMADOR, string ID_PRODUCTO, string ID_POLIZA, int VERSION_POLIZA, DateTime FECHA_INI, DateTime FECHA_FIN, string MONEDA)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaRequest request = new GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaRequest();
				request.ID_TOMADOR = ID_TOMADOR;
				request.ID_PRODUCTO = ID_PRODUCTO;
				request.ID_POLIZA = ID_POLIZA;
				request.VERSION_POLIZA = VERSION_POLIZA;
				request.MONEDA = MONEDA;
				request.FECHA_INI = FECHA_INI;
				request.FECHA_FIN = FECHA_FIN;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPöliza(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaResult.FirstOrDefault();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public async Task<SPWB_GET_DATOS_OPERACION_JURIDICA_NEMESIS_Result> GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaAsync(string ID_TOMADOR, string ID_PRODUCTO, string ID_POLIZA, int VERSION_POLIZA)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaRequest request = new GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaRequest();
				request.ID_TOMADOR = ID_TOMADOR;
				request.ID_PRODUCTO = ID_PRODUCTO;
				request.ID_POLIZA = ID_POLIZA;
				request.VERSION_POLIZA = VERSION_POLIZA;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPöliza(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetDatosOperacionByIdTomadorIdProductoIdPolizaVersionPölizaResult.FirstOrDefault();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public List<SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result> GetTomadorAseguradoByIdClienteYIdAfiliacion(string iD_PERSONA, long IdAfiliacion)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetTomadorAseguradoByIdClienteYIdAfiliacionRequest request = new GetTomadorAseguradoByIdClienteYIdAfiliacionRequest();
				request.iD_PERSONA = iD_PERSONA;
				request.iD_Afiliacion = IdAfiliacion;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetTomadorAseguradoByIdClienteYIdAfiliacion(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetTomadorAseguradoByIdClienteYIdAfiliacionResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public async Task<List<SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result>> GetTomadorAseguradoByIdClienteYIdAfiliacionAsync(string iD_PERSONA, long IdAfiliacion)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetTomadorAseguradoByIdClienteYIdAfiliacionRequest request = new GetTomadorAseguradoByIdClienteYIdAfiliacionRequest();
				request.iD_PERSONA = iD_PERSONA;
				request.iD_Afiliacion = IdAfiliacion;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetTomadorAseguradoByIdClienteYIdAfiliacion(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetTomadorAseguradoByIdClienteYIdAfiliacionResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		public List<SPWB_GET_TOMADOR_ASEGURADO_JURIDICA_NEMESIS_Result> GetTomadorDatabyIdTomador(string ID_TOMADOR, string ID_PRODUCTO)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetTomadorDatabyIdTomadorRequest request = new GetTomadorDatabyIdTomadorRequest();
				request.ID_TOMADOR = ID_TOMADOR;
				request.ID_PRODUCTO = ID_PRODUCTO;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetTomadorDatabyIdTomador(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetTomadorDatabyIdTomadorResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}
		public async Task<List<SPWB_GET_TOMADOR_ASEGURADO_JURIDICA_NEMESIS_Result>> GetTomadorDatabyIdTomadorAsync(string ID_TOMADOR, string ID_PRODUCTO)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetTomadorDatabyIdTomadorRequest request = new GetTomadorDatabyIdTomadorRequest();
				request.ID_TOMADOR = ID_TOMADOR;
				request.ID_PRODUCTO = ID_PRODUCTO;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetTomadorDatabyIdTomador(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetTomadorDatabyIdTomadorResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}


		public List<SPWB_MATRIZ_RIESGO_EJECUCION_Result> GetListMatrizDeRiesgo(string anio, string trimestre)
		{
			IServicioCierre _servicioCierre = Proxy.ServicioCierre();
			try
			{
				GetListMatrizDeRiesgoRequest request = new GetListMatrizDeRiesgoRequest();
				request.anio = anio;
				request.trimestre = trimestre;
				//CParametros parametros = new CParametros();
				request.objCredenciales = CredencialActual();//parametros.GetCredencialesCierre();
				var response = _servicioCierre.GetListMatrizDeRiesgo(request);

				if (response.ValidationResult.Error == true)
				{
					throw new Exception(response.ValidationResult.ValidationErrors[0].ErrorMessage);
				}
				else
				{
					return response.GetListMatrizDeRiesgoResult;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				Proxy.Close(_servicioCierre);
			}
		}

		
	}
}