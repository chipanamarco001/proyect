﻿using Agente;
using Agente.ServicioARegulatorios;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace Presentacion.controllers
{
    public class CArchivosRegulatorios
    {
        private readonly IServicioARegulatorios _servicioArchivoContabilidad = Proxy.ServicioARegulatorios();

        public CREDENCIALES CredencialActual()
        {
            try
            {
                var objCredencial = new CREDENCIALES()
                {
                    USUARIO = new Parametros().ObtenerIdUsuario(),
                    IP = new Parametros().ObtenerIPv4()
                };
                return objCredencial;
            }
            catch
            {
                throw;
            }
        }

        public List<COLUMNAS_ARCHIVOS> GetListColumnasByArchivo(string strIdArchivoContabilidad)
        {
            try
            {
                var response = _servicioArchivoContabilidad.GetListColumnasByArchivo(strIdArchivoContabilidad, true, CredencialActual());

                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public bool SaveArchivoRecibido(string strDestinationTableName, DataTable dtDataTable)
        {
            try
            {
                dtDataTable.TableName = strDestinationTableName;
                //Log.Debug("Accion: Realiza el vaciado a la tablas temporales; Recurso: servicio captado en Presentacion");
                var response = _servicioArchivoContabilidad.SaveArchivoRecibido(strDestinationTableName, dtDataTable, CredencialActual());
                //Log.Fin();
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public string GetDatatableFileTxtFile(ocp_archivo file, List<COLUMNAS_ARCHIVOS> lstColumnas, ref DataTable dtblArchivoDetalle, ref List<string> lstErroresArchivo, char chrSeparador)
        {

            dtblArchivoDetalle.Clear();
            dtblArchivoDetalle.Dispose();

            foreach (COLUMNAS_ARCHIVOS oColumnas in lstColumnas)
            {
                if (oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_ID_USER_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APDT_FECHA_INSERT" && oColumnas.CAVC_NOMBRE_COLUMNA != "APVC_PERIODO")
                {
                    dtblArchivoDetalle.Columns.Add(new DataColumn(oColumnas.CAVC_NOMBRE_COLUMNA));
                }

            }
            //string[] registros = File.ReadAllLines(strRutaArchivo + strNombreArchivo, Encoding.UTF8);
            //var countColumn = registros[0].Split(chrSeparador);

            //for (int fila = 0; fila < registros.Count(); fila++)
            //{

            //	string[] datos = registros[fila].Split(chrSeparador);
            //	DataRow dr = dtblArchivoDetalle.NewRow();
            //	for (int index = 0; index < dtblArchivoDetalle.Columns.Count; index++)
            //	{
            //		dr[index] = HttpUtility.HtmlDecode(datos[index]);


            //	}
            //	dtblArchivoDetalle.Rows.Add(dr);
            //}

            using (StreamReader sr = new StreamReader(new MemoryStream(file.ByteArray)))
            {
                while (sr.Peek() > -1)
                {
                    var readLine = sr.ReadLine();
                    if (readLine != null)
                    {
                        object[] currentLine = readLine.Split(chrSeparador);
                        dtblArchivoDetalle.Rows.Add(currentLine);
                        //object[] currentLine = sr.ReadLine().Split(new char[] { '|' });
                        //dt.Rows.Add(currentLine);
                    }
                }
            }
            return null;
        }
    }
}