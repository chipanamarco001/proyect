﻿using Agente;
using Agente.ServicioArchivoProducto;
using Agente.ServicioGenerales;
using DevExpress.Web;
using DevExpress.XtraPrinting;
using DynamicExpresso;
using Newtonsoft.Json;
using Presentacion.entities;
using Presentacion.libs;
using Presentacion.site.auth;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI.WebControls;


namespace Presentacion.controllers
{
	public class CArchivoProducto
	{
		#region Configuracion Inicial
		private readonly IServicioArchivoProducto _servicioArchivoProducto = Proxy.ServicioArchivoProducto();
		private readonly CGenerales _cGenerales = new CGenerales();
		public CREDENCIALES CredencialActual()
		{
			try
			{
				var objCredencial = new CREDENCIALES()
				{
					USUARIO = new Parametros().ObtenerIdUsuario(),
					IP = new Parametros().ObtenerIPv4()					
				};
				return objCredencial;
			}
			catch
			{
				throw;
			}
		}
		#endregion

		public RELACION_PRODUCTO_TABLA GetObjRelProductoTablaByIdTipoProducto(string strIdProducto)
		{
			try
			{
				var response = _servicioArchivoProducto.GetObjRelProductoTablaByIdTipoProducto(strIdProducto, CredencialActual());				
				return response;

			}
			catch (Exception)
			{

				throw;
			}
		}

		public void CrearControlesTablaTemporal(string strIdProducto)
		{
			try
			{
				_servicioArchivoProducto.CrearControlesTablaTemporal(strIdProducto, CredencialActual());

			}
			catch (Exception)
			{

				throw;
			}			
		}

		public HISTORIAL_CARGA GetObjHistorialCargaByTablaPeriodoIdProducto(string strTableName, string strPeriodo, string strIdProducto)
		{
			try
			{
				DateTime dtPeriodo = DateTime.ParseExact(strPeriodo, "yyyyMM", null);
				var response = _servicioArchivoProducto.GetObjHistorialCargaByTablaPeriodoIdProducto(strTableName, dtPeriodo, strIdProducto, CredencialActual());				
				return response;
			}
			catch (Exception)
			{
				throw;
			}
		}

		public TIPO_PRODUCTO GetObjTipoProductoById(string strIdProducto)
		{
			try
			{				
				var response = _servicioArchivoProducto.GetObjTipoProductoById(strIdProducto, CredencialActual());
				return response;
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetValidFile(ocp_archivo fileupload, string strExtension, ref string strFileExtension)
		{
			try
			{
				if (fileupload.ByteArray.Length > 0)
				{
					var extension = Path.GetExtension(fileupload.Extension);
					if (extension != null)
					{
						String fileExtension = extension.ToLower();

						string[] allowedExtensions = strExtension.Split(',');
						foreach (string extensionSelected in allowedExtensions)
						{
							if (fileExtension == "." + extensionSelected.ToLower())
							{
								strFileExtension = fileExtension;
								return true;
							}
						}
					}
				}
				return false;
			}
			catch
			{
				throw;
			}

		}

		public string GuardarFileTemporal(string idProducto,string strMesProduccion, ocp_archivo file, string rutaArchivo, string strFileExtension)
		{
			try
			{
				var strNombreArchivo = idProducto + "_Afiliaciones_" + strMesProduccion + strFileExtension;
				if (File.Exists(rutaArchivo + strNombreArchivo)) { File.Delete(rutaArchivo + strNombreArchivo); }
				File.WriteAllBytes(rutaArchivo + strNombreArchivo, file.ByteArray);
				return strNombreArchivo;
			}
			catch
			{
				throw;
			}
		}

		public string GetExcelColumnName(int columnNumber)
		{
			int dividend = columnNumber;
			string columnName = String.Empty;
			int intModulo;

			while (dividend > 0)
			{
				intModulo = (dividend - 1) % 26;
				columnName = Convert.ToChar(65 + intModulo) + columnName;
				dividend = (dividend - intModulo) / 26;
			}

			return columnName;
		}

		public List<COLUMNAS> GetListColumnasByIdProducto(string strProductoId)
		{
			try
			{
				var response = _servicioArchivoProducto.GetListColumnasByIdProducto(strProductoId, true, CredencialActual());				
				return response;
			}
			catch
			{
				throw;
			}

		}

		public int SaveObjHistorialCarga(HISTORIAL_CARGA objHistorialCarga)
		{
			try
			{
				var response = _servicioArchivoProducto.SaveObjHistorialCarga(objHistorialCarga, CredencialActual());				
				return response;
			}
			catch (Exception ex)
			{				
				throw;
			}
		}

		public int ReprocesoHistorialRetornaIdHistorial(HISTORIAL_CARGA objNuevoHistorialCarga, int intIdHistoriaEliminar, string strMotivo)
		{			
			try
			{
				var response = _servicioArchivoProducto.ReprocesoHistorialRetornaIdHistorial(objNuevoHistorialCarga, intIdHistoriaEliminar, strMotivo, CredencialActual());				
				return response;
			}
			catch
			{				
				throw;
			}
		}

		public bool SaveArchivoRecibido(string strDestinationTableName, DataTable dtDataTable)
		{
			try
			{
				dtDataTable.TableName = strDestinationTableName;
				var response = _servicioArchivoProducto.SaveArchivoRecibido(strDestinationTableName, dtDataTable, CredencialActual());				
				return response;
			}
			catch
			{
				throw;
			}
		}

		public bool UpdateEstadoHistorialCarga(int intIdHistorialCarga, string strMotivo, bool bolActivo)
		{
			try
			{
				var response = _servicioArchivoProducto.UpdateEstadoHistorialCarga(intIdHistorialCarga, strMotivo, bolActivo, CredencialActual());
				return response;
			}
			catch
			{
				throw;
			}
		}

		public bool ReprocesoArchivoFisico(string strDestinationTableName, DataTable dtDataTable)
		{
			try
			{
				dtDataTable.TableName = strDestinationTableName;
				var response = _servicioArchivoProducto.ReprocesoArchivoFisico(strDestinationTableName, dtDataTable, CredencialActual());				
				return response;
			}
			catch
			{
				throw;
			}
		}

		public bool DeleteFilasArchivoTemporal(string strTablaTemporal, int intIdHistorial)
		{
			try
			{
				var response = _servicioArchivoProducto.DeleteFilasArchivoTemporal(strTablaTemporal, intIdHistorial, CredencialActual());
				return response;
			}
			catch
			{
				throw;
			}
		}

		public Task<bool> DeleteFilasArchivoTemporalAsync(string strTablaTemporal, int intIdHistorial)
		{
			try
			{
				var response = _servicioArchivoProducto.DeleteFilasArchivoTemporalAsync(strTablaTemporal, intIdHistorial, CredencialActual());
				return response;
			}
			catch
			{
				throw;
			}
		}

		public async Task ValidaData(DataTable dtblExcelData, List<COLUMNAS> lstColumnas, TIPO_PRODUCTO objTipoProducto, string _strNameTableTemporal, int intIdHistorialCarga, occ_usuario usuarioLogueado, List<LEXICO> listaLexico, string strHtml, string strLogo)
		{
			var lstErroresArchivo = new List<string>();
			
			var context = new Interpreter();

			foreach (var itemColumna in lstColumnas)
			{
				foreach (DataRow row in dtblExcelData.Rows)
				{
					int indexRow = dtblExcelData.Rows.IndexOf(row);					
					int indexExcel = indexRow + 2 + (objTipoProducto.TPIN_NRO_FILA_CABECERA == null ? 0 : objTipoProducto.TPIN_NRO_FILA_CABECERA.Value);
					
					var formulaC = itemColumna.COVC_FORMULA;

					if (formulaC != null)
					{
						//Reemplazamos los valores en a formula
						foreach (var itemColumnaRef in lstColumnas)
						{
							formulaC = formulaC.Replace("\\", "");
							formulaC = formulaC.Replace("{" + itemColumnaRef.COVC_NOMBRE_TABLA + "}", row[itemColumnaRef.COVC_NOMBRE_TABLA].ToString());
						}

						try
						{							
							var formulaEvaluadaCorrectamente = context.Eval<bool>(formulaC);														

							if (formulaEvaluadaCorrectamente)
							{
								//success
							}
							else
							{
								//error
								lstErroresArchivo.Add("Error: en la Columna " + itemColumna.COVC_NOMBRE_DOCUMENTO
									+ ", en la Fila " + indexExcel
									+ " Por favor Revisar el Valor '" + row[itemColumna.COVC_NOMBRE_TABLA].ToString() + "' ");
							}
						}
						catch (Exception ex)
						{
							lstErroresArchivo.Add("Error: en la Columna " + itemColumna.COVC_NOMBRE_DOCUMENTO
								+ ", en la Fila " + indexExcel
								+ " Por favor Revisar, el Valor no puede ser evaluado '" + row[itemColumna.COVC_NOMBRE_TABLA].ToString() + "' ");
							
						}
					}
				}
			}
			
			if (lstErroresArchivo.Count > 0)
			{
				using (var ms = new MemoryStream())
				{
					TextWriter tw = new StreamWriter(ms);

					foreach (var itemError in lstErroresArchivo)
					{
						tw.Write(itemError);
						tw.Write(Environment.NewLine);
					}

					tw.Flush();
					ms.Position = 0;

					var archivoRev = new ocp_correo_archivo_adjunto();
					archivoRev.Bytes = ms.ToArray();
					archivoRev.Nombre = "Archivo revision_" + objTipoProducto.TPVC_IDPRODUCTO + "_.txt";
					archivoRev.FlagBytes = true;

					
					List<string> listaMailTO = new List<string>();
					listaMailTO.Add(usuarioLogueado.Correo);

					var listaMailCC = listaLexico.Where(w => w.LEPVC_TABLA == "VALIDACION" && w.LEPVC_TEMA == "COPIA_CORREO").Select(s=>s.LESVC_DESCRIPCION_1).ToList();
										
					var lstAdjuntos = new List<ocp_correo_archivo_adjunto>();
					lstAdjuntos.Add(archivoRev);

					var objCorreo = new ocp_correo();
					objCorreo.ListaCorreoDestinatario = listaMailTO;
					objCorreo.ListaCorreoCopia = listaMailCC;
					objCorreo.Asunto = "ERROR EN ARCHIVO SELECCIONADO (" + objTipoProducto.TPVC_IDPRODUCTO + ") - SISTEMA DE PRODUCCIÓN";

					objCorreo.ListaArchivosAdjuntos = lstAdjuntos;

					objCorreo.Prioridad = System.Net.Mail.MailPriority.High;
					objCorreo.Contenido = strHtml;
					objCorreo.FlagHtml = true;
					objCorreo.ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(strLogo) } };

					var objEnvioCorreo = correo.Enviar(objCorreo);

					if (objEnvioCorreo)
					{
						//eliminar data temporal
						var bolDelete = await DeleteFilasArchivoTemporalAsync(_strNameTableTemporal, intIdHistorialCarga);
					}
				}
			}			
		}

		public List<LEXICO> ObtieneLexicos()
		{
			try
			{
				if (HttpContext.Current.Session["ListaLexico"] == null)
					HttpContext.Current.Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
				return (List<LEXICO>)HttpContext.Current.Session["ListaLexico"];
			}
			catch
			{
				throw;
			}
		}

		#region TR multianual

		public DataSet CargaTrMultianual(Dictionary<string, object> lstParameters, ref MensajesError objMensajeError)
		{
			try
			{
				var objCargaTrMultianual = new CargaTrMultianualRequest();
				objCargaTrMultianual.lstParameters = lstParameters;
				objCargaTrMultianual.objCredenciales = CredencialActual();
				objCargaTrMultianual.objMensajeError = objMensajeError;

				var response = _servicioArchivoProducto.CargaTrMultianual(objCargaTrMultianual);				
				return response.CargaTrMultianualResult;
			}
			catch
			{
				throw;
			}
		}


		#endregion
	}
}