﻿using Agente.ServicioGenerales;
using Presentacion.controllers;
using Presentacion.libs;
using System;
using System.Linq;
using System.Reflection;

namespace Presentacion.site.auth
{
    public partial class account : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private occ_usuario _objUsuario;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso())
                this.CierraSesion();
            if (!IsPostBack)
                CargarDatos();
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
        }
        protected void CargarDatos()
        {
            try
            {
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
                var listaLexico = _cGenerales.ListaLexicosPorTablaYTema("PARAMETRO", "DEPARTAMENTO");
                CmbDepartamento.DataSource = listaLexico;
                CmbDepartamento.TextField = "LEPVC_DESC_LARGA";
                CmbDepartamento.ValueField = "LEPVC_VALOR";
                CmbDepartamento.DataBind();
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                var objUsuario = listaUsuarios.Where(w => w.USPVC_ID_USUARIO == _objUsuario.Matricula).First();               
                TxtUsuarioDominio.Text = _objUsuario.Matricula;
                TxtApellidoPaterno.Text = objUsuario.USSVC_PATERNO;
                TxtApellidoMaterno.Text = objUsuario.USSVC_MATERNO;
                TxtNombres.Text = objUsuario.USPVC_NOMBRES;
                TxtCorreo.Text = objUsuario.USPVC_CORREO;
                CmbDepartamento.Text = objUsuario.USSVC_CIUDAD;
                TxtTipoUsuario.Text = _objUsuario.Area;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/site/misc/inicio.aspx", false);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}