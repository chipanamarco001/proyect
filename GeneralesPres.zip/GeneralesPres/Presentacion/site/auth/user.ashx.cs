﻿using System;
using System.Web;
using System.Web.SessionState;

namespace Presentacion.site.auth
{
    public class user : IHttpHandler, IRequiresSessionState
    {
        public void ProcessRequest(HttpContext context)
        {
            string strImgUsuario = (string)context.Session["ImgUsuario"];
            byte[] bytes = Convert.FromBase64String(strImgUsuario);
            if (bytes != null)
            {
                context.Response.Buffer = true;
                context.Response.Charset = string.Empty;
                context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                context.Response.BinaryWrite(bytes);
                context.Response.Flush();
                context.Response.End();
            }
        }
        public bool IsReusable
        {
            get
            {
                return true;
            }
        }
    }
}