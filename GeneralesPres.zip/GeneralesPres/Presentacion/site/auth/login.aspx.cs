﻿using Agente.ServicioGenerales;
using Presentacion.controllers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Web.UI;

namespace Presentacion.site.auth
{
    public partial class login : System.Web.UI.Page
    {
        private string _strIdUsuario = string.Empty;
        private readonly CGenerales _cGenerales = new CGenerales();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                    Session.Clear();
                var objCredencial = new CGenerales().CredencialActual();
                _strIdUsuario = objCredencial.IdUsuario;
                Session["IdUsuario"] = _strIdUsuario;
                DatosIniciales(_strIdUsuario);
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void DatosIniciales(string strIdUsuario)
        {
            try
            {
                Session.Clear();
                var objUsuarioAD = _cGenerales.DatosDirectorioActivo(strIdUsuario);
                if (objUsuarioAD != null)
                {
                    LblNombreUsuario.Text = objUsuarioAD.NombreCompleto;
                    LblIdUsuario.Text = "(" + objUsuarioAD.Dominio + "\\" + objUsuarioAD.Matricula + ")";
                    byte[] bytes;
                    if (objUsuarioAD.Foto != null)
                        bytes = objUsuarioAD.Foto;
                    else
                    {
                        string strRutaImgUsuario = Server.MapPath("~/assets/img/user.jpg");
                        var objFileInfo = new FileInfo(strRutaImgUsuario);
                        bytes = File.ReadAllBytes(strRutaImgUsuario);
                    }
                    string strBytesImg = Convert.ToBase64String(bytes);
                    Session["ImgUsuario"] = strBytesImg;
                    ImgUsuarioDominio.ImageUrl = "user.ashx";
                }
                else
                    throw new Exception("Usuario no encontrado en AD.");
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnIniciarSesion_Click(object sender, EventArgs e)
        {
            try
            {
                var objUsuarioLogin = _cGenerales.ValidaAccesoUsuario();
                if (objUsuarioLogin != null && objUsuarioLogin.Menu.Count > 0)
                {
                    Session["SessionUsuario"] = objUsuarioLogin;
                    Response.Redirect("~/site/misc/inicio.aspx", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 2000, 'Validación', 'El usuario no cuenta con acceso al sistema.');", true);
                }
            }
            catch (Exception ex)
            {
                Session.Clear();
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void RegistrarExcepcion(Exception objExcepcion, string strPagina, string strMetodo)
        {
            try
            {
                if (Session["LISTA_EXCEPCIONES"] != null)
                {
                    var listaErrores = (List<Excepcion>)Session["LISTA_EXCEPCIONES"];
                    foreach (var objError in listaErrores)
                    {
                        var objResponseError = _cGenerales.Error_Registrar(new ERROR()
                        {
                            ERPVC_PAGINA = (string.IsNullOrEmpty(objError.Pagina) ? string.Empty : objError.Pagina),
                            ERPVC_METODO = (string.IsNullOrEmpty(objError.Metodo) ? string.Empty : objError.Metodo),
                            ERPVC_MENSAJE = (string.IsNullOrEmpty(objError.Mensaje) ? string.Empty : objError.Mensaje),
                            ERPVC_STACK_TRACE = (string.IsNullOrEmpty(objError.StackTrace) ? string.Empty : objError.StackTrace),
                            ERPVC_INNER_EXCEPTION = (string.IsNullOrEmpty(objError.InnerException) ? string.Empty : objError.InnerException)
                        });
                    }
                }
                var objResponse = _cGenerales.Error_Registrar(new ERROR()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objExcepcion.Message == null) ? string.Empty : objExcepcion.Message,
                    ERPVC_STACK_TRACE = (objExcepcion.StackTrace == null) ? string.Empty : objExcepcion.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objExcepcion.InnerException == null) ? string.Empty : "Message: " + objExcepcion.InnerException.Message,
                        (objExcepcion.InnerException == null) ? string.Empty : "StackTrace: " + objExcepcion.InnerException.StackTrace)
                });
                Session.Clear();
                Session["ErrorMensaje"] = "Se ha producido un error en el proceso.";
                Response.Redirect("~/site/misc/error.aspx", false);
            }
            catch (Exception ex)
            {
                Session.Clear();
                Session["ErrorMensaje"] = ex.Message;
                Response.Redirect("~/site/misc/error.aspx", false);
            }
        }
    }
}