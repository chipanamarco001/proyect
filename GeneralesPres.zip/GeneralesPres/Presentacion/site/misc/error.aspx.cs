﻿using Agente.ServicioGenerales;
using Presentacion.controllers;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Presentacion.site.misc
{
    public partial class error : System.Web.UI.Page
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
                return;
            if (Session["ErrorMensaje"] != null)
            {
                LblMensaje.Text = Session["ErrorMensaje"].ToString();
                Session.Remove("ErrorMensaje");
            }
        }
        protected void BtnVolverInicio_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/site/misc/inicio.aspx", false);
            }
            catch (Exception ex)
            {
                RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        public void RegistrarExcepcion(Exception objExcepcion, string strPagina, string strMetodo)
        {
            try
            {
                if (Session["LISTA_EXCEPCIONES"] != null)
                {
                    var listaErrores = (List<Excepcion>)Session["LISTA_EXCEPCIONES"];
                    foreach (var objError in listaErrores)
                    {
                        var objResponseError = _cGenerales.Error_Registrar(new ERROR()
                        {
                            ERPVC_PAGINA = (string.IsNullOrEmpty(objError.Pagina) ? string.Empty : objError.Pagina),
                            ERPVC_METODO = (string.IsNullOrEmpty(objError.Metodo) ? string.Empty : objError.Metodo),
                            ERPVC_MENSAJE = (string.IsNullOrEmpty(objError.Mensaje) ? string.Empty : objError.Mensaje),
                            ERPVC_STACK_TRACE = (string.IsNullOrEmpty(objError.StackTrace) ? string.Empty : objError.StackTrace),
                            ERPVC_INNER_EXCEPTION = (string.IsNullOrEmpty(objError.InnerException) ? string.Empty : objError.InnerException)
                        });
                    }
                    Session.Remove("LISTA_EXCEPCIONES");
                }
                var objResponse = _cGenerales.Error_Registrar(new ERROR()
                {
                    ERPVC_PAGINA = strPagina,
                    ERPVC_METODO = strMetodo,
                    ERPVC_MENSAJE = (objExcepcion.Message == null) ? string.Empty : objExcepcion.Message,
                    ERPVC_STACK_TRACE = (objExcepcion.StackTrace == null) ? string.Empty : objExcepcion.StackTrace,
                    ERPVC_INNER_EXCEPTION = string.Concat(
                        (objExcepcion.InnerException == null) ? string.Empty : "Message: " + objExcepcion.InnerException.Message,
                        (objExcepcion.InnerException == null) ? string.Empty : "StackTrace: " + objExcepcion.InnerException.StackTrace)
                });
                Session.Clear();
                Session["ErrorMensaje"] = "Se ha producido un error en el proceso.";
                Response.Redirect("~/site/misc/error.aspx", false);
            }
            catch (Exception ex)
            {
                Session.Clear();
                Session["ErrorMensaje"] = ex.Message;
                Response.Redirect("~/site/misc/error.aspx", false);
            }
        }
    }
}