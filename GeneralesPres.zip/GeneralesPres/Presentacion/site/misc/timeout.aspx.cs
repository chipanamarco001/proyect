﻿using System;
using System.Web;
using System.Configuration;
using System.Web.Configuration;
using System.Web.UI;

namespace Presentacion.site.misc
{
    public partial class timeout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            ClientScriptManager cs = Page.ClientScript;
            Session.Clear();
            Configuration config = WebConfigurationManager.OpenWebConfiguration("~/Web.Config");
            SessionStateSection section = (SessionStateSection)config.GetSection("system.web/sessionState");
            LblTiemporSesion.Text = ((int)section.Timeout.TotalMinutes).ToString();
        }
        protected void BtnVolverInicio_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("~/site/auth/login.aspx", false);
        }
    }
}