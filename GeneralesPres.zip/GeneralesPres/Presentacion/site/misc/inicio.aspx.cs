﻿using Agente.ServicioGenerales;
using Presentacion.controllers;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.UI;

namespace Presentacion.site.misc
{
    public partial class inicio : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso())
                this.CierraSesion();
            if (!IsPostBack)
            {
                Master.CargarMesProduccion();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"]; 
            
        }
        
        
    }
}