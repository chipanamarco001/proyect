﻿using Agente.ServicioArchivoProducto;
using Agente.ServicioGenerales;
using DevExpress.ClipboardSource.SpreadsheetML;
using DevExpress.Office.Utils;
using DevExpress.Spreadsheet;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using DevExpress.XtraSpreadsheet;
using DocumentFormat.OpenXml.Spreadsheet;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using Presentacion.site.auth;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
	public partial class bandeja_operaciones : SesionUsuario
	{
		private readonly CGenerales _cGenerales = new CGenerales();
		private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
		//private readonly CDocumentos _cDocumentos = new CDocumentos();
		//private readonly CCrediseguro _cCrediseguro = new CCrediseguro();
		private string _strMesProduccion;
		private string _strIdTipoProducto = "";

		private occ_usuario _user = new occ_usuario();
		private string _strRutaArchivo = "";
		private string _strNombreArchivo = "";
		private string _strArchivoExtension = "";
		private string _strNameTableTemporal = "";
		//private UploadedFile _fileUpload;
		private string _strQueryExcel = "";
		private int _intIdHistorialCarga = 0;
		private int _intIdHistorialCargaEliminado = 0;
		private string _strMotivo = "";
		private bool _bolReproceso;

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
				this.CierraSesion();
			if (!IsPostBack)
			{
				Session.Remove("DOWNLOAD");
				//UsrcCabecera.CargarDatos();
				CargaInicial();
				//Session.Remove("ARCHIVOS_BDP");
			}
			_user = (occ_usuario)Session["SessionUsuario"];
			_strMesProduccion = (string)Session["MES_PRODUCCION"];
		}

		protected void UsrcCabecera_DataBinding(object sender, EventArgs e)
		{
			try
			{
				if (Session["CAMBIO_MES_PRODUCCION"] != null)
				{
					CargaInicial();
					Session.Remove("CAMBIO_MES_PRODUCCION");
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void GrvBandeja_DataBinding(object sender, EventArgs e)
		{
			try
			{
				var listaBandeja = (List<SPR_GET_BANDEJA_PRODUCCION_Result>)Session["LISTA_BANDEJA"];
				if (listaBandeja != null)
				{
					GrvBandeja.DataSource = listaBandeja;
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void CargaInicial()
		{
			try
			{
				////polizas vencidas
				//Session.Remove("BandejaGestionarPoliza");
				//var listaPolizasVencidas = _cPersonales.ListaPolizasRenovacionAmpliacion();
				//PnlPolizasVencidas.Visible = false;
				//if (listaPolizasVencidas.Count > 0)
				//{
				//	PnlPolizasVencidas.Visible = true;
				//	Session["BandejaGestionarPoliza"] = listaPolizasVencidas;
				//	GrvPolizas.DataBind();
				//}
				////fin - polizas vencidas
				_strMesProduccion = (string)Session["MES_PRODUCCION"];
				var listaBandeja = _cGenerales.GetListaBandejaProduccion(_strMesProduccion);
				//foreach (var objPolizaVencida in listaPolizasVencidas)
				//{
				//	var objBandeja = listaBandeja.Find(e => e.ID_PRODUCTO == objPolizaVencida.IdProducto && e.FLAG_PRODUCCION == true);
				//	if (objBandeja != null)
				//		objBandeja.FLAG_PRODUCCION = false;
				//}
				Session["LISTA_BANDEJA"] = listaBandeja;
				GrvBandeja.DataBind();
				//var objUsuario = (occ_usuario)Session["SessionUsuario"];
				//GrvBandeja.Columns[12].Visible = true;
				//GrvBandeja.Columns[13].Visible = true;
				//if (objUsuario.Area != "OPERACIONES")
				//{
				//	GrvBandeja.Columns[12].Visible = false;
				//	GrvBandeja.Columns[13].Visible = false;
				//}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void GrvBandeja_PreRender(object sender, EventArgs e)
		{
			try
			{
				for (int i = 0; i < GrvBandeja.VisibleRowCount; i++)
				{
					var ImgCargaCompleta = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgCargaCompleta") as ImageButton;
					var ImgCargaIncompleta = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgCargaIncompleta") as ImageButton;
					var ImgArchivo = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgArchivo") as ImageButton;
					var ImgServicio = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgServicio") as ImageButton;
					var ImgProduccion = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgProduccion") as ImageButton;
					var LblIdProducto = GrvBandeja.FindRowCellTemplateControl(i, null, "LblIdProducto") as ImageButton;

					var LblCarga = GrvBandeja.FindRowCellTemplateControl(i, null, "LblCarga") as ImageButton;
					var LblProduccion = GrvBandeja.FindRowCellTemplateControl(i, null, "LblProduccion") as ImageButton;
					var LblFlagProducido = GrvBandeja.FindRowCellTemplateControl(i, null, "LblFlagProducido") as ImageButton;
					var LblDocumentos = GrvBandeja.FindRowCellTemplateControl(i, null, "LblDocumentos") as ImageButton;
					//var ImgDocumentos = GrvBandeja.FindRowCellTemplateControl(i, null, "ImgDocumentos") as ImageButton;

					//ImgDocumentos.Visible = false;
					//ImgCargaCompleta.Visible = false;
					//ImgCargaIncompleta.Visible = true;
					//ImgArchivo.Visible = true;
					//ImgServicio.Visible = false;

					var flagProduccion = Convert.ToBoolean(GrvBandeja.GetRowValues(i, "FLAG_PRODUCCION"));

					if (flagProduccion)
					{
						ImgProduccion.Visible = true;
					}
					else
					{
						//ImgProduccion.Visible = false;
					}




					//if (LblFlagProducido.Text == "1")
					//{
					//	ImgCargaCompleta.Visible = true;
					//	ImgCargaIncompleta.Visible = false;
					//	ImgDocumentos.Visible = (LblDocumentos.Text != string.Empty) ? true : false;
					//}
					//else if (LblIdProducto.Text == "ECOAMP") { ImgDocumentos.Visible = true; }
					//ImgArchivo.Visible = false;
					//ImgServicio.Visible = false;
					//switch (LblIdProducto.Text)
					//{
					//	case "MULBCP":
					//	case "SEGRPT":
					//	case "MSVBCP":
					//	case "DERBCP":
					//	case "SEGDES":
					//		if (LblCarga.Text.ToUpper() == "TRUE")
					//			ImgServicio.Visible = true;
					//		break;
					//	default:
					//		if (LblCarga.Text.ToUpper() == "TRUE")
					//			ImgArchivo.Visible = true;
					//		break;
					//}
					//ImgProduccion.Visible = false;

					//if (LblProduccion.Text.ToUpper() == "TRUE") { ImgProduccion.Visible = true; }

				}
				//foreach (GridViewRow row in GrvBandeja.visi)
				//{
				//	Image ImgCargaCompleta = (Image)row.FindControl("ImgCargaCompleta");
				//	Image ImgCargaIncompleta = (Image)row.FindControl("ImgCargaIncompleta");
				//	Image ImgArchivo = (Image)row.FindControl("ImgArchivo");
				//	Image ImgServicio = (Image)row.FindControl("ImgServicio");
				//	Image ImgProduccion = (Image)row.FindControl("ImgProduccion");
				//	Label LblIdProducto = (Label)row.FindControl("LblIdProducto");
				//	Label LblCarga = (Label)row.FindControl("LblCarga");
				//	Label LblProduccion = (Label)row.FindControl("LblProduccion");
				//	Label LblFlagProducido = (Label)row.FindControl("LblFlagProducido");
				//	Label LblDocumentos = (Label)row.FindControl("LblDocumentos");
				//	Image ImgDocumentos = (Image)row.FindControl("ImgDocumentos");

				//	ImgDocumentos.Visible = false;
				//	ImgCargaCompleta.Visible = false;
				//	ImgCargaIncompleta.Visible = true;
				//	if (LblFlagProducido.Text == "1")
				//	{
				//		ImgCargaCompleta.Visible = true;
				//		ImgCargaIncompleta.Visible = false;
				//		ImgDocumentos.Visible = (LblDocumentos.Text != string.Empty) ? true : false;
				//	}
				//	else if (LblIdProducto.Text == "ECOAMP") { ImgDocumentos.Visible = true; }
				//	ImgArchivo.Visible = false;
				//	ImgServicio.Visible = false;
				//	switch (LblIdProducto.Text)
				//	{
				//		case "MULBCP":
				//		case "SEGRPT":
				//		case "MSVBCP":
				//		case "DERBCP":
				//		case "SEGDES":
				//			if (LblCarga.Text.ToUpper() == "TRUE")
				//				ImgServicio.Visible = true;
				//			break;
				//		default:
				//			if (LblCarga.Text.ToUpper() == "TRUE")
				//				ImgArchivo.Visible = true;
				//			break;
				//	}
				//	ImgProduccion.Visible = false;

				//	if (LblProduccion.Text.ToUpper() == "TRUE") { ImgProduccion.Visible = true; }

				//}


				//var listaBandeja = (List<SPR_GET_BANDEJA_PRODUCCION_Result>)Session["LISTA_BANDEJA"];
				//if (listaBandeja != null)
				//{
				//	GrvBandeja.DataSource = listaBandeja;
				//}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void GrvBandeja_RowCommand(object sender, DevExpress.Web.ASPxGridViewRowCommandEventArgs e)
		{
			try
			{
				//PnlMessageSuccess.Visible = false;
				//GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
				GridViewDataItemTemplateContainer containerEdit = (GridViewDataItemTemplateContainer)(((ImageButton)e.CommandSource).NamingContainer);
				int RowIndex = containerEdit.VisibleIndex;
				var strIdProducto = Convert.ToString(GrvBandeja.GetRowValues(RowIndex, "ID_PRODUCTO"));
				//string strIdProducto = ((Label)gvr.FindControl("LblIdProducto")).Text.Trim();
				var strNombreProducto = Convert.ToString(GrvBandeja.GetRowValues(RowIndex, "NOMBRE_PRODUCTO"));
				//string strNombreProducto = ((Label)gvr.FindControl("LblNombreProducto")).Text.Trim();

				//Label LblFlagProducido = (Label)gvr.FindControl("LblFlagProducido");
				//Session["PRODUCTO_PRODUCIDO"] = LblFlagProducido.Text == "1" ? "TRUE" : "FALSE";
				//HidTipoArchivo.Value = strIdProducto;
				Session["strIdTipoProducto"] = strIdProducto;
				//HidNombreArchivo.Value = strNombreProducto;
				Session["strNombreProducto"] = strNombreProducto;

				//Session["strNameTableTemporal"] = strNombreProducto;
				//string script = string.Empty;
				switch (e.CommandArgs.CommandName)
				{
					case "CARGA":
						switch (strIdProducto)
						{
							//	case "DESBDP":
							//		PopCargaBDP.HeaderText = "CARGA DE ARCHIVOS - " + strNombreProducto;
							//		PopCargaBDP.ShowOnPageLoad = true;
							//		break;
							//	case "MSVBCP":
							//	case "MULBCP":
							//	case "SEGRPT":
							//	case "SEGRDI":
							//	case "SEGDES":
							//	case "DERBCP":
							//		PopEjecutarServicio.HeaderText = strNombreProducto;
							//		PopEjecutarServicio.ShowOnPageLoad = true;
							//		break;
							//	case "SEGECP":
							//	case "SEGECV":
							//		UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt" };
							//		PopCargarArchivo.HeaderText = strNombreProducto;
							//		PopCargarArchivo.ShowOnPageLoad = true;
							//		break;
							default:
								RELACION_PRODUCTO_TABLA objRelProductoTabla = _cArchivoProducto.GetObjRelProductoTablaByIdTipoProducto(strIdProducto);

								if (objRelProductoTabla != null)
								{
									_cArchivoProducto.CrearControlesTablaTemporal(objRelProductoTabla.RPVC_NAME_TABLA);
									_strNameTableTemporal = objRelProductoTabla.RPVC_NAME_TABLA;
									Session["strNameTableTemporal"] = _strNameTableTemporal;
								}

								UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
								PopCargarArchivo.HeaderText = strNombreProducto;
								PopCargarArchivo.ShowOnPageLoad = true;
								break;
						}
						//Session["DatosProducto"] = strIdProducto + "|" + strNombreProducto;

						break;
					case "PRODUCCION":
						string strProcedimiento = Convert.ToString(GrvBandeja.GetRowValues(RowIndex, "PROCEDIMIENTO"));
						PopProduccion.ShowOnPageLoad = true;
						//Session["DatosProducto"] = strIdProducto + "|" + strProcedimiento;
						PopProduccion.HeaderText = strNombreProducto;
						break;
					case "DOCUMENTOS":
						//string strDocumentos = ((Label)gvr.FindControl("LblDocumentos")).Text.Trim();
						//if (strDocumentos != string.Empty)
						//{
						//	string[] strItems = strDocumentos.Split(',');
						//	var DtblDocumentos = new DataTable();
						//	DtblDocumentos.Columns.Clear();
						//	DtblDocumentos.Columns.Add("ID_PRODUCTO", typeof(string));
						//	DtblDocumentos.Columns.Add("ID_DOCUMENTO", typeof(string));
						//	DtblDocumentos.Columns.Add("NOMBRE", typeof(string));
						//	DtblDocumentos.Columns.Add("FORMATO", typeof(string));
						//	for (int index = 0; index < strItems.Count(); index++)
						//	{
						//		DataRow dr = DtblDocumentos.NewRow();
						//		dr["ID_PRODUCTO"] = strIdProducto;
						//		dr["ID_DOCUMENTO"] = strItems[index].Split('|')[0];
						//		dr["NOMBRE"] = strItems[index].Split('|')[1];
						//		dr["FORMATO"] = strItems[index].Split('|')[2];
						//		DtblDocumentos.Rows.Add(dr);
						//	}
						//	GrvDocumentos.DataSource = DtblDocumentos;
						//	GrvDocumentos.DataBind();
						//	PopDocumentos.HeaderText = strNombreProducto;
						//	PopDocumentos.ShowOnPageLoad = true;
						//}
						break;

				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		#region PopCargarArchivo

		protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
		{
			try
			{
				////ValidacionCarga _validacionCarga = new ValidacionCarga();
				//string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
				//string strIdProducto = strDatosProducto[0];



				UploadedFile uploadedFile = e.UploadedFile;
				FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
				//_fileUpload = uploadedFile;
				//DataTable DtblDatos = new DataTable();
				//switch (strIdProducto)
				//{
				//	case "SEGECP":
				//	case "SEGECV":
				//		DtblDatos.Columns.Add(new DataColumn("Column1"));
				//		using (StreamReader reader = new StreamReader(uploadedFile.FileContent))
				//		{
				//			do
				//			{
				//				string strTextLine = reader.ReadLine();
				//				DataRow dr = DtblDatos.NewRow();
				//				dr[0] = strTextLine;
				//				DtblDatos.Rows.Add(dr);
				//			} while (reader.Peek() != -1);
				//		}
				//		break;
				//}
				//Session["DATOS_ARCHIVO_CARGADO"] = DtblDatos;
				Session["ARCHIVO_CARGADO"] = new ocp_archivo()
				{
					ContentType = uploadedFile.ContentType,
					Extension = fileInfo.Extension,
					Nombre = uploadedFile.FileName,
					FileStream = uploadedFile.FileContent,
					ByteArray = uploadedFile.FileBytes
				};
				e.IsValid = true;
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
		{
			try
			{
				ValidacionCarga _validacionCarga = new ValidacionCarga();

				////var valida = _validacionCarga.ValidacionByProduct("", new DataTable());

				//string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
				//string strIdProducto = strDatosProducto[0];

				_strMesProduccion = (string)Session["MES_PRODUCCION"];
				_strIdTipoProducto = (string)Session["strIdTipoProducto"];
				_strNameTableTemporal = (string)Session["strNameTableTemporal"];

				var oGetObjHistorialCargaByTablaPeriodoIdProducto = _cArchivoProducto.GetObjHistorialCargaByTablaPeriodoIdProducto(_strNameTableTemporal, _strMesProduccion, _strIdTipoProducto);

				if (oGetObjHistorialCargaByTablaPeriodoIdProducto != null)
				{

					if (oGetObjHistorialCargaByTablaPeriodoIdProducto.HCBT_PROCESADO == true)
					{
						//ScriptManager.RegisterStartupScript(this, GetType(), "modal", "$('#mdlMensajeNoReprocesar').modal({ backdrop: 'static', keyboard: false })", true);
						return;
					}
					else
					{
						_intIdHistorialCarga = oGetObjHistorialCargaByTablaPeriodoIdProducto.HCIN_ID;
						Session["intIdHistorialCarga"] = _intIdHistorialCarga;
						_bolReproceso = true;
						Session["bolReproceso"] = _bolReproceso;
						CargarArchivo();
					}

					return;
				}
				else
				{					
					_bolReproceso = false;
					Session["bolReproceso"] = _bolReproceso;
					CargarArchivo();
				}



				//if (Session["DATOS_ARCHIVO_CARGADO"] == null || Session["ARCHIVO_CARGADO"] == null)
				//	throw new Exception("Se ha encontrado un problema con el archivo seleccionado ('BtnProcesarArchivo_Click').");
				//DataTable DtblDatos = (DataTable)Session["DATOS_ARCHIVO_CARGADO"];
				//var listaErrores = new List<string>();
				//bool boolEsExcel = false;
				//var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
				//switch (strIdProducto)
				//{
				//	case "SEGECP":
				//	case "SEGECV":
				//		int intNumeroColumnas = (strIdProducto == "SEGECP") ? 43 : ((strIdProducto == "SEGECV") ? 37 : 0);
				//		DataTable DtblDatosAuxiliar = new DataTable();
				//		for (int index = 0; index < intNumeroColumnas; index++)
				//			DtblDatosAuxiliar.Columns.Add(new DataColumn("Column" + (index + 1)));
				//		for (int index = 0; index < DtblDatos.Rows.Count; index++)
				//		{
				//			string strTextLine = DtblDatos.Rows[index][0].ToString();
				//			string[] datos = strTextLine.Split('|');
				//			if (datos.Length != intNumeroColumnas)
				//				listaErrores.Add("Error en la fila '" + (index + 1) + "': El número de columnas proporcionadas es incorrecto.");
				//			else
				//			{
				//				DataRow dr = DtblDatosAuxiliar.NewRow();
				//				for (int intColumna = 0; intColumna < intNumeroColumnas; intColumna++)
				//					dr[intColumna] = datos[intColumna];
				//				DtblDatosAuxiliar.Rows.Add(dr);
				//			}
				//		}
				//		var listaValidaciones = (strIdProducto == "SEGECP") ? _validacionCarga.Validacion_SEGECP(DtblDatosAuxiliar) : ((strIdProducto == "SEGECV") ? _validacionCarga.Validacion_SEGECV(DtblDatosAuxiliar) : new List<string>());
				//		if (listaValidaciones.Count > 0)
				//		{
				//			foreach (var strError in listaValidaciones)
				//				listaErrores.Add(strError);
				//		}
				//		break;
				//	default:
				//		boolEsExcel = true;
				//		break;
				//}
				//if (!boolEsExcel)
				//{
				//	if (listaErrores.Count > 0)
				//	{
				//		MostrarLogErrores(listaErrores, strIdProducto);
				//		ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se han encontrado observaciones en el archivo seleccionado, se le ha enviado un correo con un detalle de las observaciones para su revisión.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
				//	}
				//	else
				//	{
				//		string strNombreArchivo = strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION;
				//		if (File.Exists(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION))
				//			File.Delete(CParametros.RutaArchivoDatos + strIdProducto + "_Afiliaciones_" + _strPeriodoContable + objArchivo.EXTENSION);
				//		File.WriteAllBytes(CParametros.RutaArchivoDatos + strNombreArchivo, objArchivo.BYTE_ARRAY);
				//		bool boolCargaCompleta = false;
				//		switch (strIdProducto)
				//		{
				//			case "SEGECP":
				//				boolCargaCompleta = _cCrediseguro.SEGECP_RegistrarDatos(_strPeriodoContable, true, strNombreArchivo);
				//				break;
				//			case "SEGECV":
				//				boolCargaCompleta = _cCrediseguro.SEGECV_RegistrarDatos(_strPeriodoContable, true, strNombreArchivo);
				//				break;
				//		}
				//		if (boolCargaCompleta)
				//			ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El proceso de carga de datos ha sido completado exitosamente..', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
				//		else
				//			throw new Exception("Se ha presentado un error en la carga de los datos a la base de datos ('BtnProcesarArchivo_Click'). Revise el servicio Crediseguro.Core.");
				//	}
				//	PopCargarArchivo.ShowOnPageLoad = false;
				//	CargaInicial();
				//}
				//else
				//{
				//	PopWorksheet.HeaderText = strDatosProducto[1];
				//	PopCargarArchivo.ShowOnPageLoad = false;
				//	//
				//	ChkReprocesoWorksheet.Checked = false;
				//	ChkReprocesoWorksheet.ClientEnabled = true;
				//	string[] strListaProductos = { "VGDCVN", "VCDIAF", "VCDIAS", "VCDIAV" };
				//	if (strListaProductos.Contains(strIdProducto))
				//	{
				//		ChkReprocesoWorksheet.Checked = true;
				//		ChkReprocesoWorksheet.ClientEnabled = false;
				//	}
				//	//
				//	PopWorksheet.ShowOnPageLoad = true;
				//	CmbWorksheet.Items.Clear();
				//	Workbook DEWorkbook = new Workbook();
				//	DEWorkbook.LoadDocument(objArchivo.BYTE_ARRAY, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
				//	foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
				//	{
				//		CmbWorksheet.Items.Add(new DevExpress.Web.Bootstrap.BootstrapListEditItem(DEWorksheet.Name, DEWorksheet.Name));
				//	}
				//}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		private void CargarArchivo()
		{
			//pnlMensajeError.Visible = false;
			string strFileExtension = string.Empty;
			//var PathArchivos = @"\\bcrcsw00\\D$\\ArchivosEnvioCorreo\\";
			//string rutaTemporal = Server.MapPath(PathArchivos);//\\BCRCSW00\Aplicativos\Generales.Core\Archivos //@"\\bcrcsw00\\D$\\ArchivosEnvioCorreo\\";

			var rutaTemporal = @"\\bcrcsw00\\Aplicativos\\Generales.Core\\Archivos\\";
			TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(_strIdTipoProducto));

			if (objTipoProducto == null)
			{
				lblMsg.Text = "El Producto no se encuentra configurado, por favor contacte con el administrador";
				divMsgSave.HeaderText = "Mensaje de sistema";
				divMsgSave.ShowOnPageLoad = true;
				return;
			}

			//_fileUpload = UpcArchivo.UploadedFiles[0];
			var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];
			if (_cArchivoProducto.GetValidFile(fileUpload, objTipoProducto.TPVC_EXTENSION, ref strFileExtension))
			{
				string nombreFile = _cArchivoProducto.GuardarFileTemporal(_user.Matricula, fileUpload, rutaTemporal, strFileExtension);
				_strNombreArchivo = nombreFile;
				Session["strNombreArchivo"] = _strNombreArchivo;
				_strRutaArchivo = rutaTemporal;
				Session["strRutaArchivo"] = _strRutaArchivo;
				_strArchivoExtension = strFileExtension;
				Session["strArchivoExtension"] = _strArchivoExtension;
				if (_bolReproceso)
				{
					//hidFileExtension.Value = strFileExtension;
					//hidFileName.Value = _strNombreArchivo;
					//hidRutaTemporal.Value = _strRutaArchivo;
					txtMotivo.Text = "";
					//ScriptManager.RegisterStartupScript(this, GetType(), "modal", "$('#HistorialExiste').modal('show');", true);
					HistorialExiste.HeaderText = "Reproceso";
					HistorialExiste.ShowOnPageLoad = true;
				}
				else
				{
					//HistorialExiste.ShowOnPageLoad = true;
					//ScriptManager.RegisterStartupScript(this, GetType(), "modal", "$('#HistorialExiste').modal('show');", true);
					VerificarArchivoCargado(strFileExtension);
				}

			}
			else
			{
				//pnlMensajeError.Visible = true;
				//lblMensajeError.Text = "El formato del Archivo no es valido";
			}
		}

		protected void btnReprocesoYes_Click(object sender, EventArgs e)
		{
			try
			{
				_strArchivoExtension = (string)Session["strArchivoExtension"];
				if (txtMotivo.Text.Trim() != "")
				{

					_strMotivo = txtMotivo.Text;
					//_strArchivoExtension = hidFileExtension.Value;
					//_strNombreArchivo = hidFileName.Value;
					//_strRutaArchivo = hidRutaTemporal.Value;
					_bolReproceso = true;
					HistorialExiste.ShowOnPageLoad = false;
					VerificarArchivoCargado(_strArchivoExtension);
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		private void VerificarArchivoCargado(string strFileExtension)
		{
			_strIdTipoProducto = (string)Session["strIdTipoProducto"];
			TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(_strIdTipoProducto));
			switch (strFileExtension)
			{
				case ".xls":
				case ".xlsx":
					{

						_strRutaArchivo = Session["strRutaArchivo"].ToString();
						_strNombreArchivo = Session["strNombreArchivo"].ToString();
						//int intNumSheet = 0;

						var objFile = (ocp_archivo)Session["ARCHIVO_CARGADO"];
						var lstExcelHojas = new CExcel().ListSheets(objFile.ByteArray);

						rlHojasdisponibles.DataSource = lstExcelHojas;
						rlHojasdisponibles.DataBind();

						//var lstSheet = new ExcelQuery(strFileRoot, strFileName).ListSheet(ref intNroSheet);
						//var lstSheet = new ArchivoExcel().ListSheet(_strRutaArchivo, _strNombreArchivo, ref intNumSheet);
						//var script = string.Empty;

						//if (Master != null)
						//{
						//	var hidNumeroPestanas = (HtmlInputControl)Master.FindControl("HidNumeroPestanas");
						//	//script += "$('#" + hidNumeroPestanas.ClientID + "').val('" + intNumSheet + "');";
						//}

						//script += "$('#" + DivPestañas.ClientID + "').empty();";
						//script += "$('#" + DivPestañas.ClientID + "').append(\"<table>" + lstExcelHojas + "</table>\");";

						//ScriptManager.RegisterStartupScript(this, GetType(), "script_DwSelecionarPestaña", script, true);
						//pnlSheets.Visible = true;
						//ScriptManager.RegisterStartupScript(this, GetType(), "modal",
						//	"$('#demo_modal').modal({ backdrop: 'static', keyboard: false })", true);
						SeleccionarHoja.HeaderText = "Por favor selecciona la Hoja que se cargará";
						SeleccionarHoja.ShowOnPageLoad = true;
						break;
					}
				case ".txt":
				case ".csv":
					{
						//				List<string> linesError = null;
						//				var dtData = new DataTable();
						//				List<string> lstErroresArchivo = null;

						//				Log.Debug("Action: Procesamiento del archivo TXT, CSV para su evaluacion ; Metod: btnUpload_Click");
						//				var lstColumnas = _cReceptorArchivos.GetListColumnasByIdProducto(objTipoProducto.TPVC_IDPRODUCTO);
						//				var lstErrors = _cReceptorArchivos.GetDatatableFileTxt(_strRutaArchivo, _strNombreArchivo,
						//					lstColumnas, ref dtData, ref lstErroresArchivo, ref linesError, _strIdTipoProducto,
						//					_intIdHistorialCarga);

						//				if (lstErrors == CParametros.ErrorColumnNotAssigned)
						//				{
						//					pnlLoadFile.Visible = true;
						//					pnlSheets.Visible = true;
						//					pnlResumen.Visible = false;
						//					pnlMensajeError.Visible = true;
						//					lblMensajeError.Text = "Algunas Columnas del Archivo no coinciden con la Tabla temporal";
						//				}
						//				else
						//				{

						//					var objHistorialCarga = new HISTORIAL_CARGA()
						//					{
						//						HCVC_NOMBRE_TABLA_TMP = _strNameTableTemporal,
						//						HCVC_MOTIVO = null,
						//						HCVC_ID_PRODUCTO = _strIdTipoProducto,
						//						HCIN_CANTIDAD_FILAS = 0,
						//						HCDT_PERIODO = DateTime.ParseExact(_strPeriodoArchivo, "dd-MM-yyyy", null)

						//					};

						//					if (!_bolReproceso)
						//					{

						//						var oSaveObjHistorialCarga = new CReceptorArchivos().SaveObjHistorialCarga(objHistorialCarga);
						//						_intIdHistorialCarga = oSaveObjHistorialCarga;

						//					}
						//					else
						//					{
						//						var oReprocesoHistorialRetornaIdHistoriala =
						//							new CReceptorArchivos().ReprocesoHistorialRetornaIdHistorial(objHistorialCarga,
						//								_intIdHistorialCarga, _strMotivo);
						//						_intIdHistorialCargaEliminado = _intIdHistorialCarga;

						//						_intIdHistorialCarga = oReprocesoHistorialRetornaIdHistoriala;
						//					}

						//					if (linesError != null)
						//					{
						//						VerificarErroresArchivo(linesError, lstErroresArchivo, lstErrors, _strRutaArchivo,
						//							_strNombreArchivo);
						//						_cReceptorArchivos.UpdateEstadoHistorialCargaAsync(_intIdHistorialCarga,
						//							"No Se realizo la carga por errores de formato", false);
						//					}
						//					else
						//					{
						//						btnGenerearArchError.Visible = false;
						//						dtData.TableName = _strNameTableTemporal;
						//						if (!_bolReproceso)
						//						{

						//							/***************ENVIO POR TRAMAS PROCESO********/
						//							var prueba = new DataTable();

						//							const int intCantidadtrama = 10000;
						//							int cantfil = dtData.Rows.Count;
						//							int intTrama = cantfil / intCantidadtrama;
						//							int intTramaresiduo = cantfil % intCantidadtrama;
						//							if (intTramaresiduo != 0)
						//							{
						//								intTrama = intTrama + 1;
						//							}
						//							/* AGREGA COLUMNAS AL DATATABLE PARA ENVIO*/
						//							foreach (DataColumn data in dtData.Columns)
						//								prueba.Columns.Add(data.ColumnName, typeof(System.String));

						//							int intIndex = 1;
						//							int intInicioData = 0;
						//							int intFinalData = intCantidadtrama;
						//							while (intIndex <= intTrama)
						//							{
						//								if (intIndex == intTrama)
						//								{
						//									for (int i = intInicioData; i < cantfil; i++)
						//									{
						//										DataRow row = prueba.NewRow();



						//										foreach (DataColumn datac in prueba.Columns)
						//										{
						//											if (datac.ColumnName == "CTRL_HCIN_ID")
						//											{
						//												row[datac.ColumnName] = _intIdHistorialCarga;
						//											}
						//											else
						//											{
						//												row[datac.ColumnName] = dtData.Rows[i][datac.ColumnName].ToString();
						//											}



						//										}
						//										prueba.Rows.Add(row);
						//									}
						//								}
						//								else
						//								{
						//									for (int i = intInicioData; i < intFinalData; i++)
						//									{
						//										DataRow row = prueba.NewRow();



						//										foreach (DataColumn datac in prueba.Columns)
						//										{
						//											if (datac.ColumnName == "CTRL_HCIN_ID")
						//											{
						//												row[datac.ColumnName] = _intIdHistorialCarga;
						//											}
						//											else
						//											{
						//												row[datac.ColumnName] = dtData.Rows[i][datac.ColumnName].ToString();
						//											}


						//										}
						//										prueba.Rows.Add(row);
						//									}
						//								}


						//								bool oSaveArchivoRecibidoProcesoTxt =
						//									_cReceptorArchivos.SaveArchivoRecibido(_strNameTableTemporal, prueba);
						//								if (oSaveArchivoRecibidoProcesoTxt)
						//								{
						//									intIndex = intIndex + 1;
						//									intInicioData = intFinalData;
						//									intFinalData = intFinalData + intCantidadtrama;
						//									prueba.Clear();
						//								}
						//							}

						//							lblMsgReproceso.Visible = false;
						//							ScriptManager.RegisterStartupScript(this, GetType(), "modal",
						//								"$('#divMsgSave').modal({ backdrop: 'static', keyboard: false })", true);

						//						}
						//						else
						//						{
						//							/************ENVIO POR TRAMAS REPROCESO***********/
						//							var prueba = new DataTable();

						//							const int intCantidadtrama = 10000;
						//							int cantfil = dtData.Rows.Count;
						//							int intTrama = cantfil / intCantidadtrama;
						//							int intTramaresiduo = cantfil % intCantidadtrama;
						//							if (intTramaresiduo != 0)
						//							{
						//								intTrama = intTrama + 1;
						//							}
						//							/* AGREGA COLUMNAS AL DATATABLE PARA ENVIO*/
						//							foreach (DataColumn data in dtData.Columns)
						//								prueba.Columns.Add(data.ColumnName, typeof(System.String));

						//							int intIndex = 1;
						//							int intInicioData = 0;
						//							int intFinalData = intCantidadtrama;
						//							while (intIndex <= intTrama)
						//							{
						//								if (intIndex == intTrama)
						//								{
						//									for (int i = intInicioData; i < cantfil; i++)
						//									{
						//										DataRow row = prueba.NewRow();



						//										foreach (DataColumn datac in prueba.Columns)
						//										{
						//											if (datac.ColumnName == "CTRL_HCIN_ID")
						//											{
						//												row[datac.ColumnName] = _intIdHistorialCarga;
						//											}
						//											else
						//											{
						//												row[datac.ColumnName] = dtData.Rows[i][datac.ColumnName].ToString();
						//											}



						//										}
						//										prueba.Rows.Add(row);
						//									}
						//								}
						//								else
						//								{
						//									for (int i = intInicioData; i < intFinalData; i++)
						//									{
						//										DataRow row = prueba.NewRow();



						//										foreach (DataColumn datac in prueba.Columns)
						//										{
						//											if (datac.ColumnName == "CTRL_HCIN_ID")
						//											{
						//												row[datac.ColumnName] = _intIdHistorialCarga;
						//											}
						//											else
						//											{
						//												row[datac.ColumnName] = dtData.Rows[i][datac.ColumnName].ToString();
						//											}


						//										}
						//										prueba.Rows.Add(row);
						//									}
						//								}


						//								bool oSaveArchivoRecibidoReprocesoTxt =
						//									_cReceptorArchivos.ReprocesoArchivoFisico(_strNameTableTemporal, prueba);

						//								if (oSaveArchivoRecibidoReprocesoTxt)
						//								{
						//									intIndex = intIndex + 1;
						//									intInicioData = intFinalData;
						//									intFinalData = intFinalData + intCantidadtrama;
						//									prueba.Clear();
						//								}
						//							}
						//							/************** FIN DE ENVIO POR TRAMAS REPROCESO************************/

						//							_cReceptorArchivos.DeleteFilasArchivoTemporal(_strNameTableTemporal,
						//								_intIdHistorialCargaEliminado);
						//							lblMsgReproceso.Visible = true;
						//							ScriptManager.RegisterStartupScript(this, GetType(), "modal",
						//								"$('#divMsgSave').modal({ backdrop: 'static', keyboard: false })", true);
						//						}
						//					}
					}
					break;

				//			}
				default:
					{
						break;
					}
			}
		}

		protected void BtnCargarArchivo_Click(object sender, EventArgs e)
		{
			//SeleccionarHoja.ShowOnPageLoad = false;

			_strRutaArchivo = (string)Session["strRutaArchivo"];
			_strNombreArchivo = (string)Session["strNombreArchivo"];
			_strIdTipoProducto = (string)Session["strIdTipoProducto"];
			//_strPeriodoArchivo = (string)Session["strPeriodoArchivo"];// (string)Session["MES_PRODUCCION"];
			_strNameTableTemporal = (string)Session["strNameTableTemporal"];
			List<string> linesError = null;
			//pnlLoadFile.Visible = false;
			//pnlSheets.Visible = false;
			//pnlResumen.Visible = true;
			_bolReproceso = (bool)Session["bolReproceso"];
			//var masterPage = this.Master;
			//HtmlInputControl hidPestanaSeleccionada = null;
			//if (Master != null)
			//{
			//	hidPestanaSeleccionada = (HtmlInputControl)Master.FindControl("HidPestanaSeleccionada");

			//}
			//string worksheet = hidPestanaSeleccionada.Value;

			var worksheet = Convert.ToString(rlHojasdisponibles.SelectedItem.Value);

			TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(_strIdTipoProducto));
			var lstColumnas = _cArchivoProducto.GetListColumnasByIdProducto(objTipoProducto.TPVC_IDPRODUCTO);
			//Log.Debug("Action: Procesamiento del archivo Excel para su evaluacion ; Metod: BtnCargarArchivo_Click()");
			string strNumColumn = _cArchivoProducto.GetExcelColumnName(lstColumnas.Count);
			//_strQueryExcel = "SELECT COUNT(*) AS CANTIDAD FROM [" + worksheet + "$A" + objTipoProducto.TPIN_NRO_FILA_CABECERA + ":B]";

			//var t = CExcel.DatosArchivo();
			//Worksheet worksheet = spreadsheetControl1.Document.Worksheets.ActiveWorksheet;
			//Range range = worksheet.Selection;
			//bool rangeHasHeaders = true;

			//// Create a data table with column names obtained from the first row in a range if it has headers.
			//// Column data types are obtained from cell value types of cells in the first data row of the worksheet range.
			//DataTable dataTable = worksheet.CreateDataTable(range, rangeHasHeaders);

			var objFile = (ocp_archivo)Session["ARCHIVO_CARGADO"];
			var lstExcelHojas = new CExcel().ListSheets(objFile.ByteArray);


			var dtblExcelData = new CExcel().DatosArchivo(objFile.ByteArray, objTipoProducto).DataTable;


			//verificamos campo llave
			string campoLlave = objTipoProducto.TPVC_CAMPO_LLAVE;

			if (!string.IsNullOrEmpty(campoLlave))
			{				
				foreach (DataRow row in dtblExcelData.Rows)
				{
					var valueCell = row[campoLlave].ToString();
					if (string.IsNullOrEmpty(valueCell))
					{
						row.Delete();
					}
				}
			}
			dtblExcelData.AcceptChanges();

			

			foreach (var itemColumna in lstColumnas)
			{
				var fullSplit = itemColumna.COVC_NOMBRE_TABLA.Split('_');
				var strFullType = fullSplit.First();

				var nombreColumnaSplit = fullSplit.Where((number, index) => index != 0).ToList();
				string strColumna = String.Join("_", nombreColumnaSplit);

				foreach (DataColumn column in dtblExcelData.Columns)
				{
					//if (itemColumna.COVC_NOMBRE_DOCUMENTO == column.ColumnName)
					if (Regex.Replace(itemColumna.COVC_NOMBRE_DOCUMENTO, @"\s+", " ") == column.ColumnName)
					{
						column.ColumnName = itemColumna.COVC_NOMBRE_TABLA;
					}
					//if (strColumna == column.ColumnName)
					//{
					//	column.ColumnName = itemColumna.COVC_NOMBRE_TABLA;							
					//}
				}


				//foreach (DataRow row in dtblExcelData.Rows)
				//{
				//	foreach (DataColumn column in dtblExcelData.Columns)
				//	{
				//		if (itemColumna.COVC_NOMBRE_TABLA == column.ColumnName)
				//		{
				//			//column.ColumnName = itemColumna.COVC_NOMBRE_TABLA;
				//			string strType = GetValidateTypeField(strFullType, row[column].ToString());
				//		}
				//	}
				//}

			}

			var t3 = "";

			//ValidaData(dtblExcelData, lstColumnas);
			//_cArchivoProducto.ValidaData(dtblExcelData, lstColumnas);

			//var task = _cArchivoProducto.ValidaData(dtblExcelData, lstColumnas, objTipoProducto, _strNameTableTemporal);

			//var result = task.WaitAndUnwrapException();
			var t = "";


			foreach (DataRow row in dtblExcelData.Rows)
			{
				foreach (DataColumn column in dtblExcelData.Columns)
				{
					foreach (var itemColumna in lstColumnas)
					{
						if (itemColumna.COVC_NOMBRE_TABLA == column.ColumnName)
						{
							var fullSplit = itemColumna.COVC_NOMBRE_TABLA.Split('_');
							var strFullType = fullSplit.First();
							var value = row[column].ToString();
							var error = false;
							string strType = GetValidateTypeField(strFullType, value, ref error);

							if (error)
							{
								//throw new Exception("Ocurrio un error en la columna" + itemColumna.COVC_NOMBRE_DOCUMENTO + "revice el valor " + value);								
								lblMsg.Text = "Ocurrio un error en la columna <b style='color:red'>'" + itemColumna.COVC_NOMBRE_DOCUMENTO + "'</b> revice el valor  <b style='color:red'>'" + value + "'</b>";
								SeleccionarHoja.ShowOnPageLoad = false;
								divMsgSave.ShowOnPageLoad = true;
								return;
							}
						}
					}
				}
			}

			var tt = "";
			//if (error)
			//{
			//	//throw new Exception("Ocurrio un error en la columna" + itemColumna.COVC_NOMBRE_DOCUMENTO + "revice el valor " + value);
			//	divMsgSave.ShowOnPageLoad = true;
			//	return;
			//}

			//foreach (var itemColumna in lstColumnas)
			//{
			//	var fullSplit = itemColumna.COVC_NOMBRE_TABLA.Split('_');
			//	var strFullType = fullSplit.First();

			//	var nombreColumnaSplit = fullSplit.Where((number, index) => index != 0).ToList();
			//	string strColumna = String.Join("_", nombreColumnaSplit);

			//	var ColumnData = dtblExcelData.Columns[strColumna];

			//	foreach (DataRow row in dtblExcelData.Rows)
			//	{
			//		foreach (DataColumn column in dtblExcelData.Columns)
			//		{
			//			if (strColumna == column.ColumnName)
			//			{
			//				column.ColumnName = itemColumna.COVC_NOMBRE_TABLA;
			//				string strType = GetValidateTypeField(strFullType, row[column].ToString());
			//			}
			//		}
			//	}
			//}



			//dtDataArchivo

			//int intNumReg = Convert.ToInt32(oCounRow.Rows[0][0]) + Convert.ToInt32(objTipoProducto.TPIN_NRO_FILA_CABECERA);
			//_strQueryExcel = "SELECT * FROM [" + worksheet + "$A" + objTipoProducto.TPIN_NRO_FILA_CABECERA + ":" + strNumColumn + intNumReg + "]";
			////_strQueryExcel = "SELECT * FROM [" + worksheet + "$A" + objTipoProducto.TPIN_NRO_FILA_CABECERA + ":" + strNumColumn + oCounRow.Rows[0][0] + "] WHERE  " + strCampoValidacion + " <> ''";
			//DataTable dtblArchivoDetalle = new CExcel().DatosArchivo(_strRutaArchivo, _strNombreArchivo, _strQueryExcel);

			////var dtblExcelData = new DataTable();
			////var lstErroresArchivo = new List<string>();

			var objHistorialCarga = new HISTORIAL_CARGA
			{
				HCVC_NOMBRE_TABLA_TMP = _strNameTableTemporal,
				HCVC_MOTIVO = null,
				HCVC_ID_PRODUCTO = _strIdTipoProducto,
				HCIN_CANTIDAD_FILAS = 0,
				HCDT_PERIODO = DateTime.ParseExact(_strMesProduccion, "yyyyMM", null)

			};
			//string strErrorNameColumn = "";
			
			//var oErroresArchivo = new ArchivoExcel().GetDataExcel(dtblArchivoDetalle, lstColumnas, ref dtblExcelData, ref lstErroresArchivo, ref linesError, _intIdHistorialCarga, ref strErrorNameColumn);

			//if (oErroresArchivo == CParametros.ErrorColumnNotAssigned)
			//{
			//	pnlLoadFile.Visible = true;
			//	pnlSheets.Visible = true;
			//	pnlResumen.Visible = false;
			//	pnlMensajeError.Visible = true;
			//	lblMensajeError.Text = "Algunas Columnas del Archivo no coinciden con la Tabla temporal: " + strErrorNameColumn;

			//}
			//else
			//{
			dtblExcelData.TableName = _strNameTableTemporal;
			if (!_bolReproceso)
			{
				var oSaveObjHistorialCarga = _cArchivoProducto.SaveObjHistorialCarga(objHistorialCarga);
				_intIdHistorialCarga = oSaveObjHistorialCarga;

			}
			else
			{
				_intIdHistorialCarga = (int)Session["intIdHistorialCarga"];
				var oReprocesoHistorialRetornaIdHistoriala = _cArchivoProducto.ReprocesoHistorialRetornaIdHistorial(objHistorialCarga, _intIdHistorialCarga, _strMotivo);
				_intIdHistorialCargaEliminado = _intIdHistorialCarga;

				_intIdHistorialCarga = oReprocesoHistorialRetornaIdHistoriala;
			}

			dtblExcelData.Columns.Add("CTRL_HCIN_ID", typeof(String));
			foreach (DataRow row in dtblExcelData.Rows)
			{
				//need to set value to NewColumn column
				row["CTRL_HCIN_ID"] = _intIdHistorialCarga;   // or set it to some other value
			}

			var lstDatatables = SplitDataTableTomultiple(dtblExcelData, 2000);

			var countGuardados = 0;
			if (!_bolReproceso)
			{
				foreach (var itemDatatable in lstDatatables)
				{
					bool oSaveArchivoRecibidoProceso = _cArchivoProducto.SaveArchivoRecibido(_strNameTableTemporal, itemDatatable);
					if (oSaveArchivoRecibidoProceso)
					{
						countGuardados = countGuardados + 1;
					}
				}
			}
			else
			{
				foreach (var itemDatatable in lstDatatables)
				{
					bool oSaveArchivoRecibidoReproceso = _cArchivoProducto.ReprocesoArchivoFisico(_strNameTableTemporal, itemDatatable);
					if (oSaveArchivoRecibidoReproceso)
					{
						countGuardados = countGuardados + 1;
					}
				}
			}

			if (countGuardados == lstDatatables.Count)
			{
				//success
				lblMsg.Text = "La Carga fue realizada correctamente";
				var task = _cArchivoProducto.ValidaData(dtblExcelData, lstColumnas, objTipoProducto, _strNameTableTemporal, _intIdHistorialCarga);
			}
			else
			{
				//error
				lblMsg.Text = "Ocurrio un error durante la carga por favor intente nuevamente";
			}

			SeleccionarHoja.ShowOnPageLoad = false;
			divMsgSave.ShowOnPageLoad = true;
		}

		private string GetValidateTypeField(string strField, string srtValue, ref bool error)
		{
			//si solo se tiene dos prefijos se cambia el 3 por 2

			//var strTipoDefinido = strField.Substring(3, 2).ToUpper();
			var strTipoDefinido = strField.Substring(strField.Length - 2, 2).ToUpper();
			string strType = "";
			switch (strTipoDefinido)
			{
				case "IN":
				case "SI":
					strType = "int";
					GetInteger(srtValue, ref error);
					break;
				case "BI":
					strType = "long";
					break;
				case "DT":
				case "SD":
				case "TS":
					strType = "DateTime";
					GetDateTime(srtValue, "dd/MM/yyyy", ref error);
					break;
				case "VC":
				case "CH":
				case "NC":
				case "NV":
				case "TX":
				case "NT":
					strType = "string";
					break;
				case "BN":
				case "VB":
				case "IM":
					strType = "byte[]";
					break;
				case "DC":
				case "MO":
				case "SM":
					strType = "decimal";
					GetDecimal(srtValue, ref error);
					break;
				case "NU":
				case "DO":
					strType = "double";
					break;
				case "FL":
					strType = "float";
					break;
				case "BT":
					strType = "bool";
					break;
				case "UI":
					strType = "Guid";
					break;
				default:
					strType = "string";
					break;
			}
			return strType;
		}

		private static List<DataTable> SplitDataTableTomultiple(DataTable originalTable, int batchSize)
		{
			List<DataTable> dts = new List<DataTable>();
			DataTable dt = new DataTable();
			dt = originalTable.Clone();
			int j = 0;
			int k = 1;
			if (originalTable.Rows.Count <= batchSize)
			{
				dt.TableName = "Table_" + k;
				dt = originalTable.Copy();
				dts.Add(dt.Copy());
			}
			else
			{
				for (int i = 0; i < originalTable.Rows.Count; i++)
				{
					dt.NewRow();
					dt.ImportRow(originalTable.Rows[i]);
					if ((i + 1) == originalTable.Rows.Count)
					{
						dt.TableName = "Table_" + k;
						dts.Add(dt.Copy());
						dt.Rows.Clear();
						k++;
					}
					else if (++j == batchSize)
					{
						dt.TableName = "Table_" + k;
						dts.Add(dt.Copy());
						dt.Rows.Clear();
						k++;
						j = 0;
					}
				}
			}

			return dts;
		}


		#endregion

		#region(VALIDACION DE DATOS)

		//private async Task ValidaData(DataTable dtblExcelData, List<COLUMNAS> lstColumnas)
		//{
		//	await _cArchivoProducto.ValidaData(dtblExcelData, lstColumnas);
		//}

		private static int GetInteger(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToInt32(Convert.ToDecimal(valor));
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static long GetBigint(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToInt64(Convert.ToDecimal(valor));
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static decimal GetDecimal(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToDecimal(valor);
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static string GetDate(string valor, string formato, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
				{
					if (valor.Length >= formato.Length)
						valor = valor.Substring(0, formato.Length);
				}
				else return string.Empty;
				DateTime eval = DateTime.ParseExact(valor, formato, CultureInfo.InvariantCulture);
				return eval.ToString(formato);
			}
			catch
			{
				error = true;
				return string.Empty;
			}
		}
		private static string GetShortDate(string valor, string formatoEntrada, string formatoSalida, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
				{
					if (valor.Length >= formatoEntrada.Length)
						valor = valor.Substring(0, formatoEntrada.Length);
				}
				else return string.Empty;
				DateTime eval = DateTime.ParseExact(valor, formatoEntrada, CultureInfo.InvariantCulture);
				return eval.ToString(formatoSalida);
			}
			catch
			{
				error = true;
				return string.Empty;
			}
		}
		private static DateTime? GetDateTime(string strValor, string strFormato, ref bool error)
		{
			try
			{
				if (strValor != string.Empty)
				{
					string strValorCalculo = string.Empty;
					if (strValor.Length >= strFormato.Length)
						strValorCalculo = strValor.Substring(0, strFormato.Length);
					if (IsDate(strValor))
					{
						DateTime dtFecha;
						bool success = DateTime.TryParse(strValor, out dtFecha);
						return dtFecha;
					}
					if (IsDate2(strValorCalculo, strFormato))
					{
						DateTime eval1 = DateTime.ParseExact(strValorCalculo, strFormato, CultureInfo.InvariantCulture);
						return eval1;
					}
					else if (IsOADate2(strValor))
					{
						DateTime eval2 = DateTime.FromOADate(Convert.ToDouble(strValor));
						return eval2;
					}
				}
				return null;
			}
			catch
			{
				error = true;
				throw;
			}
		}
		private static bool IsDate(string strFecha)
		{
			try
			{
				DateTime dtFecha;
				bool success = DateTime.TryParse(strFecha, out dtFecha);
				return success;
			}
			catch
			{
				return false;
			}
		}
		private static bool IsDate2(string value, string format)
		{
			try
			{
				DateTime fecha = DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
				return true;
			}
			catch
			{
				return false;
			}
		}
		private static bool IsOADate2(string value)
		{
			try
			{
				DateTime fecha = DateTime.FromOADate(Convert.ToDouble(value));
				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion

		#region PopProduccion

		protected void BtnProduccion_Click(object sender, EventArgs e)
		{
			try
			{
				//var objLexico = _cPersonales.GetListLexicoPorTabla("PERIODO_CONTABLE");
				//string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
				//if (Session["PERIODO_CONTABLE"] != null && Session["PERIODO_CONTABLE"].ToString() == strPeriodoProceso)
				//{
				//	string[] strDatosProducto = Session["DatosProducto"].ToString().Split('|');
				//	string strIdProducto = strDatosProducto[0];
				//	bool boolEjecutarProceso = true;
				//	string strMensaje = string.Empty;
				//	if (strIdProducto == "SEGDES" || strIdProducto == "DERBCP")
				//	{
				//		if (Session["DATOS_ARCHIVO_CARGADO"] != null && Session["ARCHIVO_CARGADO"] != null)
				//		{
				//			var objArchivo = (OC_ARCHIVO)Session["ARCHIVO_CARGADO"];
				//			var DtblDatosArchivo = (DataTable)Session["DATOS_ARCHIVO_CARGADO"];
				//			var boolResponseReproceso = false;
				//			switch (strIdProducto)
				//			{
				//				case "DERBCP": boolResponseReproceso = _cCrediseguro.DERBCP_ReprocesarRecargos(_strPeriodoContable); break;
				//				case "SEGDES": boolResponseReproceso = _cCrediseguro.SEGDES_ReprocesarRecargos(_strPeriodoContable); break;
				//			}
				//			if (boolResponseReproceso)
				//			{
				//				for (int index = 0; index < DtblDatosArchivo.Rows.Count; index++)
				//					if (DtblDatosArchivo.Rows[index][0].ToString().Trim() != string.Empty)
				//					{
				//						var boolResponseRecargo = false;
				//						switch (strIdProducto)
				//						{
				//							case "DERBCP":
				//								boolResponseRecargo = _cCrediseguro.DERBCP_RegistrarRecargo(
				//									_strPeriodoContable,
				//									(strIdProducto == "DERBCP" ? "R_" : string.Empty) + DtblDatosArchivo.Rows[index][0].ToString().Trim(),
				//									Convert.ToDecimal(DtblDatosArchivo.Rows[index][1].ToString().Trim()),
				//									Convert.ToDecimal(DtblDatosArchivo.Rows[index][2].ToString().Trim()));
				//								break;
				//							case "SEGDES":
				//								boolResponseRecargo = _cCrediseguro.SEGDES_RegistrarRecargo(
				//									_strPeriodoContable,
				//									DtblDatosArchivo.Rows[index][0].ToString().Trim(),
				//									Convert.ToDecimal(DtblDatosArchivo.Rows[index][1].ToString().Trim()),
				//									Convert.ToDecimal(DtblDatosArchivo.Rows[index][2].ToString().Trim()));
				//								break;
				//						}
				//						if (!boolResponseRecargo)
				//						{
				//							strMensaje = "El recargo de al menos una operación no pudo ser registrada en la base de datos, por favor revise la existencia de las operaciones en la liquidación del mes.";
				//							boolEjecutarProceso = false;
				//						}
				//					}
				//				if (boolEjecutarProceso)
				//				{
				//					if (File.Exists(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION))
				//						File.Delete(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION);
				//					File.WriteAllBytes(CParametros.RutaArchivoDatos + strIdProducto + "_Recargo_" + _strPeriodoContable + objArchivo.EXTENSION, objArchivo.BYTE_ARRAY);
				//				}
				//			}
				//			else
				//			{
				//				strMensaje = "Se ha presentado un error al momento de preparar el proceso de recargos.";
				//				boolEjecutarProceso = false;
				//			}
				//		}
				//	}
				//	//ejecutamos el procedimiento relacionado al producto
				//	PopProduccion.ShowOnPageLoad = false;
				//	if (boolEjecutarProceso)
				//	{
				//		var DsetDatos = _cPersonales.GetDatasetProcedimiento(strDatosProducto[1],
				//			new List<Agente.ServicioPersonales.CParameter>() {
				//				new Agente.ServicioPersonales.CParameter() { Key = "@PERIODO_CONTABLE", Value = _strPeriodoContable },
				//				new Agente.ServicioPersonales.CParameter() { Key = "@USUARIO", Value = _objUsuario.Matricula } });
				//		//string[] datosPagina = Request.CurrentExecutionFilePath.Split('/');
				//		//string ruta = string.Empty;
				//		//for (int index = 1; index < datosPagina.Length - 1; index++)
				//		//{
				//		//    if (ruta != string.Empty) { ruta += "/"; }
				//		//    ruta += datosPagina[index];
				//		//}
				//		//string pagina = datosPagina[datosPagina.Length - 1];
				//		//Conversor.RegistrarLogProcedimiento(ruta, pagina, nombreProcedimiento, _user.UserId);//log
				//		PopProduccion.ShowOnPageLoad = false;
				//		CargaInicial();
				//		//LoadingPanel.Visible = false;
				//		//PnlMessageSuccess.Visible = true;
				//		//LblMessageSuccess.Text = "El proceso de producción del producto seleccionado ha finalizado con éxito.";
				//		ScriptManager.RegisterStartupScript(this, typeof(Page), "PRD", "toastr.success('El proceso de producción del producto seleccionado ha finalizado con éxito.', 'PRODUCCIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
				//	}
				//	else
				//	{
				//		ScriptManager.RegisterStartupScript(this, typeof(Page), "001",
				//			"toastr.error('" + strMensaje + "', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
				//	}
				//}
				//else
				//	ScriptManager.RegisterStartupScript(this, typeof(Page), "999", "toastr.error('La producción no puede ejecutarse en un periodo contable diferente al establecido para el mes en curso.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		#endregion
	}
}