﻿using Agente.ServicioDocumentos;
using Agente.ServicioGenerales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class archivos_regulatorios : SesionUsuario
    {
        private static string _strMesProduccion;
        private readonly CGenerales _cGenerales = new CGenerales();
        private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
        private readonly CArchivosRegulatorios _cArchivosRegulatorios = new CArchivosRegulatorios();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strIdArchivoContabilidad = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }

        private void CargaInicial()
        {
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
            var lstArchivoContableCargado = _cGenerales.GetArchivoContableCargado(_strMesProduccion);
            Session["ARCHIVO_PERIODO_CONTABLE"] = lstArchivoContableCargado;
            GrvArchivoContable.DataSource = lstArchivoContableCargado;
            GrvArchivoContable.DataBind();
        }

        protected void GrvArchivoContable_PreRender(object sender, EventArgs e)
        {
            try
            {
                foreach (GridViewRow row in GrvArchivoContable.Rows)
                {
                    Image ImgCargaCompleta = (Image)row.FindControl("ImgCargaCompleta");
                    Image ImgCargaIncompleta = (Image)row.FindControl("ImgCargaIncompleta");
                    Image ImgArchivo = (Image)row.FindControl("ImgArchivo");
                    Label LblCarga = (Label)row.FindControl("LblCarga");

                    if (LblCarga.Text == "1")
                    {
                        ImgCargaCompleta.Visible = true;
                        ImgCargaIncompleta.Visible = false;

                        btnPartesProduccionBolivianos.ClientEnabled = true;
                        btnPartesProduccionDolares.ClientEnabled = true;
                        btnPartesProduccionRamos.ClientEnabled = true;
                        btnPartesSiniestrosBolivianos.ClientEnabled = true;
                        btnPartesSiniestrosDolares.ClientEnabled = true;
                        btnPartesSiniestrosRamos.ClientEnabled = true;
                        btnPartesProducciontxt.ClientEnabled = true;
                        btnPartesSiniestrosTrimestralGenerales.ClientEnabled = true;
                        btnPartesProduccionGenerales.ClientEnabled = true;
                        btnPartesSiniestrosGenerales.ClientEnabled = true;
                        BtnAnexo1.ClientEnabled = true;
                        BtnAnexo2.ClientEnabled = true;                        
                        BtnAnexo5.ClientEnabled = true;
                    }
                    else
                    {
                        ImgCargaCompleta.Visible = false;
                        ImgCargaIncompleta.Visible = true;

                        btnPartesProduccionBolivianos.ClientEnabled = false;
                        btnPartesProduccionDolares.ClientEnabled = false;
                        btnPartesProduccionRamos.ClientEnabled = false;
                        btnPartesSiniestrosBolivianos.ClientEnabled = false;
                        btnPartesSiniestrosDolares.ClientEnabled = false;
                        btnPartesSiniestrosRamos.ClientEnabled = false;
                        btnPartesProducciontxt.ClientEnabled = false;
                        btnPartesSiniestrosTrimestralGenerales.ClientEnabled = false;
                        btnPartesProduccionGenerales.ClientEnabled = false;
                        btnPartesSiniestrosGenerales.ClientEnabled = false;
                        BtnAnexo1.ClientEnabled = false;
                        BtnAnexo2.ClientEnabled = false;                        
                        BtnAnexo5.ClientEnabled = false;                        
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void GrvArchivoContable_RowCommand(Object sender, GridViewCommandEventArgs e)
        {
            try
            {
                GridViewRow gvr = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
                string LblIDArchivoCont = ((Label)gvr.FindControl("LblIDArchivoCont")).Text.Trim();
                //_strNameTableTemporal = LblIDArchivoCont;
                Session["strIdArchivoContabilidad"] = LblIDArchivoCont;
                switch (e.CommandName)
                {
                    case "CARGA":
                        UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".txt" };
                        PopCargarArchivo.HeaderText = "Cargar Archivo Contable";
                        PopCargarArchivo.ShowOnPageLoad = true;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["ARCHIVO_CARGADO"] = new ocp_archivo()
                {
                    ContentType = uploadedFile.ContentType,
                    Extension = fileInfo.Extension,
                    Nombre = uploadedFile.FileName,
                    FileStream = uploadedFile.FileContent,
                    ByteArray = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                string strFileExtension = string.Empty;
                var archivoCargado = (ocp_archivo)Session["ARCHIVO_CARGADO"];

                var objUsuarioLogin = (occ_usuario)Session["SessionUsuario"];

                if (_cArchivoProducto.GetValidFile(archivoCargado, "txt,csv", ref strFileExtension))
                {
                    VerificarArchivoCargado(archivoCargado, objUsuarioLogin.Matricula, ',');
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('El formato del Archivo no es valido.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
                    return;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

        private void VerificarArchivoCargado(ocp_archivo archivoCargado, string strUser, char chrSeparador)
        {
            _strIdArchivoContabilidad = (string)Session["strIdArchivoContabilidad"];
            var strNameTableTemporal = _strIdArchivoContabilidad;
            //List<string> linesError = null;
            var dtData = new DataTable();
            List<string> lstErroresArchivo = null;

            //Log.Debug("Action: Procesamiento del archivo TXT, CSV para su evaluacion ; Metod: btnUpload_Click");
            var lstColumnas = _cArchivosRegulatorios.GetListColumnasByArchivo(_strIdArchivoContabilidad);
            var lstErrors = _cArchivosRegulatorios.GetDatatableFileTxtFile(archivoCargado,
                           lstColumnas, ref dtData, ref lstErroresArchivo, chrSeparador);
            dtData.TableName = strNameTableTemporal;
            var prueba = new DataTable();

            const int intCantidadtrama = 10000;
            int cantfil = dtData.Rows.Count;
            int intTrama = cantfil / intCantidadtrama;
            int intTramaresiduo = cantfil % intCantidadtrama;
            if (intTramaresiduo != 0)
            {
                intTrama = intTrama + 1;
            }
            /* AGREGA COLUMNAS AL DATATABLE PARA ENVIO*/
            foreach (DataColumn data in dtData.Columns)
                prueba.Columns.Add(data.ColumnName, typeof(System.String));

            if (!_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
            {
                prueba.Columns.Add("APVC_ID_USER_INSERT", typeof(System.String));
                prueba.Columns.Add("APDT_FECHA_INSERT", typeof(System.String));
                prueba.Columns.Add("APVC_PERIODO", typeof(System.String));
            }
            int intIndex = 1;
            int intInicioData = 0;
            int intFinalData = intCantidadtrama;
            while (intIndex <= intTrama)
            {
                if (intIndex == intTrama)
                {
                    for (int i = intInicioData; i < cantfil; i++)
                    {
                        DataRow row = prueba.NewRow();
                        foreach (DataColumn datac in prueba.Columns)
                        {
                            string strValor = "";
                            if (_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
                            {
                                strValor = dtData.Rows[i][datac.ColumnName].ToString();
                                strValor = strValor.Replace("\"", "");

                                row[datac.ColumnName] = strValor;
                            }
                            else
                            {
                                switch (datac.ColumnName)
                                {
                                    case "APVC_ID_USER_INSERT":
                                        strValor = strUser;
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    case "APDT_FECHA_INSERT":
                                        strValor = DateTime.Today.ToString("yyyy-MM-dd");
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    case "APIN_Item":
                                        break;
                                    case "APVC_PERIODO":
                                        DateTime datPeriodo;
                                        bool bolRespuesta = DateTime.TryParseExact(_strMesProduccion, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datPeriodo);
                                        string strYear = datPeriodo.Year.ToString();
                                        string strMes = string.Format("{0:00}", datPeriodo.Month);
                                        strValor = strYear + strMes;
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    default:
                                        strValor = HttpUtility.HtmlDecode(dtData.Rows[i][datac.ColumnName].ToString());
                                        //strValor = strValor.Replace("\"", "");
                                        //strValor = strValor.Substring(1, strValor.Length - 1);
                                        row[datac.ColumnName] = strValor;
                                        break;

                                }
                            }
                        }
                        prueba.Rows.Add(row);
                    }
                }
                else
                {
                    for (int i = intInicioData; i < intFinalData; i++)
                    {
                        DataRow row = prueba.NewRow();
                        foreach (DataColumn datac in prueba.Columns)
                        {
                            string strValor = "";
                            if (_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
                            {
                                strValor = dtData.Rows[i][datac.ColumnName].ToString();
                                strValor = strValor.Replace("\"", "");

                                row[datac.ColumnName] = strValor;
                            }
                            else
                            {
                                switch (datac.ColumnName)
                                {
                                    case "APVC_ID_USER_INSERT":
                                        strValor = strUser;
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    case "APDT_FECHA_INSERT":
                                        strValor = DateTime.Today.ToString("yyyy-MM-dd");
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    case "APIN_Item":
                                        break;
                                    case "APVC_PERIODO":
                                        DateTime datPeriodo;
                                        bool bolRespuesta = DateTime.TryParseExact(_strMesProduccion, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out datPeriodo);
                                        string strYear = datPeriodo.Year.ToString();
                                        string strMes = string.Format("{0:00}", datPeriodo.Month);
                                        strValor = strYear + strMes;
                                        row[datac.ColumnName] = strValor;
                                        break;
                                    default:
                                        strValor = HttpUtility.HtmlDecode(dtData.Rows[i][datac.ColumnName].ToString());
                                        //strValor = strValor.Replace("\"", "");
                                        //strValor = strValor.Substring(1, strValor.Length - 1);
                                        row[datac.ColumnName] = strValor;
                                        break;
                                }
                            }
                        }
                        prueba.Rows.Add(row);
                    }
                }
                if (!_strIdArchivoContabilidad.Contains("CONTABILIDAD"))
                {
                    if (prueba.Columns.Contains("APIN_Item"))
                    {
                        prueba.Columns.Remove("APIN_Item");
                    }

                }
                bool oSaveArchivoRecibidoProcesoTxt = true;
                //bool oSaveArchivoRecibidoProcesoTxt = _cArchivosRegulatorios.SaveArchivoRecibido(strNameTableTemporal, prueba);
                if (oSaveArchivoRecibidoProcesoTxt)
                {
                    intIndex = intIndex + 1;
                    intInicioData = intFinalData;
                    intFinalData = intFinalData + intCantidadtrama;
                    prueba.Clear();
                }
            }

            ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.success('El registro del archivo contable ha sido completado con éxito.', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);

            PopCargarArchivo.HeaderText = string.Empty;
            PopCargarArchivo.ShowOnPageLoad = false;

            CargaInicial();
        }

        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }

        protected void BtnAnexo_Click(object sender, EventArgs e)
        {
            string strNumeroAnexo = ((BootstrapButton)sender).CommandName;
            try
            {
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                //_strMesProduccion = "202409";

                 var objLexico = _cGenerales.ListaLexicosPorTabla("MES_PRODUCCION");
                 string strPeriodoProceso = objLexico.Where(w => w.LEPVC_TEMA == "PROCESO").FirstOrDefault().LEPVC_VALOR.ToString();
                Session.Remove("DOWNLOAD");
                string strIdDocumento = string.Empty;
                switch (strNumeroAnexo)
                {
                    case "1": strIdDocumento = "AREG-011"; break;
                    case "2": strIdDocumento = "AREG-012"; break;
                    case "5": strIdDocumento = "AREG-013"; break;
                }
                var objDocumento = _cGenerales.GetReporteRegulatorioTXT(
                    strIdDocumento,
                    new List<Agente.ServicioGenerales.Parameter>() {
                        new Agente.ServicioGenerales.Parameter() { Key = "@MES_PRODUCCION", Value = _strMesProduccion },
                        new Agente.ServicioGenerales.Parameter() { Key = "@FLAG_REPROCESO", Value = (_strMesProduccion == strPeriodoProceso) ? true : false }
                    },
                    new occ_archivo_respuesta() { Nombre = "Anexo" + strNumeroAnexo, CarpetaSalida = string.Empty, BoolHistorico = (_strMesProduccion == strPeriodoProceso) ? true : false, FormatoSalida = "TXT" });
                if (objDocumento != null)
                {
                    string strRutaArchivoEnc = System.Text.Encoding.UTF8.GetString(System.Convert.FromBase64String(objDocumento.Ruta));
                    Session["DOWNLOAD"] = new ocp_archivo() { ByteArray = File.ReadAllBytes(strRutaArchivoEnc), ContentType = objDocumento.ContentType, Nombre = objDocumento.Nombre };
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.error('Se ha producido un error al obtener la información del reporte seleccionado.', 'VALIDACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
            }
            catch (Exception ex)
            {
               // Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }


        protected void btnExportarExcel_Click(object sender, EventArgs e)
        {
            string strArchivoNombre = ((BootstrapButton)sender).CommandName;
            try
            {
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                //_strMesProduccion = "202409";

                var periodo = DateTime.ParseExact(_strMesProduccion, "yyyyMM", CultureInfo.InvariantCulture, DateTimeStyles.None);
                periodo = periodo.AddMonths(1).AddDays(-1);

                occ_archivo_respuesta objArchivoRespuesta = null;

                string strNombreArchivo = string.Empty;
                string strArchivoExtension = string.Empty;
                switch (strArchivoNombre)
                {
                    case "RepPartesProdGeneralesBs":

                        strNombreArchivo = "Partes produccion generales Bs_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-001",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesProdGeneralesSus":

                        strNombreArchivo = "Partes produccion generales Sus_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-002",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesProdRamosGenerales":

                        strNombreArchivo = "Partes produccion ramos generales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-003",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesSiniestrosGeneralesBs":
                        strNombreArchivo = "Partes siniestros generales Bs_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-004",
                           new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesSiniestrosGeneralesSus":
                        strNombreArchivo = "Partes siniestros generales Sus_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-005",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "RepPartesSiniestrosRamosGenerales":
                        strNombreArchivo = "Partes siniestros ramos generales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".xlsx";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-006",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = periodo }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "EXCEL"
                            });

                        break;

                    case "PARTES_PRODUCCION_TRIMESTRAL_GENERALES":

                        strNombreArchivo = "Partes produccion trimestral_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-007",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = _strMesProduccion }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_SINIESTROS_TRIMESTRAL_GENERALES":

                        strNombreArchivo = "Partes siniestros trimestral_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-008",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = _strMesProduccion }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_PRODUCCION_GENERALES":

                        strNombreArchivo = "Partes produccion generales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-009",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = _strMesProduccion }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;

                    case "PARTES_SINIESTROS_GENERALES":

                        strNombreArchivo = "Partes siniestros generales_" + DateTime.Now.ToString("dd-MM-yyyy");
                        strArchivoExtension = ".txt";

                        objArchivoRespuesta = _cGenerales.GetReportesArchivosRegulatorios(
                            "AREG-010",
                            new List<Agente.ServicioGenerales.Parameter>() {
                                new Agente.ServicioGenerales.Parameter() { Key = "@FECHA_PERIODO", Value = _strMesProduccion }
                            },
                            new occ_archivo_respuesta()
                            {
                                Nombre = "Reporte_" + strNombreArchivo + strArchivoExtension,
                                CarpetaSalida = "",//_strPeriodoContable,
                                BoolHistorico = false,
                                FormatoSalida = "TXT"
                            });

                        break;
                }
                string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta));


                switch (objArchivoRespuesta.FormatoSalida)
                {
                    case "EXCEL":
                        Session["DOWNLOAD"] = new ocp_archivo()
                        {
                            ByteArray = File.ReadAllBytes(strRutaArchivoEnc),
                            ContentType = "application/vnd.ms-excel",
                            Nombre = strNombreArchivo + strArchivoExtension
                        };
                        break;
                    case "TXT":
                        Session["DOWNLOAD"] = new ocp_archivo()
                        {
                            ByteArray = File.ReadAllBytes(strRutaArchivoEnc),
                            ContentType = "text/plain",
                            Nombre = strNombreArchivo + strArchivoExtension
                        };
                        break;
                    default:
                        // code block
                        break;
                }

                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

    }
}