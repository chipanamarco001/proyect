﻿using Agente.ServicioGenerales;
using DevExpress.Spreadsheet;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.site.page
{
    public partial class cuadro_cierre : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                Session.Remove("DOWNLOAD");
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                ///iniciamos el boton de procesos contables
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
                BfaIniciarProceso.Visible = false;
                BtnDetalleConformidades.ClientVisible = false;
                var listaProcesosContables = _cGenerales.Contabilidad_ObtenerListaProcesosContablesCompletados(_strMesProduccion);                    
                if (!listaProcesosContables.Exists(x => x.PRPVC_TIPO == "MENSUAL" && x.PRPVC_ESTADO == "COMPLETADO"))
                {
                    var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                    if (objProceso == null)
                    {
                        bool boolIniciarProceso = false;
                        if (_objUsuario.Area == "OPERACIONES" && _objUsuario.Perfil == "CIERRE")
                            boolIniciarProceso = true;
                        if (_objUsuario.Area == "SISTEMAS" && _objUsuario.Perfil == "ADMIN")
                            boolIniciarProceso = true;
                        if (boolIniciarProceso)
                        {
                            var listaProductos = _cGenerales.Contabilidad_ObtenerListaProductosPorMes(_strMesProduccion);
                            Session["cuadro_cierre__listaProductos"] = listaProductos;
                            GrvProcesoParcial.DataBind();
                            BfaIniciarProceso.Visible = true;
                        }
                    }
                    else
                    {
                        BtnDetalleConformidades.ClientVisible = true;
                    }
                }
                ///obtenemos la informacion del cuadro de cierre
                var objResponse = _cGenerales.Conformidad_CuadroCierre(_strMesProduccion);
                var listaConfiguracionProducto = new List<ocp_configuracion_producto>();
                for (int index = 0; index < objResponse.Tables[0].Rows.Count; index++)
                {
                    listaConfiguracionProducto.Add(new ocp_configuracion_producto {
                        IdProducto = objResponse.Tables[0].Rows[index][0].ToString(),
                        Tipo = objResponse.Tables[0].Rows[index][1].ToString(),
                        Porcentaje = Convert.ToDecimal(objResponse.Tables[0].Rows[index][2].ToString()),
                        Formula = objResponse.Tables[0].Rows[index][3].ToString()
                    });
                }
                var listaCuadroCierre = new List<ocp_cuadro_cierre>();
                for (int index = 0; index < objResponse.Tables[1].Rows.Count; index++)
                {
                    listaCuadroCierre.Add(new ocp_cuadro_cierre
                    {
                        Ramo = objResponse.Tables[1].Rows[index][0].ToString(),
                        TipoTomador = objResponse.Tables[1].Rows[index][1].ToString(),
                        NitTomador = objResponse.Tables[1].Rows[index][2].ToString(),
                        NombreTomador = objResponse.Tables[1].Rows[index][3].ToString(),
                        NumeroPoliza = objResponse.Tables[1].Rows[index][4].ToString(),
                        IdProducto = objResponse.Tables[1].Rows[index][5].ToString(),
                        NombreProducto = objResponse.Tables[1].Rows[index][6].ToString(),
                        Moneda = objResponse.Tables[1].Rows[index][7].ToString(),                        
                        PrimaComercial = Convert.ToDecimal(objResponse.Tables[1].Rows[index][8].ToString()),
                        PrimaNeta = Convert.ToDecimal(objResponse.Tables[1].Rows[index][9].ToString()),
                        PrimaAdicional = Convert.ToDecimal(objResponse.Tables[1].Rows[index][10].ToString()),
                        ImporteIVA = Convert.ToDecimal(objResponse.Tables[1].Rows[index][11].ToString()),
                        ImporteIT = Convert.ToDecimal(objResponse.Tables[1].Rows[index][12].ToString()),
                        ComisionCobranza = Convert.ToDecimal(objResponse.Tables[1].Rows[index][13].ToString()),
                        AporteAPS = Convert.ToDecimal(objResponse.Tables[1].Rows[index][14].ToString()),
                        AporteFPA = Convert.ToDecimal(objResponse.Tables[1].Rows[index][15].ToString()),
                        SumaAsegurada = Convert.ToDecimal(objResponse.Tables[1].Rows[index][16].ToString()),
                        NombreBroker = objResponse.Tables[1].Rows[index][17].ToString(),
                        ComisionBroker = Convert.ToDecimal(objResponse.Tables[1].Rows[index][18].ToString()),
                        ///anulaciones
                        Anulacion = (objResponse.Tables[1].Rows[index][19].ToString().ToUpper() == "TRUE"),
                        AnulacionPrimaComercial = Convert.ToDecimal(objResponse.Tables[1].Rows[index][20].ToString()),
                        AnulacionPrimaNeta = Convert.ToDecimal(objResponse.Tables[1].Rows[index][21].ToString()),
                        AnulacionPrimaAdicional = Convert.ToDecimal(objResponse.Tables[1].Rows[index][22].ToString()),
                        AnulacionComisionBroker = Convert.ToDecimal(objResponse.Tables[1].Rows[index][23].ToString()),
                        ///cesion
                        NombreReasegurador = objResponse.Tables[1].Rows[index][24].ToString(),
                        PrimaCedida = Convert.ToDecimal(objResponse.Tables[1].Rows[index][25].ToString()),
                        ComisionReaseguro = Convert.ToDecimal(objResponse.Tables[1].Rows[index][26].ToString()),
                        SumaCedida = Convert.ToDecimal(objResponse.Tables[1].Rows[index][27].ToString()),
                        AnulacionPrimaCedida = Convert.ToDecimal(objResponse.Tables[1].Rows[index][28].ToString()),
                        AnulacionComisionReaseguro = Convert.ToDecimal(objResponse.Tables[1].Rows[index][29].ToString()),
                        AnulacionSumaCedida = Convert.ToDecimal(objResponse.Tables[1].Rows[index][30].ToString()),
                        ///reservas tecnicas
                        ConstitucionRRC = Convert.ToDecimal(objResponse.Tables[1].Rows[index][31].ToString()),
                        LiberacionRRC = Convert.ToDecimal(objResponse.Tables[1].Rows[index][32].ToString()),
                        PasivoRRC = Convert.ToDecimal(objResponse.Tables[1].Rows[index][33].ToString()),
                        ///parametrizacion
                        ListaConfiguracionProducto = listaConfiguracionProducto.Where(w => w.IdProducto == objResponse.Tables[1].Rows[index]["ID_PRODUCTO"].ToString()).ToList(),

                        DiferidoPrimaNeta = Convert.ToDecimal(objResponse.Tables[1].Rows[index][34].ToString()),
                        DiferidoPrimaAdicional = Convert.ToDecimal(objResponse.Tables[1].Rows[index][35].ToString())
                    });
                }
                Session["cuadro_cierre__lista"] = listaCuadroCierre;
                Session["cuadro_cierre__dataSet"] = objResponse;
                GrvProduccion.DataBind();
                GrvAnulaciones.DataBind();
                GrvCesion.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDescargar_Click(object sender, EventArgs e)
        {
            try
            {
                Session["DOWNLOAD"] = new ocp_archivo()
                {
                    ByteArray = Reporte(string.Empty),
                    ContentType = "application/vnd.ms-excel",
                    Nombre = "CUADRO_CIERRE_" + _strMesProduccion + ".xlsx"
                };
                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDetalleConformidades_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                if (objProceso != null)
                {
                    var objConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                    LblInicioProceso.Text = "El proceso de cierre ha iniciado el " + objProceso.PRSDT_FECHA_INSERT.ToString("dd/MM/yyyy HH:mm:ss");
                    Session["cuadro_cierre__detalleConformidades"] = objConformidades;
                    GrvConformidades.DataBind();
                    PopDetalleConformidades.ShowOnPageLoad = true;
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Info', 'Top right', 3000, 'DETALLE DE CONFORMIDADES', 'No existe un proceso contable activo, por lo que no se puede mostrar el detalle de conformidades.');", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["cuadro_cierre__detalleConformidades"] != null)
                {
                    var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["cuadro_cierre__detalleConformidades"];
                    GrvConformidades.DataSource = listaDetalleConformidades
                        .GroupBy(g => new {
                            g.NumeroNivel,
                            g.IdNivel,
                            g.IdGrupo,
                            g.DescripcionNivel,
                            g.DescripcionConformidad,
                            g.Estado,
                            g.IdUsuario,
                            g.FechaEstado
                        })
                        .Select(s => new occ_detalle_conformidades
                        {
                            NumeroNivel = s.Key.NumeroNivel,
                            IdNivel = s.Key.IdNivel,
                            IdGrupo = s.Key.IdGrupo,
                            DescripcionNivel = s.Key.DescripcionNivel,
                            DescripcionConformidad = s.Key.DescripcionConformidad,
                            Estado = s.Key.Estado,
                            IdUsuario = s.Key.IdUsuario,
                            FechaEstado = s.Key.FechaEstado
                        })
                        .OrderBy(o => o.NumeroNivel)
                        .ThenBy(o => o.IdGrupo)
                        .ToList();
                    GrvConformidades.Columns[8].Visible = false;
                    GrvConformidades.Columns[9].Visible = false;
                    if (_objUsuario == null)
                        _objUsuario = (occ_usuario)Session["SessionUsuario"];
                    if (listaDetalleConformidades.Where(w => w.NombreAutorizador.Contains(_objUsuario.Matricula) == true).Count() > 0)
                    {
                        GrvConformidades.Columns[8].Visible = true;
                        GrvConformidades.Columns[9].Visible = true;
                    }
                    if (!listaDetalleConformidades.Exists(eval => eval.Estado != "CONFORME"))
                    {
                        GrvConformidades.Columns[8].Visible = false;
                        GrvConformidades.Columns[9].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            var objKeyValue = (sender as BootstrapGridView).GetMasterRowKeyValue();
            var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["cuadro_cierre__detalleConformidades"];
            var GrvResponsables = (sender as BootstrapGridView);
            GrvResponsables.DataSource = listaDetalleConformidades
                .Where(w => w.IdGrupo == objKeyValue.ToString())
                .OrderByDescending(o => o.TipoUsuario)
                .ToList();
        }
        protected void BtnResponsable_Init(object sender, EventArgs e)
        {
            BootstrapButton BtnAccionesAutorizador = sender as BootstrapButton;
            var container = BtnAccionesAutorizador.NamingContainer as GridViewDataItemTemplateContainer;
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
            var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["cuadro_cierre__detalleConformidades"];
            string strIdNivel = DataBinder.Eval(container.DataItem, "IdNivel").ToString();
            string strIdGrupo = DataBinder.Eval(container.DataItem, "IdGrupo").ToString();
            string strEstado = DataBinder.Eval(container.DataItem, "Estado").ToString();
            BtnAccionesAutorizador.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
            BtnAccionesAutorizador.ClientVisible = false;
            if (strEstado == "PENDIENTE" || strEstado == "OBSERVADO")
            {
                if (listaDetalleConformidades.Exists(ex => ex.NombreAutorizador.Contains(_objUsuario.Matricula) == true && ex.IdNivel == strIdNivel && ex.IdGrupo == strIdGrupo))
                {
                    BtnAccionesAutorizador.ClientSideEvents.Click = null;
                    BtnAccionesAutorizador.ClientVisible = true;
                }
            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = ((BootstrapButton)sender).CommandArgument;
                string strIdNivel = ((BootstrapButton)sender).CommandName;
                string strIdControl = ((BootstrapButton)sender).ID;
                PopDetalleConformidades.ShowOnPageLoad = false;
                PopConformidad.ShowOnPageLoad = false;
                PopObservacion.ShowOnPageLoad = false;
                switch (strIdControl)
                {
                    case "BtnObservacion":
                        TxtObservacion.Text = null;
                        PopObservacion.ShowOnPageLoad = true;
                        break;
                    case "BtnConformidad":
                        LblUsuarioConfirmacion.Text = _objUsuario.NombreCompleto;
                        TxtPassword.Text = null;
                        PopConformidad.ShowOnPageLoad = true;
                        break;
                }
                Session["cuadro_cierre__IdGrupo"] = strIdGrupo;
                Session["cuadro_cierre__IdNivel"] = strIdNivel;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnObservar_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                string strIdGrupo = Session["cuadro_cierre__IdGrupo"].ToString();
                var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["cuadro_cierre__detalleConformidades"];
                var objDetalleConformidad = listaDetalleConformidades.Find(f => f.IdGrupo == strIdGrupo && f.NombreAutorizador.Contains(_objUsuario.Matricula) == true);
                CONFORMIDAD objConformidad = new CONFORMIDAD()
                {
                    COPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPBI_ID_PROCESO_CONTABLE = objProceso.PRPBI_ID_PROCESO_CONTABLE,
                    COPVC_ID_NIVEL = objDetalleConformidad.IdNivel,
                    COPVC_ID_GRUPO = objDetalleConformidad.IdGrupo,
                    COPVC_USUARIO = _objUsuario.Matricula,
                    COPVC_NOMBRE = _objUsuario.NombreCompleto,
                    COPVC_AREA = objDetalleConformidad.Area,
                    COPVC_PROCESO = objDetalleConformidad.DescripcionNivel + ": " + objDetalleConformidad.DescripcionConformidad,
                    COPVC_ESTADO = "OBSERVADO",
                    COPVC_OBSERVACION = TxtObservacion.Text.Trim().ToUpper()
                };
                CorreoObservacionRegistrada(strIdGrupo);
                _cGenerales.Conformidad_Registrar(objConformidad);
                PopObservacion.ShowOnPageLoad = false;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Warning', 'Top right', 3000, 'OBSERVACIÓN REGISTRADA', 'Se ha registrado la observación y se ha notificado a las áreas responsables para su revisión.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CbPassword_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            if (_objUsuario == null)
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
            string strIdUsuario = _objUsuario.Matricula;
            string strPasswordUsuario = TxtPassword.Text.Trim();
            e.Result = "false";
            if (_cGenerales.ValidarAutenticacion(strIdUsuario, strPasswordUsuario))
                e.Result = "true";
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                string strIdGrupo = Session["cuadro_cierre__IdGrupo"].ToString();
                var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["cuadro_cierre__detalleConformidades"];
                var objDetalleConformidad = listaDetalleConformidades.Find(f => f.IdGrupo == strIdGrupo && f.NombreAutorizador.Contains(_objUsuario.Matricula) == true);                
                ///registrmos la conformidad
                CONFORMIDAD objConformidad = new CONFORMIDAD()
                {
                    COPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPBI_ID_PROCESO_CONTABLE = objProceso.PRPBI_ID_PROCESO_CONTABLE,
                    COPVC_ID_NIVEL = objDetalleConformidad.IdNivel,
                    COPVC_ID_GRUPO = objDetalleConformidad.IdGrupo,
                    COPVC_USUARIO = _objUsuario.Matricula,
                    COPVC_NOMBRE = _objUsuario.NombreCompleto,
                    COPVC_AREA = objDetalleConformidad.Area,
                    COPVC_PROCESO = objDetalleConformidad.DescripcionNivel + ": " + objDetalleConformidad.DescripcionConformidad,
                    COPVC_ESTADO = "CONFORME",
                    COPVC_OBSERVACION = TxtComentarioConformidad.Text.Trim().ToUpper()
                };
                CorreoConformidadRegistrada(strIdGrupo);
                _cGenerales.Conformidad_Registrar(objConformidad);
                PopConformidad.ShowOnPageLoad = false;
                ///envio de correo para nuevo nivel
                listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                int intNumeroNivelActual = listaDetalleConformidades.Where(w => w.IdNivel == objDetalleConformidad.IdNivel).First().NumeroNivel;
                if (listaDetalleConformidades.Where(w => w.IdNivel == objDetalleConformidad.IdNivel && w.Estado != "CONFORME").ToList().Count == 0)
                {
                    int intNuevoNumeroNivel = intNumeroNivelActual + 1;
                    if (listaDetalleConformidades.Where(w => w.NumeroNivel == intNuevoNumeroNivel).ToList().Count > 0)
                    {
                        var listaLexico = ObtieneLexicos();
                        var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                        List<string> listaMailTO = new List<string>();
                        foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.NumeroNivel == intNuevoNumeroNivel))
                        {
                            var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                            if (objUsuario != null)
                                listaMailTO.Add(objUsuario.USPVC_CORREO);
                        }
                        string strIdNivel = listaDetalleConformidades.Where(w => w.NumeroNivel == intNuevoNumeroNivel).First().IdNivel;
                        List<string> listaMailCC = new List<string>();
                        var strListaCorreoCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1;
                        if (!string.IsNullOrEmpty(strListaCorreoCC))
                            listaMailCC = strListaCorreoCC.Split(';').ToList();
                        string strDescripcionNivel = listaDetalleConformidades.Where(w => w.NumeroNivel == intNuevoNumeroNivel).First().DescripcionNivel;
                        string strTextoParcial = string.Empty;
                        if (objProceso.PRPVC_TIPO == "PARCIAL")
                        {
                            var listaProductos = _cGenerales.Contabilidad_ObtenerListaProductosPorMes(_strMesProduccion);
                            var listaParametros = JsonConvert.DeserializeObject<List<ocp_parametro_proceso_contable>>(objProceso.PRSVC_PARAMETROS);
                            foreach (var objParametro in listaParametros)
                            {
                                var objProducto = listaProductos.Find(f => f.ID_PRODUCTO == objParametro.ID_PRODUCTO);
                                strTextoParcial += "<li>" + objProducto.ID_PRODUCTO + " - " + objProducto.NOMBRE_COMERCIAL + "</li>";
                            }
                        }
                        else
                        {
                            strTextoParcial += "<li>Todos los productos y movimientos de producción que no hayan sido evaluados en los procesos parciales ejecutados en el mes.</li>";
                        }
                        DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                        string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-habilitacion-nivel.html"));                        
                        strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                        strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                        strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                        strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                        strHtml = strHtml.Replace("#DESCRIPCION#", strTextoParcial);
                        var objCorreo = correo.Enviar(new ocp_correo
                        {
                            ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                            ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                            Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | HABILITACIÓN | " + strDescripcionNivel,
                            Prioridad = System.Net.Mail.MailPriority.High,
                            Contenido = strHtml,
                            FlagHtml = true,
                            ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                        });
                        BfaIniciarProceso.Visible = false;
                        CargaInicial();
                    }
                    
                }
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Success', 'Top right', 3000, 'CONFORMIDAD REGISTRADA', 'Se ha registrado exitosamente la conformidad en el proceso de cierre.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoConformidadRegistrada(string strIdGrupo)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var listaLexico = ObtieneLexicos();
                var listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                string strIdNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().IdNivel;
                string strDescripcionNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionNivel;
                string strDescripcionConformidad = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionConformidad;
                List<string> listaMailTO = new List<string>();
                foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.IdNivel == strIdNivel))
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                var listaMailCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1.Split(';').ToList();
                DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-autorizacion.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#COMENTARIO#", TxtComentarioConformidad.Text.Trim().ToUpper());
                var objCorreo = correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | CONFORMIDAD | " + strDescripcionNivel + " | " + strDescripcionConformidad,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoObservacionRegistrada(string strIdGrupo)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var listaLexico = ObtieneLexicos();
                var listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                string strIdNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().IdNivel;
                string strDescripcionNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionNivel;
                string strDescripcionConformidad = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionConformidad;
                List<string> listaMailTO = new List<string>();
                var listaCorreoLexicoTO = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_2.Split(';').Distinct().ToList();
                listaMailTO = listaCorreoLexicoTO;
                List<string> listaMailCC = new List<string>();
                foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.IdNivel == strIdNivel))
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                    if (objUsuario != null)
                        listaMailCC.Add(objUsuario.USPVC_CORREO);
                }
                var listaCorreoLexicoCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1.Split(';').Distinct().ToList();
                foreach (var strCorreoLexicoCC in listaCorreoLexicoCC)
                    if (listaCorreoLexicoTO.FirstOrDefault(f => f.Contains(strCorreoLexicoCC)) == null)
                        listaMailCC.Add(strCorreoLexicoCC);
                DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-observacion.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#OBSERVACION#", TxtObservacion.Text.Trim().ToUpper());
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                var objCorreo = correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | OBSERVACIÓN | " + strDescripcionNivel + " | " + strDescripcionConformidad,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProduccion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaCuadroCierre = (List<ocp_cuadro_cierre>)Session["cuadro_cierre__lista"];
                GrvProduccion.DataSource =
                    listaCuadroCierre
                    .Where(w => w.PrimaComercial > 0)
                    .GroupBy(g => new
                    {
                        g.Ramo,
                        g.IdProducto,
                        g.NombreProducto,
                        g.Moneda
                    })
                    .Select(s => new ocp_cuadro_cierre
                    {
                        Ramo = s.Key.Ramo,
                        IdProducto = s.Key.IdProducto,
                        NombreProducto = s.Key.NombreProducto,
                        Moneda = s.Key.Moneda,
                        PrimaComercial = s.Sum(v => v.PrimaComercial),
                        PrimaNeta = s.Sum(v => v.PrimaNeta),
                        PrimaAdicional = s.Sum(v => v.PrimaAdicional),
                        ImporteIVA = s.Sum(v => v.ImporteIVA),                        
                        ImporteIT = s.Sum(v => v.ImporteIT),
                        ComisionCobranza = s.Sum(v => v.ComisionCobranza),
                        ComisionBroker = s.Sum(v => v.ComisionBroker),
                        AporteAPS = s.Sum(v => v.AporteAPS),
                        AporteFPA = s.Sum(v => v.AporteFPA),
                        SumaAsegurada = s.Sum(v => v.SumaAsegurada),
                        DiferidoPrimaNeta = s.Sum(v => v.DiferidoPrimaNeta),
                        DiferidoPrimaAdicional = s.Sum(v => v.DiferidoPrimaAdicional)
                    })
                    .OrderBy(o => o.Ramo)
                    .ThenBy(o => o.IdProducto)
                    .ThenBy(o => o.Moneda)
                    .ToList();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAnulaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaCuadroCierre = (List<ocp_cuadro_cierre>)Session["cuadro_cierre__lista"];
                GrvAnulaciones.DataSource =
                    listaCuadroCierre
                    .Where(w => w.Anulacion == true)
                    .GroupBy(g => new
                    {
                        g.Ramo,
                        g.IdProducto,
                        g.NombreProducto,
                        g.Moneda
                    })
                    .Select(s => new ocp_cuadro_cierre
                    {
                        Ramo = s.Key.Ramo,
                        IdProducto = s.Key.IdProducto,
                        NombreProducto = s.Key.NombreProducto,
                        Moneda = s.Key.Moneda,
                        AnulacionPrimaComercial = s.Sum(v => v.AnulacionPrimaComercial),
                        AnulacionPrimaNeta = s.Sum(v => v.AnulacionPrimaNeta),
                        AnulacionPrimaAdicional = s.Sum(v => v.AnulacionPrimaAdicional),
                        AnulacionComisionBroker = s.Sum(v => v.AnulacionComisionBroker)
                    })
                    .OrderBy(o => o.Ramo)
                    .ThenBy(o => o.IdProducto)
                    .ThenBy(o => o.Moneda)
                    .ToList();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvCesion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var listaCuadroCierre = (List<ocp_cuadro_cierre>)Session["cuadro_cierre__lista"];
                GrvCesion.DataSource =
                    listaCuadroCierre
                    .Where(w => string.IsNullOrEmpty(w.NombreReasegurador) == false)
                    .GroupBy(g => new
                    {
                        g.Ramo,
                        g.IdProducto,
                        g.NombreProducto,
                        g.Moneda,
                        g.NombreReasegurador
                    })
                    .Select(s => new ocp_cuadro_cierre
                    {
                        Ramo = s.Key.Ramo,
                        IdProducto = s.Key.IdProducto,
                        NombreProducto = s.Key.NombreProducto,
                        Moneda = s.Key.Moneda,
                        NombreReasegurador = s.Key.NombreReasegurador,
                        PrimaCedida = s.Sum(v => v.PrimaCedida),
                        ComisionReaseguro = s.Sum(v => v.ComisionReaseguro),
                        SumaCedida = s.Sum(v => v.SumaCedida),
                        AnulacionPrimaCedida = s.Sum(v => v.AnulacionPrimaCedida),
                        AnulacionComisionReaseguro = s.Sum(v => v.AnulacionComisionReaseguro),
                        AnulacionSumaCedida = s.Sum(v => v.AnulacionSumaCedida)
                    })
                    .OrderBy(o => o.Ramo)
                    .ThenBy(o => o.IdProducto)
                    .ThenBy(o => o.Moneda)
                    .ToList();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }       
        protected void BtnAccion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccion.Contains("IdProducto") && HidAccion.Contains("Tipo"))
                {
                    var strIdProducto = HidAccion["IdProducto"].ToString();
                    var strTipo = HidAccion["Tipo"].ToString();
                    var listaCuadroCierre = (List<ocp_cuadro_cierre>)Session["cuadro_cierre__lista"];
                    switch (strTipo)
                    {
                        case "ConfiguracionP":
                        case "ConfiguracionA":
                        case "ConfiguracionC":
                        case "ConfiguracionR":
                            var objCuadroCierre = listaCuadroCierre.Where(w => w.IdProducto == strIdProducto).First();
                            GrvParametros.DataSource = objCuadroCierre.ListaConfiguracionProducto;
                            GrvParametros.DataBind();
                            PopParametros.HeaderText = "PARAMETRIZACIÓN: " + objCuadroCierre.IdProducto + " - " + objCuadroCierre.NombreProducto;
                            PopParametros.ShowOnPageLoad = true;
                            break;
                        case "DetalleP":
                        case "DetalleA":
                        case "DetalleC":
                        case "DetalleR":
                            Session["DOWNLOAD"] = new ocp_archivo()
                            {
                                ByteArray = Reporte(strIdProducto),
                                ContentType = "application/vnd.ms-excel",
                                Nombre = "CUADRO_CIERRE_" + _strMesProduccion + ".xlsx"
                            };
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected byte[] Reporte(string strIdProducto)
        {
            try
            {
                string strRutaPlantilla = Server.MapPath("~/assets/tpl/cuadro-cierre.xlsx");
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Producción")
                    {
                        DataTable DtblProduccion = ((DataSet)Session["cuadro_cierre__dataSet"]).Tables[1].Copy();
                        DtblProduccion.Columns.Remove("ANULADO");
                        DtblProduccion.Columns.Remove("ANULACION_PRIMA_COMERCIAL");
                        DtblProduccion.Columns.Remove("ANULACION_PRIMA_NETA");
                        DtblProduccion.Columns.Remove("ANULACION_PRIMA_ADICIONAL");
                        DtblProduccion.Columns.Remove("ANULACION_COMISION_BROKER");
                        DtblProduccion.Columns.Remove("NOMBRE_REASEGURADOR");
                        DtblProduccion.Columns.Remove("PRIMA_CEDIDA");
                        DtblProduccion.Columns.Remove("COMISION_REASEGURO");
                        DtblProduccion.Columns.Remove("SUMA_CEDIDA");
                        DtblProduccion.Columns.Remove("ANULACION_PRIMA_CEDIDA");
                        DtblProduccion.Columns.Remove("ANULACION_COMISION_REASEGURO");
                        DtblProduccion.Columns.Remove("ANULACION_SUMA_CEDIDA");
                        DtblProduccion.Columns.Remove("RRC_CONSTITUCION");
                        DtblProduccion.Columns.Remove("RRC_LIBERACION");
                        DtblProduccion.Columns.Remove("RRC_PASIVO");
                        DataView dvProduccion = new DataView(DtblProduccion);
                        dvProduccion.RowFilter = "PRIMA_COMERCIAL > 0" + ((strIdProducto != string.Empty) ? "AND ID_PRODUCTO = '" + strIdProducto + "'" : string.Empty);
                        dvProduccion.Sort = "RAMO, ID_PRODUCTO, MONEDA, NUMERO_POLIZA";
                        DEWorksheet.Import(dvProduccion.ToTable(), false, 1, 0);
                        DEWorksheet.Range["A1:S" + (dvProduccion.ToTable().Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Anulación")
                    {
                        DataTable DtblAnulacion = ((DataSet)Session["cuadro_cierre__dataSet"]).Tables[1].Copy();
                        DtblAnulacion.Columns.Remove("PRIMA_COMERCIAL");
                        DtblAnulacion.Columns.Remove("PRIMA_NETA");
                        DtblAnulacion.Columns.Remove("PRIMA_ADICIONAL");
                        DtblAnulacion.Columns.Remove("IMPORTE_IVA");
                        DtblAnulacion.Columns.Remove("IMPORTE_IT");
                        DtblAnulacion.Columns.Remove("COMISION_COBRANZA");
                        DtblAnulacion.Columns.Remove("APORTE_APS");
                        DtblAnulacion.Columns.Remove("APORTE_FPA");
                        DtblAnulacion.Columns.Remove("SUMA_ASEGURADA");
                        DtblAnulacion.Columns.Remove("COMISION_BROKER");
                        DtblAnulacion.Columns.Remove("NOMBRE_REASEGURADOR");
                        DtblAnulacion.Columns.Remove("PRIMA_CEDIDA");
                        DtblAnulacion.Columns.Remove("COMISION_REASEGURO");
                        DtblAnulacion.Columns.Remove("SUMA_CEDIDA");
                        DtblAnulacion.Columns.Remove("ANULACION_PRIMA_CEDIDA");
                        DtblAnulacion.Columns.Remove("ANULACION_COMISION_REASEGURO");
                        DtblAnulacion.Columns.Remove("ANULACION_SUMA_CEDIDA");
                        DtblAnulacion.Columns.Remove("RRC_CONSTITUCION");
                        DtblAnulacion.Columns.Remove("RRC_LIBERACION");
                        DtblAnulacion.Columns.Remove("RRC_PASIVO");
                        DtblAnulacion.Columns["NOMBRE_BROKER"].SetOrdinal(12);
                        DataView dvAnulacion = new DataView(DtblAnulacion);
                        dvAnulacion.RowFilter = "ANULADO = 1" + ((strIdProducto != string.Empty) ? "AND ID_PRODUCTO = '" + strIdProducto + "'" : string.Empty);
                        dvAnulacion.Sort = "RAMO, ID_PRODUCTO, MONEDA, NUMERO_POLIZA";
                        DEWorksheet.Import(dvAnulacion.ToTable(), false, 1, 0);
                        DEWorksheet.Columns.Remove(8);
                        DEWorksheet.Range["A1:M" + (dvAnulacion.ToTable().Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Cesión a Reaseguro")
                    {
                        DataTable DtblCesion = ((DataSet)Session["cuadro_cierre__dataSet"]).Tables[1].Copy();
                        DtblCesion.Columns.Remove("PRIMA_COMERCIAL");
                        DtblCesion.Columns.Remove("PRIMA_NETA");
                        DtblCesion.Columns.Remove("PRIMA_ADICIONAL");
                        DtblCesion.Columns.Remove("IMPORTE_IVA");
                        DtblCesion.Columns.Remove("IMPORTE_IT");
                        DtblCesion.Columns.Remove("COMISION_COBRANZA");
                        DtblCesion.Columns.Remove("APORTE_APS");
                        DtblCesion.Columns.Remove("APORTE_FPA");
                        DtblCesion.Columns.Remove("SUMA_ASEGURADA");
                        DtblCesion.Columns.Remove("NOMBRE_BROKER");
                        DtblCesion.Columns.Remove("COMISION_BROKER");
                        DtblCesion.Columns.Remove("ANULADO");
                        DtblCesion.Columns.Remove("ANULACION_PRIMA_COMERCIAL");
                        DtblCesion.Columns.Remove("ANULACION_PRIMA_NETA");
                        DtblCesion.Columns.Remove("ANULACION_PRIMA_ADICIONAL");
                        DtblCesion.Columns.Remove("ANULACION_COMISION_BROKER");
                        DtblCesion.Columns.Remove("RRC_CONSTITUCION");
                        DtblCesion.Columns.Remove("RRC_LIBERACION");
                        DtblCesion.Columns.Remove("RRC_PASIVO");
                        DataView dvCesion = new DataView(DtblCesion);
                        dvCesion.RowFilter = "PRIMA_CEDIDA > 0" + ((strIdProducto != string.Empty) ? "AND ID_PRODUCTO = '" + strIdProducto + "'" : string.Empty);
                        dvCesion.Sort = "RAMO, ID_PRODUCTO, MONEDA, NUMERO_POLIZA";
                        DEWorksheet.Import(dvCesion.ToTable(), false, 1, 0);
                        DEWorksheet.Range["A1:O" + (dvCesion.ToTable().Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Reservas Técnicas")
                    {
                        DataTable DtblReservas = ((DataSet)Session["cuadro_cierre__dataSet"]).Tables[1].Copy();
                        DtblReservas.Columns.Remove("PRIMA_COMERCIAL");
                        DtblReservas.Columns.Remove("PRIMA_NETA");
                        DtblReservas.Columns.Remove("PRIMA_ADICIONAL");
                        DtblReservas.Columns.Remove("IMPORTE_IVA");
                        DtblReservas.Columns.Remove("IMPORTE_IT");
                        DtblReservas.Columns.Remove("COMISION_COBRANZA");
                        DtblReservas.Columns.Remove("APORTE_APS");
                        DtblReservas.Columns.Remove("APORTE_FPA");
                        DtblReservas.Columns.Remove("SUMA_ASEGURADA");
                        DtblReservas.Columns.Remove("NOMBRE_BROKER");
                        DtblReservas.Columns.Remove("COMISION_BROKER");
                        DtblReservas.Columns.Remove("ANULADO");
                        DtblReservas.Columns.Remove("ANULACION_PRIMA_COMERCIAL");
                        DtblReservas.Columns.Remove("ANULACION_PRIMA_NETA");
                        DtblReservas.Columns.Remove("ANULACION_PRIMA_ADICIONAL");
                        DtblReservas.Columns.Remove("ANULACION_COMISION_BROKER");
                        DtblReservas.Columns.Remove("NOMBRE_REASEGURADOR");
                        DtblReservas.Columns.Remove("PRIMA_CEDIDA");
                        DtblReservas.Columns.Remove("COMISION_REASEGURO");
                        DtblReservas.Columns.Remove("SUMA_CEDIDA");
                        DtblReservas.Columns.Remove("ANULACION_PRIMA_CEDIDA");
                        DtblReservas.Columns.Remove("ANULACION_COMISION_REASEGURO");
                        DtblReservas.Columns.Remove("ANULACION_SUMA_CEDIDA");
                        DataView dvReservas = new DataView(DtblReservas);
                        dvReservas.RowFilter = ((strIdProducto != string.Empty) ? "ID_PRODUCTO = '" + strIdProducto + "'" : string.Empty);
                        dvReservas.Sort = "RAMO, ID_PRODUCTO, MONEDA, NUMERO_POLIZA";
                        DEWorksheet.Import(dvReservas.ToTable(), false, 1, 0);
                        DEWorksheet.Range["A1:K" + (dvReservas.ToTable().Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                    if (DEWorksheet.Name == "Parametrización")
                    {
                        DataTable DtblParametros = ((DataSet)Session["cuadro_cierre__dataSet"]).Tables[0].Copy();
                        DataView dvParametros = new DataView(DtblParametros);
                        dvParametros.RowFilter = ((strIdProducto != string.Empty) ? "ID_PRODUCTO = '" + strIdProducto + "'" : string.Empty);
                        dvParametros.Sort = "ID_PRODUCTO, TIPO DESC";
                        DEWorksheet.Import(dvParametros.ToTable(), false, 1, 0);
                        DEWorksheet.Range["A1:D" + (dvParametros.ToTable().Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                    }
                }
                return DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
            }
            catch
            {
                throw;
            }
        }
        protected void GrvProcesoParcial_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["cuadro_cierre__listaProductos"] != null)
                {
                    var listaProductos = (List<SPR_LISTA_PRODUCTOS_Result>)Session["cuadro_cierre__listaProductos"];
                    GrvProcesoParcial.DataSource = listaProductos.OrderBy(o => o.ID_PRODUCTO).ToList();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnIniciarProceso_Click(object sender, EventArgs e)
        {
            try
            {
                PopConfirmarInicioProceso.ShowOnPageLoad = false;
                PopIniciarProceso.ShowOnPageLoad = false;
                string strTipoProceso = HidIniciarProceso.Value;
                string strTextoParcial = string.Empty;
                var objProcesoContable = new PROCESO_CONTABLE
                {
                    PRPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPIN_NUMERO = 0,
                    PRPVC_TIPO = strTipoProceso,
                    PRSVC_PARAMETROS = string.Empty,
                    PRPVC_ESTADO = "PENDIENTE"
                };
                if (strTipoProceso == "PARCIAL")
                {
                    var listaProductos = (List<SPR_LISTA_PRODUCTOS_Result>)Session["cuadro_cierre__listaProductos"];
                    string strParametros = string.Empty;
                    var listaProductosSeleccionados = GrvProcesoParcial.GetSelectedFieldValues("ID_PRODUCTO");
                    for (int index = 0; index < listaProductosSeleccionados.Count; index++)
                    {
                        strParametros += ((index > 0) ? "," : string.Empty) + "{\"ID_PRODUCTO\": \"" + listaProductosSeleccionados[index].ToString() + "\"}";
                        var objProducto = listaProductos.Find(f => f.ID_PRODUCTO == listaProductosSeleccionados[index].ToString());
                        strTextoParcial += "<li>" + objProducto.ID_PRODUCTO + " - " + objProducto.NOMBRE_COMERCIAL + "</li>";
                    }
                    objProcesoContable.PRSVC_PARAMETROS = "[" + strParametros + "]";
                }
                else
                    strTextoParcial += "<li>Todos los productos y movimientos de producción que no hayan sido evaluados en los procesos parciales ejecutados en el mes.</li>";
                _cGenerales.Contabilidad_RegistrarProcesoContable(objProcesoContable);
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var listaLexico = ObtieneLexicos();
                var listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                List<string> listaMailTO = new List<string>();
                foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.NumeroNivel == 1))
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                string strIdNivel = listaDetalleConformidades.Where(w => w.NumeroNivel == 1).First().IdNivel;
                List<string> listaMailCC = new List<string>();
                var strListaCorreoCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1;
                if (!string.IsNullOrEmpty(strListaCorreoCC))
                    listaMailCC = strListaCorreoCC.Split(';').ToList();
                string strDescripcionNivel = listaDetalleConformidades.Where(w => w.NumeroNivel == 1).First().DescripcionNivel;
                string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-inicio.html"));
                DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#DESCRIPCION#", strTextoParcial);
                var objCorreo = correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | HABILITACIÓN | " + strDescripcionNivel,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                });
                BfaIniciarProceso.Visible = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "003", "ShowToastr('Success', 'Top right', 3000, 'PROCESO DE CIERRE (" + _strMesProduccion + ")', 'El proceso de conformidades ha sido iniciado con éxito.');BfaIniciarProceso.SetVisible(false);", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}