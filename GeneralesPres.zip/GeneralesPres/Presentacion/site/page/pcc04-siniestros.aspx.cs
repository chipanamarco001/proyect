﻿using Agente.ServicioCierre;
using Agente.ServicioDocumentos;
using DevExpress.Office.Services;
using DevExpress.Web.Office;
using DevExpress.XtraRichEdit;
using Microsoft.Reporting.WebForms;
using Presentacion.controllers;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
	public partial class pcc04_siniestros : System.Web.UI.Page
	{
		private CReserva _oReserva = new CReserva();
		private readonly CDocumentos _cDocumentos = new CDocumentos();
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				Session.Add("ESTADO", "PC004");
				CumulosPc004();
				//tbPc004.Attributes.Add("class", "active");
				//idPc004.Attributes.Add("class", "active");
				//grdDenunciasNew.Visible = false;
			}
		}
		private void CumulosPc004()
		{
			try
			{
				var lstCumuloPc004 = _oReserva.GetListCumulosPc004(Parametros.EntornoSiniestros);

				grdPc004.DataSource = lstCumuloPc004;
				grdPc004.DataBind();
			}
			catch (Exception e)
			{
				//Log.Error(e);
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se recopila información"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR EN BUSQUEDA', 'Algo pasó mientras se recopila información.');", true);
			}

		}

		protected void grdHistorialCommand(object sender, GridViewCommandEventArgs e)
		{
			string currentCommand = e.CommandName;
			string currentRowIndex = e.CommandArgument.ToString().Trim();
			string[] words = currentRowIndex.Split(',');

			if (words.Length > 1)
			{
				string strIdDocumento = words[0];
				string strIdDenuncia = words[1];
				string strEstado = words[2];
				GetDocumentParametroResponse objWord = _cDocumentos.GetDocumentParametro(strIdDocumento, strIdDenuncia, strEstado); // "RES-0001", "237", "RESERVA");
				Response.Clear();


				string[] nombreDoc = objWord.GetDocumentParametroResult.Name.Split('.');

				//var ms = new MemoryStream(objWord.GetDocumentParametroResult.arrbytes);
				////Response.ContentType = "application/pdf";
				//Response.ContentType = objWord.GetDocumentParametroResult.ContentType;
				//Response.AddHeader("content-disposition", "attachment;filename=" + strIdDenuncia + "." + nombreDoc[1]);
				//Response.Buffer = true;
				//ms.WriteTo(Response.OutputStream);
				//Response.End();

				if (objWord.GetDocumentParametroResult.ContentType == "application/pdf")
				{
					var streem = new MemoryStream(objWord.GetDocumentParametroResult.arrbytes);
					using (MemoryStream stream = new MemoryStream())
					{
						RichEditDocumentServer documentServer = CreateDocumentServer(streem);
						documentServer.ExportToPdf(stream);
						stream.Seek(0, SeekOrigin.Begin);
						stream.CopyTo(Response.OutputStream);
						Response.ContentType = objWord.GetDocumentParametroResult.ContentType;
						Response.AddHeader("Content-Disposition", String.Format("attachment; filename=" + strIdDocumento + "." + nombreDoc[1]));
						Response.End();
					}
				}
				else
				{
					var ms = new MemoryStream(objWord.GetDocumentParametroResult.arrbytes);
					Response.ContentType = objWord.GetDocumentParametroResult.ContentType;
					Response.AddHeader("content-disposition", "attachment;filename=" + objWord.GetDocumentParametroResult.Name);
					Response.Buffer = true;
					ms.WriteTo(Response.OutputStream);
					Response.End();
				}
			}

		}


		protected void btnCompletar_OnClick(object sender, EventArgs e)
		{
			try
			{
				var btnEditColumn = (Button)sender;
				var Ids = btnEditColumn.CommandArgument.Split('|');

				Session.Add("PC004_ID_AFILIACION", Ids[0]);
				Session.Add("PC004_ID_DENUNCIA", Ids[1]);
				Session.Add("PC004_ID_CUMULO", Ids[2]);
				Session.Add("PC004_ID_CONTEXTO", Ids[3]);
				Response.Redirect("~/site/page/FormularioPC004Sin.aspx");
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se recopila información"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'Algo pasó mientras se recopila información.');", true);
			}

		}

		protected void btnDocumento_Click(object sender, EventArgs e)
		{
			try
			{
				var btnEditColumn = (Button)sender;
				var IdFormulario = btnEditColumn.CommandArgument;

				var data = _oReserva.GetDataDocumentoFormulario(long.Parse(IdFormulario), Presentacion.libs.Parametros.EntornoSiniestros);


				// Variables   
				Warning[] warnings;
				string[] streamIds;
				string mimeType = string.Empty;
				string encoding = string.Empty;
				string extension = string.Empty;

				// Create Report DataSource
				ReportDataSource rds = new ReportDataSource("PC004", data);

				// Setup the report viewer object and get the array of bytes   
				ReportViewer viewer = new ReportViewer();
				viewer.ProcessingMode = ProcessingMode.Local;
				viewer.LocalReport.ReportPath = Server.MapPath(@"../Reporte/UIF_PC004/rptFormularioPC004.rdlc");
				viewer.LocalReport.DataSources.Add(rds); // Add datasource here
				viewer.LocalReport.EnableExternalImages = true;

				//var strImagenReceptor = new Uri(Server.MapPath(@"../Reporte/UIF_PC004/ARCAINE SAMOLENKO CLAUDIA.png")).AbsoluteUri;
				//var strImagenSupervisor = new Uri(Server.MapPath(@"../Reporte/UIF_PC004/NORIEGA PALENQUE DIEGO.png")).AbsoluteUri;

				var strImagenReceptor = new Uri(Server.MapPath(@"../Reporte/UIF_PC004/" + data.FirstOrDefault().FUVC_NOMBRE_FUNCIONARIO_RECEPTOR + ".png")).AbsoluteUri;
				var strImagenSupervisor = new Uri(Server.MapPath(@"../Reporte/UIF_PC004/" + data.FirstOrDefault().FUVC_NOMBRE_SUPERVISOR + ".png")).AbsoluteUri;


				ReportParameter[] Parametros = new ReportParameter[2];
				Parametros[0] = new ReportParameter("IMAGE_RECEPTOR", strImagenReceptor);
				Parametros[1] = new ReportParameter("IMAGE_SUPERVISOR", strImagenSupervisor);
				//ReportParameter parameter = new ReportParameter("ImagePath", imagePath);
				viewer.LocalReport.SetParameters(Parametros);

				byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

				// Now that you have all the bytes representing the PDF report, buffer it and send it to the client.   
				Response.Buffer = true;
				Response.Clear();
				Response.ContentType = mimeType;
				Response.AddHeader("content-disposition", "attachment; filename=Formulario." + extension);
				Response.BinaryWrite(bytes); // create the file   
				Response.Flush(); // send it to the client to download   


			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se genera el documento"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'Algo pasó mientras se recopila información.');", true);
			}
		}

		protected void btnModificar_Click(object sender, EventArgs e)
		{
			var btnEditColumn = (Button)sender;
			var IdFormulario = btnEditColumn.CommandArgument;
			Session.Add("PC004_ID_FORMULARIO", IdFormulario);
			Response.Redirect("~/site/page/EditarFormularioPC004Sin.aspx");
		}

		protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
		{
			//grdDenuncias.PageIndex = e.NewPageIndex;
			//this.GetListDenunciaByPage(e.NewPageIndex);
		}

		protected void grdPc004_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{

				var flag = (Label)e.Row.FindControl("lblFlagCompleto");
				var reporte = (Button)e.Row.FindControl("btnDocumento");
				var editar = (Button)e.Row.FindControl("btnEdit");
				var modificar = (Button)e.Row.FindControl("btnModificar");

				if (flag.Text == "1")
				{
					reporte.Visible = true;
					editar.Visible = false;
					modificar.Visible = true;
				}

			}
		}

		RichEditDocumentServer CreateDocumentServer(Stream stream)
		{
			RichEditDocumentServer documentServer = new RichEditDocumentServer();
			documentServer.ReplaceService<IUriStreamService>(new ASPxOfficeUriStreamService());
			using (Stream documentStream = stream)
			{
				DevExpress.XtraRichEdit.DocumentFormat documentFormat = DevExpress.XtraRichEdit.DocumentFormat.OpenXml;
				documentServer.LoadDocument(documentStream, documentFormat);
			}
			documentServer.Options.Export.Html.EmbedImages = true;
			return documentServer;
		}

	}
}