﻿using DevExpress.Web;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.site.page
{
    public partial class firma_documentos : SesionUsuario
    {
        private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
        private readonly CGenerales _cGenerales = new CGenerales();
        private readonly CDocumentos _cDocumentos = new CDocumentos();
        private string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("ARCHIVO_CARGADO");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected void CargaInicial()
        {
            var DatosFirma = _cGenerales.ListaLexicosPorTablaYTema("FIRMA_DIGITAL", "GENERALES");
            var DatosFirmaOrdenados = DatosFirma.OrderBy(d => d.LEPVC_VALOR).ToList();

            if (DatosFirmaOrdenados.Any())
            {
                FirmaNombreA.Text = DatosFirmaOrdenados.First().LESVC_DESCRIPCION_1;
                FirmaNombreB.Text = DatosFirmaOrdenados[1].LESVC_DESCRIPCION_1;
                FechaVencimientoA.Text = DatosFirmaOrdenados.First().LESVC_DESCRIPCION_2;
                FechaVencemientoB.Text = DatosFirmaOrdenados[1].LESVC_DESCRIPCION_2;
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["ARCHIVO_CARGADO"] = new ocp_archivo()
                {
                    ContentType = uploadedFile.ContentType,
                    Extension = fileInfo.Extension,
                    Nombre = uploadedFile.FileName,
                    FileStream = uploadedFile.FileContent,
                    ByteArray = uploadedFile.FileBytes
                };
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            CargarArchivo();
           
        }
        private void CargarArchivo()
        {
            try
            {
                string strFileExtension = string.Empty;
                var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];
                if (_cArchivoProducto.GetValidFile(fileUpload, "pdf", ref strFileExtension))
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                {
           
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "000", "ShowToastr('Warning', 'Top right', 3000, 'VALIDACION', 'El formato del Archivo no es .pdf .');", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["ARCHIVO_CARGADO"] != null)
            {
                var objArchivo = (ocp_archivo)Session["ARCHIVO_CARGADO"];
                byte[] result = _cDocumentos.FirmarDocumentos(objArchivo.ByteArray, _objUsuario.Matricula);
                Session.Remove("ARCHIVO_CARGADO");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(result);
                Response.Flush();
                Response.End();
            }
        }

    }
}