﻿using Agente.ServicioGenerales;
using DevExpress.Web;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.IO;
using System.Web.UI;
using DevExpress.Web.Bootstrap;
using DevExpress.Spreadsheet;
using System.Text.RegularExpressions;
using DevExpress.Web.Internal.Dialogs;

namespace Presentacion.site.page
{
    public partial class reportes_cumplimiento : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private static string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                //GrvDocumentos.DataBind();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        //protected void GrvDocumentos_DataBinding(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        string strJson = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "JSON" && w.LEPVC_TEMA == "REPORTES_CUMPLIMIENTO").First().LEPVC_VALOR;
        //        var listaReportes = JsonConvert.DeserializeObject<List<ocp_reportes_cumplimiento>>(strJson);
        //        Session["reportes_cumplimiento__listaReportes"] = listaReportes;
        //        GrvDocumentos.DataSource = listaReportes;
        //    }
        //    catch (Exception ex)
        //    {
        //        Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);

        //    }
        //}
        //protected void BtnEjecutaProceso_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (HidReporteSeleccionado.Contains("IdDocumento"))
        //        {
        //            var strIdDocumento = HidReporteSeleccionado["IdDocumento"].ToString();
        //            var listaReportes = (List<ocp_reportes_cumplimiento>)Session["reportes_cumplimiento__listaReportes"];
        //            var objReporte = listaReportes.Find(f => f.IdDocumento == strIdDocumento);
        //            if (objReporte.ListaParametros.Count > 0)
        //            {
        //                if (PopParametros.FindControl("Pnl" + strIdDocumento.Replace("-", string.Empty)) != null)
        //                {
        //                    var PnlParametros = (ASPxPanel)PopParametros.FindControl("Pnl" + strIdDocumento.Replace("-", string.Empty));
        //                    PnlParametros.ClientVisible = true;
        //                    PopParametros.ShowOnPageLoad = true;
        //                    TxtGestionMatrizRiesgoInstitucional.Value = null;
        //                    Session["reportes_cumplimiento__IdDocumento"] = strIdDocumento;
        //                }
        //                else
        //                {
        //                    throw new Exception("No se encontró el panel de parámetros");
        //                }
        //            }
        //            else
        //            {
        //                GenerarReporte(strIdDocumento);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
        //    }
        //}
        //protected void BtnGenerarReporte_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (Session["reportes_cumplimiento__IdDocumento"] != null)
        //        {
        //            GenerarReporte((string)Session["reportes_cumplimiento__IdDocumento"]);
        //            Session.Remove("reportes_cumplimiento__IdDocumento");
        //            PopParametros.ShowOnPageLoad = false;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
        //    }
        //}
        //protected void GenerarReporte(string strIdDocumento)
        //{
        //    try
        //    {
        //        var listaReportes = (List<ocp_reportes_cumplimiento>)Session["reportes_cumplimiento__listaReportes"];
        //        var objReporte = listaReportes.Find(f => f.IdDocumento == strIdDocumento);
        //        var listaParametros = new List<occ_archivo_respuesta__parametros>();
        //        switch (strIdDocumento)
        //        {
        //            case "REP-005":
        //                listaParametros.Add(new occ_archivo_respuesta__parametros { Nombre = "intGestion", Valor = Convert.ToInt32(TxtGestionMatrizRiesgoInstitucional.Text) });
        //                break;
        //        }
        //        var objArchivoRespuesta = _cGenerales.Documento_Generar(strIdDocumento, listaParametros);
        //        Session["DOWNLOAD"] = new ocp_archivo()
        //        {
        //            ByteArray = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta))),
        //            ContentType = objArchivoRespuesta.ContentType,
        //            Nombre = objArchivoRespuesta.Nombre
        //        };
        //        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
        //    }
        //    catch (Exception ex)
        //    {
        //        Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
        //    }
        //}

		protected void BtnCumplimiento_Click(object sender, EventArgs e)
		{
			try
			{
				string strReporte = ((BootstrapButton)sender).CommandName;
				string strRutaPlantilla = string.Empty;
				string strNombreReporte = string.Empty;
				switch (strReporte)
				{
					case "BENEFICIARIOS": strRutaPlantilla = Server.MapPath("~/assets/tpl/CUMPLIMIENTO_BENEFICIARIOS.xlsx"); strNombreReporte = "ReporteBeneficiarios_"; break;
					case "ASEGURADOS": strRutaPlantilla = Server.MapPath("~/assets/tpl/CUMPLIMIENTO_NUEVOS_ASEGURADOS.xlsx"); strNombreReporte = "ReporteNuevosAsegurados_"; break;
					case "PCCSINIESTROS": strRutaPlantilla = Server.MapPath("~/assets/tpl/CUMPLIMIENTO_PCCSINIESTROS.xlsx"); strNombreReporte = "ReportePCC04Siniestros_"; break;
					case "PCCPRODUCCION": strRutaPlantilla = Server.MapPath("~/assets/tpl/CUMPLIMIENTO_PCCPRODUCCION.xlsx"); strNombreReporte = "ReportePCC04Produccion_"; break;
				}
				var objFileInfo = new FileInfo(strRutaPlantilla);
				var DsetDatos = _cGenerales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_CUMPLIMIENTO_CIERRE", new List<Agente.ServicioGenerales.Parameter>() {
					new Agente.ServicioGenerales.Parameter() { Key = "@MES_PRODUCCION", Value = _strMesProduccion },
					new Agente.ServicioGenerales.Parameter() { Key = "@REPORTE", Value = strReporte } });
				Workbook DEWorkbook = new Workbook();
				DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
				foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
				{
					if (DEWorksheet.Name == "Reporte" && strReporte == "BENEFICIARIOS")
					{
						DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:G" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
					}
					if (DEWorksheet.Name == "Reporte" && strReporte == "ASEGURADOS")
					{
						DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:H" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
					}
					if (DEWorksheet.Name == "Resumen" && strReporte == "PCCSINIESTROS")
					{
						DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:H" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
						DEWorksheet.Range["H2:H" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
					}
					if (DEWorksheet.Name == "Detalle" && strReporte == "PCCSINIESTROS")
					{
						DEWorksheet.Import(DsetDatos.Tables[1], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:N" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
						DEWorksheet.Range["I2:I" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
						DEWorksheet.Columns[13].NumberFormat = "dd/mm/yyyy";
					}
					if (DEWorksheet.Name == "Resumen" && strReporte == "PCCPRODUCCION")
					{
						DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:F" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
						DEWorksheet.Range["F2:F" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
					}
					if (DEWorksheet.Name == "Detalle" && strReporte == "PCCPRODUCCION")
					{
						DEWorksheet.Import(DsetDatos.Tables[1], false, 1, 0);
						CellRange objRange = DEWorksheet.Range["A1:M" + (DsetDatos.Tables[0].Rows.Count + 1)];
						objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
						DEWorksheet.Range["C2:C" + (DsetDatos.Tables[0].Rows.Count + 1)].NumberFormat = "#,##0.00";
						DEWorksheet.Columns[6].NumberFormat = "dd/mm/yyyy";
						DEWorksheet.Columns[7].NumberFormat = "dd/mm/yyyy";
					}
				}
				byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
				Session["DOWNLOAD"] = new ocp_archivo() { ByteArray = bReporte, ContentType = "application/xls", Nombre = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
				ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void BtnFormularioPCC04_Click(object sender, EventArgs e)
		{
			try
			{
				var DtblFormularios = _cGenerales.GetTableFormularioPCC04PorPeriodo(_strMesProduccion);
				string strNombreReporte = "ReportePCC04Normativo_";
				using (var ms = new MemoryStream())
				{
					TextWriter tw = new StreamWriter(ms);
					//tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}", "ldr_entity_id", "eff_date", "jrnl_id", "jrnl_seq_nbr", "jrnl_line_nbr", "line_ldr_entity_id", "sucursal", "cuenta", "agencia", "centro", "negocio", "producto", "trans_curr_code", "prim_dr_cr_code", "trans_amt", "descp", "jrnl_user_alpha_fld_1", "jrnl_user_alpha_fld_2"));
					//tw.Write(Environment.NewLine);
					for (int index = 0; index < DtblFormularios.Rows.Count; index++)
					{
						tw.Write(string.Format(
							"{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|" +
							"{10}|{11}|{12}|{13}|{14}|{15}|{16}|{17}|{18}|{19}|" +
							"{20}|{21}|{22}|{23}|{24}|{25}|{26}|{27}|{28}|{29}|" +
							"{30}|{31}|{32}|{33}|{34}|{35}|{36}|{37}|{38}|{39}|" +
							"{40}|{41}|{42}|{43}|{44}|{45}|{46}|{47}|{48}",
							string.IsNullOrEmpty(DtblFormularios.Rows[index][0].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][0].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][1].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][1].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][2].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][2].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][3].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][3].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][4].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][4].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][5].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][5].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][6].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][6].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][7].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][7].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][8].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][8].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][9].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][9].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

							string.IsNullOrEmpty(DtblFormularios.Rows[index][10].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][10].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][11].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][11].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][12].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][12].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][13].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][13].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][14].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][14].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][15].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][15].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][16].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][16].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][17].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][17].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][18].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][18].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][19].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][19].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

							string.IsNullOrEmpty(DtblFormularios.Rows[index][20].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][20].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][21].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][21].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][22].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][22].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][23].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][23].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][24].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][24].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][25].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][25].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][26].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][26].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][27].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][27].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][28].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][28].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][29].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][29].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

							string.IsNullOrEmpty(DtblFormularios.Rows[index][30].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][30].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][31].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][31].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][32].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][32].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][33].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][33].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][34].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][34].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][35].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][35].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][36].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][36].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][37].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][37].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][38].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][38].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][39].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][39].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),

							string.IsNullOrEmpty(DtblFormularios.Rows[index][40].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][40].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][41].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][41].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][42].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][42].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][43].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][43].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][44].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][44].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][45].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][45].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][46].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][46].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][47].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][47].ToString(), @"\r\n?|\n", string.Empty), @"\t", " "),
							string.IsNullOrEmpty(DtblFormularios.Rows[index][48].ToString()) ? string.Empty : Regex.Replace(Regex.Replace(DtblFormularios.Rows[index][48].ToString(), @"\r\n?|\n", string.Empty), @"\t", " ")));
						tw.Write(Environment.NewLine);
					}
					tw.Flush();
					ms.Position = 0;
					Session["DOWNLOAD"] = new ocp_archivo() { ByteArray = ms.ToArray(), ContentType = "application/csv", Nombre = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".csv" };
					ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
				}
			}
			catch (Exception ex)
			{
				//Master.RegistrarError(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "toastr.danger('" + ex.Message + "', 'INFORMACIÓN', { progressBar: true, positionClass: 'toastr toast-top-right', containerId: 'toast-top-right' });", true);
			}
		}

		//protected void BtnMatrizRiesgo_Click(object sender, EventArgs e)
		//{
		//	try
		//	{
		//		int intGestion = Convert.ToInt32(TxtGestion.Text.ToString());
		//		int intTrimestre = Convert.ToInt32(TxtNumeroTrimestre.Text.ToString());
		//		string strRutaPlantilla = Server.MapPath("~/assets/tpl/MATRIZ_RIESGO.xlsx");
		//		string strNombreReporte = "MatrizRiesgoCRSP_" + intGestion.ToString() + "_" + intTrimestre.ToString() + "T_";
		//		var objFileInfo = new FileInfo(strRutaPlantilla);
		//		var DsetDatos = _cGenerales.GetDatasetProcedimiento("pro.SPR_GETLIST_REPORTE_MATRIZ_RIESGO",
		//			new List<Agente.ServicioGenerales.Parameter> () {
		//				new Agente.ServicioGenerales.Parameter() { Key = "@GESTION", Value = intGestion },
		//				new Agente.ServicioGenerales.Parameter() { Key = "@NUMERO_TRIMESTRE", Value = intTrimestre } });
		//		Workbook DEWorkbook = new Workbook();
		//		DEWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
		//		foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
		//		{
		//			if (DEWorksheet.Name == "Reporte")
		//			{
		//				DEWorksheet.Import(DsetDatos.Tables[0], false, 1, 0);
		//				CellRange objRange = DEWorksheet.Range["A1:S" + (DsetDatos.Tables[0].Rows.Count + 1)];
		//				objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
		//			}
		//		}
		//		byte[] bReporte = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx);
		//		Session["DOWNLOAD"] = new ocp_archivo() { ByteArray = bReporte, ContentType = "application/xls", Nombre = strNombreReporte + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx" };
		//		ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
		//		TxtGestion.Text = TxtNumeroTrimestre.Text = null;
		//	}
		//	catch (Exception ex)
		//	{
		//		Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
		//	}
		//}

		protected void BtnMatrizRiesgoInstitucional_Click(object sender, EventArgs e)
		{
			try
			{
				int intGestion = Convert.ToInt32(TxtGestionMatrizRiesgoInstitucional.Text.ToString());
				
                var listaParametros = new List<occ_archivo_respuesta__parametros>();
				listaParametros.Add(new occ_archivo_respuesta__parametros { Nombre = "intGestion", Valor = Convert.ToInt32(TxtGestionMatrizRiesgoInstitucional.Text) });
				
				var objArchivoRespuesta = _cGenerales.Documento_Generar("REP-005", listaParametros);

				Session["DOWNLOAD"] = new ocp_archivo
				{
					ByteArray = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta))),
					ContentType = objArchivoRespuesta.ContentType,
					Nombre = objArchivoRespuesta.Nombre
				};
				ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
				TxtGestionMatrizRiesgoInstitucional.Text = null;
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
			
	}
}