﻿using Agente.ServicioGenerales;
using DevExpress.Web.Bootstrap;
using DevExpress.Web;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.IO;
using DevExpress.Spreadsheet;
using System.Data;
using System.Web.UI;


namespace Presentacion.site.page
{
    public partial class siniestros_validacion : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private static string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                GrvResumen.DataBind();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvResumen_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var dSetSiniestros = _cGenerales.Siniestros_Validacion((string)Session["MES_PRODUCCION"]);
                Session["siniestros_validacion__datos"] = dSetSiniestros;
                GrvResumen.DataSource = dSetSiniestros.Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);

            }
        }
        protected void BtnReporteMensual_Click(object sender, EventArgs e)
        {
            string strRutaPlantilla = Server.MapPath("~/assets/tpl/siniestros-validacion.xlsx");
            try
            {
                var dSetSiniestros = (DataSet)Session["siniestros_validacion__datos"];
                Workbook objWorkbook = new Workbook();
                objWorkbook.LoadDocument(strRutaPlantilla, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet objWorksheet in objWorkbook.Worksheets)
                {
                    if (objWorksheet.Name == "Resumen")
                    {
                        var DtblResumen = dSetSiniestros.Tables[0];
                        objWorksheet.Import(DtblResumen, false, 2, 0);
                        objWorksheet.Range["A2:G" + (DtblResumen.Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        objWorksheet.Range["C3:C" + (DtblResumen.Rows.Count + 2)].NumberFormat = "#,0"; //formato numerico
                        objWorksheet.Range["D3:G" + (DtblResumen.Rows.Count + 2)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                    }
                    if (objWorksheet.Name == "Detalle")
                    {
                        var dtblDetalle = dSetSiniestros.Tables[1];
                        objWorksheet.Import(dtblDetalle, false, 1, 0);
                        objWorksheet.Range["A1:AC" + (dtblDetalle.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        objWorksheet.Range["Q1:V" + (dtblDetalle.Rows.Count + 1)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                        objWorksheet.Range["W1:Z" + (dtblDetalle.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                        objWorksheet.Range["AA1:AA" + (dtblDetalle.Rows.Count + 1)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                        objWorksheet.Range["AB1:AB" + (dtblDetalle.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                    }
                    if (objWorksheet.Name == "Facturacion")
                    {
                        var dtblFacturacion = dSetSiniestros.Tables[2];
                        objWorksheet.Import(dtblFacturacion, false, 2, 0);
                        objWorksheet.Range["A2:AG" + (dtblFacturacion.Rows.Count + 2)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        objWorksheet.Range["Q2:V" + (dtblFacturacion.Rows.Count + 1)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                        objWorksheet.Range["W2:Z" + (dtblFacturacion.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                        objWorksheet.Range["AA2:AA" + (dtblFacturacion.Rows.Count + 1)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                        objWorksheet.Range["AB2:AB" + (dtblFacturacion.Rows.Count + 1)].NumberFormat = "yyyy-mm-dd"; //formato numerico
                        objWorksheet.Range["AF2:AG" + (dtblFacturacion.Rows.Count + 1)].NumberFormat = "#,0.00;(#,0.00)"; //formato numerico
                    }
                }
                Session["DOWNLOAD"] = new ocp_archivo()
                {
                    ByteArray = objWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                    ContentType = "application/vnd.ms-excel",
                    Nombre = "ValidacionSiniestros_" + _strMesProduccion + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx"
                };
                ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}