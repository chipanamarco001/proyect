﻿using DevExpress.Web;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class CargaMasiva : SesionUsuario
    {
        private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
        private readonly CSegip _Segip = new CSegip();
        protected void Page_Load(object sender, EventArgs e)
        {
            CargaInicial();

        }
        protected void CargaInicial()
        {

        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["ARCHIVO_CARGADO"] = new ocp_archivo()
                {
                    ContentType = uploadedFile.ContentType,
                    Extension = fileInfo.Extension,
                    Nombre = uploadedFile.FileName,
                    FileStream = uploadedFile.FileContent,
                    ByteArray = uploadedFile.FileBytes
                };
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toast" + DateTime.Now.Ticks, "ShowToastr('Danger', 'Validación', 'Las contraseñas ingresadas no coinciden.');", true);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            CargarArchivo();

        }
        private void CargarArchivo()
        {
            try
            {
                string strFileExtension = string.Empty;
                var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];
                if (_cArchivoProducto.GetValidFile(fileUpload, "xlsx", ref strFileExtension))
                {
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                {

                    ScriptManager.RegisterStartupScript(this, typeof(Page), "Notify" + DateTime.Now.Ticks, "MostrarNotificacion('error', 'Por favor, verifique que no es un robot.');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toast" + DateTime.Now.Ticks, "MostrarToastr('warning', 'Validación', 'Las contraseñas ingresadas no coinciden.');", true);
            }
        }


        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["ARCHIVO_CARGADO"] != null)
            {
                var objArchivo = (ocp_archivo)Session["ARCHIVO_CARGADO"];
                byte[] resultadoBits = _Segip.Verificador(objArchivo.ByteArray);
                Session.Remove("ARCHIVO_CARGADO");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(resultadoBits);
                Response.Flush();
                Response.End();
            }
        }

    }
}