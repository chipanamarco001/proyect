﻿using Agente.ServicioSiniestroDenuncia;
using Presentacion.controllers;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
	public partial class FormularioPC004 : System.Web.UI.Page
	{
		private CReserva _oReserva = new CReserva();
		//public static CParametros _cParametros = new CParametros();

		//private readonly CDocumentos _cDocumentos = new CDocumentos();

		private CLexico _cLexicos = new CLexico();


		protected void Page_Load(object sender, EventArgs e)
		{
			if (IsPostBack)
			{
				return;
			}

			CargarFormulario();


		}

		private void CargarFormulario()
		{

			try
			{
				if (Session["CUVC_POLIZA"] == null || Session["PC004_ID_CUMULO"] == null)
				{
					return;
				}
				var idPoliza = Session["CUVC_POLIZA"].ToString();
				//var idDenuncia = long.Parse(Session["PC004_ID_DENUNCIA"].ToString());
				//var idDenuncia = null;
				var idCumulo = long.Parse(Session["PC004_ID_CUMULO"].ToString());
				var data = _oReserva.GetPc004Data(idPoliza, Parametros.EntornoProduccion);

				var lstCiudad = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_CIUDAD");
				var lstSujetoObligadoCrediseguro = _cLexicos.GetListLexicoSiniestroByAppNameTabla("CREDISEGURO_PC004");
				var lstTipoPersona = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_TIPO_PERSONA");

				var objPc004 = new FORMULARIO_PC004()
				{
					FUVC_CRS_CIUDAD = lstSujetoObligadoCrediseguro.Where(w => w.TEMA == "CIUDAD").Select(S => S.VALOR).FirstOrDefault(),
					FUVC_CRS_DIRECCION = lstSujetoObligadoCrediseguro.Where(w => w.TEMA == "DIRECCION").Select(S => S.VALOR).FirstOrDefault(),
					FUVC_CRS_TELEFONO = lstSujetoObligadoCrediseguro.Where(w => w.TEMA == "TELEFONO").Select(S => S.VALOR).FirstOrDefault(),
					FUVC_CRS_ZONA = lstSujetoObligadoCrediseguro.Where(w => w.TEMA == "ZONA").Select(S => S.VALOR).FirstOrDefault(),
					CUIN_ID = idCumulo

				};
				Session.Add("PC004_FORMULARIO", objPc004);


				//combos persona natural
				var lstTipoDocumento = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "PN_CLAVE_TIPO_DOCUMENTO");
				var lstDepartamento = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_DEPARTAMENTO");
				var lstPais = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_PAIS");
				var lstProfesion = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "PN_CLAVE_PROFESION");
				var lstActividadEconomica = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CM_CLAVE_ACTIVIDAD_ECONOMICA");
				var lstFuncionarioReceptor = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "FUNCIONARIO_RECEPTOR");
				var lstFuncionarioSupervisor = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "FUNCIONARIO_SUPERVISOR");


				//OPERACION
				var lstTipoOperacion = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_OPERACION_UNICA");
				var lstNaturalezaOperacion = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_OPERACION_PCC04");
				var lstTipoSeguro = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_SEGUROS_PCC04");
				var lstPlazoSeguro = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_CORTO_PLAZO");
				var lstRamoSeguro = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_RAMOS_PCC04");
				var lstMoneda = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_MONEDA");
				var lstSujetoObligado = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "SUJETO_OBLIGADO");
				//var lstReposicion = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "CLAVE_REPOSICION");
				var lstCorredor = _oReserva.GetListCorredorasIntermediarias();

				cmbSO_FuncionarioReceptor.DataSource = lstFuncionarioReceptor;
				cmbSO_FuncionarioReceptor.DataValueField = "VALOR";
				cmbSO_FuncionarioReceptor.DataTextField = "DESCRIPCION";
				cmbSO_FuncionarioReceptor.DataBind();

				cmbSO_FuncionarioSupervisor.DataSource = lstFuncionarioSupervisor;
				cmbSO_FuncionarioSupervisor.DataValueField = "VALOR";
				cmbSO_FuncionarioSupervisor.DataTextField = "DESCRIPCION";
				cmbSO_FuncionarioSupervisor.DataBind();

				cmbPJ_Ciudad.DataSource = lstDepartamento;
				cmbPJ_Ciudad.DataValueField = "VALOR";
				cmbPJ_Ciudad.DataTextField = "DESC_LARGA";
				cmbPJ_Ciudad.DataBind();

				cmb_ActividadEconomica.DataSource = lstActividadEconomica;
				cmb_ActividadEconomica.ValueField = "VALOR";
				cmb_ActividadEconomica.TextField = "DESC_LARGA";
				cmb_ActividadEconomica.DataBind();

				cmbOP_TipoOperacion.DataSource = lstTipoOperacion;
				cmbOP_TipoOperacion.DataValueField = "VALOR";
				cmbOP_TipoOperacion.DataTextField = "DESC_LARGA";
				cmbOP_TipoOperacion.DataBind();

				cmbOP_NaturalezaOperacion.DataSource = lstNaturalezaOperacion;
				cmbOP_NaturalezaOperacion.DataValueField = "VALOR";
				cmbOP_NaturalezaOperacion.DataTextField = "DESC_LARGA";
				cmbOP_NaturalezaOperacion.DataBind();

				cmbOP_TipoSeguro.DataSource = lstTipoSeguro;
				cmbOP_TipoSeguro.DataValueField = "VALOR";
				cmbOP_TipoSeguro.DataTextField = "DESC_LARGA";
				cmbOP_TipoSeguro.DataBind();

				cmbOP_PlazoSeguro.DataSource = lstPlazoSeguro;
				cmbOP_PlazoSeguro.DataValueField = "VALOR";
				cmbOP_PlazoSeguro.DataTextField = "DESC_LARGA";
				cmbOP_PlazoSeguro.DataBind();

				cmbOP_Ramo.DataSource = lstRamoSeguro;
				cmbOP_Ramo.ValueField = "VALOR";
				cmbOP_Ramo.TextField = "DESC_LARGA";
				cmbOP_Ramo.DataBind();

				cmbOP_Moneda.DataSource = lstMoneda;
				cmbOP_Moneda.DataValueField = "VALOR";
				cmbOP_Moneda.DataTextField = "DESC_LARGA";
				cmbOP_Moneda.DataBind();

				cmbOP_SujetoObligado.DataSource = lstSujetoObligado;
				cmbOP_SujetoObligado.ValueField = "VALOR";
				cmbOP_SujetoObligado.TextField = "DESC_LARGA";
				cmbOP_SujetoObligado.DataBind();

				//cmbOP_Reposicion.DataSource = lstReposicion;
				//cmbOP_Reposicion.DataValueField = "VALOR";
				//cmbOP_Reposicion.DataTextField = "DESC_LARGA";
				//cmbOP_Reposicion.DataBind();

				cmbDE_ExtensionDocumento.DataSource = lstDepartamento;
				cmbDE_ExtensionDocumento.DataValueField = "VALOR";
				cmbDE_ExtensionDocumento.DataTextField = "DESC_LARGA";
				cmbDE_ExtensionDocumento.DataBind();


				cmbOP_NombreCorredorParaOperacion.DataSource = lstCorredor;
				cmbOP_NombreCorredorParaOperacion.DataValueField = "COVC_ID_CORREDORA";
				cmbOP_NombreCorredorParaOperacion.DataTextField = "COVC_NOMBRE_CORREDORA";
				cmbOP_NombreCorredorParaOperacion.DataBind();

				//cmbOP_NombreIntermediarioParaOperacion.DataSource = lstCorredor;
				//cmbOP_NombreIntermediarioParaOperacion.DataValueField = "COVC_ID_CORREDORA";
				//cmbOP_NombreIntermediarioParaOperacion.DataTextField = "COVC_NOMBRE_CORREDORA";
				//cmbOP_NombreIntermediarioParaOperacion.DataBind();


				switch (data.TIPO_PERSONA)
				{
					case "NATURAL":
						txtPN_Nombre.Text = data.PN_NOMBRES;
						txtPN_Paterno.Text = data.PN_PATERNO;
						txtPN_Materno.Text = data.PN_MATERNO;

						txtPN_NroIdentidad.Text = data.PN_NRO_DOCUMENTO_IDENTIDAD;

						//txtPN_Nacionalidad.Text = data.
						cmbPN_TipoDocumento.DataSource = lstTipoDocumento;
						cmbPN_TipoDocumento.DataValueField = "VALOR";
						cmbPN_TipoDocumento.DataTextField = "DESC_LARGA";
						cmbPN_TipoDocumento.DataBind();

						cmbPN_Extension.DataSource = lstDepartamento;
						cmbPN_Extension.DataValueField = "VALOR";
						cmbPN_Extension.DataTextField = "DESC_LARGA";
						cmbPN_Extension.DataBind();

						cmbPN_Nacionalidad.DataSource = lstPais;
						cmbPN_Nacionalidad.DataValueField = "VALOR";
						cmbPN_Nacionalidad.DataTextField = "DESC_LARGA";
						cmbPN_Nacionalidad.DataBind();

						cmbPN_PaisResidencia.DataSource = lstPais;
						cmbPN_PaisResidencia.DataValueField = "VALOR";
						cmbPN_PaisResidencia.DataTextField = "DESC_LARGA";
						cmbPN_PaisResidencia.DataBind();

						cmbPN_Profesion.DataSource = lstProfesion;
						cmbPN_Profesion.DataValueField = "VALOR";
						cmbPN_Profesion.DataTextField = "DESC_LARGA";
						cmbPN_Profesion.DataBind();

						pnlPersonaNatural.Visible = true;
						txt_TipoPersona.Text = lstTipoPersona.Where(w => w.TEMA == "CLAVE_TIPO_PERSONA" && w.VALOR == "N").Select(S => S.VALOR).FirstOrDefault();
						break;
					case "JURIDICA":
						txtPJ_Nit.Text = data.PJ_NIT.ToString();
						txtPJ_RazonSocial.Text = data.PJ_RAZON_SOCIAL;
						pnlPersonaJuridica.Visible = true;
						txt_TipoPersona.Text = lstTipoPersona.Where(w => w.TEMA == "CLAVE_TIPO_PERSONA" && w.VALOR == "J").Select(S => S.VALOR).FirstOrDefault();

						break;
				}

				txtOP_NroPoliza.Text = data.POLIZA;
				txtOP_MontoOperacion.Text = data.MONTO_CUMULO.ToString();
				cmbOP_Moneda.SelectedValue = data.MONEDA;
				txtOP_NombreTitularPolizaParaOperacion.Text = data.PN_NOMBRES + " " + data.PN_PATERNO + " " + data.PN_MATERNO;
				txtDE_NombreDeclarante.Text = data.PN_NOMBRES + " " + data.PN_PATERNO + " " + data.PN_MATERNO;
				txtDE_NroIdentidadDeclarante.Text = data.PN_NRO_DOCUMENTO_IDENTIDAD;
				//txtDE_ExtensionDocumento.Text = data.PN_EXPEDICION_IDENTIDAD;


				//homologacion
				cmbPN_PaisResidencia.SelectedValue = data.PN_PAIS_DE_RESIDENCIA == "BO" ? "BOL" : "";
				cmbPN_Nacionalidad.SelectedValue = data.PN_PAIS_DE_RESIDENCIA == "BO" ? "BOL" : "";
				cmbDE_ExtensionDocumento.SelectedValue = data.PN_EXPEDICION_IDENTIDAD;
				cmbPN_Extension.SelectedValue = data.PN_EXPEDICION_IDENTIDAD;
				cmbOP_NombreCorredorParaOperacion.SelectedValue = data.CORREDOR;
				//cmbOP_NombreIntermediarioParaOperacion.SelectedValue = data.CORREDOR;


				//switch (cmbOP_NaturalezaOperacion.SelectedValue)
				//{
				//    case "S":
				//        divOrigenRecursos.Visible = false;
				//        divDestinoRecursos.Visible = true;
				//        break;
				//    case "P":
				//        divOrigenRecursos.Visible = true;
				//        divDestinoRecursos.Visible = false;
				//        break;

				//    default:
				//        divOrigenRecursos.Visible = false;
				//        divDestinoRecursos.Visible = false;
				//        break;

				//}


			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				lblMensaje.Text = "Algo pasó mientras se cargaba la información";
				MsgInfo.Visible = true;
			}

		}

		protected void cmbOP_NaturalezaOperacion_SelectedIndexChanged(object sender, EventArgs e)
		{
			switch (cmbOP_NaturalezaOperacion.SelectedValue)
			{
				case "S":
					divOrigenRecursos.Visible = false;
					divDestinoRecursos.Visible = true;
					break;
				case "P":
					divOrigenRecursos.Visible = true;
					divDestinoRecursos.Visible = false;
					break;

				default:
					divOrigenRecursos.Visible = false;
					divDestinoRecursos.Visible = false;
					break;

			}

			txtObservaciones.Focus();
		}

		protected void btnRegistrar_Click(object sender, EventArgs e)
		{
			try
			{
				//acultar errores
				txtSO_FuncionarioReceptor_Error.Visible = false;
				txtSO_NombreSupervisor_Error.Visible = false;
				txtPN_Nombre_Error.Visible = false;
				txtPN_Paterno_Error.Visible = false;
				txtPN_Materno_Error.Visible = false;
				txtPN_NroIdentidad_Error.Visible = false;
				txtPN_EmpresaTrabajo_Error.Visible = false;
				txtPN_CargoTrabajo_Error.Visible = false;
				txtPN_DireccionTrabajo_Error.Visible = false;
				txtPJ_Nit_Error.Visible = false;
				txtPJ_RazonSocial_Error.Visible = false;
				txtPJ_Zona_Error.Visible = false;
				txtPJ_Direccion_Error.Visible = false;
				txtPJ_Telefono_Error.Visible = false;
				txtOP_MontoOperacion_Error.Visible = false;
				txtOP_NombreCorredorParaOperacion_Error.Visible = false;
				//txtOP_NombreIntermediarioParaOperacion_Error.Visible = false;
				txtOP_NombreTitularPolizaParaOperacion_Error.Visible = false;
				txtOP_NroPoliza_Error.Visible = false;
				txtOP_NroCuenta_Error.Visible = false;
				txtOP_NroCheque_Error.Visible = false;
				txtOP_OrigenRecursos_Error.Visible = false;
				txtOP_DestinoRecursos_Error.Visible = false;
				txtDE_NombreDeclarante_Error.Visible = false;
				txtDE_NroIdentidadDeclarante_Error.Visible = false;
				txtDE_CargoDeclarante_Error.Visible = false;
				cmb_ActividadEconomica_Error.Visible = false;
				cmbOP_Ramo_Error.Visible = false;
				cmbOP_SujetoObligado_Error.Visible = false;

				//validacion de inputs
				var validacion = false;

				if (string.IsNullOrEmpty(cmbSO_FuncionarioReceptor.SelectedValue)) { txtSO_FuncionarioReceptor_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(cmbSO_FuncionarioSupervisor.SelectedValue)) { txtSO_NombreSupervisor_Error.Visible = true; validacion = true; }

				switch (txt_TipoPersona.Text)
				{
					case "N":
						if (string.IsNullOrEmpty(txtPN_Nombre.Text)) { txtPN_Nombre_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPN_Paterno.Text)) { txtPN_Paterno_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPN_Materno.Text)) { txtPN_Materno_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPN_NroIdentidad.Text)) { txtPN_NroIdentidad_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPN_EmpresaTrabajo.Text)) { txtPN_EmpresaTrabajo_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPN_CargoTrabajo.Text)) { txtPN_CargoTrabajo_Error.Visible = true; validacion = true; }
						//if (string.IsNullOrEmpty(txtPN_DireccionTrabajo.Text)) { txtPN_DireccionTrabajo_Error.Visible = true; validacion = true; }
						break;
					case "J":
						if (string.IsNullOrEmpty(txtPJ_Nit.Text)) { txtPJ_Nit_Error.Visible = true; validacion = true; }
						if (string.IsNullOrEmpty(txtPJ_RazonSocial.Text)) { txtPJ_RazonSocial_Error.Visible = true; validacion = true; }
						break;
				}

				switch (cmbOP_NaturalezaOperacion.SelectedValue)
				{
					case "S":
						if (string.IsNullOrEmpty(txtOP_DestinoRecursos.Text)) { txtOP_DestinoRecursos_Error.Visible = true; validacion = true; }
						//txtOP_OrigenRecursos.Text = null;
						break;
					case "P":
						if (string.IsNullOrEmpty(txtOP_OrigenRecursos.Text)) { txtOP_OrigenRecursos_Error.Visible = true; validacion = true; }
						//txtOP_DestinoRecursos.Text = null;
						break;

					default:
						break;

				}
				if (string.IsNullOrEmpty(txtPJ_Zona.Text)) { txtPJ_Zona_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(txtPJ_Direccion.Text)) { txtPJ_Direccion_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(txtPJ_Telefono.Text)) { txtPJ_Telefono_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(txtOP_MontoOperacion.Text)) { txtOP_MontoOperacion_Error.Visible = true; validacion = true; }
				//if (string.IsNullOrEmpty(txtOP_NombreCorredorParaOperacion.Text)) { txtOP_NombreCorredorParaOperacion_Error.Visible = true; validacion = true; }
				//if (string.IsNullOrEmpty(txtOP_NombreIntermediarioParaOperacion.Text)) { txtOP_NombreIntermediarioParaOperacion_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(txtOP_NombreTitularPolizaParaOperacion.Text)) { txtOP_NombreTitularPolizaParaOperacion_Error.Visible = true; validacion = true; }
				if (string.IsNullOrEmpty(txtOP_NroPoliza.Text)) { txtOP_NroPoliza_Error.Visible = true; validacion = true; }
				if (cmbOP_SujetoObligado.Value == null || string.IsNullOrEmpty(cmbOP_SujetoObligado.Value.ToString())) { cmbOP_SujetoObligado_Error.Visible = true; validacion = true; }
				if (cmbOP_SujetoObligado.Value != null && cmbOP_SujetoObligado.Value.ToString() != "0") { if (string.IsNullOrEmpty(txtOP_NroCuenta.Text) && string.IsNullOrEmpty(txtOP_NroCheque.Text)) { txtOP_NroCuenta_Error.Visible = true; txtOP_NroCheque_Error.Visible = true; validacion = true; } }

				//if (string.IsNullOrEmpty(txtDE_NombreDeclarante.Text)) { txtDE_NombreDeclarante_Error.Visible = true; validacion = true; }
				//if (string.IsNullOrEmpty(txtDE_NroIdentidadDeclarante.Text)) { txtDE_NroIdentidadDeclarante_Error.Visible = true; validacion = true; }
				//if (string.IsNullOrEmpty(txtDE_CargoDeclarante.Text)) { txtDE_CargoDeclarante_Error.Visible = true; validacion = true; }

				//validacion combos devexpress
				if (cmb_ActividadEconomica.Value == null || string.IsNullOrEmpty(cmb_ActividadEconomica.Value.ToString())) { cmb_ActividadEconomica_Error.Visible = true; validacion = true; }
				if (cmbOP_Ramo.Value == null || string.IsNullOrEmpty(cmbOP_Ramo.Value.ToString())) { cmbOP_Ramo_Error.Visible = true; validacion = true; }

				if (validacion)
				{
					return;
				}



				var objPC004 = (FORMULARIO_PC004)Session["PC004_FORMULARIO"];
				objPC004.FUVC_NOMBRE_FUNCIONARIO_RECEPTOR = cmbSO_FuncionarioReceptor.SelectedValue;
				objPC004.FUVC_NOMBRE_SUPERVISOR = cmbSO_FuncionarioSupervisor.SelectedValue;
				objPC004.FUVC_PN_NOMBRE = txtPN_Nombre.Text.ToUpper();
				objPC004.FUVC_PN_PATERNO = txtPN_Paterno.Text.ToUpper();
				objPC004.FUVC_PN_MATERNO_CASADA = txtPN_Materno.Text.ToUpper();
				objPC004.FUVC_PN_TIPO_DOCUMENTO_IDENTIDAD = cmbPN_TipoDocumento.SelectedValue;
				objPC004.FUVC_PN_NUMERO_DOCUMENTO_IDENTIDAD = txtPN_NroIdentidad.Text.ToUpper();
				objPC004.FUVC_PN_LUGAR_EXPEDICION = cmbPN_Extension.SelectedValue;
				objPC004.FUVC_PN_NACIONALIDAD = cmbPN_Nacionalidad.Text.ToUpper();
				objPC004.FUVC_PN_PAIS_RESIDENCIA = cmbPN_PaisResidencia.Text.ToUpper();
				objPC004.FUVC_PN_PROFESION = cmbPN_Profesion.Text.ToUpper();
				objPC004.FUVC_PN_ACTIVIDAD_ECONOMICA = cmb_ActividadEconomica.Value.ToString();
				objPC004.FUVC_PN_EMPRESA_TRABAJO = txtPN_EmpresaTrabajo.Text.ToUpper();
				objPC004.FUVC_PN_CARGO_TRABAJO = txtPN_CargoTrabajo.Text.ToUpper();
				objPC004.FUVC_PN_DIRECCION_TRABAJO = txtPN_DireccionTrabajo.Text.ToUpper();
				objPC004.FUVC_PJ_NIT = txtPJ_Nit.Text.ToUpper();
				objPC004.FUVC_PJ_RAZON_SOCIAL = txtPJ_RazonSocial.Text.ToUpper();
				objPC004.FUVC_PJ_CIUDAD = cmbPJ_Ciudad.SelectedItem == null ? "" : cmbPJ_Ciudad.SelectedValue;
				objPC004.FUVC_PJ_ZONA = txtPJ_Zona.Text.ToUpper();
				objPC004.FUVC_PJ_DIRECCION = txtPJ_Direccion.Text.ToUpper();
				objPC004.FUVC_PJ_TELEFONO = txtPJ_Telefono.Text.ToUpper();
				objPC004.FUVC_TIPO_OPERACION = cmbOP_TipoOperacion.SelectedValue;
				objPC004.FUVC_NATURALEZA_OPERACION = cmbOP_NaturalezaOperacion.SelectedValue;
				objPC004.FUVC_TIPO_SEGURO = cmbOP_TipoSeguro.SelectedValue;
				objPC004.FUVC_PLAZO_SEGURO = cmbOP_PlazoSeguro.SelectedValue;
				objPC004.FUVC_RAMO_SEGURO = cmbOP_Ramo.Value.ToString();
				objPC004.FUVC_MONEDA_SEGURO = cmbOP_Moneda.SelectedValue;
				objPC004.FUDC_MONTO_OPERACION = decimal.Parse(txtOP_MontoOperacion.Text);
				objPC004.FUVC_NOMBRE_CORREDOR_PARA_OPERACION = cmbOP_NombreCorredorParaOperacion.SelectedValue;
				objPC004.FUVC_NOMBRE_INTERMEDIARIO_PARA_OPERACION = cmbOP_NombreCorredorParaOperacion.SelectedValue;
				objPC004.FUVC_NOMBRE_TITULAR_POLIZA_PARA_OPERACION = txtOP_NombreTitularPolizaParaOperacion.Text.ToUpper();
				objPC004.FUVC_NRO_POLIZA_OPERACION = txtOP_NroPoliza.Text.ToUpper();
				objPC004.FUVC_NRO_CUENTA_PARA_SINIESTRO_RESCATE = txtOP_NroCuenta.Text.ToUpper();
				objPC004.FUIN_SUJETO_OBLIGADO_PARA_SINIESTRO_RESCATE = long.Parse(cmbOP_SujetoObligado.SelectedItem.Value.ToString());
				objPC004.FUVC_NRO_CHEQUE_PARA_SINIESTRO_RESCATE = txtOP_NroCheque.Text.ToUpper();
				//objPC004.FUVC_REPOSICION_PARA_SINIESTRO_RESCATE = cmbOP_Reposicion.SelectedValue;
				objPC004.FUVC_ORIGEN_RECURSOS = txtOP_OrigenRecursos.Text.ToUpper();
				objPC004.FUVC_DESTINO_RECURSOS = txtOP_DestinoRecursos.Text.ToUpper();
				objPC004.FUVC_NOMBRE_DECLARANTE = txtDE_NombreDeclarante.Text.ToUpper();
				objPC004.FUVC_NRO_DOCUMENTO_IDENTIDAD_DECLARANTE = txtDE_NroIdentidadDeclarante.Text.ToUpper();
				objPC004.FUVC_EXPEDICION_DOCUMENTO_IDENTIDAD_DECLARANTE = cmbDE_ExtensionDocumento.SelectedValue;
				objPC004.FUVC_CARGO_DECLARANTE = txtDE_CargoDeclarante.Text.ToUpper();
				objPC004.FUVC_OBSERVACIONES = txtObservaciones.Text.ToUpper();
				objPC004.FUVC_TIPO_PERSONA = txt_TipoPersona.Text.ToUpper();

				var response = _oReserva.SaveFormularioPC004(objPC004, Parametros.EntornoProduccion);

			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				lblMensaje.Text = "Algo pasó mientras se registraban los datos";
				MsgInfo.Visible = true;
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se registran los datos"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'Algo pasó mientras se recopila información.');", true);
			}
			Response.Redirect("~/site/page/pcc04-produccion.aspx");

		}

		protected void btnVolver_Click(object sender, EventArgs e)
		{
			Response.Redirect("pcc04-produccion.aspx");
		}

		//protected void cmb_ActividadEconomica_SelectedIndexChanged(object sender, EventArgs e)
		//{
		//    pnlActividadEconomicaOtro.Visible = false;
		//    if (cmb_ActividadEconomica.SelectedValue == "OTRO")
		//    {
		//        var lstCrsAE = _cLexicos.GetListLexicoSiniestroByAppNameTablaTema("UIF_PC004", "ACTIVIDAD_ECONOMICA_CRS");
		//        cmb_ActividadEconomicaCRS.DataSource = lstCrsAE;
		//        cmb_ActividadEconomicaCRS.DataValueField = "VALOR";
		//        cmb_ActividadEconomicaCRS.DataTextField = "DESC_LARGA";
		//        cmb_ActividadEconomicaCRS.DataBind();
		//        pnlActividadEconomicaOtro.Visible = true;
		//    }

		//    cmb_ActividadEconomica.Focus();

		//}
	}
}