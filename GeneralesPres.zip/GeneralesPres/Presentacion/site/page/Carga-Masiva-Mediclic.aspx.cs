﻿using Agente.SericioAfiliacionBroker;
using DevExpress.Web;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class Carga_Masiva_Mediclic : SesionUsuario
    {
        private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
        private readonly CAfiliacionMasiva _AfiliacionMasiva = new CAfiliacionMasiva();
        protected void Page_Load(object sender, EventArgs e)
        {
            CargaInicial();

        }
        protected void CargaInicial()
        {

        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["ARCHIVO_CARGADO"] = new ocp_archivo()
                {
                    ContentType = uploadedFile.ContentType,
                    Extension = fileInfo.Extension,
                    Nombre = uploadedFile.FileName,
                    FileStream = uploadedFile.FileContent,
                    ByteArray = uploadedFile.FileBytes
                };
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toast" + DateTime.Now.Ticks, "ShowToastr('Danger', 'Validación', 'Las contraseñas ingresadas no coinciden.');", true);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            CargarArchivo();

        }
        private void CargarArchivo()
        {
            try
            {
                string strFileExtension = string.Empty;
                var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];
                if (_cArchivoProducto.GetValidFile(fileUpload, "xlsx", ref strFileExtension))
                {
                    var resultado = _AfiliacionMasiva.Afiliacion(fileUpload);
                    Session["observaciones"] = resultado;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
                else
                {

                    ScriptManager.RegisterStartupScript(this, typeof(Page), "000", "ShowToastr('Warning', 'Top right', 3000, 'VALIDACION', 'El formato del Archivo no es .xlsx');", true);
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, typeof(Page), "000", "ShowToastr('Warning', 'Top right', 3000, 'VALIDACION', 'Archivo con un error o esta vacio');", true);
            }
        }


        protected void BtnDownload_Click(object sender, EventArgs e)
        {

            var listaTexto = Session["observaciones"] as List<string>;

            if (Session["ARCHIVO_CARGADO"] != null)
            {

                string contenido = string.Join(Environment.NewLine, listaTexto);
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(contenido);
                Session.Remove("observaciones");
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = "text/plain"; // Tipo MIME para archivos .txt
                Response.AddHeader("content-disposition", "attachment;filename=observaciones.txt");
                Response.BinaryWrite(bytes);
                Response.Flush();
                Response.End();

            }
        }
    }
}