﻿using Agente.ServicioArchivoProducto;
using Agente.ServicioGenerales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;

namespace Presentacion.site.page
{
    public partial class bandeja_produccion : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
		private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
		private static string _strMesProduccion;		
		private string _strNameTableTemporal = "";
		private int _intIdHistorialCarga = 0;
		private bool _bolReproceso;
		private string _strRutaArchivo = "";
		private string _strNombreArchivo = "";
		private string _strArchivoExtension = "";
		private string _strMotivo = "";
		private int _intIdHistorialCargaEliminado = 0;

		protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
			_strArchivoExtension = (string)Session["strArchivoExtension"];
			_strNameTableTemporal = (string)Session["strNameTableTemporal"];
			_strRutaArchivo = (string)Session["strRutaArchivo"];
			_strNombreArchivo = (string)Session["strNombreArchivo"];
			_strMotivo = (string)Session["strMotivo"];
		}
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
			catch
			{
				throw;
			}
		}
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                GrvBandeja.DataBind();
                var objUsuario = (occ_usuario)Session["SessionUsuario"];
                GrvBandeja.Columns[7].Visible = true;
                GrvBandeja.Columns[8].Visible = true;
                var objLexico = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "MES_PRODUCCION" && w.LEPVC_TEMA == "PROCESO").First();
                DateTime dtPeriodoProcesoActual = DateTime.ParseExact(objLexico.LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                if (objUsuario.Area != "OPERACIONES" || dtPeriodoProceso < dtPeriodoProcesoActual)
                {
                    GrvBandeja.Columns[7].Visible = false;
                    GrvBandeja.Columns[8].Visible = false;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvBandeja_DataBinding(object sender, EventArgs e)
        {
            try
            {
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                var listaBandeja = _cGenerales.GetListaBandejaProduccion(_strMesProduccion);
                var listaBandejaOperaciones = new List<ocp_bandeja_produccion>();
                foreach (var objBandeja in listaBandeja)
                {
                    string[] strItems = objBandeja.DOCUMENTOS.Split(',');
                    var listaDocumentos = new List<ocp_bandeja_produccion__documento>();
                    for (int index = 0; index < strItems.Count(); index++)
                    {
                        if (strItems[index] != string.Empty)
                        {
                            listaDocumentos.Add(new ocp_bandeja_produccion__documento
                            {
                                IdDocumento = strItems[index].Split('|')[0],
                                Nombre = strItems[index].Split('|')[1],
                                Formato = strItems[index].Split('|')[2]
                            });
                        }
                    }
                    listaBandejaOperaciones.Add(new ocp_bandeja_produccion
                    {
                        ModalidadRamo = objBandeja.RAVC_CODIGO_RAMO,
                        NombreProducto = objBandeja.NOMBRE_PRODUCTO,
                        IdProducto = objBandeja.ID_PRODUCTO,
                        Moneda = objBandeja.MONEDA,
                        PrimaComercial = objBandeja.PRIMA_COMERCIAL,
                        ComisionCobranza = objBandeja.COMISION_COBRANZA,
                        CantidadRegistros = objBandeja.CANTIDAD_REGISTROS,
                        FlagCarga = objBandeja.FLAG_CARGA ?? false,
                        TipoCarga = objBandeja.TIPO_CARGA,
                        FlagProduccion = objBandeja.FLAG_PRODUCCION ?? false,
                        Procedimiento = objBandeja.PROCEDIMIENTO,
                        ImagenEstado = (objBandeja.PRIMA_COMERCIAL > 0) ? "check.png" : "close.png",
                        ListaDocumentos = listaDocumentos
                    });
                }

                var objLexico = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "MES_PRODUCCION" && w.LEPVC_TEMA == "PROCESO").First();
                DateTime dtPeriodoProcesoActual = DateTime.ParseExact(objLexico.LEPVC_VALOR.ToString() + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                DateTime dtPeriodoProceso = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                if (dtPeriodoProceso < dtPeriodoProcesoActual)
                {
                    listaBandejaOperaciones = listaBandejaOperaciones.Where(w => w.PrimaComercial > 0).ToList();
                }
                Session["LISTA_BANDEJA"] = listaBandejaOperaciones;
                GrvBandeja.DataSource = listaBandejaOperaciones
                    .OrderBy(O => O.ModalidadRamo)
                    .ThenBy(o => o.IdProducto)
                    .ThenBy(o => o.Moneda);
                string strMesProduccionCore = objLexico.LEPVC_VALOR;
                GrvBandeja.Columns[7].Visible = false;
                GrvBandeja.Columns[8].Visible = false;
                if (_strMesProduccion == strMesProduccionCore)
                {
                    var listaProcesosContable = _cGenerales.Contabilidad_ListaProcesosContablesPorMes(_strMesProduccion);
                    if (!listaProcesosContable.Exists(f => f.PRPVC_TIPO == "MENSUAL" && f.PRPVC_ESTADO == "COMPLETADO"))
                    {
                        GrvBandeja.Columns[7].Visible = true;
                        GrvBandeja.Columns[8].Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        protected void GrvBandeja_CustomButtonInitialize(object sender, BootstrapGridViewCustomButtonEventArgs e)
        {
            try
            {
                BootstrapGridView iGrvBandeja = (BootstrapGridView)sender;
                var objBandejaProduccion = (ocp_bandeja_produccion)iGrvBandeja.GetRow(e.VisibleIndex);
                switch (e.ButtonID)
                {
                    case "Documentos":
                        e.Visible = (objBandejaProduccion.PrimaComercial > 0 && objBandejaProduccion.ListaDocumentos.Count > 0) ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "Produccion":
                        e.Visible = (objBandejaProduccion.FlagProduccion) ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "CargaArchivo":
                        bool boolEsArchivo = false;
                        string strTipoCarga = objBandejaProduccion.TipoCarga;
                        if (strTipoCarga == "EXCEL" || strTipoCarga == "TXT")
                            boolEsArchivo = true;
                        e.Visible = (objBandejaProduccion.FlagCarga && boolEsArchivo) ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                    case "CargaServicio":
                        e.Visible = (objBandejaProduccion.FlagCarga && objBandejaProduccion.TipoCarga == "SERVICIO") ? DevExpress.Utils.DefaultBoolean.True : DevExpress.Utils.DefaultBoolean.False;
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccionBandeja_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccionBandeja.Contains("IdProducto") && HidAccionBandeja.Contains("Accion"))
                {                    
                    string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
                    Session["bandeja_produccion__IdProducto"] = strIdProducto;
                    var listaBandeja = (List<ocp_bandeja_produccion>)Session["LISTA_BANDEJA"];
                    var objBandeja = listaBandeja.Where(w => w.IdProducto == strIdProducto).First();
					switch (HidAccionBandeja.Get("Accion"))
					{
						case "Documentos":
							GrvDocumentos.DataBind();
							PopDocumentos.HeaderText = objBandeja.NombreProducto;
							PopDocumentos.ShowOnPageLoad = true;
							break;
						case "Produccion":
							PopProduccion.HeaderText = objBandeja.NombreProducto;
							PopProduccion.ShowOnPageLoad = true;
							break;
						case "CargaArchivo":
							switch (objBandeja.TipoCarga)
							{
								case "EXCEL":
									RELACION_PRODUCTO_TABLA objRelProductoTabla = _cArchivoProducto.GetObjRelProductoTablaByIdTipoProducto(strIdProducto);
									if (objRelProductoTabla != null)
									{
										_cArchivoProducto.CrearControlesTablaTemporal(objRelProductoTabla.RPVC_NAME_TABLA);
										var _strNameTableTemporal = objRelProductoTabla.RPVC_NAME_TABLA;
										Session["strNameTableTemporal"] = _strNameTableTemporal;
									}
									UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
									PopCargarArchivo.HeaderText = objBandeja.NombreProducto;
									PopCargarArchivo.ShowOnPageLoad = true;
									break;
								case "TXT":
									break;
								default:
									break;
							}
							break;

						case "CargaServicio":
							switch (objBandeja.IdProducto)
							{
								case "GENTRM":
									var objUsuarioLogin = (occ_usuario)Session["SessionUsuario"];
									var lstParametros = new Dictionary<string, object>();
									lstParametros.Add("@mesProceso", _strMesProduccion);
									lstParametros.Add("@user", objUsuarioLogin.Matricula);
									var objMensajeError = new MensajesError();
									var response = _cArchivoProducto.CargaTrMultianual(lstParametros, ref objMensajeError);
									if (!objMensajeError.Error)
									{		
										lblMsg.Text = "La carga se realizo correctamente";
										divMsgSave.HeaderText = "Mensaje de sistema";
										divMsgSave.ShowOnPageLoad = true;
									}
									else
									{
										lblMsg.Text = "Ocurrio un error durante la carga, por favor contacte con el administrador";// con 0 registros";
										divMsgSave.HeaderText = "Mensaje de sistema";
										divMsgSave.ShowOnPageLoad = true;
									}
									break;
								case "":


									break;
								default:
									// code block
									break;
							}
							break;
					}
                    Session["bandeja_produccion__IdProducto"] = strIdProducto;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }

		protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
		{
			try
			{				
				UploadedFile uploadedFile = e.UploadedFile;
				FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
				
				Session["ARCHIVO_CARGADO"] = new ocp_archivo()
				{
					ContentType = uploadedFile.ContentType,
					Extension = fileInfo.Extension,
					Nombre = uploadedFile.FileName,
					FileStream = uploadedFile.FileContent,
					ByteArray = uploadedFile.FileBytes
				};
				e.IsValid = true;
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
		{
			try
			{
				ValidacionCarga _validacionCarga = new ValidacionCarga();

				string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
				var oGetObjHistorialCargaByTablaPeriodoIdProducto = _cArchivoProducto.GetObjHistorialCargaByTablaPeriodoIdProducto(_strNameTableTemporal, _strMesProduccion, strIdProducto);

				if (oGetObjHistorialCargaByTablaPeriodoIdProducto != null)
				{
					if (oGetObjHistorialCargaByTablaPeriodoIdProducto.HCBT_PROCESADO == true)
					{
						return;
					}
					else
					{
						_intIdHistorialCarga = oGetObjHistorialCargaByTablaPeriodoIdProducto.HCIN_ID;
						Session["intIdHistorialCarga"] = _intIdHistorialCarga;
						_bolReproceso = true;
						Session["bolReproceso"] = _bolReproceso;
						CargarArchivo();
					}
					return;
				}
				else
				{
					_bolReproceso = false;
					Session["bolReproceso"] = _bolReproceso;
					CargarArchivo();
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		private void CargarArchivo()
		{
			try
			{
                string strFileExtension = string.Empty;
                string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
                var listaLexicos = ObtieneLexicos();
                string strRutaArchivos = listaLexicos.Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ARCHIVOS").First().LEPVC_VALOR;
                TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(strIdProducto));
				if (objTipoProducto == null)
				{
					lblMsg.Text = "El Producto no se encuentra configurado, por favor contacte con el administrador";
					divMsgSave.HeaderText = "Mensaje de sistema";
					divMsgSave.ShowOnPageLoad = true;
					return;
				}

				var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];
				if (_cArchivoProducto.GetValidFile(fileUpload, objTipoProducto.TPVC_EXTENSION, ref strFileExtension))
				{
					string nombreFile = _cArchivoProducto.GuardarFileTemporal(strIdProducto, _strMesProduccion, fileUpload, strRutaArchivos, strFileExtension);

					Session["strNombreArchivo"] = nombreFile;
					Session["strRutaArchivo"] = strRutaArchivos;
					Session["strArchivoExtension"] = strFileExtension;
					if (_bolReproceso)
					{
						txtMotivo.Text = "";
						HistorialExiste.HeaderText = "Reproceso";
						HistorialExiste.ShowOnPageLoad = true;
					}
					else
					{
						VerificarArchivoCargado(strFileExtension);
					}
				}
				else
				{
					lblMsg.Text = "El formato del Archivo no es valido";
					divMsgSave.HeaderText = "Mensaje de sistema";
					divMsgSave.ShowOnPageLoad = true;
					return;
					//pnlMensajeError.Visible = true;
					//lblMensajeError.Text = "El formato del Archivo no es valido";
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		protected void btnReprocesoYes_Click(object sender, EventArgs e)
		{
			try
			{
				if (txtMotivo.Text.Trim() != "")
				{
					Session["strMotivo"] = txtMotivo.Text;				
					_bolReproceso = true;
					HistorialExiste.ShowOnPageLoad = false;
					VerificarArchivoCargado(_strArchivoExtension);
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		private void VerificarArchivoCargado(string strFileExtension)
		{
			try
			{
				string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
				switch (strFileExtension)
				{
					case ".xls":
					case ".xlsx":
						{
							var objFile = (ocp_archivo)Session["ARCHIVO_CARGADO"];
							var lstExcelHojas = new CExcel().ListSheets(objFile.ByteArray);

							rlHojasdisponibles.DataSource = lstExcelHojas;
							rlHojasdisponibles.DataBind();

							SeleccionarHoja.HeaderText = "Por favor selecciona la Hoja que se cargará";
							SeleccionarHoja.ShowOnPageLoad = true;
							break;
						}
					default:
						{
							break;
						}
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void BtnCargarArchivo_Click(object sender, EventArgs e)
		{
			try
			{
				List<string> linesError = null;
				_bolReproceso = (bool)Session["bolReproceso"];

				string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
				var worksheet = Convert.ToString(rlHojasdisponibles.SelectedItem.Value);
				TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(strIdProducto));
				var lstColumnas = _cArchivoProducto.GetListColumnasByIdProducto(objTipoProducto.TPVC_IDPRODUCTO);
				string strNumColumn = _cArchivoProducto.GetExcelColumnName(lstColumnas.Count);

				var objFile = (ocp_archivo)Session["ARCHIVO_CARGADO"];
				var lstExcelHojas = new CExcel().ListSheets(objFile.ByteArray);

				var dtblExcelData = new CExcel().DatosArchivo(objFile.ByteArray, objTipoProducto).DataTable;

				//verificamos campo llave
				string campoLlave = objTipoProducto.TPVC_CAMPO_LLAVE;

				if (!string.IsNullOrEmpty(campoLlave))
				{
					foreach (DataRow row in dtblExcelData.Rows)
					{
						var valueCell = row[campoLlave].ToString();
						if (string.IsNullOrEmpty(valueCell))
						{
							//eliminamos el registro que no cumple con la llave
							row.Delete();
						}
					}
				}
				dtblExcelData.AcceptChanges();

				var dtBase = new DataTable();
				dtBase.TableName = dtblExcelData.TableName;
				DataColumn newColumn;

				foreach (var itemColumna in lstColumnas)
				{
					foreach (DataColumn column in dtblExcelData.Columns)
					{
						//borramos espacios que esten demas
						if (Regex.Replace(itemColumna.COVC_NOMBRE_DOCUMENTO, @"\s+", " ") == Regex.Replace(column.ColumnName, @"\s+", " "))
						{
							column.ColumnName = itemColumna.COVC_NOMBRE_TABLA;

							newColumn = new DataColumn();
							newColumn.ColumnName = itemColumna.COVC_NOMBRE_TABLA;

							string[] fieldType = itemColumna.COVC_TIPO_DATO.Split('_');

							switch (fieldType[0].ToUpper())
							//switch (itemColumna.COVC_TIPO_DATO.ToUpper())
							{
								case "STRING":
									newColumn.DataType = typeof(string);
									break;
								case "DECIMAL":
									if (itemColumna.COBT_OBLIGATORIO.Value)
									{
										newColumn.DataType = typeof(decimal); 
									}
									else { 
										newColumn.DataType = typeof(decimal); 
										newColumn.AllowDBNull = true; 
									}
									break;
								case "FLOAT":
									if (itemColumna.COBT_OBLIGATORIO.Value)
									{
										newColumn.DataType = typeof(float);
									}
									else 
									{ 
										newColumn.DataType = typeof(float);
										newColumn.AllowDBNull = true;
									}

									break;
								case "DATETIME":
								case "DATETIMEFORMAT":
									if (itemColumna.COBT_OBLIGATORIO.Value)
									{
										newColumn.DataType = typeof(DateTime);
									}
									else {
										newColumn.DataType = newColumn.DataType = typeof(DateTime);
										newColumn.AllowDBNull = true;
									}
									break;
								default:
									newColumn.DataType = typeof(string);
									break;
							}
							dtBase.Columns.Add(newColumn);



						}
					}
				}


				foreach (DataRow row in dtblExcelData.Rows)
				{
					DataRow resultRow = dtBase.NewRow();
					foreach (DataColumn column in dtblExcelData.Columns)
					{
						foreach (var itemColumna in lstColumnas)
						{
							if (itemColumna.COVC_NOMBRE_TABLA == column.ColumnName)
							{
								var value = row[column].ToString();
								var error = false;
								var mensajeError = string.Empty;

								dynamic valueCorrect = null;
								if ((bool)itemColumna.COBT_OBLIGATORIO)
								{
									var type = GetValidateTypeField(itemColumna.COVC_TIPO_DATO, value, ref valueCorrect, ref error, ref mensajeError);
								}
								else
								{
									if (!string.IsNullOrEmpty(value.TrimEnd()))
									{
										var type = GetValidateTypeField(itemColumna.COVC_TIPO_DATO, value, ref valueCorrect, ref error, ref mensajeError);
									}
									else
									{
										var type = GetValidateTypeField("NULLABLE", value, ref valueCorrect, ref error, ref mensajeError);
									}
								}

								int index = dtblExcelData.Rows.IndexOf(row) + objTipoProducto.TPIN_NRO_FILA_CONTENIDO.Value + 1;

								if (error)
								{
									lblMsg.Text = "Ocurrio un error en la columna <b style='color:red'>'"
										+ itemColumna.COVC_NOMBRE_DOCUMENTO + "'</b>, en la fila <b style='color:red'>'" + index + "'</b>, revice el valor  <b style='color:red'>'"
										+ value + "'</b> " + mensajeError;
									SeleccionarHoja.ShowOnPageLoad = false;
									divMsgSave.ShowOnPageLoad = true;
									return;
								}
								else
								{
									resultRow[column.ColumnName] = valueCorrect;
								}
							}
						}
					}
					dtBase.Rows.Add(resultRow);
				}

				var objHistorialCarga = new HISTORIAL_CARGA
				{
					HCVC_NOMBRE_TABLA_TMP = _strNameTableTemporal,
					HCVC_MOTIVO = null,
					HCVC_ID_PRODUCTO = strIdProducto,
					HCIN_CANTIDAD_FILAS = 0,
					HCDT_PERIODO = DateTime.ParseExact(_strMesProduccion, "yyyyMM", null)

				};

				dtblExcelData.TableName = _strNameTableTemporal;
				if (!_bolReproceso)
				{
					var oSaveObjHistorialCarga = _cArchivoProducto.SaveObjHistorialCarga(objHistorialCarga);
					_intIdHistorialCarga = oSaveObjHistorialCarga;

				}
				else
				{
					_intIdHistorialCarga = (int)Session["intIdHistorialCarga"];
					var actualizaHistorialCarga = _cArchivoProducto.UpdateEstadoHistorialCarga(_intIdHistorialCarga, _strMotivo, true);
					_intIdHistorialCargaEliminado = _intIdHistorialCarga;
				}

				dtBase.Columns.Add("CTRL_HCIN_ID", typeof(String));
				foreach (DataRow row in dtBase.Rows)
				{
					row["CTRL_HCIN_ID"] = _intIdHistorialCarga;   // or set it to some other value
				}

				var lstDatatables = SplitDataTableTomultiple(dtBase, 2000);

				var countGuardados = 0;
				if (!_bolReproceso)
				{
					foreach (var itemDatatable in lstDatatables)
					{
						bool oSaveArchivoRecibidoProceso = _cArchivoProducto.SaveArchivoRecibido(_strNameTableTemporal, itemDatatable);
						if (oSaveArchivoRecibidoProceso)
						{
							countGuardados = countGuardados + 1;
						}
					}
				}
				else
				{
					var bolDelete = _cArchivoProducto.DeleteFilasArchivoTemporal(_strNameTableTemporal, _intIdHistorialCargaEliminado);
					if (bolDelete)
					{
						//historico temporal eliminado correctamente
						foreach (var itemDatatable in lstDatatables)
						{
							bool oSaveArchivoRecibidoReproceso = _cArchivoProducto.ReprocesoArchivoFisico(_strNameTableTemporal, itemDatatable);
							if (oSaveArchivoRecibidoReproceso)
							{
								countGuardados = countGuardados + 1;
							}
						}
					}
					else
					{
						//no se pudo eliminar el historico
						lblMsg.Text = "Ocurrio un error durante la carga por favor intente nuevamente";
						SeleccionarHoja.ShowOnPageLoad = false;
						divMsgSave.ShowOnPageLoad = true;
						return;
					}
				}

				if (countGuardados == lstDatatables.Count)
				{
					//success
					lblMsg.Text = "La Carga fue realizada correctamente";

					PopCargarArchivo.ShowOnPageLoad = false;

					divMsgSave.HeaderText = "Respues de Sistema";
					SeleccionarHoja.ShowOnPageLoad = false;
					divMsgSave.ShowOnPageLoad = true;

					var usuarioLogueado = (occ_usuario)HttpContext.Current.Session["SessionUsuario"];
					var listaLexico = _cArchivoProducto.ObtieneLexicos();
					string strHtml = File.ReadAllText(HttpContext.Current.Server.MapPath("~/assets/tpl/email_error_carga.html"));
					string strLogo = HttpContext.Current.Server.MapPath("~/assets/img/logo-email.png");
					Task[] task = new Task[1]
					{
					Task.Factory.StartNew(() => _cArchivoProducto.ValidaData(dtblExcelData, lstColumnas, objTipoProducto, _strNameTableTemporal, _intIdHistorialCarga, usuarioLogueado, listaLexico, strHtml, strLogo))
					};

					Task.WaitAll(task);
				}
				else
				{
					//error
					lblMsg.Text = "Ocurrio un error durante la carga por favor intente nuevamente";
					PopCargarArchivo.ShowOnPageLoad = false;

					divMsgSave.HeaderText = "Respues de Sistema";
					SeleccionarHoja.ShowOnPageLoad = false;
					divMsgSave.ShowOnPageLoad = true;
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		private string GetValidateTypeField(string strField, string srtValue, ref dynamic valueCorrect, ref bool error, ref string mensajeError)
		{
			try
			{
				string strType = "";
				string[] fieldType = strField.Split('_');
				switch (fieldType[0].ToUpper())
				{
					case "INTEGER":
					case "INT":
					case "SI":
						strType = "int";
						valueCorrect = GetInteger(srtValue, ref error);
						break;
					case "BIGINT":
					case "LONG":
						strType = "long";
						valueCorrect = GetBigInt(srtValue, ref error);
						break;
					case "DATETIME":
					case "SD":
					case "TS":
						strType = "DateTime";
						valueCorrect = GetDateTime(srtValue, "dd/MM/yyyy", ref error, ref mensajeError);
						break;
					case "DATETIMEFORMAT":
						strType = "DateTime";
						valueCorrect = GetDateTime(srtValue, fieldType[1], ref error, ref mensajeError);
						break;
					case "STRING":
					case "VARCHAR":
					case "TEXT":
					case "VC":
					case "CH":
					case "NC":
					case "NV":
					case "TX":
					case "NT":
						strType = "string";
						valueCorrect = Convert.ToString(srtValue);
						break;

					case "ARRAY_BYTE":
					case "BN":
					case "VB":
					case "IM":
						strType = "byte[]";
						break;

					case "DECIMAL":
					case "DC":
					case "MO":
					case "SM":
						strType = "decimal";
						valueCorrect = GetDecimal(srtValue, ref error);
						break;
					case "DOUBLE":
					case "NU":
					case "DO":
						strType = "double";
						valueCorrect = GetDouble(srtValue, ref error);
						break;
					case "FL":
					case "FLOAT":
						strType = "float";
						valueCorrect = GetFloat(srtValue, ref error);
						break;
					case "BOOL":
					case "BOOLEAN":
					case "BT":
						strType = "bool";
						valueCorrect = GetBool(srtValue, ref error);
						break;
					case "UI":
					case "GUID":
						strType = "Guid";
						break;
					case "NULLABLE":
						strType = "NULLABLE";
						valueCorrect = DBNull.Value;
						break;
					default:
						strType = "string";
						valueCorrect = Convert.ToString(srtValue);
						break;
				}
				return strType;
			}
			catch
			{
				throw;
			}
		}
		private static List<DataTable> SplitDataTableTomultiple(DataTable originalTable, int batchSize)
		{
			try
			{
				List<DataTable> dts = new List<DataTable>();
				DataTable dt = new DataTable();
				dt = originalTable.Clone();
				int j = 0;
				int k = 1;
				if (originalTable.Rows.Count <= batchSize)
				{
					dt.TableName = "Table_" + k;
					dt = originalTable.Copy();
					dts.Add(dt.Copy());
				}
				else
				{
					for (int i = 0; i < originalTable.Rows.Count; i++)
					{
						dt.NewRow();
						dt.ImportRow(originalTable.Rows[i]);
						if ((i + 1) == originalTable.Rows.Count)
						{
							dt.TableName = "Table_" + k;
							dts.Add(dt.Copy());
							dt.Rows.Clear();
							k++;
						}
						else if (++j == batchSize)
						{
							dt.TableName = "Table_" + k;
							dts.Add(dt.Copy());
							dt.Rows.Clear();
							k++;
							j = 0;
						}
					}
				}

				return dts;
			}
			catch
			{
				throw;
			}
		}

		#region(VALIDACION DE DATOS)
		
		private static int GetInteger(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToInt32(Convert.ToDecimal(valor));
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static long GetBigInt(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToInt64(Convert.ToDecimal(valor));
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static decimal GetDecimal(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToDecimal(valor);
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static float GetFloat(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToSingle(valor);
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static double GetDouble(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToDouble(valor);
				else return 0;
			}
			catch
			{
				error = true;
				return 0;
			}
		}
		private static bool GetBool(string valor, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
					return Convert.ToBoolean(valor);
				else return false;
			}
			catch
			{
				error = true;
				return false;
			}
		}
		private static string GetDate(string valor, string formato, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
				{
					if (valor.Length >= formato.Length)
						valor = valor.Substring(0, formato.Length);
				}
				else return string.Empty;
				DateTime eval = DateTime.ParseExact(valor, formato, CultureInfo.InvariantCulture);
				return eval.ToString(formato);
			}
			catch
			{
				error = true;
				return string.Empty;
			}
		}
		private static string GetShortDate(string valor, string formatoEntrada, string formatoSalida, ref bool error)
		{
			try
			{
				if (valor != string.Empty)
				{
					if (valor.Length >= formatoEntrada.Length)
						valor = valor.Substring(0, formatoEntrada.Length);
				}
				else return string.Empty;
				DateTime eval = DateTime.ParseExact(valor, formatoEntrada, CultureInfo.InvariantCulture);
				return eval.ToString(formatoSalida);
			}
			catch
			{
				error = true;
				return string.Empty;
			}
		}
		private static DateTime? GetDateTime(string strValor, string strFormato, ref bool error, ref string mensajeError)
		{
			try
			{
				if (strValor != string.Empty)
				{
                    string strValorCalculo = string.Empty;
					if (strValor.Length >= strFormato.Length)
						strValorCalculo = strValor.Substring(0, strFormato.Length);
                    string strFecha1 = strValor.Split(' ')[0].Trim();
                    if (IsDate2(strFecha1, strFormato.Trim()))
                    {
                        return DateTime.ParseExact(strFecha1, strFormato.Trim(), CultureInfo.InvariantCulture);
                    }
                    if (IsDate2(strValorCalculo, strFormato))
					{                        
						DateTime eval1 = DateTime.ParseExact(strValorCalculo, strFormato, CultureInfo.InvariantCulture);
						return eval1;
					}
                    if (IsDate(strValor))
                    {
                        DateTime dtFecha;
                        bool success = DateTime.TryParse(strValor, out dtFecha);
                        return dtFecha;
                    }
                    if (IsOADate2(strValor))
					{
						DateTime eval2 = DateTime.FromOADate(Convert.ToDouble(strValor));
						return eval2;
					}
				}
				else
				{
					error = true;
					mensajeError = "El valor no puedo estar vacio";
				}
				return null;
			}
			catch
			{
				error = true;
				throw;
			}
		}
		private static bool IsDate(string strFecha)
		{
			try
			{
				DateTime dtFecha;
				bool success = DateTime.TryParse(strFecha, out dtFecha);
				return success;
			}
			catch
			{
				return false;
			}
		}
		private static bool IsDate2(string value, string format)
		{
			try
			{
				DateTime fecha = DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
				return true;
			}
			catch
			{
				return false;
			}
		}
		private static bool IsOADate2(string value)
		{
			try
			{
				DateTime fecha = DateTime.FromOADate(Convert.ToDouble(value));
				return true;
			}
			catch
			{
				return false;
			}
		}

		#endregion

		protected void BtnProduccion_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdProducto = (string)Session["bandeja_produccion__IdProducto"];
                _cGenerales.BandejaProduccion_EjecutarProcedimiento(_strMesProduccion, strIdProducto);
                PopProduccion.ShowOnPageLoad = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "000", "ShowToastr('Success', 'Top right', 3000, 'PRODUCCIÓN', 'El proceso de producción ha sido ejecutado con éxito.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvDocumentos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                string strIdProducto = (string)Session["bandeja_produccion__IdProducto"];
                var listaBandeja = (List<ocp_bandeja_produccion>)Session["LISTA_BANDEJA"];
                var objBandeja = listaBandeja.Where(w => w.IdProducto == strIdProducto).First();
                GrvDocumentos.DataSource = objBandeja.ListaDocumentos;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);

            }
        }
        protected void GrvDocumentos_CustomButtonCallback(object sender, ASPxGridViewCustomButtonCallbackEventArgs e)
        {
			try
			{
				BootstrapGridView iGrvDocumentos = (BootstrapGridView)sender;
				string strIdProducto = (string)Session["bandeja_produccion__IdProducto"];
				if (e.ButtonID == "Descargar")
				{
					var objDocumento = (ocp_bandeja_produccion__documento)iGrvDocumentos.GetRow(e.VisibleIndex);
					var objArchivoRespuesta = _cGenerales.Documento_Generar(
						objDocumento.IdDocumento,
						new List<occ_archivo_respuesta__parametros>() {
						new occ_archivo_respuesta__parametros { Nombre = "strMesProduccion", Valor = _strMesProduccion },
						new occ_archivo_respuesta__parametros { Nombre = "strIdProducto", Valor = strIdProducto }
						});
					Session["DOWNLOAD"] = new ocp_archivo()
					{
						ByteArray = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta))),
						ContentType = objArchivoRespuesta.ContentType,
						Nombre = objArchivoRespuesta.Nombre
					};
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}        
    }
}