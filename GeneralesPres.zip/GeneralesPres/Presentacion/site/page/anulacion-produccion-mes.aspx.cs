﻿using Agente.ServicioArchivoProducto;
using Agente.ServicioGenerales;
using DevExpress.Web;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
	public partial class anulacion_produccion_mes : System.Web.UI.Page
	{
		private readonly CArchivoProducto _cArchivoProducto = new CArchivoProducto();
		protected void Page_Load(object sender, EventArgs e)
		{
			if (IsPostBack)
			{
				return;
			}
			//CargaInicial();
			Session["ANULACION_PRODUCCION_MES"] = null;
		}
		private void CargaInicial()
		{
			CGenerales cGenerales = new CGenerales();
			var response = cGenerales.ObtenerAnulacionesPendientes();
			Session["ANULACION_PRODUCCION_MES"] = response;
		}

		protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
		{
			CargarArchivo();
		}

		protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
		{
			try
			{
				UploadedFile uploadedFile = e.UploadedFile;
				FileInfo fileInfo = new FileInfo(uploadedFile.FileName);

				Session["ARCHIVO_CARGADO"] = new ocp_archivo()
				{
					ContentType = uploadedFile.ContentType,
					Extension = fileInfo.Extension,
					Nombre = uploadedFile.FileName,
					FileStream = uploadedFile.FileContent,
					ByteArray = uploadedFile.FileBytes
				};
				e.IsValid = true;
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		protected void GrvBandeja_DataBinding(object sender, EventArgs e)
		{
			if(Session["ANULACION_PRODUCCION_MES"] != null)
				GrvBandeja.DataSource = (List<ANULACION_PRODUCCION_MES>)Session["ANULACION_PRODUCCION_MES"];

		}

		private void CargarArchivo()
		{
			try
			{
				string strFileExtension = string.Empty;
				//string strIdProducto = HidAccionBandeja.Get("IdProducto").ToString();
				//var listaLexicos = ObtieneLexicos();
				//string strRutaArchivos = listaLexicos.Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ARCHIVOS").First().LEPVC_VALOR;
				//TIPO_PRODUCTO objTipoProducto = _cArchivoProducto.GetObjTipoProductoById(Convert.ToString(strIdProducto));
				//if (objTipoProducto == null)
				//{
				//	lblMsg.Text = "El Producto no se encuentra configurado, por favor contacte con el administrador";
				//	divMsgSave.HeaderText = "Mensaje de sistema";
				//	divMsgSave.ShowOnPageLoad = true;
				//	return;
				//}

				var fileUpload = (ocp_archivo)Session["ARCHIVO_CARGADO"];


				if (_cArchivoProducto.GetValidFile(fileUpload, "xls,xlsx", ref strFileExtension))
				{
					var objFile = (ocp_archivo)Session["ARCHIVO_CARGADO"];
					var lstExcelHojas = new CExcel().ListSheets(objFile.ByteArray);
					var objTipoProducto = new TIPO_PRODUCTO ();
					objTipoProducto.TPIN_NRO_FILA_CABECERA = 0;
					objTipoProducto.TPIN_NRO_FILA_CONTENIDO = 1;
					var dtblExcelData = new CExcel().DatosArchivo(objFile.ByteArray, objTipoProducto).DataTable;


					var list = dtblExcelData.AsEnumerable().Select(row =>
							new ANULACION_PRODUCCION_MES
							{
								ANPVC_ID_CLIENTE = Convert.ToString(row.Field<dynamic>("ID CLIENTE")),
								ANPVC_PATERNO = Convert.ToString(row.Field<dynamic>("PATERNO")),
								ANPVC_MATERNO = Convert.ToString(row.Field<dynamic>("MATERNO")),
								ANPVC_NOMBRES = Convert.ToString(row.Field<dynamic>("NOMBRES")),
								ANPVC_NUMERO_DOCUMENTO = Convert.ToString(row.Field<dynamic>("CI")),

								ANPVC_EXTENSION = Convert.ToString(row.Field<dynamic>("EXTENSIÓN")),
								ANPVC_COMPLEMENTO = Convert.ToString(row.Field<dynamic>("COMPLEMENTO")),
								//ANPVC_FECHA_NACIMIENTO = row.Field<DateTime>("FECHA NACIMIENTO"),
								ANPVC_DIRECCION = Convert.ToString(row.Field<dynamic>("DIRECCION")),
								//ANPVC_NUMERO = Convert.ToInt64(row.Field<dynamic>("DIRECCION")),

								ANPVC_POLIZA = Convert.ToString(row.Field<dynamic>("PÓLIZA")),
								ANPVC_ID_PRODUCTO = Convert.ToString(row.Field<dynamic>("PRODUCTO")),
								ANPVC_PRODUCTO = Convert.ToString(row.Field<dynamic>("PRODUCTO")),
								ANPVC_CERTIFICADO = Convert.ToString(row.Field<dynamic>("CERTIFICADO")),
								ANPVC_CUENTA = Convert.ToString(row.Field<dynamic>("CUENTA")),

								//ANPVC_FECHA_INICIO_VIGENCIA = row.Field<DateTime>("FECHA INICIO VIGENCIA"),

								//ANPVC_MES_LIQUIDACION = Convert.ToString(row.Field<dynamic>("PERIODO LIQUIDACIÓN")),
								ANPVC_MES_LIQUIDACION = Convert.ToString(row.Field<dynamic>("MES LIQUIDACIÓN")),

								//ANPVC_MES_LIQUIDACION = string.IsNullOrEmpty(Convert.ToString(row.Field<dynamic>("MES LIQUIDACIÓN")))? 
								//( 
								//string.IsNullOrEmpty(Convert.ToString(row.Field<dynamic>("PERIODO LIQUIDACIÓN"))) ? "" : Convert.ToString(row.Field<dynamic>("PERIODO LIQUIDACIÓN"))
								//) 
								//: Convert.ToString(row.Field<dynamic>("MES LIQUIDACIÓN")),



								//ANPVC_MES_LIQUIDACION = Convert.ToString(row.Field<dynamic>("PERIODO LIQUIDACIÓN")),

								ANPVC_ENTIDAD = Convert.ToString(row.Field<dynamic>("ENTIDAD")),
								//ANPVC_FECHA_COBRO = Convert.ToString(row.Field<dynamic>("FECHA COBRO")),
								ANPVC_ID_AFILIACION = Convert.ToString(row.Field<dynamic>("ID AFILIACIÓN")),

								ANPVC_MONEDA = Convert.ToString(row.Field<dynamic>("MONEDA")),
								//ANPVC_PRIMA_COMERCIAL = Convert.ToDecimal(row.Field<dynamic>("ENTIDAD")),
								ANPVC_USUARIO_VENTA = Convert.ToString(row.Field<dynamic>("USUARIO VENTA")),
								ANPVC_AGENCIA = Convert.ToString(row.Field<dynamic>("AGENCIA")),
								ANPVC_SUCURSAL = Convert.ToString(row.Field<dynamic>("SUCURSAL")),

								//ANPVC_TIPO_VIGENCIA = Convert.ToString(row.Field<dynamic>("TIPO VIGENCIA")),
								//ANPVC_ESTADO = Convert.ToString(row.Field<string>("Column27")),
								//ANPVC_FECHA = row.Field<string>("Column28"),

								//ID = row.Field<int>("ID_CLIENTE"),
								//Category = row.Field<string>("Category")
							}).ToList();


					var lstAnulacionesMes = (List<ANULACION_PRODUCCION_MES>)Session["ANULACION_PRODUCCION_MES"];
					if (lstAnulacionesMes == null)
					{
						lstAnulacionesMes = new List<ANULACION_PRODUCCION_MES>();
					}
					lstAnulacionesMes.AddRange(list);

					Session["ANULACION_PRODUCCION_MES"] = lstAnulacionesMes;
					GrvBandeja.DataBind();
				}
				//else
				//{
				//	lblMsg.Text = "El formato del Archivo no es valido";
				//	divMsgSave.HeaderText = "Mensaje de sistema";
				//	divMsgSave.ShowOnPageLoad = true;
				//	return;
				//	//pnlMensajeError.Visible = true;
				//	//lblMensajeError.Text = "El formato del Archivo no es valido";
				//}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}


		}

		protected void GrvBandeja_RowCommand(object sender, ASPxGridViewRowCommandEventArgs e)
		{
			GridViewDataItemTemplateContainer cont = (GridViewDataItemTemplateContainer)(((ImageButton)e.CommandSource).NamingContainer);
			var stIdAnulacion = GrvBandeja.GetRowValues(cont.VisibleIndex, GrvBandeja.KeyFieldName);

			var lstAnulacionesMes = (List<ANULACION_PRODUCCION_MES>)Session["ANULACION_PRODUCCION_MES"];

			switch (e.CommandArgs.CommandName)
			{	
				case "ELIMINAR":

					var itemToRemove = lstAnulacionesMes.Single(r => r.ANPBI_ID_REGISTRO == Convert.ToInt64(stIdAnulacion));
					lstAnulacionesMes.Remove(itemToRemove);

					Session["ANULACION_PRODUCCION_MES"] = lstAnulacionesMes;
					GrvBandeja.DataBind();

					break;
			}

		}

		protected void btnRegistrar_Click(object sender, EventArgs e)
		{
			var lstAnulacionesMes = (List<ANULACION_PRODUCCION_MES>)Session["ANULACION_PRODUCCION_MES"];

			CGenerales cGenerales = new CGenerales();
			var response = cGenerales.RegistrarLstAnulacionProduccionMes(lstAnulacionesMes);

			if (response)
			{
				lblMsg.Text = "Las anulaciones fueron registradas, en estado PENDIENTE";
				divMsgSave.HeaderText = "Mensaje de sistema";
				divMsgSave.ShowOnPageLoad = true;
				return;
			}
		}

		protected void btnAnular_Click(object sender, EventArgs e)
		{
			CGenerales cGenerales = new CGenerales();
			var response = cGenerales.AnularProduccionMes();

			if (response)
			{
				lblMsg.Text = "Los registros fueron anulados correctamente";
				divMsgSave.HeaderText = "Mensaje de sistema";
				divMsgSave.ShowOnPageLoad = true;
				CargarArchivo();
				return;
			}
		}
        //public static string RemoveAcentos_BH(string _textoNAOFormatado)
        //{
        //	string ret;
        //	string pattern = @"(?i)[^0-9a-záéíóúàèìòùâêîôûãõç\\s]";
        //	string replacement = "";
        //	Regex rgx = new Regex(pattern);
        //	ret = rgx.Replace(_textoNAOFormatado, replacement);
        //	return ret;
        //}
    }
}