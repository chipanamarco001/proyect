﻿using Agente.ServicioCierre;
using Agente.ServicioGenerales;
using DevExpress.Web.Bootstrap;
using DevExpress.Web;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Presentacion.site.page
{
	public partial class nemesis_pn : SesionUsuario
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
				this.CierraSesion();
			if (!IsPostBack)
			{
				CargaInicial();
			}
		}
		protected void CargaInicial()
		{
			try
			{
				Session["LST_PERSONAS_NEMESIS"] = null;
				Session["LST_AFILIACIONES_NEMESIS"] = null;
				dttFechaInicio.Value = DateTime.Now.AddYears(-5);
				dttFechaFin.Value = DateTime.Now;
				List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result> listaCarrito = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["CARRITO"];
				if (listaCarrito != null && listaCarrito.Count > 0)
				{
					grdCarrito.DataSource = listaCarrito;
					grdBuscaPersona.DataBind();
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
		protected void BtnDownload_Click(object sender, EventArgs e)
		{
			if (Session["DOWNLOAD"] != null)
			{
				var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
				Session.Remove("DOWNLOAD");
				Response.Buffer = true;
				Response.Clear();
				Response.ContentType = objArchivo.ContentType;
				Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
				Response.BinaryWrite(objArchivo.ByteArray);
				Response.Flush();
				Response.End();
			}
		}
		protected void btnBuscar_Click(object sender, EventArgs e)
		{
			try
			{
				CNemesis controlador = new CNemesis();
				string ci = txtCINIT.Text.Trim();
				string nombres = txtNombresRazonSocial.Text.Trim();
				string paterno = txtApellidoPaterno.Text.Trim();
				string materno = txtApellidoMaterno.Text.Trim();
				DateTime fechaInicio = (DateTime)dttFechaInicio.Value;
				DateTime fechaFin = (DateTime)dttFechaFin.Value;

				var lstPersonasNemesis = controlador.GetListPersonasNemesis(ci, nombres, paterno, materno, fechaInicio, fechaFin);

				var lstPersonasBuscadas = (List<SPWB_GETLIST_PERSONAS_NEMESIS_Result>)Session["LST_PERSONAS_NEMESIS"];
				if (lstPersonasBuscadas == null)
				{
					Session["LST_PERSONAS_NEMESIS"] = lstPersonasNemesis;
				}
				else
				{
					var listaActualizada = lstPersonasBuscadas.Union(lstPersonasNemesis).ToList();
					Session["LST_PERSONAS_NEMESIS"] = listaActualizada;
				}

				grdBuscaPersona.DataSource = lstPersonasNemesis;
				grdBuscaPersona.DataBind();
				grdDetalles.EmptyDataText = string.Empty;
				grdDetalles.DataSource = null;
				grdDetalles.DataBind();
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void grdBuscaPersona_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			try
			{
				if (e.CommandName == "SELECT")
				{
					int index = Convert.ToInt32(e.CommandArgument);

					GridViewRow selectedRow = grdBuscaPersona.Rows[index];
					TableCell idPersona = selectedRow.Cells[5];

					CNemesis controlador = new CNemesis();
					string id = idPersona.Text.Trim();
					DateTime fechaInicio = (DateTime)dttFechaInicio.Value;
					DateTime fechaFin = (DateTime)dttFechaFin.Value;

					var lstAfiliacionesPersona = controlador.GetListAfiliacionesByPersonaNemesis(id, fechaInicio, fechaFin);

					var lstAfiliacionesBuscadas = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["LST_AFILIACIONES_NEMESIS"];
					if (lstAfiliacionesBuscadas == null)
					{
						Session["LST_AFILIACIONES_NEMESIS"] = lstAfiliacionesPersona;
					}
					else
					{
						var listaActualizada = lstAfiliacionesBuscadas.Union(lstAfiliacionesPersona).ToList();
						Session["LST_AFILIACIONES_NEMESIS"] = listaActualizada;
					}
					grdDetalles.EmptyDataText = "NO SE ENCONTRARON AFILIACIONES";
					grdDetalles.DataSource = lstAfiliacionesPersona;
					grdDetalles.DataBind();
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void grdDetalles_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			try
			{
				if (e.CommandName == "SELECT")
				{
					int index = Convert.ToInt32(e.CommandArgument);

					GridViewRow selectedRow = grdDetalles.Rows[index];
					string POLIZA = selectedRow.Cells[0].Text;
					string PRODUCTO = selectedRow.Cells[1].Text;
					string CERTIFICADO = selectedRow.Cells[2].Text;
					string FECHA_INICIO = selectedRow.Cells[3].Text;
					string ID_AFILIACION = selectedRow.Cells[4].Text;
					string ID_PERSONA = selectedRow.Cells[5].Text;

					//string contact = idPersona.Text;
					List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result> carrito = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["CARRITO"];
					if (carrito == null)
						carrito = new List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>();

					var lstAfiliacionesPersona = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["LST_AFILIACIONES_NEMESIS"];

					DateTime dtFechaInicio = DateTime.Parse(FECHA_INICIO);

					var objAfiliacion = lstAfiliacionesPersona.Where(w => w.AFIN_ID_AFILIACION == long.Parse(ID_AFILIACION)).FirstOrDefault();

					SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result item = new SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result();
					
					item.POVC_ID_POLIZA_COLOCADA = objAfiliacion.POVC_ID_POLIZA_COLOCADA;
					item.PRVC_DESCRIPCION_COMERCIAL = objAfiliacion.PRVC_DESCRIPCION_COMERCIAL;
					item.CERTIFICADO = objAfiliacion.CERTIFICADO;
					item.AFDT_FECHA_INICIO_VIGENCIA = objAfiliacion.AFDT_FECHA_INICIO_VIGENCIA;
					item.AFDT_FECHA_FIN_VIGENCIA = objAfiliacion.AFDT_FECHA_FIN_VIGENCIA;
					item.AFIN_ID_AFILIACION = long.Parse(ID_AFILIACION);
					item.ID_PERSONA = ID_PERSONA;
					item.AFBT_ESTADO_AFILIACION = objAfiliacion.AFBT_ESTADO_AFILIACION;

					if (carrito.Where(x => x.AFIN_ID_AFILIACION == item.AFIN_ID_AFILIACION).ToList().Count == 0)
						carrito.Add(item);

					Session["CARRITO"] = carrito;

					grdCarrito.DataSource = Session["CARRITO"];
					grdCarrito.DataBind();
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void grdCarrito_RowCommand(object sender, GridViewCommandEventArgs e)
		{
			try
			{
				if (e.CommandName == "SELECT")
				{
					int index = Convert.ToInt32(e.CommandArgument);

					GridViewRow selectedRow = grdCarrito.Rows[index];
					string ID_AFILIACION = selectedRow.Cells[3].Text;

					List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result> carrito = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["CARRITO"];
					if (carrito == null)
						carrito = new List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>();

					carrito = carrito.Where(x => x.AFIN_ID_AFILIACION != long.Parse(ID_AFILIACION)).ToList();

					Session["CARRITO"] = carrito;

					grdCarrito.DataSource = Session["CARRITO"];
					grdCarrito.DataBind();
				}
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		protected void btnDescargarArchivo_Click(object sender, EventArgs e)
		{
			try
			{
				List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result> carrito = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["CARRITO"];
				if (carrito == null)
					return;
				if (carrito.Count == 0)
					return;

				CNemesis controlador = new CNemesis();
				List<string> resultadoFinal = new List<string>();
				foreach (var item in carrito)
				{
					SPWB_GET_DATOS_OPERACION_NEMESIS_Result datosOperacion = controlador.GetDatosOperacionByIdClienteYIdAfiliacion(item.ID_PERSONA, item.AFIN_ID_AFILIACION);
					List<SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result> tomadorAsegurado = controlador.GetTomadorAseguradoByIdClienteYIdAfiliacion(item.ID_PERSONA, item.AFIN_ID_AFILIACION);
					string fila = GenerarFila(datosOperacion, tomadorAsegurado);
					resultadoFinal.Add(fila);
				}

				byte[] bytes = null;
				var stringBuilder = new StringBuilder();
				foreach (var line in resultadoFinal)
				{
					stringBuilder.AppendLine(line);
				}
				bytes = Encoding.UTF8.GetBytes(stringBuilder.ToString());

				//Response.Buffer = true;
				//Response.Clear();
				//Response.ContentType = "text/csv";
				//HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".csv");
				//Response.BinaryWrite(bytes);
				//Response.Flush();
				//Response.End();

				Session["DOWNLOAD"] = new ocp_archivo()
				{
					ByteArray = bytes,
					ContentType = "text/csv",
					Nombre = DateTime.Now.ToString("yyyyMMdd-HHmm") + ".csv"
				};
				ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		private string GenerarFila(SPWB_GET_DATOS_OPERACION_NEMESIS_Result datosOperacion, List<SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result> tomadorAsegurado)
		{
			string resultado = string.Empty;
			resultado += datosOperacion.CARNET + "|";
			resultado += datosOperacion.SECTOR + "|";
			resultado += datosOperacion.TIPO + "|";
			resultado += datosOperacion.RAMO + "|";
			resultado += datosOperacion.NOMBRE_PRODUCTO + "|";
			resultado += datosOperacion.NUMERO_POLIZA + "|";
			resultado += datosOperacion.FECHA_EMISION + "|";
			resultado += datosOperacion.ESTADO_SEGURO + "|";
			resultado += datosOperacion.FECHA_INICIO_VIGENCIA + "|";
			resultado += datosOperacion.FECHA_FIN_VIGENCIA + "|";
			resultado += ((decimal)datosOperacion.VALOR_ASEGURABLE).ToString("0.00") + "|";
			//resultado += String.Format(CultureInfo.InvariantCulture, "{0:N}", (decimal)datosOperacion.VALOR_ASEGURABLE) + "|";
			resultado += datosOperacion.MONEDA_VALOR_ASEGURABLE + "|";
			resultado += "|";//((decimal)datosOperacion.PRIMA_NETA_REASEGURO).ToString("0.00") + "|";
			resultado += "|";//datosOperacion.MONEDA_PRIMA_NETA_REASEGURO + "|";
			resultado += datosOperacion.OBJETO_ASEGURADO + "|";
			resultado += datosOperacion.FORMA_PAGO_SEGURO + "|";
			resultado += ((decimal)datosOperacion.PRIMA_TOTAL).ToString("0.00") + "|";
			//resultado += String.Format(CultureInfo.InvariantCulture, "N", (decimal)datosOperacion.PRIMA_TOTAL) + "|";
			resultado += datosOperacion.MONEDA_PRIMA_TOTAL + "|";
			resultado += datosOperacion.TIENE_DATOS_ASEGURADO + "|";
			resultado += datosOperacion.TIENE_DATOS_BENEFICIARIO + "|";
			resultado += datosOperacion.ORDEN_REASEGURO + "|";
			resultado += datosOperacion.OBSERVACION + "|";

			SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result tomador = tomadorAsegurado.Where(x => x.TIPO_NEMESIS == "TOMADOR").First();
			resultado += tomador.TIPO_PERSONA + "|";
			resultado += tomador.TIPO_DOCUMENTO + "|";
			resultado += tomador.NUMERO_DOCUMENTO + "|";
			resultado += tomador.COMPLEMENTO + "|";
			resultado += tomador.EXTENSION + "|";
			resultado += tomador.NOMBRE1 + "|";
			resultado += tomador.NOMBRE2 + "|";
			resultado += tomador.PATERNO + "|";
			resultado += tomador.MATERNO + "|";
			resultado += tomador.RAZON_SOCIAL + "|";
			resultado += tomador.ESTADO_CIVIL + "|";
			resultado += "1|";//numero registros asegurado
							  //resultado += "0|";//numero registros beneiciario

			SPWB_GET_TOMADOR_ASEGURADO_NEMESIS_Result asegurado = tomadorAsegurado.Where(x => x.TIPO_NEMESIS == "ASEGURADO").First();
			resultado += asegurado.TIPO_PERSONA == "N" ? "0|" : "0";

			if (asegurado.TIPO_PERSONA == "N")
			{
				resultado += asegurado.TIPO_PERSONA + "|";
				resultado += asegurado.TIPO_DOCUMENTO + "|";
				resultado += asegurado.NUMERO_DOCUMENTO + "|";
				resultado += asegurado.COMPLEMENTO + "|";
				resultado += asegurado.EXTENSION + "|";
				resultado += asegurado.NOMBRE1 + "|";
				resultado += asegurado.NOMBRE2 + "|";
				resultado += asegurado.PATERNO + "|";
				resultado += asegurado.MATERNO + "|";
				resultado += asegurado.RAZON_SOCIAL + "|";
				resultado += asegurado.ESTADO_CIVIL /*+ "|"*/;
			}
			return resultado;
		}

		protected void btnDescargarCarta_Click(object sender, EventArgs e)
		{
			try
			{
				var carrito = (List<SPWB_GETLIST_AFILIACIONES_BY_PERSONA_NEMESIS_Result>)Session["CARRITO"];
				if (carrito == null)
				{
					ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'No existe informacion para generar la carta.');", true);
					return;
				}
				var lstPersonas = carrito.GroupBy(x => x.ID_PERSONA).Select(s => s.Key).ToList();

				var lstPersonasCartaNemesis = new List<persona_carta_nemesis>();
				var lstBuscaPersonasNemesis = (List<SPWB_GETLIST_PERSONAS_NEMESIS_Result>)Session["LST_PERSONAS_NEMESIS"];


				StringBuilder sb = new StringBuilder();
				sb.Append(@"<html>");
				sb.AppendLine("<head>");
				sb.AppendLine("<title></title>");
				sb.AppendLine("<style>");
				sb.AppendLine(".center {width:10%; margin: auto;}");
				sb.AppendLine(".divNombre {text-align:center;font-weight:bold;font-family:Arial; font-size:12px;}");
				sb.AppendLine("table, th, td { text-align: center; border:1px solid black; border-collapse: collapse; font-family:Arial;font-size:10px;}");
				sb.AppendLine(".titulo {font-family:Arial;font-size:11px;font-weight:bold;background-color:#CCCCCC}");
				sb.AppendLine("</style>");
				sb.AppendLine("</head>");
				sb.AppendLine("<body class=\"center\">");

				foreach (var itemPersona in lstPersonas)
				{
					var objPersonaCartaNemesis = new persona_carta_nemesis();
					var objPersona = lstBuscaPersonasNemesis.Where(w => w.ID_PERSONA == itemPersona).FirstOrDefault();

					var nombrePersona = objPersona.PATERNO + " " + objPersona.MATERNO + " " + objPersona.NOMBRES;
					var documento = (objPersona.CARNET + " " + objPersona.EXT + " " + objPersona.COMPLEMENTO).TrimStart().TrimEnd();

					objPersonaCartaNemesis.PATERNO = objPersona.PATERNO;
					objPersonaCartaNemesis.MATERNO = objPersona.MATERNO;
					objPersonaCartaNemesis.NOMBRE = objPersona.NOMBRES;
					objPersonaCartaNemesis.NOMBRE_PERSONA = nombrePersona;
					objPersonaCartaNemesis.ID_PERSONA = itemPersona;
					objPersonaCartaNemesis.NUMERO_DOCUMENTO = objPersona.CARNET.TrimStart().TrimEnd();
					objPersonaCartaNemesis.EXTENSION = objPersona.EXT;
					objPersonaCartaNemesis.COMPLEMENTO = objPersona.COMPLEMENTO;

					objPersonaCartaNemesis.DOCUMENTO = documento;

					sb.AppendLine("<div class=\"divNombre\">");
					sb.AppendLine("<br />");
					sb.AppendLine(nombrePersona);
					sb.AppendLine("<br />");
					sb.AppendLine("CÉDULA DE IDENTIDAD: " + documento);
					sb.AppendLine("<br />");

					sb.AppendLine("<table style=\"width:100%;\">");
					sb.AppendLine("<tr>");
					sb.AppendLine("<td class=\"titulo\">Tipo de Producto</td>");
					sb.AppendLine("<td class=\"titulo\">N° de <br /> Afiliación</td>");
					sb.AppendLine("<td class=\"titulo\">Fecha Inicio <br /> de Afiliación</td>");
					sb.AppendLine("<td class=\"titulo\">Fecha de Cierre <br /> de Afiliación</td>");
					sb.AppendLine("<td class=\"titulo\">Periodo de <br /> Alcance</td>");
					sb.AppendLine("</tr>");

					var lstAfiliaciones = carrito.Where(w => w.ID_PERSONA == itemPersona).ToList();
					var lstAfiliacionesPersonaNemesis = new List<afiliaciones_carta_nemesis>();
					foreach (var itemAfiliacion in lstAfiliaciones)
					{
						var estadoAfiliacionFinal = itemAfiliacion.AFBT_ESTADO_AFILIACION.Value == true ? "VIGENTE" : "DESAFILIADO";
						var numeroAfiliacion = itemAfiliacion.AFIN_ID_AFILIACION;
						var fechaInicioVigencia = itemAfiliacion.AFDT_FECHA_INICIO_VIGENCIA == null ? "-" : itemAfiliacion.AFDT_FECHA_INICIO_VIGENCIA.ToShortDateString();
						var fechaFinVigencia = itemAfiliacion.AFDT_FECHA_FIN_VIGENCIA == null ? estadoAfiliacionFinal : itemAfiliacion.AFDT_FECHA_FIN_VIGENCIA.Value.ToShortDateString();

						var strPeriodoAlcance = txtFechaPeriodoAlcanceInicio.Text + " al " + txtFechaPeriodoAlcanceFin.Text;
						var objAfiliacionesCartaNemesis = new afiliaciones_carta_nemesis();
						objAfiliacionesCartaNemesis.TIPO_PRODUCTO = itemAfiliacion.PRVC_DESCRIPCION_COMERCIAL;
						objAfiliacionesCartaNemesis.NUMERO_AFILIACION = itemAfiliacion.AFIN_ID_AFILIACION;
						objAfiliacionesCartaNemesis.FECHA_INICIO = itemAfiliacion.AFDT_FECHA_INICIO_VIGENCIA;
						objAfiliacionesCartaNemesis.FECHA_FIN = itemAfiliacion.AFDT_FECHA_FIN_VIGENCIA;
						objAfiliacionesCartaNemesis.PERIODO_ALCANCE = strPeriodoAlcance;
						lstAfiliacionesPersonaNemesis.Add(objAfiliacionesCartaNemesis);
						sb.AppendLine("<tr>");
						sb.AppendLine("<td>" + itemAfiliacion.PRVC_DESCRIPCION_COMERCIAL + "</td>");
						sb.AppendLine("<td>" + numeroAfiliacion + "</td>");
						sb.AppendLine("<td>" + fechaInicioVigencia + "</td>");
						//sb.AppendLine("<td>" + itemAfiliacion.AFDT_FECHA_FIN_VIGENCIA.Value.ToShortDateString() + "</td>");
						sb.AppendLine("<td>" + fechaFinVigencia + "</td>");
						sb.AppendLine("<td>" + strPeriodoAlcance + "</td>");
						sb.AppendLine("</tr>");
					}

					sb.AppendLine("</table>");

					sb.AppendLine("</body>");
					sb.AppendLine("</html>");
					objPersonaCartaNemesis.LST_AFILIACIONES = lstAfiliacionesPersonaNemesis;

					lstPersonasCartaNemesis.Add(objPersonaCartaNemesis);
				}

				var jsonData = JsonConvert.SerializeObject(lstPersonasCartaNemesis);

				var objCartaNemesis = new CARTA_NEMESIS();
				objCartaNemesis.CAPVC_TIPO_PERSONA = "PN";
				objCartaNemesis.CAPVC_DATOS_ENVIADOS = jsonData;
				objCartaNemesis.CAPVC_CODIGO_SOLICITUD = txtCodigoSolicitud.Text;
				objCartaNemesis.CAPVC_CASO = txtCaso.Text;
				objCartaNemesis.CAPVC_SICOD = txtSicod.Text;
				objCartaNemesis.CAPVC_SOLICITUD = txtNumeroSolicitud.Text;
				objCartaNemesis.CAPVC_HTML_DATOS_ENVIADOS = sb.ToString();
				CGenerales cGenerales = new CGenerales();
				var response = cGenerales.RegistrarCartaNemesis(objCartaNemesis);

				var objArchivoRespuesta = cGenerales.Documento_Generar(
							"NEM-001",
							new List<occ_archivo_respuesta__parametros>() {
						new occ_archivo_respuesta__parametros { Nombre = "longCartaId", Valor = response.CARTA_ID },
						new occ_archivo_respuesta__parametros { Nombre = "strFormato", Valor = "WORD" }
							});

				string strRutaArchivoEnc = Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta));
				
				Session["DOWNLOAD"] = new ocp_archivo()
				{
					ByteArray = File.ReadAllBytes(strRutaArchivoEnc),
					ContentType = "application/msword",
					Nombre = "SC UIF " + response.CODIGO_CARTA + ".docx"
				};
				ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);

			}
			catch (Exception ex)
			{
				Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
			}
		}
	}
}