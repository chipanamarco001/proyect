﻿using Agente.ServicioGenerales;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Web;
using DocumentFormat.OpenXml.Drawing.Charts;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.site.page
{
    public partial class registrar_anulacion : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private static string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void CargaInicial()
        {
            try
            {
                if (_objUsuario == null)
                    _objUsuario = (occ_usuario)Session["SessionUsuario"];
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                Session["registrar_anulacion__bandeja"] = _cGenerales.Anulacion_Bandeja(_strMesProduccion);
                GrvAnulaciones.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAnulaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["registrar_anulacion__bandeja"] != null)
                    GrvAnulaciones.DataSource = ((DataSet)Session["registrar_anulacion__bandeja"]).Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAnulaciones_PreRender(object sender, EventArgs e)
        {
            try
            {
                var objLexico = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "MES_PRODUCCION" && w.LEPVC_TEMA == "PROCESO").First();
                string strMesProduccionCore = objLexico.LEPVC_VALOR;
                BtnCargaIndividual.ClientVisible = false;
                BtnCargaMasiva.ClientVisible = false;
                GrvAnulaciones.Columns[10].Visible = false;
                GrvAnulaciones.Columns[11].Visible = false;
                if (_strMesProduccion == strMesProduccionCore)
                {
                    var listaProcesosContable = _cGenerales.Contabilidad_ListaProcesosContablesPorMes(_strMesProduccion);
                    if (!listaProcesosContable.Exists(f => f.PRPVC_TIPO == "MENSUAL" && f.PRPVC_ESTADO == "COMPLETADO"))
                    {
                        BtnCargaIndividual.ClientVisible = true;
                        BtnCargaMasiva.ClientVisible = true;
                        GrvAnulaciones.Columns[10].Visible = true;
                        GrvAnulaciones.Columns[11].Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        protected void BtnCargaIndividual_Click(object sender, EventArgs e)
        {
            try
            {
                PopCargaIndividual.ShowOnPageLoad = true;
                PnlBusqueda.Visible = true;
                CmbProducto.Value = null;
                TxtNumeroDocumento.Text = null;
                TxtNombre.Text = null;
                GrvAfiliaciones.Visible = false;
                var listaProductos = _cGenerales.ListaProductos();
                CmbProducto.Items.Clear();
                foreach (var objProducto in listaProductos)
                {
                    CmbProducto.Items.Add(objProducto.PRVC_ID_PRODUCTO + " - " + objProducto.PRVC_DESCRIPCION_COMERCIAL, objProducto.PRVC_ID_PRODUCTO);
                }
                PnlRegistro.Visible = false;
                PopCargaIndividual.FindControl("BtnRegistrar").Visible = false;
                PopCargaIndividual.FindControl("BtnActualizar").Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Session["registrar_anulacion__afiliaciones"] = _cGenerales.Anulacion_Buscar(
                    "INDIVIDUAL",
                    CmbProducto.SelectedItem.Value.ToString(),
                    string.Empty,
                    string.Empty,
                    DateTime.Today,
                    string.IsNullOrEmpty(TxtNumeroDocumento.Text) ? string.Empty : TxtNumeroDocumento.Text.Trim().ToUpper(),
                    string.IsNullOrEmpty(TxtNombre.Text) ? string.Empty : TxtNombre.Text.Trim().ToUpper(),
                    0);
                GrvAfiliaciones.Visible = true;
                GrvAfiliaciones.DataBind();
                PnlRegistro.Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvAfiliaciones_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["registrar_anulacion__afiliaciones"] != null)
                    GrvAfiliaciones.DataSource = ((DataSet)Session["registrar_anulacion__afiliaciones"]).Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnSeleccionarAfiliacion_Click(object sender, EventArgs e)
        {
            try
            {
                long longIdAfiliacion = Convert.ToInt64(HidIdAfiliacion.Value);
                var DtblAfiliaciones = ((DataSet)Session["registrar_anulacion__afiliaciones"]).Tables[0];                
                TxtFechaAnulacion.Text = null;
                TxtPrima.Text = null;
                TxtComisionBroker.Text = null;
                TxtPrimaCedida.Text = null;
                PopCargaIndividual.FindControl("BtnRegistrar").Visible = true;
                PopCargaIndividual.FindControl("BtnActualizar").Visible = false;
                for (int index = 0; index < DtblAfiliaciones.Rows.Count; index++)
                {
                    if (DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString() == longIdAfiliacion.ToString())
                    {
                        var objAnulacion = new ocp_anulacion
                        {
                            IdAfiliacion = longIdAfiliacion,
                            IdProducto = DtblAfiliaciones.Rows[index]["ID_PRODUCTO"].ToString(),
                            Poliza = DtblAfiliaciones.Rows[index]["POLIZA"].ToString(),
                            NumeroCertificado = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString(),                            
                            FechaInicioVigencia = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]),
                            FechaFinVigencia = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_FIN_VIGENCIA"]),
                            Moneda = DtblAfiliaciones.Rows[index]["MONEDA"].ToString(),
                            PrimaComercial = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_COMERCIAL"].ToString()),
                            PrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_NETA"].ToString()),
                            PrimaAdicional = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_ADICIONAL"].ToString()),
                            DocumentoNumero = DtblAfiliaciones.Rows[index]["DOCUMENTO_NUMERO"].ToString().Trim(),
                            ImporteIVA = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["IVA"].ToString()),
                            PrimaCedida = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_CEDIDA"].ToString()),
                            FactorPrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["FACTOR_PRIMA_NETA"].ToString()),
                            ComisionBroker = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["COMISION_BROKER"].ToString()),
                            DiasVigenciaAfiliacion = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIAS_VIGENCIA"].ToString()),
                            TipoAnulacion = DtblAfiliaciones.Rows[index]["TIPO_ANULACION"].ToString(),
                            Diferimiento_Aniversarios = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_ANIVERSARIOS"].ToString()),
                            Diferimiento_Desde = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_DESDE"].ToString()),
                            Diferimiento_Hasta = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_HASTA"].ToString()),
                            Diferimiento_Dias = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_DIAS"].ToString()),
                            Diferimiento_Prima = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_PRIMA_NETA"].ToString()),
                            Diferimiento_Saldo = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_SALDO"].ToString())
                        };
                        Session["registrar_anulacion__anulacion"] = objAnulacion;
                        PnlBusqueda.Visible = false;
                        PnlRegistro.Visible = true;
                        TxtRegistroAsegurado.Text = DtblAfiliaciones.Rows[index]["ASEGURADO"].ToString();
                        TxtRegistroProducto.Text = DtblAfiliaciones.Rows[index]["PRODUCTO"].ToString();
                        TxtRegistroPoliza.Text = DtblAfiliaciones.Rows[index]["POLIZA"].ToString();
                        TxtRegistroCertificado.Text = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString();
                        TxtRegistroFechaAfiliacion.Text = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]).ToString("dd/MM/yyyy");
                        TxtRegistroMoneda.Text = DtblAfiliaciones.Rows[index]["MONEDA"].ToString();
                        BtnCalcular.ClientVisible = false;
                        TxtFechaAnulacion.MinDate = objAnulacion.Diferimiento_Desde;
                        TxtFechaAnulacion.MaxDate = DateTime.Today;
                        LblProduccionTipoAnulacion.Text = objAnulacion.TipoAnulacion;
                        LblProduccionFinVigencia.Text = objAnulacion.FechaFinVigencia.ToString("dd/MM/yyyy");
                        LblProduccionDiasVigencia.Text = objAnulacion.DiasVigenciaAfiliacion.ToString("n0");
                        LblProduccionPrimaComercial.Text = objAnulacion.PrimaComercial.ToString("n2");
                        LblProduccionPrimaNeta.Text = objAnulacion.PrimaNeta.ToString("n2");
                        LblProduccionFactorPrimaNeta.Text = objAnulacion.FactorPrimaNeta.ToString("p2");
                        LblProduccionPrimaAdicional.Text = objAnulacion.PrimaAdicional.ToString("n2");
                        LblProduccionIVA.Text = objAnulacion.ImporteIVA.ToString("n2");
                        LblProduccionPrimaCedida.Text = objAnulacion.PrimaCedida.ToString("n2");
                        LblProduccionComisionBroker.Text = objAnulacion.ComisionBroker.ToString("n2");
                        if (objAnulacion.PrimaNeta != objAnulacion.Diferimiento_Prima)
                        {
                            LblDiferimientoAniversarios.Text = objAnulacion.Diferimiento_Aniversarios.ToString("n0");
                            LblDiferimientoDesde.Text = objAnulacion.Diferimiento_Desde.ToString("dd/MM/yyyy");
                            LblDiferimientoHasta.Text = objAnulacion.Diferimiento_Hasta.ToString("dd/MM/yyyy");
                            LblDiferimientoDias.Text = objAnulacion.Diferimiento_Dias.ToString("n0");
                            LblDiferimientoPrima.Text = objAnulacion.Diferimiento_Prima.ToString("n2");
                            LblDiferimientoSaldo.Text = objAnulacion.Diferimiento_Saldo.ToString("n2");
                        }
                        else
                        {
                            LblDiferimientoAniversarios.Text = "-";
                            LblDiferimientoDesde.Text = "-";
                            LblDiferimientoHasta.Text = "-";
                            LblDiferimientoDias.Text = "-";
                            LblDiferimientoPrima.Text = "-";
                            LblDiferimientoSaldo.Text = "-";
                        }
                        if (objAnulacion.TipoAnulacion == "PRORRATA")
                        {
                            BtnCalcular.ClientVisible = true;
                        }
                        HidAccionConfirmacion.Value = "CARGA_INDIVIDUAL";
                        LblMensajeConfirmacion.Text = "Se registrará la anulación con los datos ingresados en el formulario. ¿Está seguro(a) que desea continuar?";
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                var objAnulacion = (ocp_anulacion)Session["registrar_anulacion__anulacion"];
                DateTime DtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                int intDiasCoberturaPeriodo = (DtFechaAnulacion - objAnulacion.Diferimiento_Desde).Days + 1;
                int intDiasCoberturaAfiliacion = (DtFechaAnulacion - objAnulacion.FechaInicioVigencia).Days + 1;
                TxtDiasCobertura.Text = intDiasCoberturaPeriodo.ToString();
                decimal decPrima = 0, decPrimaCedida = 0, decComisionBroker = 0;
                if (objAnulacion.TipoAnulacion == "PRORRATA")
                {
                    decPrima = ocp_anulacion.Prorrateo(objAnulacion.Diferimiento_Prima, objAnulacion.Diferimiento_Dias, intDiasCoberturaPeriodo) + objAnulacion.Diferimiento_Saldo;
                    decPrimaCedida = ocp_anulacion.Prorrateo(objAnulacion.PrimaCedida, objAnulacion.DiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                    decComisionBroker = ocp_anulacion.Prorrateo(objAnulacion.ComisionBroker, objAnulacion.DiasVigenciaAfiliacion, intDiasCoberturaAfiliacion);
                }
                TxtPrima.Value = decPrima;
                TxtComisionBroker.Value = decComisionBroker;
                TxtPrimaCedida.Value = decPrimaCedida;
                TxtPrima.IsValid = true;
                TxtComisionBroker.IsValid = true;
                TxtPrimaCedida.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnCargaMasiva_Click(object sender, EventArgs e)
        {
            try
            {
                UpcArchivo.ValidationSettings.AllowedFileExtensions = new string[] { ".xls", ".xlsx" };
                PopCargaMasiva.ShowOnPageLoad = true;
                PnlMasivoPaso1.Visible = true;
                PnlMasivoPaso2.Visible = false;
                PopCargaMasiva.FindControl("BtnMasivoContinuar").Visible = true;
                PopCargaMasiva.FindControl("BtnMasivoProcesar").Visible = false;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void UpcArchivo_FileUploadComplete(object sender, FileUploadCompleteEventArgs e)
        {
            try
            {
                UploadedFile uploadedFile = e.UploadedFile;
                FileInfo fileInfo = new FileInfo(uploadedFile.FileName);
                Session["registrar_anulacion__archivo"] = new ocp_archivo
                {
                    ContentType = uploadedFile.ContentType,
                    Extension = fileInfo.Extension,
                    Nombre = uploadedFile.FileName,
                    FileStream = uploadedFile.FileContent,
                    ByteArray = uploadedFile.FileBytes
                };
                e.IsValid = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesarArchivo_Click(object sender, EventArgs e)
        {
            try
            {
                var objArchivo = (ocp_archivo)Session["registrar_anulacion__archivo"];
                CmbWorksheet.Items.Clear();
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(objArchivo.ByteArray, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    CmbWorksheet.Items.Add(new DevExpress.Web.Bootstrap.BootstrapListEditItem(DEWorksheet.Name, DEWorksheet.Name));
                }
                CmbWorksheet.Value = null;
                PnlMasivoPaso1.Visible = false;
                PnlMasivoPaso2.Visible = true;
                PopCargaMasiva.FindControl("BtnMasivoContinuar").Visible = false;
                PopCargaMasiva.FindControl("BtnMasivoProcesar").Visible = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnMasivoProcesar_Click(object sender, EventArgs e)
        {
            try
            {
                var objArchivo = (ocp_archivo)Session["registrar_anulacion__archivo"];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(objArchivo.ByteArray, DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                var listaAnulaciones = new List<ANULACION>();
                var listaErrores = new List<ERROR>();
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == (string)CmbWorksheet.SelectedItem.Value)
                    {
                        CellRange range = DEWorksheet.Range["A2:F1011"];
                        System.Data.DataTable dataTable = DEWorksheet.CreateDataTable(range, false, true);
                        DataTableExporter exporter = DEWorksheet.CreateDataTableExporter(range, dataTable, false);
                        exporter.CellValueConversionError += exporter_CellValueConversionError;
                        exporter.Options.DefaultCellValueToColumnTypeConverter.ConvertStringValues = false;
                        exporter.Export();
                        for (int index = 0; index < dataTable.Rows.Count; index++)
                        {
                            if (!string.IsNullOrEmpty(dataTable.Rows[index][0].ToString().Trim()))
                            {
                                if (string.IsNullOrEmpty(dataTable.Rows[index][1].ToString().Trim()))
                                    listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número de póliza\" no ha sido proporcionado (" + dataTable.Rows[index][1].ToString().Trim() + ")." });
                                if (string.IsNullOrEmpty(dataTable.Rows[index][3].ToString().Trim()))
                                {
                                    listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número del documento de identidad\" no ha sido proporcionado." });
                                }
                                else
                                {
                                    int intNumeroDocumento = 0;
                                    if (!int.TryParse(dataTable.Rows[index][3].ToString().Trim(), out intNumeroDocumento))
                                    {
                                        listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': El \"número del documento de identidad\" debe ser un valor numérico (" + dataTable.Rows[index][3].ToString().Trim() + ")." });
                                    }
                                }
                                var dtFechaInicioVigencia = funciones.GetDateTime(dataTable.Rows[index][4].ToString().Trim(), "dd/MM/yyyy");
                                if (dtFechaInicioVigencia == null)
                                    listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': La \"fecha de inicio de vigencia\" no ha sido proporcionada o no es un valor valido (" + dataTable.Rows[index][4].ToString().Trim() + ")." });
                                var dtFechaAnulacion = funciones.GetDateTime(dataTable.Rows[index][5].ToString().Trim(), "dd/MM/yyyy");
                                if (dtFechaAnulacion == null)
                                    listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (index + 1) + "': La \"fecha de anulación\" no ha sido proporcionada o no es un valor valido (" + dataTable.Rows[index][5].ToString().Trim() + ")." });
                                listaAnulaciones.Add(new ANULACION
                                {
                                    ANPBI_ID_ANULACION = index + 1,
                                    ANPCH_MES_PRODUCCION = _strMesProduccion,
                                    ANPVC_ID_PRODUCTO = dataTable.Rows[index][0].ToString().Trim().ToUpper(),
                                    ANPVC_NUMERO_POLIZA = dataTable.Rows[index][1].ToString().Trim().ToUpper(),
                                    ANPVC_CERTIFICADO = dataTable.Rows[index][2].ToString().Trim().ToUpper(),
                                    ANPVC_DOCUMENTO_NUMERO = dataTable.Rows[index][3].ToString().Trim().ToUpper(),
                                    ANPDT_FECHA_AFILIACION = dtFechaInicioVigencia ?? DateTime.Today,
                                    ANPDT_FECHA_ANULACION = dtFechaAnulacion ?? DateTime.Today,
                                    ANPDC_PRIMA_ANULADA = 0,
                                    ANPDC_PRIMA_CEDIDA = 0,
                                    ANPDC_COMISION_BROKER = 0
                                });
                            }
                        }
                        break;
                    }
                }
                if (listaAnulaciones.Count == 0)
                {
                    listaErrores.Add(new ERROR { ERPVC_MENSAJE = "No se encontraron registros validos para evaluar en el proceso de anulación masiva." });
                }
                bool boolMostrarErrores = true;
                if (listaErrores.Count == 0)
                {
                    boolMostrarErrores = false;
                    foreach (var objAnulacion in listaAnulaciones)
                    {
                        DataSet dsetBusqueda = _cGenerales.Anulacion_Buscar(
                            "MASIVO",
                            objAnulacion.ANPVC_ID_PRODUCTO,
                            objAnulacion.ANPVC_NUMERO_POLIZA,
                            objAnulacion.ANPVC_CERTIFICADO,
                            objAnulacion.ANPDT_FECHA_AFILIACION,
                            objAnulacion.ANPVC_DOCUMENTO_NUMERO,
                            string.Empty,
                            0);
                        if (dsetBusqueda.Tables[0].Columns.Count == 1)
                        {
                            listaErrores.Add(new ERROR { ERPVC_MENSAJE = "Error en la registro '" + (objAnulacion.ANPBI_ID_ANULACION) + "': " + dsetBusqueda.Tables[0].Rows[0][0].ToString() });
                        }
                        else
                        {
                            var dtDiferimientoDesde = Convert.ToDateTime(dsetBusqueda.Tables[0].Rows[0]["DIFERIMIENTO_DESDE"].ToString());
                            var decDiferimientoPrima = Convert.ToDecimal(dsetBusqueda.Tables[0].Rows[0]["DIFERIMIENTO_PRIMA_NETA"].ToString());
                            var intDiferimientoDias = Convert.ToInt32(dsetBusqueda.Tables[0].Rows[0]["DIFERIMIENTO_DIAS"].ToString());
                            var decDiferimientoSaldo = Convert.ToDecimal(dsetBusqueda.Tables[0].Rows[0]["DIFERIMIENTO_SALDO"].ToString());
                            var intVigenciaDias = Convert.ToInt32(dsetBusqueda.Tables[0].Rows[0]["DIAS_VIGENCIA"].ToString());
                            var decProduccionPrimaCedida = Convert.ToDecimal(dsetBusqueda.Tables[0].Rows[0]["PRIMA_CEDIDA"].ToString());
                            var decProduccionComisionBroker = Convert.ToDecimal(dsetBusqueda.Tables[0].Rows[0]["COMISION_BROKER"].ToString());
                            int intDiasCoberturaPeriodo = (objAnulacion.ANPDT_FECHA_ANULACION - dtDiferimientoDesde).Days + 1;
                            int intDiasCoberturaAfiliacion = (objAnulacion.ANPDT_FECHA_ANULACION - objAnulacion.ANPDT_FECHA_AFILIACION).Days + 1;
                            objAnulacion.AFPBI_ID_AFILIACION = Convert.ToInt64(dsetBusqueda.Tables[0].Rows[0]["ID_AFILIACION"].ToString());
                            objAnulacion.ANPDC_PRIMA_ANULADA = ocp_anulacion.Prorrateo(decDiferimientoPrima, intDiferimientoDias, intDiasCoberturaPeriodo) + decDiferimientoSaldo;
                            objAnulacion.ANPDC_PRIMA_CEDIDA = ocp_anulacion.Prorrateo(decProduccionPrimaCedida, intVigenciaDias, intDiasCoberturaAfiliacion);
                            objAnulacion.ANPDC_COMISION_BROKER = ocp_anulacion.Prorrateo(decProduccionComisionBroker, intVigenciaDias, intDiasCoberturaAfiliacion);
                        }
                    }
                    if (listaErrores.Count == 0)
                    {
                        Session["registrar_anulacion__listaAnulaciones"] = listaAnulaciones;
                        HidAccionConfirmacion.Value = "CARGA_MASIVA";
                        LblMensajeConfirmacion.Text = "¿Está seguro que desea registrar las anulaciones del archivo seleccionado?";
                        PopCargaMasiva.ShowOnPageLoad = false;
                        PopConfirmacion.ShowOnPageLoad = true;
                    }
                    else
                    {
                        boolMostrarErrores = true;
                    }
                }
                if (boolMostrarErrores)
                {
                    PopCargaMasiva.ShowOnPageLoad = false;
                    PopValidacion.ShowOnPageLoad = true;
                    GrvErrores.DataSource = listaErrores;
                    GrvErrores.DataBind();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "registrar_anulacion__validacion", "ShowToastr('Danger', 'Top right', 3000, 'VALIDACIÓN', 'Se han encontrado observaciones en el archivo seleccionado, por favor revise el detalle desplegado.');", true);
                }                
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            if (e.CellValue.IsEmpty && e.DataColumn.DataType == typeof(DateTime))
            {
                e.DataTableValue = DBNull.Value;
                e.Action = DataTableExporterAction.Continue;
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                string strAccion = HidAccionConfirmacion.Value;
                if (strAccion == "CARGA_MASIVA")
                {
                    var objArchivo = (ocp_archivo)Session["registrar_anulacion__archivo"];
                    var listaAnulaciones = (List<ANULACION>)Session["registrar_anulacion__listaAnulaciones"];
                    string strRutaArchivos = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ARCHIVOS").First().LEPVC_VALOR;
                    string strNombreArchivo = "AnulacionMasiva_" + DateTime.Now.ToString("yyyyMMddHHmmss") + objArchivo.Extension;
                    if (File.Exists(strRutaArchivos + strNombreArchivo))
                        File.Delete(strRutaArchivos + strNombreArchivo);
                    File.WriteAllBytes(strRutaArchivos + strNombreArchivo, objArchivo.ByteArray);
                    _cGenerales.Anulacion_RegistrarLista(listaAnulaciones);
                    Session.Remove("registrar_anulacion__archivo");
                    Session.Remove("registrar_anulacion__listaAnulaciones");
                    PopConfirmacion.ShowOnPageLoad = false;
                    PopCargaMasiva.ShowOnPageLoad = false;
                    CargaInicial();
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "registrar_anulacion__masivo", "ShowToastr('Success', 'Top right', 3000, 'PROCESO COMPLETADO', 'La carga masiva de anulaciones ha finalizado con éxito " + listaAnulaciones.Count.ToString() + " anulaciones han sido registradas en el sistema de producción.');", true);
                }
                if (strAccion == "CARGA_INDIVIDUAL")
                {
                    var objAnulacion = (ocp_anulacion)Session["registrar_anulacion__anulacion"];
                    DateTime dtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    var objAnulacionResult = _cGenerales.Anulacion_Registrar(new ANULACION {
                        ANPCH_MES_PRODUCCION = _strMesProduccion,
                        AFPBI_ID_AFILIACION = objAnulacion.IdAfiliacion,
                        ANPVC_ID_PRODUCTO = objAnulacion.IdProducto,
                        ANPVC_NUMERO_POLIZA = objAnulacion.Poliza,
                        ANPVC_CERTIFICADO = objAnulacion.NumeroCertificado,
                        ANPVC_DOCUMENTO_NUMERO = objAnulacion.DocumentoNumero,
                        ANPDT_FECHA_AFILIACION = objAnulacion.FechaInicioVigencia,
                        ANPDT_FECHA_ANULACION = dtFechaAnulacion,
                        ANPDC_PRIMA_ANULADA = funciones.GetDecimal(TxtPrima.Text.ToString().Trim()),
                        ANPDC_PRIMA_CEDIDA = funciones.GetDecimal(TxtPrimaCedida.Text.ToString().Trim()),
                        ANPDC_COMISION_BROKER = funciones.GetDecimal(TxtComisionBroker.Text.ToString().Trim())
                    });
                    CargaInicial();
                    PopCargaIndividual.ShowOnPageLoad = false;
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__anulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "registrar_anulacion__individual", "ShowToastr('Success', 'Top right', 3000, 'PROCESO COMPLETADO', 'El registro de la anulación en el sistema de producción ha sido completado con éxito.');", true);
                }
                if (strAccion == "ELIMINAR")
                {
                    var longIdAnulacion = (long)Session["registrar_anulacion__idAnulacion"];
                    var objAnulacion = _cGenerales.Anulacion_ObtenerAnulacionPorId(longIdAnulacion);
                    objAnulacion.ANPBT_ACTIVO = false;
                    _cGenerales.Anulacion_Modificar(objAnulacion);                    
                    CargaInicial();
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__idAnulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "registrar_anulacion__eliminar", "ShowToastr('Success', 'Top right', 3000, 'PROCESO COMPLETADO', 'El registro de anulación ha sido eliminado de la base de producción con éxito.');", true);
                }
                if (strAccion == "ACTUALIZAR")
                {
                    var objAnulacion = (ANULACION)Session["registrar_anulacion__objAnulacion"];
                    DateTime dtFechaAnulacion = DateTime.ParseExact(TxtFechaAnulacion.Text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    objAnulacion.ANPDT_FECHA_ANULACION = dtFechaAnulacion;
                    objAnulacion.ANPDC_PRIMA_ANULADA = funciones.GetDecimal(TxtPrima.Text.ToString().Trim());
                    objAnulacion.ANPDC_PRIMA_CEDIDA = funciones.GetDecimal(TxtPrimaCedida.Text.ToString().Trim());
                    objAnulacion.ANPDC_COMISION_BROKER = funciones.GetDecimal(TxtComisionBroker.Text.ToString().Trim());
                    _cGenerales.Anulacion_Modificar(objAnulacion);                    
                    CargaInicial();
                    PopCargaIndividual.ShowOnPageLoad = false;
                    PopConfirmacion.ShowOnPageLoad = false;
                    Session.Remove("registrar_anulacion__objAnulacion");
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "registrar_anulacion__actualizar", "ShowToastr('Success', 'Top right', 3000, 'PROCESO COMPLETADO', 'La actualización de la anulación en el sistema de producción ha sido completado con éxito.');", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnSeleccionarAnulacion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAnulacion.Contains("IdAnulacion") && HidAnulacion.Contains("Accion"))
                {
                    var longIdAnulacion = Convert.ToInt64(HidAnulacion.Get("IdAnulacion"));                    
                    switch (HidAnulacion.Get("Accion"))
                    {
                        case "Editar":
                            var objAnulacion = _cGenerales.Anulacion_ObtenerAnulacionPorId(longIdAnulacion);
                            var dsetAfiliaciones = _cGenerales.Anulacion_Buscar(
                                "INDIVIDUAL",
                                objAnulacion.ANPVC_ID_PRODUCTO,
                                string.Empty,
                                string.Empty,
                                DateTime.Today,
                                objAnulacion.ANPVC_DOCUMENTO_NUMERO,
                                string.Empty,
                                objAnulacion.AFPBI_ID_AFILIACION);
                            var DtblAfiliaciones = dsetAfiliaciones.Tables[0];
                            TxtFechaAnulacion.Value = objAnulacion.ANPDT_FECHA_ANULACION;
                            TxtPrima.Value = objAnulacion.ANPDC_PRIMA_ANULADA;
                            TxtComisionBroker.Value = objAnulacion.ANPDC_COMISION_BROKER;
                            TxtPrimaCedida.Value = objAnulacion.ANPDC_PRIMA_CEDIDA;
                            PopCargaIndividual.FindControl("BtnRegistrar").Visible = false;
                            PopCargaIndividual.FindControl("BtnActualizar").Visible = true;
                            for (int index = 0; index < DtblAfiliaciones.Rows.Count; index++)
                            {
                                if (DtblAfiliaciones.Rows[index]["ID_AFILIACION"].ToString() == objAnulacion.AFPBI_ID_AFILIACION.ToString())
                                {
                                    var objAnulacionEdicion = new ocp_anulacion
                                    {
                                        IdAfiliacion = objAnulacion.AFPBI_ID_AFILIACION,
                                        IdProducto = DtblAfiliaciones.Rows[index]["ID_PRODUCTO"].ToString(),
                                        Poliza = DtblAfiliaciones.Rows[index]["POLIZA"].ToString(),
                                        NumeroCertificado = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString(),
                                        FechaInicioVigencia = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]),
                                        FechaFinVigencia = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_FIN_VIGENCIA"]),
                                        Moneda = DtblAfiliaciones.Rows[index]["MONEDA"].ToString(),
                                        PrimaComercial = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_COMERCIAL"].ToString()),
                                        PrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_NETA"].ToString()),
                                        PrimaAdicional = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_ADICIONAL"].ToString()),
                                        DocumentoNumero = DtblAfiliaciones.Rows[index]["DOCUMENTO_NUMERO"].ToString().Trim(),
                                        ImporteIVA = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["IVA"].ToString()),
                                        PrimaCedida = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["PRIMA_CEDIDA"].ToString()),
                                        FactorPrimaNeta = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["FACTOR_PRIMA_NETA"].ToString()),
                                        ComisionBroker = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["COMISION_BROKER"].ToString()),
                                        DiasVigenciaAfiliacion = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIAS_VIGENCIA"].ToString()),
                                        TipoAnulacion = DtblAfiliaciones.Rows[index]["TIPO_ANULACION"].ToString(),
                                        Diferimiento_Aniversarios = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_ANIVERSARIOS"].ToString()),
                                        Diferimiento_Desde = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_DESDE"].ToString()),
                                        Diferimiento_Hasta = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_HASTA"].ToString()),
                                        Diferimiento_Dias = Convert.ToInt32(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_DIAS"].ToString()),
                                        Diferimiento_Prima = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_PRIMA_NETA"].ToString()),
                                        Diferimiento_Saldo = Convert.ToDecimal(DtblAfiliaciones.Rows[index]["DIFERIMIENTO_SALDO"].ToString())
                                    };
                                    Session["registrar_anulacion__objAnulacion"] = objAnulacion;
                                    Session["registrar_anulacion__anulacion"] = objAnulacionEdicion;
                                    PnlBusqueda.Visible = false;
                                    PnlRegistro.Visible = true;
                                    TxtRegistroAsegurado.Text = DtblAfiliaciones.Rows[index]["ASEGURADO"].ToString();
                                    TxtRegistroProducto.Text = DtblAfiliaciones.Rows[index]["PRODUCTO"].ToString();
                                    TxtRegistroPoliza.Text = DtblAfiliaciones.Rows[index]["POLIZA"].ToString();
                                    TxtRegistroCertificado.Text = DtblAfiliaciones.Rows[index]["CERTIFICADO"].ToString();
                                    TxtRegistroFechaAfiliacion.Text = Convert.ToDateTime(DtblAfiliaciones.Rows[index]["FECHA_INICIO_VIGENCIA"]).ToString("dd/MM/yyyy");
                                    TxtRegistroMoneda.Text = DtblAfiliaciones.Rows[index]["MONEDA"].ToString();
                                    BtnCalcular.ClientVisible = false;
                                    TxtFechaAnulacion.MinDate = objAnulacionEdicion.Diferimiento_Desde;
                                    TxtFechaAnulacion.MaxDate = DateTime.Today;
                                    LblProduccionTipoAnulacion.Text = objAnulacionEdicion.TipoAnulacion;
                                    LblProduccionFinVigencia.Text = objAnulacionEdicion.FechaFinVigencia.ToString("dd/MM/yyyy");
                                    LblProduccionDiasVigencia.Text = objAnulacionEdicion.DiasVigenciaAfiliacion.ToString("n0");
                                    LblProduccionPrimaComercial.Text = objAnulacionEdicion.PrimaComercial.ToString("n2");
                                    LblProduccionPrimaNeta.Text = objAnulacionEdicion.PrimaNeta.ToString("n2");
                                    LblProduccionFactorPrimaNeta.Text = objAnulacionEdicion.FactorPrimaNeta.ToString("p2");
                                    LblProduccionPrimaAdicional.Text = objAnulacionEdicion.PrimaAdicional.ToString("n2");
                                    LblProduccionIVA.Text = objAnulacionEdicion.ImporteIVA.ToString("n2");
                                    LblProduccionPrimaCedida.Text = objAnulacionEdicion.PrimaCedida.ToString("n2");
                                    LblProduccionComisionBroker.Text = objAnulacionEdicion.ComisionBroker.ToString("n2");
                                    if (objAnulacionEdicion.PrimaNeta != objAnulacionEdicion.Diferimiento_Prima)
                                    {
                                        LblDiferimientoAniversarios.Text = objAnulacionEdicion.Diferimiento_Aniversarios.ToString("n0");
                                        LblDiferimientoDesde.Text = objAnulacionEdicion.Diferimiento_Desde.ToString("dd/MM/yyyy");
                                        LblDiferimientoHasta.Text = objAnulacionEdicion.Diferimiento_Hasta.ToString("dd/MM/yyyy");
                                        LblDiferimientoDias.Text = objAnulacionEdicion.Diferimiento_Dias.ToString("n0");
                                        LblDiferimientoPrima.Text = objAnulacionEdicion.Diferimiento_Prima.ToString("n2");
                                        LblDiferimientoSaldo.Text = objAnulacionEdicion.Diferimiento_Saldo.ToString("n2");
                                    }
                                    else
                                    {
                                        LblDiferimientoAniversarios.Text = "-";
                                        LblDiferimientoDesde.Text = "-";
                                        LblDiferimientoHasta.Text = "-";
                                        LblDiferimientoDias.Text = "-";
                                        LblDiferimientoPrima.Text = "-";
                                        LblDiferimientoSaldo.Text = "-";
                                    }
                                    if (objAnulacionEdicion.TipoAnulacion == "PRORRATA")
                                    {
                                        BtnCalcular.ClientVisible = true;
                                    }
                                    HidAccionConfirmacion.Value = "ACTUALIZAR";
                                    LblMensajeConfirmacion.Text = "Se actualizará la anulación con los datos ingresados en el formulario. ¿Está seguro(a) que desea continuar?";
                                    PopCargaIndividual.ShowOnPageLoad = true;
                                }
                            }
                            break;
                        case "Eliminar":
                            Session["registrar_anulacion__idAnulacion"] = longIdAnulacion;
                            HidAccionConfirmacion.Value = "ELIMINAR";
                            LblMensajeConfirmacion.Text = "Esta acción eliminara la anulación de la base de producción. ¿Está seguro(a) que desea continuar?";
                            PopConfirmacion.ShowOnPageLoad = true;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnReporte_Click(object sender, EventArgs e)
        {
            try
            {
                var DtblDatos = ((DataSet)Session["registrar_anulacion__bandeja"]).Tables[0];
                Workbook DEWorkbook = new Workbook();
                DEWorkbook.LoadDocument(Server.MapPath("~/assets/tpl/reporte-anulaciones.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                {
                    if (DEWorksheet.Name == "Reporte")
                    {
                        DEWorksheet.Import(DtblDatos, false, 1, 0);
                        DEWorksheet.Range["A1:L" + (DtblDatos.Rows.Count + 1)].Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin); //bordes
                        DEWorksheet.Columns[5].NumberFormat = "dd/mm/yyyy";
                        DEWorksheet.Columns[6].NumberFormat = "dd/mm/yyyy";
                        DEWorksheet.Columns[7].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[8].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[10].NumberFormat = "#,##0.00";
                        DEWorksheet.Columns[2].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[3].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[4].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[5].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[6].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.Columns[7].Alignment.Horizontal = SpreadsheetHorizontalAlignment.Center;
                        DEWorksheet.DeleteCells(DEWorksheet.Range["M1:Z" + (DtblDatos.Rows.Count + 1)], DeleteMode.EntireColumn);
                        Session["DOWNLOAD"] = new ocp_archivo()
                        {
                            ByteArray = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                            ContentType = "application/vnd.ms-excel",
                            Nombre = "Anulaciones_" + _strMesProduccion + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx"
                        };
                        ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}