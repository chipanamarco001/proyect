﻿using Agente.ServicioGenerales;
using DevExpress.Web.Bootstrap;
using DevExpress.Web;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.IO;

namespace Presentacion.site.page
{
    public partial class reportes_tecnica : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private static string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                GrvDocumentos.DataBind();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];            
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDocumentos_DataBinding(object sender, EventArgs e)
        {
            try
            {
                string strJson = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "JSON" && w.LEPVC_TEMA == "REPORTES_TECNICA").First().LEPVC_VALOR;
                var listaReportes = JsonConvert.DeserializeObject<List<ocp_reportes_tecnica>>(strJson);
                GrvDocumentos.DataSource = listaReportes;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);

            }
        }
        protected void GrvDocumentos_CustomButtonCallback(object sender, ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            BootstrapGridView iGrvDocumentos = (BootstrapGridView)sender;
            string strIdProducto = (string)Session["bandeja_produccion__IdProducto"];
            if (e.ButtonID == "Descargar")
            {
                var objDocumento = (ocp_reportes_tecnica)iGrvDocumentos.GetRow(e.VisibleIndex);
                var objArchivoRespuesta = _cGenerales.Documento_Generar(
                    objDocumento.IdDocumento,
                    new List<occ_archivo_respuesta__parametros>() {
                        new occ_archivo_respuesta__parametros { Nombre = "strMesProduccion", Valor = _strMesProduccion },
                        new occ_archivo_respuesta__parametros { Nombre = "strTipo", Valor = objDocumento.Tipo }
                    });
                Session["DOWNLOAD"] = new ocp_archivo()
                {
                    ByteArray = File.ReadAllBytes(Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta))),
                    ContentType = objArchivoRespuesta.ContentType,
                    Nombre = objArchivoRespuesta.Nombre
                };
            }
        }
    }
}