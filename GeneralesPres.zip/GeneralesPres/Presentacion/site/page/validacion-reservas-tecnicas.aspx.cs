﻿using DevExpress.Spreadsheet;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;

namespace Presentacion.site.page
{
    public partial class validacion_reservas_tecnicas : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                Session["validacion_reservas_tecnicas__datos"] = _cGenerales.ReservasTecnicas_Validacion((string)Session["MES_PRODUCCION"], string.Empty);
                GrvDiferencias.DataBind();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDiferencias_DataBinding(object sender, EventArgs e)
        {
            try
            {
                var dsDatos = (DataSet)Session["validacion_reservas_tecnicas__datos"];
                GrvDiferencias.DataSource = dsDatos.Tables[0];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnAccion_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidAccion.Contains("Ramo"))
                {
                    var strRamo = HidAccion["Ramo"].ToString();
                    var DsetDatos = _cGenerales.ReservasTecnicas_Validacion(_strMesProduccion, strRamo);
                    int intNumeroAfiliaciones = 0;
                    for (int index = 0; index < DsetDatos.Tables[0].Rows.Count; index++)
                    {
                        if (DsetDatos.Tables[0].Rows[index][0].ToString() == strRamo)
                        {
                            intNumeroAfiliaciones = intNumeroAfiliaciones + Convert.ToInt32(DsetDatos.Tables[0].Rows[index][8].ToString());
                        }
                    }
                    if (intNumeroAfiliaciones <= 5000)
                    {
                        Workbook DEWorkbook = new Workbook();
                        DEWorkbook.LoadDocument(Server.MapPath("~/assets/tpl/validacion-rrc.xlsx"), DevExpress.Spreadsheet.DocumentFormat.Xlsx);
                        foreach (Worksheet DEWorksheet in DEWorkbook.Worksheets)
                        {
                            if (DEWorksheet.Name == "RRC")
                            {
                                DataTable DtblReservasTecnicas = DsetDatos.Tables[1];
                                DEWorksheet.Import(DtblReservasTecnicas, false, 1, 0);
                                CellRange objRange = DEWorksheet.Range["A1:S" + (DtblReservasTecnicas.Rows.Count + 1)];
                                objRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Thin);
                            }
                        }
                        Session["DOWNLOAD"] = new ocp_archivo
                        {
                            ByteArray = DEWorkbook.SaveDocument(DevExpress.Spreadsheet.DocumentFormat.Xlsx),
                            ContentType = "application/xls",
                            Nombre = "ValidacionRRC_" + strRamo + "_" + _strMesProduccion + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".xlsx"
                        };
                    }
                    else
                    {
                        using (var ms = new MemoryStream())
                        {
                            TextWriter tw = new StreamWriter(ms);
                            tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}\t{18}",
                                "MES_PRODUCCION",
                                "ID_PRODUCTO",
                                "RAMO",
                                "NIT_TOMADOR",
                                "POLIZA",
                                "INICIO_VIGENCIA",
                                "FIN_VIGENCIA",
                                "FECHA_AFILIACION",
                                "CERTIFICADO",
                                "TIPO_RRC",
                                "MESES_VIGENCIA",
                                "MES_ACTUAL",
                                "MONEDA",
                                "PRIMA_COMERCIAL",
                                "PRIMA_NETA",
                                "PRIMA_CEDIDA",
                                "CONSTITUCION",
                                "LIBERACION",
                                "PASIVO"));
                            tw.Write(Environment.NewLine);
                            foreach (DataRow objDataRow in DsetDatos.Tables[1].Rows)
                            {
                                tw.Write(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}\t{18}",
                                    objDataRow[0].ToString(),
                                    objDataRow[1].ToString(),
                                    objDataRow[2].ToString(),
                                    objDataRow[3].ToString(),
                                    objDataRow[4].ToString(),
                                    objDataRow[5].ToString(),
                                    objDataRow[6].ToString(),
                                    objDataRow[7].ToString(),
                                    objDataRow[8].ToString(),
                                    objDataRow[9].ToString(),
                                    objDataRow[10].ToString(),
                                    objDataRow[11].ToString(),
                                    objDataRow[12].ToString(),
                                    objDataRow[13].ToString(),
                                    objDataRow[14].ToString(),
                                    objDataRow[15].ToString(),
                                    objDataRow[16].ToString(),
                                    objDataRow[17].ToString(),
                                    objDataRow[18].ToString()));
                                tw.Write(Environment.NewLine);
                            }
                            tw.Flush();
                            ms.Position = 0;
                            Session["DOWNLOAD"] = new ocp_archivo
                            {
                                ByteArray = ms.ToArray(),
                                ContentType = "text/plain",
                                Nombre = "ValidacionRRC_" + strRamo + "_" + _strMesProduccion + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt"
                            };
                        }
                    }
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnActualizarDatos_Click(object sender, EventArgs e)
        {
            try
            {
                _cGenerales.ReservasTecnicas_Cargar(_strMesProduccion);
                Session["validacion_reservas_tecnicas__datos"] = _cGenerales.ReservasTecnicas_Validacion((string)Session["MES_PRODUCCION"], string.Empty);
                GrvDiferencias.DataBind();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "Toastr" + DateTime.Now.Ticks, "ShowToastr('Success', 'Top right', 4000, 'Información', 'Se ha completado el proceso de actualización, el cuadro comparativo y las diferencias tambien fueron actualizados.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}