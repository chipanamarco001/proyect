﻿using Agente.ServicioGenerales;
using DevExpress.Web;
using DevExpress.Web.Bootstrap;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class generar_contabilidad : SesionUsuario
    {
        private readonly CGenerales _cGenerales = new CGenerales();
        private string _strMesProduccion;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected List<LEXICO> ObtieneLexicos()
        {
            try
            {
                if (Session["ListaLexico"] == null)
                    Session["ListaLexico"] = _cGenerales.Lexico_ObtenerListaActivos();
                return (List<LEXICO>)Session["ListaLexico"];
            }
            catch
            {
                throw;
            }
        }
        protected void CargaInicial()
        {
            try
            {
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                string strEstadoProceso = (objProceso == null) ? string.Empty : objProceso.PRPVC_ESTADO;
                PnlProcesoPendiente.Visible = false;
                PnlProcesoActivo.Visible = false;
                PnlProcesoValidacion.Visible = false;
                BpcProcesos.TabPages.FindByName("Activo").Visible = true;
                BpcProcesos.ActiveTabIndex = 0;
                switch (strEstadoProceso)
                {
                    case "PENDIENTE":
                        PnlProcesoPendiente.Visible = true;
                        break;
                    case "ACTIVO":
                        var listaAsientosContable = _cGenerales.Contabilidad_ObtenerAsientosContablesPorNumeroProceso(_strMesProduccion, objProceso.PRPIN_NUMERO);
                        if (listaAsientosContable.Count == 0)
                        {
                            PnlProcesoActivo.Visible = true;
                        }
                        else
                        {
                            PnlProcesoValidacion.Visible = true;
                            var objProcesoActivo = _cGenerales.Contabilidad_Validar(_strMesProduccion);
                            var listaValidacionActiva = new List<ocp_contabilidad_validacion>();
                            for (int index = 0; index < objProcesoActivo.Tables[0].Rows.Count; index++)
                            {
                                listaValidacionActiva.Add(new ocp_contabilidad_validacion
                                {
                                    Glosa = objProcesoActivo.Tables[0].Rows[index][0].ToString(),
                                    Descripcion = objProcesoActivo.Tables[0].Rows[index][1].ToString(),
                                    IdProducto = objProcesoActivo.Tables[0].Rows[index][2].ToString(),
                                    Moneda = objProcesoActivo.Tables[0].Rows[index][3].ToString(),
                                    ImporteProduccion = Convert.ToDecimal(objProcesoActivo.Tables[0].Rows[index][4].ToString()),
                                    ImporteAsientos = Convert.ToDecimal(objProcesoActivo.Tables[0].Rows[index][5].ToString())
                                });
                            }
                            CmbFiltroProducto.DataSource = (from l1 in listaValidacionActiva select new ocp_contabilidad_validacion { IdProducto = l1.IdProducto }).GroupBy(g => g.IdProducto).Select(s => s.First()).ToList();
                            CmbFiltroProducto.ValueField = "IdProducto";
                            CmbFiltroProducto.TextField = "IdProducto";
                            CmbFiltroProducto.DataBind();
                            CmbFiltroMoneda.DataSource = (from l1 in listaValidacionActiva select new ocp_contabilidad_validacion { Moneda = l1.Moneda }).GroupBy(g => g.Moneda).Select(s => s.First()).ToList();
                            CmbFiltroMoneda.TextField = "Moneda";
                            CmbFiltroMoneda.ValueField = "Moneda";
                            CmbFiltroMoneda.DataBind();
                            Session["generar_contabilidad__validacion"] = listaValidacionActiva;
                            GrvProcesoActivo.DataBind();
                        }
                        break;
                    default:
                        BpcProcesos.TabPages.FindByName("Activo").Visible = false;
                        break;
                }
                ///procesos completados
                Session.Remove("generar_contabilidad__ProcesosCompletados");
                GrvProcesosCompletados.DataBind();
                ///proceso de cobros
                var listaProductos = _cGenerales.Contabilidad_ObtenerListaProductosPorMes(_strMesProduccion).Where(w => w.TOTAL_PRIMA_COBRADA > 0).ToList();
                var listaProcesosCompletados = _cGenerales.Contabilidad_ObtenerListaProcesosContablesCompletados(_strMesProduccion).Where(w => w.PRPVC_TIPO == "COBROS").ToList();
                foreach (var objProcesoContable in listaProcesosCompletados)
                {
                    if (!string.IsNullOrEmpty(objProcesoContable.PRSVC_PARAMETROS))
                    {
                        var listaParametros = JsonConvert.DeserializeObject<List<ocp_parametro_proceso_contable>>(objProcesoContable.PRSVC_PARAMETROS);
                        foreach (var objParametro in listaParametros)
                            listaProductos.Remove(listaProductos.Find(f => f.ID_PRODUCTO == objParametro.ID_PRODUCTO));
                    }
                }
                Session["generar_contabilidad__listaProductos"] = listaProductos;
                GrvProcesoCobro.DataBind();
                BfabProcesoCobro.Visible = (objProceso == null) ? (listaProductos.Count > 0) : false;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProcesoActivo_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["generar_contabilidad__validacion"] != null)
                {
                    var listaValidacionActiva = (List<ocp_contabilidad_validacion>)Session["generar_contabilidad__validacion"];
                    GrvProcesoActivo.Columns[2].Visible = false;
                    if (HidFiltros.Count > 0)
                        GrvProcesoActivo.Columns[2].Visible = (HidFiltros.Get("PRODUCTO").ToString() == string.Empty) ? false : true;
                    GrvProcesoActivo.DataSource = FiltrosProcesoContable(listaValidacionActiva);
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CbPassword_Callback(object source, DevExpress.Web.CallbackEventArgs e)
        {
            if (_objUsuario == null)
                _objUsuario = (occ_usuario)Session["SessionUsuario"];
            string strIdUsuario = _objUsuario.Matricula;
            string strPasswordUsuario = TxtPassword.Text.Trim();
            e.Result = "false";
            if (_cGenerales.ValidarAutenticacion(strIdUsuario, strPasswordUsuario))
                e.Result = "true";
        }
        protected byte[] AsientosContables(string strMesProduccion, int intNumeroProceso)
        {
            try
            {
                var objArchivoRespuesta = _cGenerales.Documento_AsientosContables(strMesProduccion, intNumeroProceso);
                string strRutaDesencriptada = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(objArchivoRespuesta.Ruta));
                return File.ReadAllBytes(strRutaDesencriptada);
            }
            catch
            {
                throw;
            }
        }
        protected void BtnConfirmacion_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                string strIdGrupo = Session["generar_contabilidad__IdGrupo"].ToString();
                var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["generar_contabilidad__detalleConformidades"];
                var objDetalleConformidad = listaDetalleConformidades.Find(f => f.IdGrupo == strIdGrupo && f.NombreAutorizador.Contains(_objUsuario.Matricula) == true);
                ///guardamos la validacion del proceso
                var listaValidacionActiva = (List<ocp_contabilidad_validacion>)Session["generar_contabilidad__validacion"];
                objProceso.PRPVC_VALIDACION = JsonConvert.SerializeObject(listaValidacionActiva);
                _cGenerales.Contabilidad_ActualizarProcesoContable(objProceso);
                ///registrmos la conformidad
                CONFORMIDAD objConformidad = new CONFORMIDAD()
                {
                    COPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPBI_ID_PROCESO_CONTABLE = objProceso.PRPBI_ID_PROCESO_CONTABLE,
                    COPVC_ID_NIVEL = objDetalleConformidad.IdNivel,
                    COPVC_ID_GRUPO = objDetalleConformidad.IdGrupo,
                    COPVC_USUARIO = _objUsuario.Matricula,
                    COPVC_NOMBRE = _objUsuario.NombreCompleto,
                    COPVC_AREA = objDetalleConformidad.Area,
                    COPVC_PROCESO = objDetalleConformidad.DescripcionNivel + ": " + objDetalleConformidad.DescripcionConformidad,
                    COPVC_ESTADO = "CONFORME",
                    COPVC_OBSERVACION = TxtComentarioConformidad.Text.Trim().ToUpper()
                };
                string strRutaSistemaContable = ObtieneLexicos().Where(w => w.LEPVC_TABLA == "RUTA_SISTEMA" && w.LEPVC_TEMA == "ASIENTOS").First().LEPVC_VALOR;
                if (File.Exists(strRutaSistemaContable + "ASIENTOS.txt"))
                    File.Move(strRutaSistemaContable + "ASIENTOS.txt", strRutaSistemaContable + "ASIENTOS_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".txt");
                File.WriteAllBytes(strRutaSistemaContable + "ASIENTOS.txt", AsientosContables(objProceso.PRPCH_MES_PRODUCCION, objProceso.PRPIN_NUMERO));
                CorreoConformidadRegistrada(strIdGrupo);
                _cGenerales.Conformidad_Registrar(objConformidad);
                PopConformidad.ShowOnPageLoad = false;
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Success', 'Top right', 3000, 'CONFORMIDAD REGISTRADA', 'Se ha completado el proceso y el archivo 'ASIENTOS.txt' ya fue colocado en la ruta del sistema Smart Stream.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnDetalleConformidades_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var objConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                LblInicioProceso.Text = "El proceso de cierre ha iniciado el " + objProceso.PRSDT_FECHA_INSERT.ToString("dd/MM/yyyy HH:mm:ss");
                Session["generar_contabilidad__detalleConformidades"] = objConformidades;
                GrvConformidades.DataBind();
                PopDetalleConformidades.ShowOnPageLoad = true;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvConformidades_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["generar_contabilidad__detalleConformidades"] != null)
                {
                    var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["generar_contabilidad__detalleConformidades"];
                    GrvConformidades.DataSource = listaDetalleConformidades
                        .GroupBy(g => new {
                            g.NumeroNivel,
                            g.IdNivel,
                            g.IdGrupo,
                            g.DescripcionNivel,
                            g.DescripcionConformidad,
                            g.Estado,
                            g.IdUsuario,
                            g.FechaEstado
                        })
                        .Select(s => new occ_detalle_conformidades {
                            NumeroNivel = s.Key.NumeroNivel,
                            IdNivel = s.Key.IdNivel,
                            IdGrupo = s.Key.IdGrupo,
                            DescripcionNivel = s.Key.DescripcionNivel,
                            DescripcionConformidad = s.Key.DescripcionConformidad,
                            Estado = s.Key.Estado,
                            IdUsuario = s.Key.IdUsuario,
                            FechaEstado = s.Key.FechaEstado
                        })
                        .OrderBy(o => o.NumeroNivel)
                        .ThenBy(o => o.IdGrupo)
                        .ToList();
                    GrvConformidades.Columns[8].Visible = false;
                    GrvConformidades.Columns[9].Visible = false;
                    if (_objUsuario == null)
                        _objUsuario = (occ_usuario)Session["SessionUsuario"];
                    if (listaDetalleConformidades.Where(w => w.NombreAutorizador.Contains(_objUsuario.Matricula) == true).Count() > 0)
                    {
                        GrvConformidades.Columns[8].Visible = true;
                        GrvConformidades.Columns[9].Visible = true;
                    }
                    if (!listaDetalleConformidades.Exists(eval => eval.Estado != "CONFORME"))
                    {
                        GrvConformidades.Columns[8].Visible = false;
                        GrvConformidades.Columns[9].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            var objKeyValue = (sender as BootstrapGridView).GetMasterRowKeyValue();
            var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["generar_contabilidad__detalleConformidades"];
            var GrvResponsables = (sender as BootstrapGridView);
            GrvResponsables.DataSource = listaDetalleConformidades
                .Where(w => w.IdGrupo == objKeyValue.ToString())
                .OrderByDescending(o => o.TipoUsuario)
                .ToList();
        }
        protected void BtnResponsable_Init(object sender, EventArgs e)
        {
            BootstrapButton BtnAccionesAutorizador = sender as BootstrapButton;
            var container = BtnAccionesAutorizador.NamingContainer as GridViewDataItemTemplateContainer;
            _objUsuario = (occ_usuario)Session["SessionUsuario"];
            var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["generar_contabilidad__detalleConformidades"];            
            string strIdNivel = DataBinder.Eval(container.DataItem, "IdNivel").ToString();
            string strIdGrupo = DataBinder.Eval(container.DataItem, "IdGrupo").ToString();
            string strEstado = DataBinder.Eval(container.DataItem, "Estado").ToString();
            BtnAccionesAutorizador.ClientSideEvents.Click = "function(s,e){ alert('Esta acción no esta permitida'); e.processOnServer = false; }";
            BtnAccionesAutorizador.ClientVisible = false;
            if (strEstado == "PENDIENTE" || strEstado == "OBSERVADO")
            {
                if (listaDetalleConformidades.Exists(ex => ex.NombreAutorizador.Contains(_objUsuario.Matricula) == true && ex.IdNivel == strIdNivel && ex.IdGrupo == strIdGrupo))
                {
                    BtnAccionesAutorizador.ClientSideEvents.Click = null;
                    BtnAccionesAutorizador.ClientVisible = true;
                }
            }
        }
        protected void BtnCommand_Click(object sender, EventArgs e)
        {
            try
            {
                string strIdGrupo = ((BootstrapButton)sender).CommandArgument;
                string strIdNivel = ((BootstrapButton)sender).CommandName;
                string strIdControl = ((BootstrapButton)sender).ID;
                PopDetalleConformidades.ShowOnPageLoad = false;
                PopConformidad.ShowOnPageLoad = false;
                PopObservacion.ShowOnPageLoad = false;
                switch (strIdControl)
                {
                    case "BtnObservacion":
                        TxtObservacion.Text = null;
                        PopObservacion.ShowOnPageLoad = true;
                        break;
                    case "BtnConformidad":
                        LblUsuarioConfirmacion.Text = _objUsuario.NombreCompleto;
                        TxtPassword.Text = null;
                        PopConformidad.ShowOnPageLoad = true;
                        break;
                }
                Session["generar_contabilidad__IdGrupo"] = strIdGrupo;
                Session["generar_contabilidad__IdNivel"] = strIdNivel;
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnObservar_Click(object sender, EventArgs e)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                string strIdGrupo = Session["generar_contabilidad__IdGrupo"].ToString();
                var listaDetalleConformidades = (List<occ_detalle_conformidades>)Session["generar_contabilidad__detalleConformidades"];
                var objDetalleConformidad = listaDetalleConformidades.Find(f => f.IdGrupo == strIdGrupo && f.NombreAutorizador.Contains(_objUsuario.Matricula) == true);
                CONFORMIDAD objConformidad = new CONFORMIDAD()
                {
                    COPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPBI_ID_PROCESO_CONTABLE = objProceso.PRPBI_ID_PROCESO_CONTABLE,
                    COPVC_ID_NIVEL = objDetalleConformidad.IdNivel,
                    COPVC_ID_GRUPO = objDetalleConformidad.IdGrupo,
                    COPVC_USUARIO = _objUsuario.Matricula,
                    COPVC_NOMBRE = _objUsuario.NombreCompleto,
                    COPVC_AREA = objDetalleConformidad.Area,
                    COPVC_PROCESO = objDetalleConformidad.DescripcionNivel + ": " + objDetalleConformidad.DescripcionConformidad,
                    COPVC_ESTADO = "OBSERVADO",
                    COPVC_OBSERVACION = TxtObservacion.Text.Trim().ToUpper()
                };
                if (_cGenerales.Conformidad_Registrar(objConformidad))
                {
                    CorreoObservacionRegistrada(strIdGrupo);
                    PopObservacion.ShowOnPageLoad = false;
                    ScriptManager.RegisterStartupScript(this, typeof(Page), "002", "ShowToastr('Warning', 'Top right', 3000, 'Observación Registrada!', " +
                        "'Se ha registrado la observación y se ha notificado a las áreas responsables para su revisión.');", true);
                }
                else
                    throw new Exception("No se pudo registrar la conformidad en la BD.");   
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoConformidadRegistrada(string strIdGrupo)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var listaLexico = ObtieneLexicos();
                var listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                string strIdNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().IdNivel;
                string strDescripcionNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionNivel;
                string strDescripcionConformidad = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionConformidad;
                List<string> listaMailTO = new List<string>();
                foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.IdNivel == strIdNivel))
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                    if (objUsuario != null)
                        listaMailTO.Add(objUsuario.USPVC_CORREO);
                }
                var listaMailCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1.Split(';').ToList();
                DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-autorizacion.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                strHtml = strHtml.Replace("#COMENTARIO#", TxtComentarioConformidad.Text.Trim().ToUpper());
                var objCorreo = correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | CONFORMIDAD | " + strDescripcionNivel + " | " + strDescripcionConformidad,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CorreoObservacionRegistrada(string strIdGrupo)
        {
            try
            {
                var objProceso = _cGenerales.Contabilidad_ObtenerProcesoContable(_strMesProduccion);
                var listaLexico = ObtieneLexicos();
                var listaDetalleConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProceso.PRPIN_NUMERO);
                var listaUsuarios = _cGenerales.ObtenerListaUsuariosActivos();
                string strIdNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().IdNivel;
                string strDescripcionNivel = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionNivel;
                string strDescripcionConformidad = listaDetalleConformidades.Where(w => w.IdGrupo == strIdGrupo).First().DescripcionConformidad;
                List<string> listaMailTO = new List<string>();
                var listaCorreoLexicoTO = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_2.Split(';').Distinct().ToList();
                listaMailTO = listaCorreoLexicoTO;
                List<string> listaMailCC = new List<string>();
                foreach (var objAutorizador in listaDetalleConformidades.Where(w => w.IdNivel == strIdNivel))
                {
                    var objUsuario = listaUsuarios.Find(f => f.USPVC_ID_USUARIO == objAutorizador.IdAutorizador);
                    if (objUsuario != null)
                        listaMailCC.Add(objUsuario.USPVC_CORREO);
                }                
                var listaCorreoLexicoCC = listaLexico.Where(w => w.LEPVC_TABLA == "CONFORMIDAD" && w.LEPVC_TEMA == "CORREO" && w.LEPVC_VALOR == strIdNivel).First().LESVC_DESCRIPCION_1.Split(';').Distinct().ToList();
                foreach (var strCorreoLexicoCC in listaCorreoLexicoCC)
                    if (listaCorreoLexicoTO.FirstOrDefault(f => f.Contains(strCorreoLexicoCC)) == null)
                        listaMailCC.Add(strCorreoLexicoCC);
                DateTime dtMesProduccion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture);
                string strHtml = File.ReadAllText(Server.MapPath("~/assets/tpl/email-conformidad-observacion.html"));
                strHtml = strHtml.Replace("#MES_PRODUCCION#", dtMesProduccion.ToString("MMMM", CultureInfo.CreateSpecificCulture("es")).ToUpper() + " " + dtMesProduccion.Year.ToString());
                strHtml = strHtml.Replace("#PROCESO_CONTABLE#", objProceso.PRPVC_TIPO + " - " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION);
                strHtml = strHtml.Replace("#NIVEL#", strDescripcionNivel);
                strHtml = strHtml.Replace("#DESCRIPCION#", strDescripcionConformidad);
                strHtml = strHtml.Replace("#USUARIO#", _objUsuario.Matricula + " - " + _objUsuario.NombreCompleto);
                strHtml = strHtml.Replace("#OBSERVACION#", TxtObservacion.Text.Trim().ToUpper());
                strHtml = strHtml.Replace("#FECHA#", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                var objCorreo = correo.Enviar(new ocp_correo
                {
                    ListaCorreoDestinatario = listaMailTO.Distinct().ToList(),
                    ListaCorreoCopia = listaMailCC.Distinct().ToList(),
                    Asunto = "CRS GENERALES - CIERRE " + objProceso.PRPVC_TIPO + " " + objProceso.PRPIN_NUMERO.ToString() + "/" + objProceso.PRPCH_MES_PRODUCCION + " | OBSERVACIÓN | " + strDescripcionNivel + " | " + strDescripcionConformidad,
                    Prioridad = System.Net.Mail.MailPriority.High,
                    Contenido = strHtml,
                    FlagHtml = true,
                    ListaImagenes = new List<ocp_correo_imagen>() { new ocp_correo_imagen() { ContentId = "logo", Bytes = File.ReadAllBytes(Server.MapPath("~/assets/img/logo-email.png")) } }
                });
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        protected void BtnFiltros_Click(object sender, EventArgs e)
        {
            try
            {
                HidFiltros.Clear();
                switch (((BootstrapButton)sender).CommandName)
                {
                    case "FILTRAR":
                        HidFiltros.Add("PRODUCTO", (CmbFiltroProducto.SelectedItem != null) ? CmbFiltroProducto.SelectedItem.Value.ToString() : string.Empty);
                        HidFiltros.Add("MONEDA", (CmbFiltroMoneda.SelectedItem != null) ? CmbFiltroMoneda.SelectedItem.Value.ToString() : string.Empty);
                        HidFiltros.Add("DIFERENCIA", string.IsNullOrEmpty(TxtFiltroDiferencia.Text) ? "0" : TxtFiltroDiferencia.Text);
                        break;
                    default:
                        CmbFiltroProducto.Value = null;
                        CmbFiltroMoneda.Value = null;
                        TxtFiltroDiferencia.Value = null;
                        break;
                }
                PopFiltros.ShowOnPageLoad = false;
                GrvProcesoActivo.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProcesosCompletados_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["generar_contabilidad__ProcesosCompletados"] == null)
                {
                    var listaProcesosContables = _cGenerales.Contabilidad_ObtenerListaProcesosContablesCompletados(_strMesProduccion);
                    var listaProductos = _cGenerales.Contabilidad_ObtenerListaProductosPorMes(_strMesProduccion);
                    foreach (var objProcesoContable in listaProcesosContables)
                    {
                        if (!string.IsNullOrEmpty(objProcesoContable.PRSVC_PARAMETROS))
                        {
                            string strDetalle = string.Empty;
                            var listaParametros = JsonConvert.DeserializeObject<List<ocp_parametro_proceso_contable>>(objProcesoContable.PRSVC_PARAMETROS);
                            foreach (var objParametro in listaParametros)
                                strDetalle += "<li>" + objParametro.ID_PRODUCTO + " - " + listaProductos.Find(f => f.ID_PRODUCTO == objParametro.ID_PRODUCTO).NOMBRE_COMERCIAL + "</li>";
                            objProcesoContable.PRSVC_PARAMETROS = "<b>Productos seleccionados:</b><br /><br /><ul>" + strDetalle + "</ul>";
                        }
                        else
                        {
                            objProcesoContable.PRSVC_PARAMETROS = "<p class='text-justify'>EN ESTE PROCESO SE EVALUARON TODOS LOS PRODUCTOS Y MOVIMIENTOS DE PRODUCCIÓN QUE NO HAYAN SIDO PROCESADOS EN LOS PROCESOS PARCIALES.<br /><br /><b>NOTA:</b> EN ESTE PROCESO NO SE GENERAN LOS ASIENTOS CONTABLES CORRESPONDIENTES A LOS COBROS.</p>";
                        }
                    }
                    Session["generar_contabilidad__ProcesosCompletados"] = listaProcesosContables;
                }
                GrvProcesosCompletados.DataSource = (List<PROCESO_CONTABLE>)Session["generar_contabilidad__ProcesosCompletados"];   
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected List<ocp_contabilidad_validacion> FiltrosProcesoContable(List<ocp_contabilidad_validacion> listaInicial)
        {
            try
            {
                var listaFiltrada = new List<ocp_contabilidad_validacion>();
                if (HidFiltros.Count > 0)
                {
                    string strFiltroIdProducto = HidFiltros.Get("PRODUCTO").ToString();
                    decimal decFiltroDiferenciaMayor = Convert.ToDecimal(HidFiltros.Get("DIFERENCIA").ToString()), decFiltroDiferenciaMenor = decFiltroDiferenciaMayor * -1m;
                    if (strFiltroIdProducto == string.Empty)
                        listaFiltrada = listaInicial
                            .Where(w => w.Moneda.Contains(HidFiltros.Get("MONEDA").ToString()) == true)
                            .GroupBy(g => new
                            {
                                g.Glosa,
                                g.Descripcion,
                                g.Moneda
                            })
                            .Select(s => new ocp_contabilidad_validacion
                            {
                                Glosa = s.Key.Glosa,
                                Descripcion = s.Key.Descripcion,
                                Moneda = s.Key.Moneda,
                                ImporteProduccion = s.Sum(x1 => x1.ImporteProduccion),
                                ImporteAsientos = s.Sum(x2 => x2.ImporteAsientos)
                            })
                            .ToList();
                    else
                        listaFiltrada = listaInicial
                            .Where(w => w.IdProducto.Contains(strFiltroIdProducto) == true && w.Moneda.Contains(HidFiltros.Get("MONEDA").ToString()) == true)
                            .GroupBy(g => new
                            {
                                g.Glosa,
                                g.Descripcion,
                                g.IdProducto,
                                g.Moneda
                            })
                            .Select(s => new ocp_contabilidad_validacion
                            {
                                Glosa = s.Key.Glosa,
                                Descripcion = s.Key.Descripcion,
                                IdProducto = s.Key.IdProducto,
                                Moneda = s.Key.Moneda,
                                ImporteProduccion = s.Sum(x1 => x1.ImporteProduccion),
                                ImporteAsientos = s.Sum(x2 => x2.ImporteAsientos)
                            })
                            .ToList();
                        foreach (var objAsiento in listaFiltrada)
                            objAsiento.Diferencia = objAsiento.ImporteProduccion - objAsiento.ImporteAsientos;
                        if (decFiltroDiferenciaMayor > 0)
                            return listaFiltrada
                                .Where(w => w.Diferencia > decFiltroDiferenciaMayor || w.Diferencia < decFiltroDiferenciaMenor)
                                .OrderBy(o => o.Glosa)
                                .ThenBy(o => o.Descripcion)
                                .ToList();
                        else
                            return listaFiltrada
                                .OrderBy(o => o.Glosa)
                                .ThenBy(o => o.Descripcion)
                                .ToList();
                }
                else
                    return listaInicial
                        .GroupBy(g => new
                        {
                            g.Glosa,
                            g.Descripcion,
                            g.Moneda
                        })
                        .Select(s => new ocp_contabilidad_validacion
                        {
                            Glosa = s.Key.Glosa,
                            Descripcion = s.Key.Descripcion,
                            Moneda = s.Key.Moneda,
                            ImporteProduccion = s.Sum(x1 => x1.ImporteProduccion),
                            ImporteAsientos = s.Sum(x2 => x2.ImporteAsientos)
                        })
                        .OrderBy(o => o.Glosa)
                        .ThenBy(o => o.Descripcion)
                        .ToList();
            }
            catch
            {
                throw;
            }
        }
        protected void BtnGenerarAsientos_Click(object sender, EventArgs e)
        {
            try
            {
                var listaAsientosContable = _cGenerales.Contabilidad_Generar(_strMesProduccion);
                HidFiltros.Clear();
                CargaInicial();
                ScriptManager.RegisterStartupScript(this, typeof(Page), "DES", "ShowToastr('Success', 'Top right', 3000, 'PROCESO FINALIZADO!', 'Los asientos contables fueron generados con éxito.');", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesoCompletado_Click(object sender, EventArgs e)
        {
            try
            {
                if (HidProcesoCompletado.Contains("IdProceso") && HidProcesoCompletado.Contains("Tipo"))
                {
                    var longIdProcesoContable = Convert.ToInt64(HidProcesoCompletado["IdProceso"].ToString());
                    var strTipo = HidProcesoCompletado["Tipo"].ToString();
                    var listaProcesosContables = (List<PROCESO_CONTABLE>)Session["generar_contabilidad__ProcesosCompletados"];
                    var objProcesoContable = listaProcesosContables.Find(f => f.PRPBI_ID_PROCESO_CONTABLE == longIdProcesoContable);
                    switch (strTipo)
                    {
                        case "Detalle":
                            PopProcesoCompletadoDetalle.HeaderText = "PROCESO CONTABLE: " + objProcesoContable.PRPVC_TIPO + " " + objProcesoContable.PRPIN_NUMERO.ToString() + "/" + objProcesoContable.PRPCH_MES_PRODUCCION;
                            PopProcesoCompletadoDetalle.ShowOnPageLoad = true;
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "PopProcesoCompletadoDetalle.SetContentHtml('" + objProcesoContable.PRSVC_PARAMETROS + "');", true);
                            break;
                        case "Conformidades":
                            var objConformidades = _cGenerales.Conformidad_ObtenerDetalleConformidades(_strMesProduccion, objProcesoContable.PRPIN_NUMERO);
                            LblInicioProceso.Text = "El proceso de cierre ha iniciado el " + objProcesoContable.PRSDT_FECHA_INSERT.ToString("dd/MM/yyyy") + " a las " + objProcesoContable.PRSDT_FECHA_INSERT.ToString("HH:mm:ss");
                            Session["generar_contabilidad__detalleConformidades"] = objConformidades;
                            GrvConformidades.DataBind();
                            PopDetalleConformidades.ShowOnPageLoad = true;
                            break;
                        case "Asientos":
                            Session["DOWNLOAD"] = new ocp_archivo()
                            {
                                ByteArray = AsientosContables(objProcesoContable.PRPCH_MES_PRODUCCION, objProcesoContable.PRPIN_NUMERO),
                                ContentType = "text/plain",
                                Nombre = "ASIENTOS.txt"
                            };
                            ScriptManager.RegisterStartupScript(this, typeof(Page), "__download", "BtnDownload.DoClick();", true);
                            break;
                        case "Validacion":
                            var listaValidacion = JsonConvert.DeserializeObject<List<ocp_contabilidad_validacion>>(objProcesoContable.PRPVC_VALIDACION);
                            Session["generar_contabilidad__ProcesoCompletadoValidacion"] = listaValidacion;
                            GrvProcesoCompletadoValidacion.DataBind();
                            PopProcesoCompletadoValidacion.HeaderText = "PROCESO CONTABLE: " + objProcesoContable.PRPVC_TIPO + " " + objProcesoContable.PRPIN_NUMERO.ToString() + "/" + objProcesoContable.PRPCH_MES_PRODUCCION + " - DIFERENCIAS ENTRE PRODUCCIÓN Y ASIENTOS CONTABLES";
                            PopProcesoCompletadoValidacion.ShowOnPageLoad = true;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProcesoCompletadoValidacion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["generar_contabilidad__ProcesoCompletadoValidacion"] != null)
                {
                    var listaValidacionActiva = (List<ocp_contabilidad_validacion>)Session["generar_contabilidad__ProcesoCompletadoValidacion"];
                    GrvProcesoCompletadoValidacion.Columns[2].Visible = false;
                    GrvProcesoCompletadoValidacion.DataSource = listaValidacionActiva
                        .GroupBy(g => new
                        {
                            g.Glosa,
                            g.Descripcion,
                            g.Moneda
                        })
                        .Select(s => new ocp_contabilidad_validacion
                        {
                            Glosa = s.Key.Glosa,
                            Descripcion = s.Key.Descripcion,
                            Moneda = s.Key.Moneda,
                            ImporteProduccion = s.Sum(x1 => x1.ImporteProduccion),
                            ImporteAsientos = s.Sum(x2 => x2.ImporteAsientos)
                        })
                        .OrderBy(o => o.Glosa)
                        .ThenBy(o => o.Descripcion)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProcesoCobro_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["generar_contabilidad__listaProductos"] != null)
                {
                    var listaProductos = (List<SPR_LISTA_PRODUCTOS_Result>)Session["generar_contabilidad__listaProductos"];                    
                    GrvProcesoCobro.DataSource = listaProductos.OrderBy(o => o.ID_PRODUCTO).ToList();
                    GrvProcesoCobro.Selection.SelectAll();
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void BtnProcesoCobroEjecutar_Click(object sender, EventArgs e)
        {
            try
            {
                var objProcesoContable = new PROCESO_CONTABLE
                {
                    PRPCH_MES_PRODUCCION = _strMesProduccion,
                    PRPIN_NUMERO = 0,
                    PRPVC_TIPO = "COBROS",
                    PRSVC_PARAMETROS = string.Empty,
                    PRPVC_ESTADO = "ACTIVO"
                };
                var listaProductos = (List<SPR_LISTA_PRODUCTOS_Result>)Session["generar_contabilidad__listaProductos"];
                string strParametros = string.Empty;
                var listaProductosSeleccionados = GrvProcesoCobro.GetSelectedFieldValues("ID_PRODUCTO");
                for (int index = 0; index < listaProductosSeleccionados.Count; index++)
                    strParametros += ((index > 0) ? "," : string.Empty) + "{\"ID_PRODUCTO\": \"" + listaProductosSeleccionados[index].ToString() + "\"}";                    
                objProcesoContable.PRSVC_PARAMETROS = "[" + strParametros + "]";
                _cGenerales.Contabilidad_RegistrarProcesoContable(objProcesoContable);
                BtnGenerarAsientos_Click(null, null);
                PopConfirmarProcesoCobro.ShowOnPageLoad = false;
                PopIniciarProcesoCobro.ShowOnPageLoad = false;
                ScriptManager.RegisterStartupScript(this, typeof(Page), "003", "ShowToastr('Success', 'Top right', 3000, 'GENERACIÓN DE ASIENTOS', 'Ya puede generar los asientos contables de cobro para los productos seleccionados.'); BfabProcesoCobro.SetVisible(false);", true);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}