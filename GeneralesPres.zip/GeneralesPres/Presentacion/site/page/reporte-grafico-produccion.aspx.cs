﻿using Agente.ServicioGenerales;
using DevExpress.Export;
using DevExpress.Web.Bootstrap;
using DevExpress.XtraPrinting;
using Newtonsoft.Json;
using Presentacion.controllers;
using Presentacion.entities;
using Presentacion.libs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class reporte_grafico_produccion : SesionUsuario
    {
        private static string _strMesProduccion;
        private readonly CGenerales _cGenerales = new CGenerales();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.ValidaUsuarioYAcceso(HttpContext.Current.Request.CurrentExecutionFilePath))
                this.CierraSesion();
            if (!IsPostBack)
            {
                Session.Remove("DOWNLOAD");
                CargaInicial();
            }
            _strMesProduccion = (string)Session["MES_PRODUCCION"];
        }
        protected void CargaInicial()
        {
            try
            {
                _strMesProduccion = (string)Session["MES_PRODUCCION"];
                int intGestion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                var listaRegistros = _cGenerales.Reporte_GraficaProduccion(_strMesProduccion, "PRODUCCION");
                var listaProduccionActual = listaRegistros.Where(w => w.GESTION == intGestion).ToList();
                var listaProduccionAnterior = listaRegistros.Where(w => w.GESTION == (intGestion - 1)).ToList();
                var listaBaseReporteProduccion = new ocp_base_reporte_produccion()
                {
                    ListaProduccionAnterior = listaProduccionAnterior,
                    ListaProduccionActual = listaProduccionActual
                };
                listaBaseReporteProduccion.GeneraBaseReporteProduccion();
                Session["reporte_grafico_produccion__base_reporte_produccion"] = listaBaseReporteProduccion;
                PgcReporte.ActiveTabIndex = 0;
                IniciarFormularios(0);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void IniciarFormularios(int intIndex)
        {
            try
            {
                var objBaseReporteProduccion = (ocp_base_reporte_produccion)Session["reporte_grafico_produccion__base_reporte_produccion"];
                int intGestion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                switch (intIndex)
                {
                    case 0:
                        Session["reporte_grafico_produccion__DatosProduccion"] = objBaseReporteProduccion.ListaProduccionActual;
                        GrvProduccion.DataBind();
                        break;
                    case 1:
                        var listaProductos = objBaseReporteProduccion.ListaProduccionActual
                           .GroupBy(g => g.ID_PRODUCTO)
                           .Select(s => new SPR_REPORTE_GRAFICOS_PRODUCCION_Result
                           {
                               ID_PRODUCTO = s.First().ID_PRODUCTO,
                               NOMBRE_PRODUCTO = s.First().ID_PRODUCTO + " - " + s.First().NOMBRE_PRODUCTO
                           }).ToList();
                        CmbProductos.DataSource = listaProductos;
                        CmbProductos.ValueField = "ID_PRODUCTO";
                        CmbProductos.TextField = "NOMBRE_PRODUCTO";
                        CmbProductos.DataBind();
                        break;
                }
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }        
        protected void BtnDescargarDatosGrafico_Click(object sender, EventArgs e)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                GrvDatosGrafico.ExportToXlsx(stream, new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });
                Session["DOWNLOAD"] = new ocp_archivo()
                {
                    ByteArray = stream.ToArray(),
                    ContentType = "application/vnd.ms-excel",
                    Nombre = "DatosGrafico.xlsx"
                };
                stream.Close();
            }
            int intGestion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
            IniciarFormularios(1);
            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
        }
        protected void BtnDescargarDatosProduccion_Click(object sender, EventArgs e)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                GrvProduccion.ExportToXlsx(stream, new XlsxExportOptionsEx() { ExportType = ExportType.WYSIWYG });
                Session["DOWNLOAD"] = new ocp_archivo()
                {
                    ByteArray = stream.ToArray(),
                    ContentType = "application/vnd.ms-excel",
                    Nombre = "DatosProduccion.xlsx"
                };
                stream.Close();
            }
            int intGestion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
            IniciarFormularios(0);
            ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.Page), "__download", "BtnDownload.DoClick();", true);
        }
        protected void BtnDownload_Click(object sender, EventArgs e)
        {
            if (Session["DOWNLOAD"] != null)
            {
                var objArchivo = (ocp_archivo)Session["DOWNLOAD"];
                Session.Remove("DOWNLOAD");
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = objArchivo.ContentType;
                Response.AddHeader("content-disposition", "attachment;filename=" + objArchivo.Nombre);
                Response.BinaryWrite(objArchivo.ByteArray);
                Response.Flush();
                Response.End();
            }
        }
        protected void GrvDatosGrafico_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["reporte_grafico_produccion__DatosGrafico"] != null)
                    GrvDatosGrafico.DataSource = (List<ocp_reporte_produccion>)Session["reporte_grafico_produccion__DatosGrafico"];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void GrvProduccion_DataBinding(object sender, EventArgs e)
        {
            try
            {
                if (Session["reporte_grafico_produccion__DatosProduccion"] != null)
                    GrvProduccion.DataSource = (List<SPR_REPORTE_GRAFICOS_PRODUCCION_Result>)Session["reporte_grafico_produccion__DatosProduccion"];
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void PgcReporte_ActiveTabChanged(object source, BootstrapPageControlEventArgs e)
        {
            try
            {
                IniciarFormularios(e.Tab.Index);
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
        protected void CmbProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var objBaseReporteProduccion = (ocp_base_reporte_produccion)Session["reporte_grafico_produccion__base_reporte_produccion"];
                int intGestion = DateTime.ParseExact(_strMesProduccion + "01", "yyyyMMdd", CultureInfo.InvariantCulture).AddMonths(1).Year;
                var listaProducto = objBaseReporteProduccion.DatosProductoReporte(CmbProductos.SelectedItem.Value.ToString());
                ChtProducto.TitleSettings.Text = CmbProductos.SelectedItem.Text.Replace(CmbProductos.SelectedItem.Value.ToString() + " - ", string.Empty);
                ChtProducto.SettingsCommonSeries.ArgumentField = "Mes";
                ChtProducto.SeriesCollection.Clear();
                ChtProducto.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Anterior", Name = "Producción " + (intGestion - 1) });
                ChtProducto.SeriesCollection.Add(new BootstrapChartLineSeries() { ValueField = "Actual", Name = "Producción " + intGestion });
                ChtProducto.DataSource = listaProducto;
                ChtProducto.DataBind();
                GrvDatosGraficoProducto.DataSource = listaProducto;
                GrvDatosGraficoProducto.Columns[1].Caption = "Producción " + (intGestion - 1);
                GrvDatosGraficoProducto.Columns[2].Caption = "Producción " + intGestion;
                GrvDatosGraficoProducto.DataBind();
            }
            catch (Exception ex)
            {
                Master.RegistrarExcepcion(ex, this.GetType().Name, MethodBase.GetCurrentMethod().Name);
            }
        }
    }
}