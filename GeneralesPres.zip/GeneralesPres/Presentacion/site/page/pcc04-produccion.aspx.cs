﻿using Microsoft.Reporting.WebForms;
using Presentacion.controllers;
using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Presentacion.site.page
{
    public partial class pcc04_produccion : System.Web.UI.Page
	{
		private CReserva _oReserva = new CReserva();

		protected void Page_Load(object sender, EventArgs e)
		{
			MsgInfo.Visible = false;
			if (IsPostBack)
			{
				return;
			}
			CumulosPc004();

		}

		private void CumulosPc004()
		{
			try
			{
				var lstCumuloPc004 = _oReserva.GetListCumulosPc004(Presentacion.libs.Parametros.EntornoProduccion);

				grdPc004.DataSource = lstCumuloPc004;
				grdPc004.DataBind();
			}
			catch (Exception e)
			{
				//Log.Error(e);
				lblMensaje.Text = "Algo pasó mientras se obtenian los registros";
				MsgInfo.Visible = true;
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se recopila información"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR EN BUSQUEDA', 'Algo pasó mientras se recopila información.');", true);
			}

		}
		protected void btnCompletar_OnClick(object sender, EventArgs e)
		{
			try
			{
				var btnEditColumn = (Button)sender;
				var Ids = btnEditColumn.CommandArgument.Split('|');

				Session.Add("CUVC_POLIZA", Ids[0]);
				Session.Add("PC004_ID_CUMULO", Ids[1]);
				Response.Redirect("~/site/page/FormularioPC004.aspx");
			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				lblMensaje.Text = "Algo pasó mientras se muestra el fomulario";
				MsgInfo.Visible = true;
				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se recopila información"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'Algo pasó mientras se recopila información.');", true);
			}

		}

		protected void grdPc004_RowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.DataRow)
			{

				var flag = (Label)e.Row.FindControl("lblFlagCompleto");
				var reporte = (Button)e.Row.FindControl("btnDocumento");
				var editar = (Button)e.Row.FindControl("btnEdit");
				var modificar = (Button)e.Row.FindControl("btnModificar");

				if (flag.Text == "1")
				{
					reporte.Visible = true;
					editar.Visible = false;
					modificar.Visible = true;
				}

			}
		}
		//protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
		//{
		//    grdDenuncias.PageIndex = e.NewPageIndex;
		//    this.GetListDenunciaByPage(e.NewPageIndex);
		//}
		protected void btnDocumento_Click(object sender, EventArgs e)
		{
			try
			{
				var btnEditColumn = (Button)sender;
				var IdFormulario = btnEditColumn.CommandArgument;

				var data = _oReserva.GetDataDocumentoFormulario(long.Parse(IdFormulario), Presentacion.libs.Parametros.EntornoProduccion);


				// Variables   
				Warning[] warnings;
				string[] streamIds;
				string mimeType = string.Empty;
				string encoding = string.Empty;
				string extension = string.Empty;

				//// Create Report DataSource
				ReportDataSource rds = new ReportDataSource("PC004", data);

				// Setup the report viewer object and get the array of bytes   
				ReportViewer viewer = new ReportViewer();
				viewer.ProcessingMode = ProcessingMode.Local;
				//viewer.LocalReport.ReportPath = Server.MapPath(@"~/Sitio/Vista/UIF/Reportes/rptFormularioPC004.rdlc");
				viewer.LocalReport.ReportPath = Server.MapPath(@"~/assets/rdlc/rptFormularioPC004.rdlc");
				viewer.LocalReport.DataSources.Add(rds); // Add datasource here
				viewer.LocalReport.EnableExternalImages = true;

				//var strImagenReceptor = new Uri(Server.MapPath(@"~/Sitio/Vista/UIF/Reportes/ARCAINE SAMOLENKO CLAUDIA.png")).AbsoluteUri;
				//var strImagenSupervisor = new Uri(Server.MapPath(@"~/Sitio/Vista/UIF/Reportes/NORIEGA PALENQUE DIEGO.png")).AbsoluteUri;

				var strImagenReceptor = new Uri(Server.MapPath(@"~/assets/img/UIF_PC004/" + data.FirstOrDefault().FUVC_NOMBRE_FUNCIONARIO_RECEPTOR + ".png")).AbsoluteUri;
				var strImagenSupervisor = new Uri(Server.MapPath(@"~/assets/img/UIF_PC004/" + data.FirstOrDefault().FUVC_NOMBRE_SUPERVISOR + ".png")).AbsoluteUri;


				ReportParameter[] Parametros = new ReportParameter[2];
				Parametros[0] = new ReportParameter("IMAGE_RECEPTOR", strImagenReceptor);
				Parametros[1] = new ReportParameter("IMAGE_SUPERVISOR", strImagenSupervisor);
				//ReportParameter parameter = new ReportParameter("ImagePath", imagePath);
				viewer.LocalReport.SetParameters(Parametros);

				byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

				// Now that you have all the bytes representing the PDF report, buffer it and send it to the client.   
				Response.Buffer = true;
				Response.Clear();
				Response.ContentType = mimeType;
				Response.AddHeader("content-disposition", "attachment; filename=Formulario." + extension);
				Response.BinaryWrite(bytes); // create the file   
				Response.Flush(); // send it to the client to download   


			}
			catch (Exception ex)
			{
				//Log.Error(ex);
				lblMensaje.Text = "Algo pasó mientras se creaba el documento";
				MsgInfo.Visible = true;

				//ScriptManager.RegisterStartupScript(this, typeof(Page), "response", CParametrosComplejos.ToastrInfo("Algo pasó mientras se genera el documento"), true);
				ScriptManager.RegisterStartupScript(this, typeof(Page), "001", "ShowToastr('Danger', 'Top right', 3000, 'ERROR', 'Algo pasó mientras se recopila información.');", true);
			}
		}

		protected void btnModificar_Click(object sender, EventArgs e)
		{
			var btnEditColumn = (Button)sender;
			var IdFormulario = btnEditColumn.CommandArgument;
			Session.Add("PC004_ID_FORMULARIO", IdFormulario);
			Response.Redirect("~/site/page/EditarFormularioPC004.aspx");
		}
	}
}