﻿function IniciarSticky() {
    var topSpacing;
    const stickyEl = $('.sticky-element');
    if (Helpers.isNavbarFixed()) { topSpacing = $('.layout-navbar').height() + 7; }
    else { topSpacing = 5; }
    if (stickyEl.length) {
        stickyEl.sticky({
            topSpacing: topSpacing,
            zIndex: 9
        });
    }
}