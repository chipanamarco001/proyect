﻿"use strict";
function ShowToastr(strTipo, strUbicacion, intDelay, strTitle, strMessage) {
    var bg, position;
    let r;
    switch (strTipo) {
        case "Danger": bg = "bg-danger"; break;
        case "Warning": bg = "bg-warning"; break;
        case "Success": bg = "bg-success"; break;
        case "Info": bg = "bg-info"; break;
    }
    switch (strUbicacion) {
        case "Top right": position = "top-0 end-0".split(" "); break;
    }
    var o = document.getElementById("pageToastr");
    o.setAttribute("data-bs-delay", intDelay);
    o.getElementsByClassName("me-auto")[0].innerHTML = strTitle; //message
    o.getElementsByClassName("toast-body")[0].innerHTML = strMessage; //message
    r && c(r);
    o.classList.add(bg, "animate__fadeIn");
    DOMTokenList.prototype.add.apply(o.classList, position);
    (r = new bootstrap.Toast(o)).show();
}
function c(t) {
    t && null !== t._element && (o && (o.classList.remove(a),
        DOMTokenList.prototype.remove.apply(o.classList, i)),
        e && e.classList.remove(a, n),
        t.dispose())
}



function ShowAlert(strTipo, strTitulo, strMensaje) {
    const alertPlaceholder = document.getElementById('pageAlert')
    const wrapper = document.createElement('div')
    wrapper.innerHTML = [
        `<div id="myAlert" class="alert alert-${strTipo} alert-dismissible text-black" role="alert">`,
        `   <h6 class="alert-heading d-flex align-items-center mb-1">${strTitulo}</h6>`,
        `   <p class="mb-0">${strMensaje}</p>`,
        '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
        '</div>'
    ].join('')
    alertPlaceholder.innerHTML = ""
    alertPlaceholder.append(wrapper)
    const alertElement = bootstrap.Alert.getOrCreateInstance('#myAlert')
    var alertTimeout;
    clearTimeout(alertTimeout);
    alertTimeout = setTimeout(function () { alertElement.close() }, 10000);
}