﻿$(function () {
    "use strict";
    var url = window.location + "";
    var path = url.replace(window.location.protocol + "//" + window.location.host + "/", "");
    var element = $('aside#layout-menu a').filter(function () {
        return this.href === url || this.href === path;// || url.href.indexOf(this.href) === 0;
    });
    element.parentsUntil(".menu-inner").each(function (index) {
        if ($(this).is("li") && $(this).children("a").length !== 0) {
            $(this).addClass("active open");
            ///abrimos el menu interno para que se muestre con el menu replegado
            var listaActiva = $(this).find('.menu-sub');
            var objetoActivo = listaActiva.first();
            objetoActivo.addClass("d-block");
        }
    });
});