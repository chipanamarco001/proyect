﻿using Agente.SericioAfiliacionBroker;
using Agente.ServiceSegip;
using Agente.ServicioArchivoProducto;
using Agente.ServicioARegulatorios;
using Agente.ServicioCierre;
using Agente.ServicioDocumentos;
using Agente.ServicioGenerales;
using Agente.ServicioLexico;
using Agente.ServicioSiniestroDenuncia;

namespace Agente
{
    public class Proxy
    {
        public static IServicioGenerales ServicioGenerales()
        {
            IServicioGenerales objServicio = new ServicioGeneralesClient("ServicioGeneralesHttpEndPoint");
            return objServicio;
        }
        public static void Close(IServicioGenerales conexion)
        {
            ((ServicioGeneralesClient)conexion).Close();
        }

		public static IServicioArchivoProducto ServicioArchivoProducto()
		{
			IServicioArchivoProducto objServicio = new ServicioArchivoProductoClient("ServicioArchivoProductoHttpEndPoint");
			return objServicio;
		}
		public static void Close(IServicioArchivoProducto conexion)
		{
			((ServicioArchivoProductoClient)conexion).Close();
		}

		public static IServicioCierre ServicioCierre()
		{
			IServicioCierre objServicio = new ServicioCierreClient("ServicioCierreHttpEndPoint");
			return objServicio;
		}
		public static void Close(IServicioCierre conexion)
		{
			((ServicioCierreClient)conexion).Close();
		}
		public static IServicioSiniestroDenuncia ServiciosSiniestroDenuncia()
		{
			IServicioSiniestroDenuncia objServicio =
				new ServicioSiniestroDenunciaClient("ServicioSiniestroDenunciaHttpEndPoint");
			return objServicio;
		}
		public static void Close(IServicioSiniestroDenuncia conexion)
		{
			((ServicioSiniestroDenunciaClient)conexion).Close();
		}

		public static IServicioLexico ServicioLexico()
		{
			IServicioLexico objServicioLexico = new ServicioLexicoClient("ServicioLexicoHttpEndPoint");
			return objServicioLexico;
		}

		public static void Close(IServicioLexico conexion)
		{
			((ServicioLexicoClient)conexion).Close();
		}

		public static IServicioDocumentos ServicioDocumentos()
		{
			IServicioDocumentos objServicioDocumentos = new ServicioDocumentosClient("ServicioDocumentosHttpEndPoint");
			return objServicioDocumentos;
		}

		public static void Close(IServicioDocumentos conexion)
		{
			((ServicioDocumentosClient)conexion).Close();
		}

        #region Archivos regulatorios

        public static IServicioARegulatorios ServicioARegulatorios()
        {
            IServicioARegulatorios objServicio = new ServicioARegulatoriosClient("ServicioARegulatoriosHttpEndPoint");
            return objServicio;
        }

        public static void Close(IServicioARegulatorios conexion)
        {
            ((ServicioARegulatoriosClient)conexion).Close();
        }

        #endregion
        #region masiva
        public static IServicioAfiliacionBroker SericioAfiliacionBroker()
        {
            IServicioAfiliacionBroker objServicio = new ServicioAfiliacionBrokerClient("ServicioAfiliacionBrokerHttpEndPoint");
            return objServicio;

        }
        public static IServicioExternoInstitucion ServicioSegip()
        {
            IServicioExternoInstitucion objServicio = new ServicioExternoInstitucionClient("httpBasicConfig");
            return objServicio;

        }
        #endregion
    }
}
